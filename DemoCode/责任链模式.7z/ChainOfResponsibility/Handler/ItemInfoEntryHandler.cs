﻿namespace ChainOfResponsibility.Handler
{
    /// <summary>
    /// 商品信息录入处理器
    /// </summary>
    public class ItemInfoEntryHandler : IItemCreateHandler
    {
        public IItemCreateHandler NextHandler { get; protected set; }

        public bool HandleItemCreate(ItemInfo itemInfo)
        {
            itemInfo = itemInfo ?? this.GetItemInfoFromUI();

            return this.NextHandler.HandleItemCreate(itemInfo);
        }

        public void SetNextHandler(IItemCreateHandler handler)
        {
            this.NextHandler = handler;
        }

        //模拟从UI上获取数据
        private ItemInfo GetItemInfoFromUI()
        {
            return new ItemInfo() { };
        }
    }
}