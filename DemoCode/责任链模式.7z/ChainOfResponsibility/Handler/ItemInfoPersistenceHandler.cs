﻿namespace ChainOfResponsibility.Handler
{
    /// <summary>
    /// 商品信息持久化处理者
    /// </summary>
    public class ItemInfoPersistenceHandler : IItemCreateHandler
    {
        public IItemCreateHandler NextHandler { get; protected set; }

        public bool HandleItemCreate(ItemInfo itemInfo)
        {
            //把数据写到数据库中，并且不再调用NextHandler

            return true;
        }

        public void SetNextHandler(IItemCreateHandler handler)
        {
            this.NextHandler = handler;
        }
    }
}