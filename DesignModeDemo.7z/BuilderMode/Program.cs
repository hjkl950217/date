﻿using BuilderMode.Simplify;
using BuilderMode.Standard;
using System;

namespace BuilderMode
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("建议打断点跟代码来查看运行过程");
            //new StandardDemo().ShowDemo();
            new SimplifyDemo().ShowDemo();
        }
    }
}
