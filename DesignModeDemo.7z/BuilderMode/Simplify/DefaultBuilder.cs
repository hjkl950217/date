﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BuilderMode.Simplify
{
    /// <summary>
    /// 默认的item创建器
    /// </summary>
    public class DefaultItemInfoCreator
    {
        private readonly List<ItemInfo> itemInfos = new List<ItemInfo>();

        #region 子方法

        private Action addData = null;
        private Action check = null;
        private Action persistence = null;

        protected virtual DefaultItemInfoCreator AddData(IEnumerable<ItemInfo> itemInfos)
        {
            this.addData = () =>
            {
                this.itemInfos.Clear();
                this.itemInfos.AddRange(itemInfos);
            };

            return this;
        }

        protected virtual DefaultItemInfoCreator Check(Action<ItemInfo> checkAction = null)
        {
            // .. 一些基础检查

            this.check = this.BaseCallAction(checkAction);

            return this;
        }

        protected virtual DefaultItemInfoCreator Persistence(Action<ItemInfo> action = null)
        {
            this.persistence = this.BaseCallAction(action);

            return this;
        }

        protected virtual Action BaseCallAction(Action<ItemInfo> action = null)
        {
            return () =>
            {
                if (this.itemInfos.Any() && action != null)
                {
                    this.itemInfos.ForEach(t => action?.Invoke(t));
                }
            };
        }

        #endregion 子方法

        public virtual bool CreateItems(IEnumerable<ItemInfo> itemInfos)
        {
            void check(ItemInfo item)
            {
                if (string.IsNullOrWhiteSpace(item.Name))
                {
#pragma warning disable S3928
                    throw new System.ArgumentNullException(nameof(ItemInfo.Name));
#pragma warning restore S3928
                }
            }

            this
                .AddData(itemInfos)
                .Check(check)
                .Persistence(t => t.Name?.Trim());

            try
            {
                this.addData?.Invoke();
                this.check?.Invoke();
                this.persistence?.Invoke();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}