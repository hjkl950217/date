﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderMode.Simplify
{
   public class SimplifyDemo
    {
        public void ShowDemo()
        {
            Console.WriteLine("==开始创建商品==");

            DefaultItemInfoCreator creator = new DefaultItemInfoCreator();

            bool createSusess = false;
            while (!createSusess)
            {
                Console.Write("请输入商品名：");
                string itemName = Console.ReadLine();

                var items = new ItemInfo[] { new ItemInfo() { Name = itemName } };
                createSusess = creator.CreateItems(items);
            }

            Console.WriteLine("==商品创建结束==");
            Console.ReadLine();
        }

    }
}
