﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BuilderMode.Standard
{
    /// <summary>
    /// 默认建造者
    /// </summary>
    public class DefaultBuilder : IBuilder
    {
        private readonly List<ItemInfo> itemInfos = new List<ItemInfo>();

        #region 子方法

        private Action addData = null;
        private Action check = null;
        private Action persistence = null;

        public virtual IBuilder AddData(IEnumerable<ItemInfo> itemInfos)
        {
            this.addData = () =>
            {
                this.itemInfos.Clear();
                this.itemInfos.AddRange(itemInfos);
            };

            return this;
        }

        public virtual IBuilder Check(Action<ItemInfo> checkAction = null)
        {
            // .. 一些基础检查

            this.check = this.BaseCallAction(checkAction);

            return this;
        }

        public virtual IBuilder Persistence(Action<ItemInfo> action = null)
        {
            this.persistence = this.BaseCallAction(action);

            //写DB

            return this;
        }

        protected virtual Action BaseCallAction(Action<ItemInfo> action = null)
        {
            return () =>
            {
                if (this.itemInfos.Any() && action != null)
                {
                    this.itemInfos.ForEach(t => action?.Invoke(t));
                }
            };
        }

        #endregion 子方法

        public virtual bool CreateItems(IEnumerable<ItemInfo> itemInfos)
        {
            try
            {
                this.addData?.Invoke();
                this.check?.Invoke();
                this.persistence?.Invoke();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}