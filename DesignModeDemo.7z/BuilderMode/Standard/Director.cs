﻿using System.Collections.Generic;

namespace BuilderMode.Standard
{
    /// <summary>
    /// 指挥者
    /// </summary>
    /// <remarks>
    /// 用来获得实际的建造者(相当于创建建造者的工厂)
    /// </remarks>
    public class Director
    {
        public bool CreateItemByDefault(IEnumerable<ItemInfo> itemInfos)
        {
            IBuilder builder = new DefaultBuilder();

            void check(ItemInfo item)
            {
                if (string.IsNullOrWhiteSpace(item.Name))
                {
#pragma warning disable S3928
                    throw new System.ArgumentNullException(nameof(ItemInfo.Name));
#pragma warning restore S3928
                }
            }

            builder
                .AddData(itemInfos)
                .Check(check)
                .Persistence(t => t.Name?.Trim());

            return builder.CreateItems(itemInfos);
        }

        public IBuilder CreateItemByMapItemInfo(IEnumerable<ItemInfo> itemInfos)
        {
            IBuilder builder = new MapItemInfoBuilder();

            void check(ItemInfo item)
            {
                if (item.Name == null)
                {
#pragma warning disable S3928
                    throw new System.ArgumentNullException(nameof(ItemInfo.Name));
#pragma warning restore S3928
                }
            }

            builder
                .AddData(itemInfos)
                .Check(check)
                .Persistence(t => t.Name?.Trim());

            // return builder.CreateItems(itemInfos);
            //
            //   return build.GetCreateItemsFunc()
        }
    }
}