﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderMode.Standard
{
    /// <summary>
    /// 抽象建造者
    /// </summary>
    public interface IBuilder
    {
        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="itemInfos"></param>
        /// <returns></returns>
        IBuilder AddData(IEnumerable<ItemInfo> itemInfos);

        /// <summary>
        /// 检查
        /// </summary>
        /// <param name="checkAction">附件的检查代码</param>
        /// <returns></returns>
        IBuilder Check(Action<ItemInfo> checkAction =null);

        /// <summary>
        /// 持久化
        /// </summary>
        /// <param name="action">持久化时的附加处理</param>
        /// <returns></returns>
        IBuilder Persistence(Action<ItemInfo> action = null);


        /// <summary>
        /// 创建item
        /// </summary>
        /// <param name="itemInfos"></param>
        /// <returns></returns>
        bool CreateItems(IEnumerable<ItemInfo> itemInfos);

    }

    

}
