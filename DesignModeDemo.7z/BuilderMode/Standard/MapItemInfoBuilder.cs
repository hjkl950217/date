﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderMode.Standard
{
    /// <summary>
    /// 需要映射商品信息的建造者
    /// </summary>
   public class MapItemInfoBuilder : DefaultBuilder
    {
#pragma warning disable S1185
        public override IBuilder AddData(IEnumerable<ItemInfo> itemInfos)
        {
            //在这个类中记录下子公司与分司的关系


            return base.AddData(itemInfos);
        }
#pragma warning restore S1185 

    }
}
