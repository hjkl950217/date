﻿using System;

namespace BuilderMode.Standard
{
    public class StandardDemo
    {
        public void ShowDemo()
        {
            Console.WriteLine("==开始创建商品==");

            Director director = new Director();

            bool createSusess = false;
            while (!createSusess)
            {
                Console.Write("请输入商品名：");
                string itemName = Console.ReadLine();

                var items = new ItemInfo[] { new ItemInfo() { Name = itemName } };
                createSusess = director.CreateItemByDefault(items);
            }

            Console.WriteLine("==商品创建结束==");
            Console.ReadLine();
        }
    }
}