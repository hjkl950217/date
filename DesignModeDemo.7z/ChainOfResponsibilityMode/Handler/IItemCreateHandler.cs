﻿namespace ChainOfResponsibilityMode.Handler
{
    /// <summary>
    /// 商品创建处理者
    /// </summary>
    public interface IItemCreateHandler
    {
        /// <summary>
        /// 下一个处理者
        /// </summary>
        IItemCreateHandler NextHandler { get; }

        /// <summary>
        /// 设置下一个处理者
        /// </summary>
        /// <param name="handler"></param>
        void SetNextHandler(IItemCreateHandler handler);

        /// <summary>
        /// 处理商品创建
        /// </summary>
        /// <param name="itemInfo"></param>
        bool HandleItemCreate(ItemInfo itemInfo);
    }
}