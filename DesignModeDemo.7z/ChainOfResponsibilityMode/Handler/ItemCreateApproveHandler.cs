﻿using System;

namespace ChainOfResponsibilityMode.Handler
{
    /// <summary>
    /// 商品创建审批处理者
    /// </summary>
    public class ItemCreateApproveHandler : IItemCreateHandler
    {
        public IItemCreateHandler NextHandler { get; protected set; }

        public bool HandleItemCreate(ItemInfo itemInfo)
        {
            //做一些检查，比如名字、信息是否匹配等
            //实际中，这些检查是由管理者在UI上审核的，这里只需要接受审核结果即可

            if (string.IsNullOrWhiteSpace(itemInfo.Name))
            {
                Console.WriteLine("商品名不能为空,请重新输入");
                return false;
            }
            else
            {
                return this.NextHandler.HandleItemCreate(itemInfo);
            }
        }

        public void SetNextHandler(IItemCreateHandler handler)
        {
            this.NextHandler = handler;
        }
    }
}