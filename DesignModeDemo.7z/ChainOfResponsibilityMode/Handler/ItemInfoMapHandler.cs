﻿namespace ChainOfResponsibilityMode.Handler
{
    /// <summary>
    /// 商品信息映射处理者
    /// </summary>
    internal class ItemInfoMapHandler : IItemCreateHandler
    {
        public IItemCreateHandler NextHandler { get; protected set; }

        public bool HandleItemCreate(ItemInfo itemInfo)
        {
            //在这个类中记录下子公司与分司的关系

            return this.NextHandler.HandleItemCreate(itemInfo);
        }

        public void SetNextHandler(IItemCreateHandler handler)
        {
            this.NextHandler = handler;
        }
    }
}