﻿namespace ChainOfResponsibilityMode
{
    /// <summary>
    /// 商品创建帮助类
    /// </summary>
    public class ItemCreateHelper
    {
        //编写一个方法，用来排列接口调用
    }
}