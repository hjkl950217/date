﻿namespace ChainOfResponsibilityMode
{
    /// <summary>
    /// 商品信息
    /// </summary>
    public class ItemInfo
    {
        /// <summary>
        /// 商品名
        /// </summary>
        public string Name { get; set; }
    }
}