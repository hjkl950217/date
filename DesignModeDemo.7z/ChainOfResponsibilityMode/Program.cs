﻿using ChainOfResponsibilityMode;
using ChainOfResponsibilityMode.Handler;
using System;

namespace ChainOfResponsibilityMode
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("==开始创建商品==");

            IItemCreateHandler handler1 = new ItemInfoEntryHandler();
            IItemCreateHandler handler2 = new ItemCreateApproveHandler();
            IItemCreateHandler handler3 = new ItemInfoPersistenceHandler();

            IItemCreateHandler newHandler = new ItemInfoMapHandler();//新加代码

            handler1.SetNextHandler(newHandler);//修改代码
            newHandler.SetNextHandler(handler2);//修改代码
            handler2.SetNextHandler(handler3);

            bool createSusess = false;
            while (!createSusess)
            {
                Console.Write("请输入商品名：");
                string itemName = Console.ReadLine();
                createSusess = handler1.HandleItemCreate(new ItemInfo() { Name = itemName });
            }

            Console.WriteLine("==商品创建结束==");
            Console.ReadLine();
        }
    }
}