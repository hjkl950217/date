﻿using ConsoleApplication1;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

//using Microsoft.Office.Interop;

namespace ConsoleApplication1
{
    class Program
    {
        #region 引用和值类型
        //    static void Main( string[ ] args )
        //    {
        //        Console.WriteLine( "1.返回值在try中，int类型" );
        //        Console.WriteLine( Test( ) );

        //        Console.WriteLine( "2.返回值在最后，int类型" );
        //        Console.WriteLine( Test2( ) );

        //        Console.WriteLine( "3.返回值在try中，string类型" );
        //        Console.WriteLine( Test3( ) );

        //        Console.WriteLine( "4.返回值在最后，string类型" );
        //        Console.WriteLine( Test4( ) );


        //        Console.ReadLine( );
        //    }


        //    public static int Test( )
        //    {
        //        int i = 0;
        //        try
        //        {
        //            return i;
        //        }
        //        finally
        //        {
        //            i = 2;
        //        }


        //    }


        //    public static int Test2( )
        //    {
        //        int num = 0;
        //        int num2;


        //        try
        //        {
        //            num2 = num;
        //        }
        //        finally
        //        {
        //            num = 2;
        //        }
        //        return num2;
        //    }



        //    public static string Test3( )
        //    {
        //        string i = "";
        //        try
        //        {
        //            return i;
        //        }
        //        finally
        //        {
        //            i = "有";
        //        }


        //    }


        //    public static string Test4( )
        //    {
        //        string str = "";
        //        string str2;


        //        try
        //        {
        //            str2 = str;
        //        }
        //        finally
        //        {
        //            str = "有";
        //        }
        //        return str2;
        //    }


        #endregion


        static void Main( string[ ] args )
        {



            var obj1 = new Student() { StudentId = 1001 , StudentName = "学员1" , ScoreList = new List<int>( ) { 90 , 80 , 95 } };
            var obj2 = new Student( ) { StudentId = 1002 , StudentName = "学员2" , ScoreList = new List<int>( ) { 60 , 80 , 90 } };
            var obj3 = new Student( ) { StudentId = 1003 , StudentName = "学员3" , ScoreList = new List<int>( ) { 79 , 76 , 89 } };
            var obj4 = new Student( ) { StudentId = 1004 , StudentName = "学员4" , ScoreList = new List<int>( ) { 79 , 76 , 95 } };

            var stulist = new List<Student>( ) { obj1 , obj2 , obj3, obj4 };

            var result = from a in stulist
                         from score in a.ScoreList
                         where score >= 95
                         select a;

            var result2 = stulist
              .SelectMany( t => t.ScoreList , ( b , score ) => { return new { b , score }; } )
              .Where( t => t.score >= 50 )           
              .Select( t => t.b );


            string SS = result.ToString( );


            foreach( var item in result )
            {
                Console.WriteLine(item.StudentName);
            }
            Console.WriteLine("-------");

            foreach( var item in result2 )
            {
                Console.WriteLine( $"{item.StudentName}" );
                // Console.WriteLine( $"{item.b.StudentName}\t{item.score}");
            }


            Console.ReadLine( );

            //性能测试
            Console.WriteLine("性能测试开始");
            Stopwatch sp = new Stopwatch( );
            List<Student> tempList = new List<Student>( );
            for( int i = 0 ; i < 20 * 10000 ; i++ )
            {
                tempList.Add( new Student( ) {
                    StudentId = i ,
                    StudentName = $"学员{i}" ,
                    ScoreList = new List<int>( ) { 90 , 80 , 95 }
                } );
            }

            //第一次运行
            Console.WriteLine( $"总数据量{tempList.Count()}");
            sp.Start( );
            var ret = from a in stulist
                      from score in a.ScoreList
                      where score == 90
                      select a;
            sp.Stop( );


            Console.WriteLine($"第一次用时{sp.Elapsed.Ticks}");
            sp.Restart( );

            //第二次运行
            sp = new Stopwatch( );
            sp.Start( );

           /* var re2 = stulist.FindAll( t =>
                   t.ScoreList.Where( c => c ==80 ).Count( ) > 0
                 );*/

            var re2 = tempList
                .SelectMany( t => t.ScoreList , ( b , score ) => { return new { b , score }; } )
                .Where( t => t.score==90 )
                .Select( t => t.b );

            sp.Stop( );

            
            Console.WriteLine( $"第二次用时{sp.Elapsed.Ticks}" );


        


            Console.ReadLine( );
        }



        sealed class Student
        {
            public int Age { get; set; }
            public int StudentId { get; set; }
            public string StudentName { get; set; }

            public List<int> ScoreList { get; set; }
        }

    }

 
}
