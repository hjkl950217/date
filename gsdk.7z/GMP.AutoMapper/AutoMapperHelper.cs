﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 10:53:59
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using AutoMapper;

namespace GMP.AutoMapper
{
	public static class AutoMapperHelper
	{
		/// <summary>
		/// 扫描程序集批量创建实例，用无参数构造方法
		/// </summary>
		/// <typeparam name="TResult"></typeparam>
		/// <param name="ass"></param>
		/// <returns></returns>
		public static IEnumerable<TResult> GetInstancesByAssembly<TResult>(this Assembly ass)
		{
			return ass.GetTypes()
					.Where(x => typeof(TResult).IsAssignableFrom(x) && x.IsPublic)
					.Select(x => Activator.CreateInstance(x))
					.Cast<TResult>();
		}

		/// <summary>
		/// 供框架和测试使用
		/// </summary>
		/// <param name="assemblies">要注册automapper的程序集</param>
		/// <param name="configure">映射配置委托</param>
		/// <returns>
		/// mapper：映射器<para></para>
		/// config：autoMapper的配置提供器。参考<see cref="IConfigurationProvider"/>
		/// </returns>
		public static (IMapper mapper, IConfigurationProvider config) CrateMapper(
			IEnumerable<Assembly> assemblies = null,
			Action<IMapperConfigurationExpression> configure = null)
		{
			IConfigurationProvider config = new MapperConfiguration(cfg =>
			{
				//配置替换字符，一定要在创建map之前
				//cfg.ReplaceMemberName( "Ä" , "A" );//把源类型属性名中的Ä替换成A

				//添加配置类
				//cfg.AddProfiles(typeof(Program).Assembly.GetInstancesByAssembly<Profile>());
				assemblies
				?.Select(t => { cfg.AddProfiles(t.GetInstancesByAssembly<Profile>()); return t; })
				.ToArray();//这里只是为了遍历执行

				// 映射具有public或internal的get的属性
				cfg.ShouldMapProperty = p =>
					p.GetMethod != null
					&& (p.GetMethod.IsPublic || p.GetMethod.IsAssembly);

				//动态创建缺少的映射规则，使用默认的约定
				//cfg.CreateMissingTypeMaps = true;

				//调用传递的委托进行配置
				configure?.Invoke(cfg);
			});

			config.AssertConfigurationIsValid();//启动自动验证映射规则是否正确

			return (config.CreateMapper(), config);
		}
	}
}