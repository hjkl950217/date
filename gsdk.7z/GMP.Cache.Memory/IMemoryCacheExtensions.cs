﻿using System;
using System.Collections.Concurrent;
using Microsoft.Extensions.Caching.Memory;

namespace GMP.Cache.Memory
{
    public static class IMemoryCacheExtensions
    {
        private static readonly ConcurrentDictionary<string, Action> cacheCallBackDic = new ConcurrentDictionary<string, Action>();

        #region 设置

        public static TItem Set<TItem>(
            this IMemoryCache memoryCache,
            string key,
            TItem value,
            Func<string, TItem> itemFactory,
            Action<MemoryCacheEntryOptions> optionsAction)
        {
            //配置选项
            MemoryCacheEntryOptions entryOptions = new MemoryCacheEntryOptions();
            optionsAction.Invoke(entryOptions);

            //尝试添加回调
            Action callBackAction = () => memoryCache.Set(key, itemFactory(key), entryOptions);
            IMemoryCacheExtensions.cacheCallBackDic
                .AddOrUpdate(
                    key: key,
                    addValue: callBackAction,
                    updateValueFactory: (k, oldValue) => callBackAction);

            //添加一次
            memoryCache.Set(key, value, entryOptions);
            return value;
        }

        public static TItem Set<TItem>(
             this IMemoryCache memoryCache,
             string key,
             TItem item)
        {
            return CacheExtensions.Set(memoryCache, key, item);
        }

        /// <summary>
        ///
        /// </summary>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="memoryCache"></param>
        /// <param name="key"></param>
        /// <param name="item"></param>
        /// <param name="slidingExpiration">滑动过期时间</param>
        /// <returns></returns>
        public static TItem SetSliding<TItem>(
             this IMemoryCache memoryCache,
             string key,
             TItem item,
             TimeSpan slidingExpiration)
        {
            return IMemoryCacheExtensions.Set(
                memoryCache,
                key,
                item,
                k => item,
                opt =>
                {
                    opt.SetSlidingExpiration(slidingExpiration);
                });
        }

        public static TItem SetAbsolute<TItem>(
            this IMemoryCache memoryCache,
            string key,
            TItem value,
            TimeSpan absoluteExpirationRelativeToNow,
            Func<string, TItem> itemFactory)
        {
            return IMemoryCacheExtensions.Set(
                memoryCache,
                key,
                value,
                itemFactory,
                opt =>
                {
                    opt.AbsoluteExpirationRelativeToNow = absoluteExpirationRelativeToNow;
                });
        }

        public static TItem SetSliding<TItem>(
            this IMemoryCache memoryCache,
            string key,
            TItem value,
            TimeSpan slidingExpiration,
            Func<string, TItem> itemFactory)
        {
            return IMemoryCacheExtensions.Set(
                memoryCache,
                key,
                value,
                itemFactory,
                opt =>
                {
                    opt.SlidingExpiration = slidingExpiration;
                });
        }

        #endregion 设置

        #region 获取

        public static TItem Get<TItem>(this IMemoryCache memoryCache, string key)

        {
            bool cacheResult = memoryCache.TryGetValue(key, out TItem item);
            if (cacheResult)
            {
                return item;
            }
            else
            {
                IMemoryCacheExtensions.cacheCallBackDic.TryGetValue(key, out Action refresh);
                refresh?.Invoke();//尝试刷新缓存
                return memoryCache.Get<TItem>(key);
            }
        }

        #endregion 获取
    }
}