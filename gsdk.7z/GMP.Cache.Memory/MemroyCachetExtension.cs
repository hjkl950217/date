﻿using System;
using Microsoft.Extensions.Caching.Memory;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// CacheMemory
    /// </summary>
    public static class MemroyCachetExtension
    {
        /// <summary>
        /// 添加 CacheMemory 服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="setupAction"></param>
        /// <returns></returns>
        public static IServiceCollection AddGmpCacheMemory(
            this IServiceCollection services,
            Action<MemoryCacheOptions> setupAction = null)
        {
            if (setupAction == null)
            {
                services.AddMemoryCache();
            }
            else
            {
                services.AddMemoryCache(setupAction);
            }

            return services;
        }
    }
}