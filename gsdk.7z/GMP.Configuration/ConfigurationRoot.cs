﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:45:21
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Configuration
{
	/// <summary>
	/// The root node for a configuration.
	/// </summary>
	public class ConfigurationRoot : IConfiguration, IDisposable
	{
		private readonly IList<IConfigurationProvider> providers;
		private readonly IList<IDisposable> changeTokens;

		/// <summary>
		/// Initializes a Configuration root with a list of providers.
		/// </summary>
		/// <param name="providers">The <see cref="IConfigurationProvider"/>s for this configuration.</param>
		public ConfigurationRoot(IList<IConfigurationProvider> providers)
		{
			if (providers == null) throw new ArgumentNullException(nameof(providers));

			this.providers = providers;
			this.changeTokens = new List<IDisposable>(providers.Count);
			foreach (IConfigurationProvider provider in providers)
			{
				provider.Load();
			}
		}

		/// <summary>
		/// The <see cref="IConfigurationProvider"/>s for this configuration.
		/// </summary>
		public IEnumerable<IConfigurationProvider> Providers => this.providers;

		/// <summary>
		/// Gets or sets the value corresponding to a configuration key.
		/// </summary>
		/// <param name="key">The configuration key.</param>
		/// <returns>The configuration value.</returns>
		public string this[string key]
		{
			get
			{
				for (int i = this.providers.Count - 1 ; i >= 0 ; i--)
				{
					IConfigurationProvider provider = this.providers[i];

					if (provider.TryGet(key.ToLower(), out string value))
					{
						return value;
					}
				}

				return null;
			}
			set
			{
				if (!this.providers.Any())
				{
					throw new InvalidOperationException("A configuration source is not registered. Please register one before setting a value.");
				}

				foreach (IConfigurationProvider provider in this.providers)
				{
					provider.Set(key.ToLower(), value);
				}
			}
		}

		/// <summary>
		/// Gets the immediate children sub-sections.
		/// </summary>
		/// <returns>The children.</returns>
		public IEnumerable<IConfigurationSection> GetChildren() => this.GetChildren(null);

		/// <summary>
		/// Gets the immediate children sub-sections.
		/// </summary>
		/// <param name="path">Key of a section of which children to retrieve.</param>
		/// <returns>The children.</returns>
		public IEnumerable<IConfigurationSection> GetChildren(string path)
		{
			return this.Providers
				.Aggregate(Enumerable.Empty<string>(),
					(seed, source) => source.GetChildKeys(seed, path))
				.Distinct(StringComparer.OrdinalIgnoreCase)
				.Select(key => this.GetSection(path == null ? key : ConfigurationPath.Combine(path, key)));
		}

		/// <summary>
		/// Gets a configuration sub-section with the specified key.
		/// </summary>
		/// <param name="key">The key of the configuration section.</param>
		/// <returns>The <see cref="IConfigurationSection"/>.</returns>
		/// <remarks>
		///     This method will never return <c>null</c>. If no matching sub-section is found with the specified key,
		///     an empty <see cref="IConfigurationSection"/> will be returned.
		/// </remarks>
		public IConfigurationSection GetSection(string key) => new ConfigurationSection(this, key);

		/// <summary>
		/// Force the configuration values to be reloaded from the underlying sources.
		/// </summary>
		public void Reload()
		{
			foreach (IConfigurationProvider provider in this.providers)
			{
				provider.Load();
			}
		}

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing,
		/// or resetting unmanaged resources.
		/// </summary>
		public void Dispose()
		{
			//Dispose change tokens.
			foreach (IDisposable registration in this.changeTokens)
			{
				registration.Dispose();
			}

			//Dispose providers
			foreach (IConfigurationProvider provider in this.providers)
			{
				(provider as IDisposable)?.Dispose();
			}
		}
	}
}