﻿namespace GMP.Configuration.Env
{
    /// <summary>
    /// 程序环境类型
    /// </summary>
    public enum AppEnvType
    {
        /// <summary>
        /// 本地
        /// </summary>
        Development = 0,

        /// <summary>
        /// 内部开发部署的环境，主要用于开发自测
        /// </summary>
        Develop = 100,

        /// <summary>
        /// 测试环境,主要用于测试与客户测试
        /// </summary>
        Test = 200,

        /// <summary>
        /// 自动化测试环境，主要用于做自动化相关的测试
        /// </summary>
        AutoTest = 210,

        /// <summary>
        /// 性能测试环境，主要用于做性能相关的测试
        /// </summary>
        PerformanceTest = 220,

        /// <summary>
        /// 验证环境,用于产品验收阶段走验证流程
        /// </summary>
        Verification = 300,

        /// <summary>
        /// 正式产品环境
        /// </summary>
        Product = 400,
    }
}