﻿using System.Collections.Generic;

namespace GMP.Configuration.Env
{
    /// <summary>
    /// 代表环境信息
    /// </summary>
    public class EnvInfo
    {
        public EnvInfo()
        {
            this.WebEnvInfo = new WebEnvInfo();
            this.AllEnv = new Dictionary<string, string>();
        }

        /// <summary>
        /// 程序运行时所处的环境
        /// </summary>
        public AppEnvType AppEnvType { get; set; }

        /// <summary>
        /// web项目相关的环境变量
        /// </summary>
        public WebEnvInfo WebEnvInfo { get; set; }

        /// <summary>
        /// 所有环境变量信息
        /// </summary>
        public IReadOnlyDictionary<string, string> AllEnv { get; set; }
    }
}