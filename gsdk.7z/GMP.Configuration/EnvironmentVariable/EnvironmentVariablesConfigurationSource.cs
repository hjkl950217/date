﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:09:17
*
***************************************************************************/

namespace GMP.Configuration.EnvironmentVariable
{
	/// <summary>
	/// Represents environment variables as an <see cref="IConfigurationSource"/>.
	/// </summary>
	public class EnvironmentVariablesConfigurationSource : IConfigurationSource
	{
		/// <summary>
		/// Gets or sets a prefix used to filter environment variables.
		/// </summary>
		public string Prefix { get; set; }

		/// <summary>
		/// Gets or sets the original environment variable delimiter.
		/// </summary>
		public string Delimiter { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether to transform
		/// the delimiter of an environment variable.
		/// </summary>
		public bool ConvertDelimiter { get; set; }

		/// <summary>
		/// Builds the <see cref="EnvironmentVariablesConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>A <see cref="EnvironmentVariablesConfigurationProvider"/></returns>
		public IConfigurationProvider Build(IConfigurationBuilder builder)
			=> new EnvironmentVariablesConfigurationProvider(this);
	}
}