﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 23:25:06
*
***************************************************************************/

using System;
using GMP.Configuration.EnvironmentVariable;

namespace GMP.Configuration
{
	/// <summary>
	/// Extension methods for registering <see cref="EnvironmentVariablesConfigurationProvider"/> with <see cref="IConfigurationBuilder"/>.
	/// </summary>
	public static class EnvironmentVariablesExtensions
	{
		/// <summary>
		/// Adds an <see cref="IConfigurationProvider"/> that reads configuration values from environment variables.
		/// </summary>
		/// <param name="configurationBuilder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddEnvironmentVariables(this IConfigurationBuilder configurationBuilder)
			=> configurationBuilder.AddEnvironmentVariables("", true, "_");

		/// <summary>
		/// Adds an <see cref="IConfigurationProvider"/> that reads configuration values from environment variables
		/// with a specified prefix.
		/// </summary>
		/// <param name="configurationBuilder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="prefix">The prefix that environment variable names must start with. The prefix will be removed from the environment variable names.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddEnvironmentVariables(this IConfigurationBuilder configurationBuilder, string prefix)
			=> configurationBuilder.AddEnvironmentVariables(prefix, true, "_");

		/// <summary>
		/// Adds an <see cref="IConfigurationProvider"/> that reads configuration values from environment variables.
		/// </summary>
		/// <param name="configurationBuilder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="prefix">The prefix that environment variable names must start with. The prefix will be removed from the environment variable names.</param>
		/// <param name="convertDelimiter">Whether the transformation environment variable separator is required.</param>
		/// <param name="delimiter">The delimiter for an environment variable.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddEnvironmentVariables(this IConfigurationBuilder configurationBuilder, string prefix, bool convertDelimiter, string delimiter)
		{
			return configurationBuilder.AddEnvironmentVariables(source =>
			{
				source.Prefix = prefix;
				source.ConvertDelimiter = convertDelimiter;
				source.Delimiter = delimiter;
			});
		}

		/// <summary>
		/// Adds an <see cref="IConfigurationProvider"/> that reads configuration values from environment variables.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="configureSource">Configures the source.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddEnvironmentVariables(this IConfigurationBuilder builder, Action<EnvironmentVariablesConfigurationSource> configureSource)
			=> builder.Add(configureSource);
	}
}