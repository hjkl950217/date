﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:37:31
*
***************************************************************************/

using System;
using System.IO;

namespace GMP.Configuration.File
{
	/// <summary>
	/// Stream based configuration provider
	/// </summary>
	public abstract class StreamConfigurationProvider : ConfigurationProvider
	{
		private bool loaded;

		/// <summary>
		/// Gets the source settings for this provider.
		/// </summary>
		public StreamConfigurationSource Source { get; }

		/// <summary>
		/// Initialize a new instance of the <see cref="StreamConfigurationProvider"/> class.
		/// </summary>
		/// <param name="source">The source.</param>
		public StreamConfigurationProvider(StreamConfigurationSource source)
		{
			this.Source = source ?? throw new ArgumentNullException(nameof(source));
		}

		/// <summary>
		/// Load the configuration data from the stream.
		/// </summary>
		/// <param name="stream">The data stream.</param>
		public abstract void Load(Stream stream);

		/// <summary>
		/// Load the configuration data from the stream. Will throw after the first call.
		/// </summary>
		public override void Load()
		{
			if (this.loaded)
			{
				throw new InvalidOperationException("StreamConfigurationProviders cannot be loaded more than once.");
			}

			this.Load(this.Source.Stream);
			this.loaded = true;
		}
	}
}