﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:33:57
*
***************************************************************************/

namespace GMP.Configuration
{
	/// <summary>
	/// Represents a section of application configuration values.
	/// </summary>
	public interface IConfigurationSection : IConfiguration
	{
		/// <summary>
		/// Gets the key this section occupies in its parent.
		/// </summary>
		string Key { get; }

		/// <summary>
		/// Gets the full path to this section within the <see cref="IConfiguration"/>.
		/// </summary>
		string Path { get; }

		/// <summary>
		/// Gets or sets the section value.
		/// </summary>
		string Value { get; set; }
	}
}