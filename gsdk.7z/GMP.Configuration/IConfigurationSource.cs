﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:21:27
*
***************************************************************************/

namespace GMP.Configuration
{
	/// <summary>
	/// Represents a source of configuration key/values for an application.
	/// </summary>
	public interface IConfigurationSource
	{
		/// <summary>
		/// Builds the <see cref="IConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>An <see cref="IConfigurationProvider"/></returns>
		IConfigurationProvider Build(IConfigurationBuilder builder);
	}
}