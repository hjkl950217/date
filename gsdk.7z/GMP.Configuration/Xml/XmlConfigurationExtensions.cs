﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:51:38
*
***************************************************************************/

using System;
using System.IO;
using GMP.Configuration.Xml;

namespace GMP.Configuration
{
	/// <summary>
	/// Extension methods for adding <see cref="XmlConfigurationProvider"/>.
	/// </summary>
	public static class XmlConfigurationExtensions
	{
		/// <summary>
		/// Adds the XML configuration provider at <paramref name="path"/> to <paramref name="builder"/>.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="path">Path relative to the base path stored in
		/// <see cref="IConfigurationBuilder.Properties"/> of <paramref name="builder"/>.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddXmlFile(this IConfigurationBuilder builder, string path)
			=> AddXmlFile(builder, path, false, false);

		/// <summary>
		/// Adds the XML configuration provider at <paramref name="path"/> to <paramref name="builder"/>.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="path">Path relative to the base path stored in
		/// <see cref="IConfigurationBuilder.Properties"/> of <paramref name="builder"/>.</param>
		/// <param name="optional">Whether the file is optional.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddXmlFile(this IConfigurationBuilder builder, string path, bool optional)
			=> AddXmlFile(builder, path, optional, false);

		/// <summary>
		/// Adds a XML configuration source to <paramref name="builder"/>.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="path">Path relative to the base path stored in
		/// <see cref="IConfigurationBuilder.Properties"/> of <paramref name="builder"/>.</param>
		/// <param name="optional">Whether the file is optional.</param>
		/// <param name="reloadOnChange">Whether the configuration should be reloaded if the file changes.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddXmlFile(this IConfigurationBuilder builder, string path, bool optional, bool reloadOnChange)
		{
			if (builder == null) throw new ArgumentNullException(nameof(builder));
			if (string.IsNullOrEmpty(path)) throw new ArgumentException("File path must be a non-empty string.", nameof(path));

			return builder.AddXmlFile(s =>
			{
				s.Path = path;
				s.Optional = optional;
				s.ReloadOnChange = reloadOnChange;
			});
		}

		/// <summary>
		/// Adds a XML configuration source to <paramref name="builder"/>.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="configureSource">Configures the source.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddXmlFile(this IConfigurationBuilder builder, Action<XmlConfigurationSource> configureSource)
			=> builder.Add(configureSource);

		/// <summary>
		/// Adds a XML configuration source to <paramref name="builder"/>.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/> to add to.</param>
		/// <param name="stream">The <see cref="Stream"/> to read the xml configuration data from.</param>
		/// <returns>The <see cref="IConfigurationBuilder"/>.</returns>
		public static IConfigurationBuilder AddXmlFile(this IConfigurationBuilder builder, Stream stream)
		{
			if (builder == null) throw new ArgumentNullException(nameof(builder));
			return builder.Add<JsonStreamConfigurationSource>(s => s.Stream = stream);
		}
	}
}