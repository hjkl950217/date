﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 1:07:48
*
***************************************************************************/

using GMP.Configuration.File;

namespace GMP.Configuration.Xml
{
	/// <summary>
	/// Represents a XML file as an <see cref="IConfigurationSource"/>.
	/// </summary>
	public class JsonStreamConfigurationSource : StreamConfigurationSource
	{
		/// <summary>
		/// Builds the <see cref="XmlStreamConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>An <see cref="XmlStreamConfigurationProvider"/></returns>
		public override IConfigurationProvider Build(IConfigurationBuilder builder)
			=> new XmlStreamConfigurationProvider(this);
	}
}