﻿namespace System.ComponentModel.DataAnnotations
{
    /// <summary>
    /// 标记枚举值对应的中文描述
    /// </summary>
    [Obsolete("请改为使用系统自带的Description特性")]
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public class KeyDescriptionAttribute : Attribute
    {
        /// <summary>
        /// 枚举字段的名称,加在枚举上面,与枚举的StringName方法配合使用
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 枚举字段的名称,加在枚举上面,与枚举的StringName方法配合使用
        /// </summary>
        /// <param name="name">枚举字段的名称,加在枚举上面,与枚举的StringName方法配合使用</param>
        public KeyDescriptionAttribute(string name)
        {
            this.Name = name;
        }
    }
}