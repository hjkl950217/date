﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2022/8/17 13:16:10
*
***************************************************************************/

using System.ComponentModel;

namespace GMP
{
    public static partial class ErrorCodes
    {
        /// <summary>
        /// Indicates an unknown error.
        /// </summary>
        [Description("未知错误")]
        public const int GLOBAL_UNKNOWN = -1;
        /// <summary>
        /// Indicates an operation failure.
        /// </summary>
        [Description("操作失败")]
        public const int GLOBAL_FAILED = 1;
        /// <summary>
        /// Indicates that the operation needs to continue.
        /// </summary>
        [Description("继续操作")]
        public const int GLOBAL_CONTINUE = 100;

        #region ErrorCodes.2xx Success
        /// <summary>
        /// Indicates that the operation succeeded.
        /// </summary>
        [Description("操作成功")]
        public const int GLOBAL_SUCCESSED = 200;
        /// <summary>
        /// Indicates that a new data is created.
        /// </summary>
        [Description("创建成功")]
        public const int GLOBAL_CREATED = 201;
        /// <summary>
        /// Indicates that the request is being executed.
        /// </summary>
        [Description("正在执行")]
        public const int GLOBAL_EXECUTING = 202;
        /// <summary>
        /// Indicates that no content is returned.
        /// </summary>
        [Description("没有内容")]
        public const int GLOBAL_NO_CONTENT = 204;
        /// <summary>
        /// Indicates that the client data needs to be reset or refreshed.
        /// </summary>
        [Description("重置内容")]
        public const int GLOBAL_RESET_CONTENT = 205;
        /// <summary>
        /// Indicates that part of the request was successfully executed.
        /// </summary>
        [Description("部分内容执行成功")]
        public const int GLOBAL_PARTIAL_CONTENT = 206;
        #endregion

        #region ErrorCodes.3xx
        /// <summary>
        /// Indicates that you need to redirect to a new URI.
        /// </summary>
        [Description("请求需要重定向")]
        public const int GLOBAL_REDIRECT = 301;
        /// <summary>
        /// Indicates that nothing has been changed.
        /// </summary>
        [Description("没有改变任何内容")]
        public const int GLOBAL_UNMODIFIED = 304;
        #endregion

        #region ErrorCodes.4xx Client
        /// <summary>
        /// Indicates an error occurred during a client request.
        /// </summary>
        [Description("客户端错误")]
        public const int REQUEST_FAILED = 400;
        /// <summary>
        /// Indicates that the current operation is unauthorized.
        /// </summary>
        [Description("未授权")]
        public const int REQUEST_UNAUTHORIZED = 401;
        /// <summary>
        /// Indicates that the current user is not logged in.
        /// </summary>
        [Description("未登录")]
        public const int REQUEST_NOT_LOGIN = 402;
        /// <summary>
        /// Indicates that the current request has been rejected, 
        /// usually due to repeated requests.
        /// </summary>
        [Description("请求被拒绝")]
        public const int REQUEST_REFUSED = 403;
        /// <summary>
        /// Indicates that the required content is not found.
        /// </summary>
        [Description("未找到")]
        public const int REQUEST_NOT_FOUND = 404;
        /// <summary>
        /// Indicates that the user token is missing.
        /// </summary>
        [Description("缺失Token")]
        public const int REQUEST_TOEKN_MISSING = 405;
        /// <summary>
        /// Indicates that the user token is invalid or expired.
        /// </summary>
        [Description("Token无效或已过期")]
        public const int REQUEST_TOKEN_EXPIRED = 406;
        /// <summary>
        /// Indicates that the state of the resource has changed.
        /// </summary>
        [Description("资源状态冲突")]
        public const int REQUEST_STATUS_CONFLICT = 409;
        /// <summary>
        /// Indicates that the current resource is unavailable.
        /// </summary>
        [Description("资源不可用")]
        public const int REQUEST_DATA_UNAVAILABLE = 410;
        /// <summary>
        /// Indicates that the required parameters are missing.
        /// </summary>
        [Description("缺少必要参数")]
        public const int REQUEST_PARAMS_MISSING = 411;
        /// <summary>
        /// Indicates that the required request header is missing.
        /// </summary>
        [Description("缺少必要请求头")]
        public const int REQUEST_HEAD_MISSING = 412;
        /// <summary>
        /// Indicates that the requested data is too large.
        /// </summary>
        [Description("请求的数据过大")]
        public const int REQUEST_DATA_OVERRUN = 413;
        /// <summary>
        /// Indicates that the data type mismatch.
        /// </summary>
        [Description("数据类型不匹配")]
        public const int REQUEST_TYPE_MISMATCH = 415;
        /// <summary>
        /// Indicates that the data exceeds the allowed range.
        /// </summary>
        [Description("数据范围不匹配")]
        public const int REQUEST_RANGE_MISMATCH = 416;
        /// <summary>
        /// Indicates that the client is locked.
        /// </summary>
        [Description("用户端已锁定")]
        public const int REQUEST_CLIENT_LOCKED = 423;
        /// <summary>
        /// Indicates an unsafe request.
        /// </summary>
        [Description("不安全的请求")]
        public const int REQUEST_UNSAFE = 425;
        #endregion

        #region ErrorCodes.5xx Server
        /// <summary>
        /// Indicates an internal server error.
        /// </summary>
        [Description("服务端错误")]
        public const int SERVER_ERROR = 500;
        /// <summary>
        /// Indicates that the method is not implemented.
        /// </summary>
        [Description("尚未实现")]
        public const int SERVER_NOT_IMPLEMENTED = 501;
        /// <summary>
        /// Indicates that an error occurred when connecting to the gateway.
        /// </summary>
        [Description("网关错误")]
        public const int SERVER_GATEWAY_ERROR = 502;
        /// <summary>
        /// Indicates that the service is unavailable.
        /// </summary>
        [Description("服务不可用")]
        public const int SERVER_UNAVAILABLE = 503;
        /// <summary>
        /// Indicates that the gateway connection timed out.
        /// </summary>
        [Description("网关超时")]
        public const int SERVER_GATEWAY_TIMEOUT = 504;
        /// <summary>
        /// Indicates that the license has expired.
        /// </summary>
        [Description("License已过期")]
        public const int SERVER_LICENSE_EXPIRED = 505;
        #endregion

        #region ErrorCodes.1xxx File
        /// <summary>
        /// Indicates that the file exists.
        /// </summary>
        [Description("文件已存在")]
        public const int FILE_EXISTS = 1000;
        /// <summary>
        /// Indicates that the file does not exist.
        /// </summary>
        [Description("文件不存在")]
        public const int FILE_NOT_EXISTS = 1001;
        /// <summary>
        /// Indicates that the file name is repeated.
        /// </summary>
        [Description("文件名称重复")]
        public const int FILE_NAME_REPEAT = 1002;
        /// <summary>
        /// Indicates that the file code is repeated.
        /// </summary>
        [Description("文件编号重复")]
        public const int FILE_CODE_REPEAT = 1003;
        /// <summary>
        /// Indicates that the file version exists.
        /// </summary>
        [Description("版本已存在")]
        public const int FILE_VER_EXISTS = 1100;
        /// <summary>
        /// Indicates that the file version does not exist.
        /// </summary>
        [Description("版本不存在")]
        public const int FILE_VER_NOT_EXISTS = 1101;
        #endregion

        #region ErrorCodes.2xxx Folder
        /// <summary>
        /// Indicates that the folder exists.
        /// </summary>
        [Description("文件夹已存在")]
        public const int FOLDER_EXISTS = 2000;
        /// <summary>
        /// Indicates that the folder does not exist.
        /// </summary>
        [Description("文件夹不存在")]
        public const int FOLDER_NOT_EXISTS = 2001;
        /// <summary>
        /// Indicates that the folder name is repeated.
        /// </summary>
        [Description("文件夹名称重复")]
        public const int FOLDER_NAME_REPEAT = 2002;
        #endregion

        #region ErrorCodes.3000~3499 Permissions
        /// <summary>
        /// Indicates that the user does not have permission.
        /// </summary>
        [Description("没有权限")]
        public const int PERM_DENIED = 3000;
        /// <summary>
        /// Indicates that the permission category does not exist.
        /// </summary>
        [Description("权限类别不存在")]
        public const int PERM_CATEGORY_NOT_EXISTS = 3001;
        #endregion

        #region ErrorCodes.3500~3999 Organization
        /// <summary>
        /// Indicates that the organization exists.
        /// </summary>
        [Description("机构已存在")]
        public const int ORG_EXISTS = 3500;
        /// <summary>
        /// Indicates that the organization does not exist.
        /// </summary>
        [Description("机构不存在")]
        public const int ORG_NOT_EXISTS = 3501;
        /// <summary>
        /// Indicates that the organization name is repeated.
        /// </summary>
        [Description("机构名称重复")]
        public const int ORG_NAME_REPEAT = 3502;
        /// <summary>
        /// Indicates that the organization code is repeated.
        /// </summary>
        [Description("机构编号重复")]
        public const int ORG_CODE_REPEAT = 3503;
        /// <summary>
        /// Indicates that the user exists.
        /// </summary>
        [Description("用户已存在")]
        public const int ORG_USER_EXISTS = 3600;
        /// <summary>
        /// Indicates that the user does not exist.
        /// </summary>
        [Description("用户不存在")]
        public const int ORG_USER_NOT_EXISTS = 3601;
        /// <summary>
        /// Indicates that the user is locked.
        /// </summary>
        [Description("用户已锁定")]
        public const int ORG_USER_LOCKED = 3602;
        /// <summary>
        /// Indicates that the user is logged out.
        /// </summary>
        [Description("用户已注销")]
        public const int ORG_USER_LOGOUT = 3603;
        /// <summary>
        /// Indicates that the account is no bound to a third-party system.
        /// </summary>
        [Description("没有绑定其他系统账户")]
        public const int ORG_USER_NO_THIRDPARTY = 3604;
        /// <summary>
        /// Indicates that the department exists.
        /// </summary>
        [Description("部门已存在")]
        public const int ORG_DEPT_EXISTS = 3700;
        /// <summary>
        /// Indicates that the department does not exist.
        /// </summary>
        [Description("部门不存在")]
        public const int ORG_DEPT_NOT_EXISTS = 3701;
        /// <summary>
        /// Indicates that the department name is repeated.
        /// </summary>
        [Description("部门名称重复")]
        public const int ORG_DEPT_NAME_REPEAT = 3702;
        /// <summary>
        /// Indicates that the department code is repeated.
        /// </summary>
        [Description("部门编号重复")]
        public const int ORG_DEPT_CODE_REPEAT = 3703;
        /// <summary>
        /// Indicates that the position exists.
        /// </summary>
        [Description("职位已存在")]
        public const int ORG_POSITION_EXISTS = 3800;
        /// <summary>
        /// Indicates that the position does not exist.
        /// </summary>
        [Description("职位不存在")]
        public const int ORG_POSITION_NOT_EXISTS = 3801;
        /// <summary>
        /// Indicates that the position name is repeated.
        /// </summary>
        [Description("职位名称重复")]
        public const int ORG_POSITION_NAME_REPEAT = 3802;
        /// <summary>
        /// Indicates that the position code is repeated.
        /// </summary>
        [Description("职位编号重复")]
        public const int ORG_POSITION_CODE_REPEAT = 3803;
        /// <summary>
        /// Indicates that the user group exists.
        /// </summary>
        [Description("用户组已存在")]
        public const int ORG_GROUP_EXISTS = 3900;
        /// <summary>
        /// Indicates that the user group does not exist.
        /// </summary>
        [Description("用户组不存在")]
        public const int ORG_GROUP_NOT_EXISTS = 3901;
        /// <summary>
        /// Indicates that the user group name is repeated.
        /// </summary>
        [Description("用户组名称重复")]
        public const int ORG_GROUP_NAME_REPEAT = 3902;
        /// <summary>
        /// Indicates that the user group code is repeated.
        /// </summary>
        [Description("用户组编号重复")]
        public const int ORG_GROUP_CODE_REPEAT = 3903;
        #endregion

        #region ErrorCodes.4000~4299 Process
        /// <summary>
        /// Indicates that the process definition does not exist.
        /// </summary>
        [Description("流程模板不存在")]
        public const int PROC_DEF_NOT_EXISTS = 4000;
        /// <summary>
        /// Indicates that the process instance does not exist.
        /// </summary>
        [Description("流程实例不存在")]
        public const int PROC_INST_NOT_EXISTS = 4100;
        /// <summary>
        /// Indicates that the process task does not exist.
        /// </summary>
        [Description("流程任务不存在")]
        public const int PROC_TASK_NOT_EXISTS = 4200; 
        #endregion
    }
}
