﻿namespace System
{
    /// <summary>
    /// bool扩展类
    /// </summary>
    public static class BoolExtension
    {
        /// <summary>
        /// 转换为数据库中的bit类型
        /// <para>true为1,false为0</para>
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToBit(this bool value)
        {
            return value ? 1 : 0;
        }

        /// <summary>
        /// 转换为数据库中的bit类型
        /// <para>true为1,false为0</para>
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToBit(this bool? value)
        {
            return value.GetValueOrDefault() ? 1 : 0;
        }

        /// <summary>
        /// 转换为数据库中的<see cref="int"/>类型
        /// <para>true为1,false为0</para>
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToInt(this bool value)
        {
            return value.ToBit();
        }

        /// <summary>
        /// 转换为数据库中的<see cref="int"/> 类型
        /// <para>true为1,false为0</para>
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToInt(this bool? value)
        {
            return value.ToBit();
        }
    }
}