﻿namespace System
{
    /// <summary>
    /// Double的扩展
    /// </summary>
    public static class DoubleExtension
    {
        private static readonly double Zero = 0D;

        /// <summary>
        /// 转换成百分比字符串,如 0.05->5.00%<para></para>
        /// 如果<paramref name="value"/>是NaN的话，则返回0的格式化值
        /// </summary>
        /// <param name="value"></param>
        /// <param name="precision">精度位</param>
        /// <returns></returns>
        public static string ToRateString(this double value, int precision = 2)
        {
            value = double.IsNaN(value) ? Zero : value;
            return value.ToString($"P{precision}");
        }

        /// <summary>
        /// 转换成百分比字符串,如 0.05->5.00%<para></para>
        /// 如果<paramref name="value"/>是NaN的话，则返回0的格式化值
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToRateString(this double value)
        {
            value = double.IsNaN(value) ? Zero : value;
            return value.ToString("P2");
        }
    }
}
