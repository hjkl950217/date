﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;

using GMP.Helper;

namespace System
{
    /// <summary>
    /// 枚举扩展
    /// </summary>
    public static class EnumExtension
    {
        #region 公共方法

        /// <summary>
        /// 获取枚举值上的特性，获取不到时返回null
        /// </summary>
        /// <param name="en">枚举值</param>
        /// <param name="attributeType">枚举值上的Attribute类型</param>
        /// <returns></returns>
        public static System.Attribute GetAttribute(
            this Enum en,
            Type attributeType)
        {
            return EnumHelper.GetAttribute<System.Attribute>(attributeType, en);
        }

        /// <summary>
        /// 获取枚举值上的特性，获取不到时返回null
        /// </summary>
        /// <typeparam name="TAttribute">枚举上的Attribute类型</typeparam>
        /// <param name="enumValue">枚举值</param>
        /// <returns></returns>
        public static TAttribute GetAttribute<TAttribute>(this Enum enumValue)
            where TAttribute : System.Attribute
        {
            return EnumHelper.GetAttribute<TAttribute>(enumValue.GetType(), enumValue);
        }

        /// <summary>
        /// 获取枚举值（不是枚举名）对应的字符串类型。<para></para>
        /// 如: AAA.B=1  返回"1"
        /// </summary>
        /// <param name="enumValue">枚举值</param>
        /// <returns>枚举值对应的值类型，字符串表现形式</returns>
        public static string GetValueString(this Enum enumValue)
        {
            return Enum.Format(enumValue.GetType(), enumValue, "D");
        }

        /// <summary>
        /// 获取枚举值对应的值数据
        /// </summary>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        public static TValue GetValue<TValue>(this Enum enumValue)
            where TValue : struct
        {
            try
            {
                return (TValue)Convert.ChangeType(enumValue, typeof(TValue));
            }
            catch (InvalidCastException ex)
            {
                throw new InvalidCastException($"获取枚举值时出错。枚举名:{enumValue.GetType().Name}", ex);
            }
        }

        #endregion 公共方法

        #region 结合业务的方法

        /// <summary>
        /// 获取枚举值对应的中文描述
        /// </summary>
        /// <param name="enumValue">枚举值</param>
        /// <returns>枚举值对应的值类型，字符串表现形式</returns>
        [Obsolete("请改为使用 GetEnumMember")]
        public static string GetKeyDescription(this Enum enumValue)
        {
            return enumValue.GetAttribute<KeyDescriptionAttribute>()?.Name;
        }

        /// <summary>
        /// 获取枚举值对应的描述
        /// </summary>
        /// <param name="enumValue">枚举值</param>
        /// <returns>枚举值对应的值类型，字符串表现形式</returns>
        public static string GetEnumMember(this Enum enumValue)
        {
            return enumValue.GetAttribute<EnumMemberAttribute>()?.Value;
        }

        /// <summary>
        /// 获取枚举类型对应的描述
        /// </summary>
        /// <param name="enumValue">枚举值</param>
        /// <returns>枚举值对应的值类型，字符串表现形式</returns>
        public static string GetTypeDescription(this Enum enumValue)
        {
            DescriptionAttribute attr = EnumHelper.GetEnumData(enumValue.GetType())
                .AttributeList
                ?.FirstOrDefault(t => t.EqualsType(typeof(DescriptionAttribute)))
                as DescriptionAttribute;

            return attr?.Description;
        }

        #endregion 结合业务的方法
    }
}