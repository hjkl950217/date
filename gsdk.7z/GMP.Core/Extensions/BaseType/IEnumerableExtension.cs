﻿using System.Linq;
using System.Linq.Expressions;

namespace System.Collections.Generic
{
    /// <summary>
    /// IEnumerable 扩展类
    /// </summary>
    public static class IEnumerableExtension
    {
        /// <summary>
        /// foreach的方法版
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="action"></param>
        public static void For<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (T item in source)
            {
                action(item);
            }
        }

        #region WhereIf

        public static IEnumerable<TSource> WhereIf<TSource>(
            this IEnumerable<TSource> source,
            Func<bool> isCondition,
            Func<TSource, bool> predicate)
        {
            return isCondition() ? System.Linq.Enumerable.Where(source, predicate) : source;
        }

        public static IEnumerable<TSource> WhereIf<TSource>(
            this IEnumerable<TSource> source,
            bool isCondition,
            Func<TSource, bool> predicate)
        {
            return IEnumerableExtension.WhereIf(source, () => isCondition, predicate);
        }

        public static IQueryable<TSource> WhereIf<TSource>(
            this IQueryable<TSource> source,
            Func<bool> isCondition,
            Expression<Func<TSource, bool>> predicate)
        {
            return isCondition() ? System.Linq.Queryable.Where(source, predicate) : source;
        }

        public static IQueryable<TSource> WhereIf<TSource>(
            this IQueryable<TSource> source,
            bool isCondition,
            Expression<Func<TSource, bool>> predicate)
        {
            return IEnumerableExtension.WhereIf(source, () => isCondition, predicate);
        }

        #endregion WhereIf

        #region SelectIf

        public static IEnumerable<TSource> SelectIf<TSource>(
            this IEnumerable<TSource> source,
             Func<bool> isCondition,
            Func<TSource, TSource> selector)
        {
            return isCondition() ? Enumerable.Select(source, selector) : source;
        }

        public static IEnumerable<TSource> SelectIf<TSource>(
            this IEnumerable<TSource> source,
             bool isCondition,
            Func<TSource, TSource> selector)
        {
            return IEnumerableExtension.SelectIf(source, () => isCondition, selector);
        }

        public static IQueryable<TSource> SelectIf<TSource>(
            this IQueryable<TSource> source,
            Func<bool> isCondition,
            Expression<Func<TSource, TSource>> selector)
        {
            return isCondition() ? Queryable.Select(source, selector) : source;
        }

        public static IQueryable<TSource> SelectIf<TSource>(
            this IQueryable<TSource> source,
            bool isCondition,
            Expression<Func<TSource, TSource>> selector)
        {
            return IEnumerableExtension.SelectIf(source, () => isCondition, selector);
        }

        #endregion SelectIf

        /// <summary>
        /// 将对象集合转换成字符串
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="source"></param>
        /// <param name="valueFunc"></param>
        /// <param name="separator"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static string JoinString<TSource, TValue>(
            this IEnumerable<TSource> source,
            Func<TSource, TValue> valueFunc,
            string separator = ",")
        {
            if (source == null || !source.Any())
            {
                return string.Empty;
            }

            if (valueFunc is null)
            {
                throw new ArgumentNullException(nameof(valueFunc));
            }

            return string.Join(separator, source.Select(valueFunc));
        }
    }
}