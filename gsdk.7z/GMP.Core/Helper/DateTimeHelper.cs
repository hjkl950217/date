﻿using System;
using System.Collections.Concurrent;
using System.Linq;

namespace GMP.Helper
{
    /// <summary>
    /// DateTime 帮助类
    /// </summary>
    public static class DateTimeHelper
    {
        /// <summary>
        /// 获取Unix时间戳,单位为秒（前端默认是s）
        /// </summary>
        /// <param name="isUtc">是否从UTC时间开始计算,传递flase时使用本地时区进行计算</param>
        /// <remarks>从1970-01-01T00:00:00.000Z到现在的时间戳</remarks>
        /// <returns></returns>
        public static long GetUnixTimestamp(bool isUtc = true)
        {
            return DateTimeExtensions.GetUnixTimestamp(DateTimeOffset.Now, isUtc);
        }

        /// <summary>
        /// 获取Unix时间戳,单位为毫秒
        /// </summary>
        /// <param name="isUtc">是否从UTC时间开始计算,传递flase时使用本地时区进行计算</param>
        /// <remarks>从1970-01-01T00:00:00.000Z到现在的时间戳</remarks>
        /// <returns></returns>
        public static long GetMilliUnixTimestamp(bool isUtc = true)
        {
            return DateTimeExtensions.GetMilliUnixTimestamp(DateTimeOffset.Now, isUtc);
        }

        private static readonly ConcurrentDictionary<TimeZoneType, TimeZoneInfo> TimeZoneMap = new ConcurrentDictionary<TimeZoneType, TimeZoneInfo>();

        /// <summary>
        /// 获取时区
        /// </summary>
        /// <param name="timeZoneType"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public static TimeZoneInfo GetTimeZoneInfo(TimeZoneType timeZoneType = TimeZoneType.China)
        {
            if (timeZoneType == TimeZoneType.None)
            {
                throw new NotImplementedException();
            }

            return TimeZoneMap.GetOrAdd(timeZoneType, tzType =>
             {
                 string[] timeZoneIds = new string[2];//只支持windows linux平台

                 switch (tzType)
                 {
                     case TimeZoneType.China:
                         timeZoneIds[0] = "China Standard Time";
                         timeZoneIds[1] = "Asia/Shanghai";
                         break;

                     case TimeZoneType.None:
                     default:
                         throw new NotImplementedException();
                 }

                 TimeZoneInfo timeZoneInfo = TimeZoneInfo.GetSystemTimeZones()
                    .FirstOrDefault(t => timeZoneIds.Contains(t.Id));
                 return timeZoneInfo;
             });
        }
    }
}