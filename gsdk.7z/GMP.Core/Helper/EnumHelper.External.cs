﻿using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Helper.Model;

namespace GMP.Helper
{
    public static partial class EnumHelper
    {
        #region 公共-获取枚举的结构

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TValue">
        /// 枚举对应的值类型.<para></para>
        /// 程序使用：一般为明确写在枚举上的类型，如果没有写，则为int.<para></para>
        /// UI显示：传递string
        /// </typeparam>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        public static IDictionary<string, TValue> GetEnumStruct<TValue>(Type tEnum)
        // where TEnum : struct
        {
            Dictionary<string, TValue> resultList = new Dictionary<string, TValue>();

            //获取枚举结构数据
            EnumValueData[] fieldArray = EnumHelper.GetOrAddEnumCache(tEnum).EnumValueDataList;

            //遍历数据并组合成Dictionary
            foreach (EnumValueData item in fieldArray)
            {
                try
                {
                    TValue value = (TValue)item.BaseValue;
                    resultList.Add(item.Name, value);
                }
                catch (InvalidCastException ex)
                {
                    throw new InvalidCastException(
                        $"获取枚举结构时，枚举值的类型传递错误。枚举名:{item.EnumType.Name}",
                        ex);
                }
            }

            return resultList;
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TEnum">枚举类型</typeparam>
        /// <typeparam name="TValue">
        /// 枚举对应的值类型.<para></para>
        /// 程序使用：一般为明确写在枚举上的类型，如果没有写，则为int.<para></para>
        /// UI显示：传递string
        /// </typeparam>
        /// <returns></returns>
        public static IDictionary<string, TValue> GetEnumStruct<TEnum, TValue>()
        // where TEnum : struct
        {
            return EnumHelper.GetEnumStruct<TValue>(typeof(TEnum));
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        public static IDictionary<string, string> GetEnumStruct(Type tEnum)
        // where TEnum : Enum
        {
            Dictionary<string, string> resultList = new Dictionary<string, string>();

            //获取枚举结构数据
            EnumValueData[] fieldArray = EnumHelper.GetOrAddEnumCache(tEnum).EnumValueDataList;

            //遍历数据并组合成Dictionary
            foreach (EnumValueData item in fieldArray)
            {
                resultList.Add(item.Name, item.BaseValueString);
            }

            return resultList;
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TEnum">枚举类型</typeparam>
        /// <returns></returns>
        public static IDictionary<string, string> GetEnumStruct<TEnum>()
        // where TEnum : Enum
        {
            return EnumHelper.GetEnumStruct(typeof(TEnum));
        }

        /// <summary>
        /// 获取枚举的结构信息
        /// </summary>
        /// <param name="tEnum"></param>
        /// <returns></returns>
        public static IReadOnlyList<EnumValueData> GetEnumInfo(Type tEnum)
        {
            return EnumHelper.GetOrAddEnumCache(tEnum).EnumValueDataList;
        }

        /// <summary>
        /// 获取枚举的结构信息
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <returns></returns>
        public static IReadOnlyList<EnumValueData> GetEnumInfo<TEnum>()
        {
            return EnumHelper.GetEnumInfo(typeof(TEnum));
        }

        /// <summary>
        /// 获取枚举值的结构信息
        /// </summary>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        public static EnumValueData GetEnumValueInfo(
            Enum enumValue)
        {
            EnumData enumData = EnumHelper.GetOrAddEnumCache(enumValue.GetType());

            return enumData.EnumValueDataList.FirstOrDefault(t => t.EnumValue == enumValue);
        }

        #endregion 公共-获取枚举的结构

        #region 公共-获取枚举上的Attribute

        /// <summary>
        ///获取枚举值上的默认第一个特性
        /// </summary>
        /// <typeparam name="TAttribute"></typeparam>
        /// <param name="enumType">枚举的Type数据</param>
        /// <param name="enumValue">枚举值</param>
        /// <returns></returns>
        public static TAttribute GetAttribute<TAttribute>(Type enumType, object enumValue)
            where TAttribute : Attribute
        {
            //获取枚举结构数据
            EnumValueData[] fieldArray = EnumHelper.GetOrAddEnumCache(enumType).EnumValueDataList;

            //获取枚举值上面的特性集合
            Attribute[] attributeArry = fieldArray
                .FirstOrDefault(t => enumValue.Equals(t.EnumValue))
                ?.AttributeList;

            if (attributeArry == null) return null;

            return attributeArry.FirstOrDefault(t => t is TAttribute) as TAttribute;
        }

        /// <summary>
        ///获取枚举值上的默认第一个特性
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <typeparam name="TAttribute"></typeparam>
        /// <returns></returns>
        public static TAttribute GetAttribute<TEnum, TAttribute>(TEnum enumValue)
            where TAttribute : Attribute
        {
            return EnumHelper.GetAttribute<TAttribute>(typeof(TEnum), enumValue);
        }

        #endregion 公共-获取枚举上的Attribute
    }
}
