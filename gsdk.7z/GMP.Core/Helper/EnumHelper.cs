﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using GMP.Helper.Model;

namespace GMP.Helper
{
    /// <summary>
    /// 枚举帮助类
    /// </summary>
    /// <remarks>
    /// 等待重构为有类型缓存的
    /// </remarks>
    public static partial class EnumHelper
    {
        /// <summary>
        /// 枚举结构缓存
        /// </summary>
        private static readonly ConcurrentDictionary<string, EnumData> EnumStructCache = new ConcurrentDictionary<string, EnumData>();

        /// <summary>
        /// 提取枚举的结构
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        public static EnumData GetEnumData(Type tEnum)
        {
            EnumData result = new EnumData();
            Type enumType = tEnum;

            #region 获得枚举的数据

            result.Name = enumType.Name;
            result.EnumType = enumType;
            result.AttributeList = enumType
                .GetCustomAttributes<Attribute>()
                .ToArray();

            #endregion 获得枚举的数据

            #region 获得枚举值的数据

            //获得枚举的字段数据
            FieldInfo[] fields = enumType
                 .GetFields(BindingFlags.Static | BindingFlags.Public);
            List<EnumValueData> tempEnumValueDataList = new List<EnumValueData>();
            foreach (FieldInfo item in fields)
            {
                //解析数据
                object enumValue = item.GetValue(null);
                Type baseType = System.Enum.GetUnderlyingType(enumValue.GetType());
                Attribute[] attributeArry = item
                    .GetCustomAttributes<Attribute>()
                    .ToArray();

                //组合
                EnumValueData tempData = new EnumValueData()
                {
                    Name = item.Name,
                    EnumValue = enumValue,
                    EnumType = enumType,

                    AttributeList = attributeArry,

                    BaseValueType = baseType,
                    BaseValue = Convert.ChangeType(enumValue, baseType),
                    BaseValueString = System.Enum.Format(enumType, enumValue, "D")
                };

#pragma warning disable S125 // Sections of code should not be "commented out"
                //找问题时可以用这个一行一行的
                //EnumData tempData = new EnumData();
                //tempData.Name = item.Name;
                //tempData.EnumValue = enumValue;
                //tempData.EnumType = enumType;
                //tempData.BaseValueType = baseType;
                //tempData.BaseValue = Convert.ChangeType(enumValue , baseType);
                //tempData.BaseValueString = Enum.Format(enumType , enumValue , "D");
#pragma warning restore S125 // Sections of code should not be "commented out"

                //保存
                tempEnumValueDataList.Add(tempData);
            }
            result.EnumValueDataList = tempEnumValueDataList.ToArray();

            #endregion 获得枚举值的数据

            return result;
        }

        /// <summary>
        /// 获取或添加枚举数据。数据源为 (私有)EnumHelper.EnumStructCache
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        private static EnumData GetOrAddEnumCache(Type tEnum)
        {
            EnumData result = EnumHelper.EnumStructCache
                 .GetOrAdd(
                 tEnum.Name,
                 t =>
                 {
                     return GetEnumData(tEnum);
                 });

            return result;
        }
    }
}