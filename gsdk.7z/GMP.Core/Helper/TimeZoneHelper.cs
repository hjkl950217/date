﻿using System;
using System.Linq;

namespace GMP.Helper
{
    public static class TimeZoneHelper
    {
        /// <summary>
        /// 获取中国时区信息
        /// </summary>
        private static TimeZoneInfo ChineseTimeZoneInfo = null;

        /// <summary>
        /// 获取中国时区信息(不同系统的时区ID不一样)
        /// </summary>
        /// <returns></returns>
        public static TimeZoneInfo GetChineseTimeZoneInfo()
        {
            if (TimeZoneHelper.ChineseTimeZoneInfo != null)
            {
                return TimeZoneHelper.ChineseTimeZoneInfo;
            }

            //win10 ‘China Standard Time’
            //linux ‘Asia/Shanghai’

            TimeZoneHelper.ChineseTimeZoneInfo = TimeZoneInfo.GetSystemTimeZones()
                .First(t => t.Id == "China Standard Time" || t.Id == "Asia/Shanghai");

            return TimeZoneHelper.ChineseTimeZoneInfo;
        }
    }
}