﻿using System;

namespace GMP.Helper.Model
{
    public class EnumData
    {
        /// <summary>
        /// 枚举的名字
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 枚举本身的类型数据
        /// </summary>
        public Type EnumType { get; set; }

        /// <summary>
        /// 获取枚举值，上面的特性
        /// </summary>
        public Attribute[] AttributeList { get; set; }

        /// <summary>
        /// 枚举值的数据
        /// </summary>
        public EnumValueData[] EnumValueDataList { get; set; }
    }
}