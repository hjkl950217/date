﻿using System;

namespace GMP.Helper.Model
{
    /// <summary>
    /// 缓存的枚举结构
    /// </summary>
    public class EnumValueData
    {
        /// <summary>
        /// 枚举值的名字，不是枚举名！
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 枚举本身的类型数据
        /// </summary>
        public Type EnumType { get; set; }

        /// <summary>
        /// 枚举值
        /// </summary>
        /// <remarks>因为从反射出来的数据类型是object</remarks>
        public object EnumValue { get; set; }

        /// <summary>
        /// 枚举值对应的基础类型值
        /// </summary>
        public object BaseValue { get; set; }

        /// <summary>
        /// 枚举值对应的基础类型值-string格式
        /// </summary>
        public string BaseValueString { get; set; }

        /// <summary>
        /// 枚举的基础类型数据
        /// </summary>
        public Type BaseValueType { get; set; }

        /// <summary>
        /// 枚举值上面的特性
        /// </summary>
        public Attribute[] AttributeList { get; set; }
    }
}