﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 17:33:50
*
***************************************************************************/

namespace GMP
{
    /// <summary>
    /// 时区类型
    /// </summary>
    public enum TimeZoneType
    {
        /// <summary>
        /// 无（未实现）
        /// </summary>
        None = 0,

        /// <summary>
        /// 中国
        /// </summary>
        China
    }
}