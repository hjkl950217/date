﻿namespace GMP.Db.Abstractions
{
	/// <summary>
	/// db相关常量类
	/// </summary>
	public static class DbBaseConst
	{
		/// <summary>
		///
		/// </summary>
		public static class MySql
		{
			/// <summary>
			/// 连接字符串获取的Key(从环境变量)
			/// </summary>
			public const string ConnectStringKey = "MYSQL_CONN";
		}

		/// <summary>
		///
		/// </summary>
		public static class SqlServer
		{
		}
	}
}