﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:14:26
*
***************************************************************************/

using System;

namespace GMP.Db.Abstractions
{
    /// <summary>
    /// Db帮助类
    /// </summary>
    public static class DbHelper
    {
        ///// <summary>
        ///// 获取连接字符串,如果获取不到会抛出异常
        ///// </summary>
        ///// <param name="dbType"></param>
        ///// <returns></returns>
        //public static string GetConnectString(DbType dbType)
        //{
        //    return dbType switch
        //    {
        //        DbType.MySql => DbHelper.GetEnvValueWithException(DbBaseConst.MySql.ConnectStringKey),
        //        _ => throw new NotImplementedException(),
        //    };
        //}

        public static string GetEnvValueWithException(string envName)
        {
            if (envName == null || envName.Length == 0)
            {
                throw new ArgumentException($"env name not can be null! para:{envName}");
            }

            string envValue = Environment.GetEnvironmentVariable(envName);

            if (envName == null || envName.Length == 0)
            {
                throw new ArgumentException($"value not can be null! para:{envName}");
            }
            return envValue;
        }
    }
}