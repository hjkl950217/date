﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:13:32
*
***************************************************************************/

using System.ComponentModel;

namespace GMP.Db.Abstractions.Enum
{
    /// <summary>
    /// DB类型
    /// </summary>
    [Description("DB类型")]
    public enum DbType
    {
        /// <summary>
        /// MySql
        /// </summary>
        [Description("MySql")]
        MySql,

        /// <summary>
        /// SqlServer
        /// </summary>
        [Description("SqlServer")]
        SqlServer
    }
}