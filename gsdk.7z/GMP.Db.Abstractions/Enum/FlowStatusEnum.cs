﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-26 星期三 16:13:53
*
***************************************************************************/

using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace GMP.Db.Abstractions.Enum
{
    /// <summary>
    /// 流程状态
    /// </summary>
    [Description("流程状态")]
    public enum FlowStatusEnum
    {
        /// <summary>
        /// 默认值
        /// </summary>
        [KeyDescription("默认值")]
        [Description("默认值")]
        Default = 0,

        /// <summary>
        /// 审批中
        /// </summary>
        [KeyDescription("审批中")]
        [Description("审批中")]
        UnderApproval = 20,

        /// <summary>
        /// 已完成
        /// </summary>
        [KeyDescription("已完成")]
        [Description("已完成")]
        Completed = 30,

        /// <summary>
        /// 已终止
        /// </summary>
        [KeyDescription("已终止")]
        [Description("已终止")]
        Termination = 90
    }
}