﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:18:25
*
***************************************************************************/

using System.ComponentModel;

namespace GMP.Db.Abstractions.Enum
{
    /// <summary>
    /// 指数据库中某条数据的有效性,非业务字段
    /// </summary>
    [Description("有效性")]
    public enum Validity
    {
        /// <summary>
        /// 无效
        /// </summary>
        [Description("无效")]
        Invalid = 0,

        /// <summary>
        /// 有效
        /// </summary>
        [Description("有效")]
        Effective = 1,

        /// <summary>
        /// 禁用
        /// </summary>
        [Description("禁用")]
        Disable = 2,
    }
}