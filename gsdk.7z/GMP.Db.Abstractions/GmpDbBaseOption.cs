﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

using System;

namespace GMP.Db.Abstractions
{
    /// <summary>
    /// DB配置基础模型
    /// </summary>
    public abstract class GmpDbBaseOption
    {
        #region 软删除

        /// <summary>
        ///  是否软删除
        /// </summary>
        public bool IsSoftDelete { get; private set; }

        /// <summary>
        /// 启用软删除
        /// </summary>
        /// <returns></returns>
        public GmpDbBaseOption EnableFilterSoftDelete()
        {
            this.IsSoftDelete = true;
            return this;
        }

        /// <summary>
        /// 禁用软删除
        /// </summary>
        /// <returns></returns>
        public GmpDbBaseOption DisableFilterSoftDelete()
        {
            this.IsSoftDelete = false;
            return this;
        }

        #endregion 软删除

        #region 控制台日志

        private bool isConsoleLog;

        /// <summary>
        /// 是否记录控制台日志
        /// </summary>
        public bool IsConsoleLog
        {
            get => this.isConsoleLog;
            private set { this.IsLog = value; this.isConsoleLog = value; }
        }

        /// <summary>
        ///是否记录日志
        /// </summary>
        public bool IsLog { get; private set; }

        /// <summary>
        /// 启用控制台日志
        /// </summary>
        /// <returns></returns>
        public GmpDbBaseOption EnableConsoleLog()
        {
            this.IsLog = true;
            this.IsConsoleLog = true;
            return this;
        }

        /// <summary>
        /// 禁用控制台日志
        /// </summary>
        /// <returns></returns>
        public GmpDbBaseOption DisableConsoleLog()
        {
            this.IsLog = false;
            this.IsConsoleLog = false;
            return this;
        }

        #endregion 控制台日志

        #region 连接字符串

        /// <summary>
        /// 连接字符串
        /// </summary>
        public string ConnectString { get; private set; }

        /// <summary>
        /// 配置连接字符串
        /// </summary>
        /// <param name="connStr"></param>
        /// <returns></returns>
        public virtual GmpDbBaseOption ConfigConnectString(string connStr)
        {
            if (string.IsNullOrEmpty(connStr))
            {
                throw new ArgumentNullException(nameof(connStr));
            }

            this.ConnectString = connStr;
            return this;
        }

        #region 检查

        /// <summary>
        /// 检查连接字符串是否配置正确
        /// </summary>
        /// <returns></returns>
        public bool CheckConnectString(out string errorMsg)
        {
            errorMsg = string.Empty;
            return this.CheckConnectStrEmpty(ref errorMsg);//以后有其它检查继续添加
        }

        /// <summary>
        /// 检查连接字符串是否为空,检查通过时返回true,否则返回false
        /// </summary>
        /// <param name="errorMsg"></param>
        /// <returns>检查通过时返回true,否则返回false</returns>
        protected virtual bool CheckConnectStrEmpty(ref string errorMsg)
        {
            if (string.IsNullOrWhiteSpace(this.ConnectString))
            {
                errorMsg = "未配置数据库连接字符串";
                return false;
            }
            else
            {
                return true;
            }
        }

        #endregion 检查

        #endregion 连接字符串

        /// <summary>
        /// 浅拷贝(this为空时报错)
        /// </summary>
        /// <returns></returns>
        public virtual GmpDbBaseOption Clone()
        {
            if (this == null)
            {
                throw new ArgumentNullException(" object is null in clone!");
            }

            return this.MemberwiseClone() as GmpDbBaseOption;
        }
    }
}