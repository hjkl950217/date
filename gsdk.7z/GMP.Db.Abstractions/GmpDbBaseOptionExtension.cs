﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-29 星期二 10:05:02
*
***************************************************************************/

using System;
using GMP.Configuration;
using GMP.Configuration.Env;
using GMP.Db.Abstractions.Const;

namespace GMP.Db.Abstractions
{
    public static class GmpDbBaseOptionExtension
    {
        /// <summary>
        /// 配置连接字符串从环境变量中获取
        /// </summary>
        /// <param name="gmpDbBaseOption"></param>
        /// <param name="envName"></param>
        /// <returns></returns>
        public static GmpDbBaseOption ConfigConnectStringFromEnv(
            this GmpDbBaseOption gmpDbBaseOption,
            string envName)
        {
            if (gmpDbBaseOption == null)
            {
                throw new ArgumentNullException(nameof(gmpDbBaseOption));
            }

            if (envName == null || envName.Length == 0)
            {
                throw new ArgumentException($"env name not can be null!", nameof(envName));
            }

            string envValue = Environment.GetEnvironmentVariable(envName);
            if (envValue == null || envValue.Length == 0)
            {
                throw new ArgumentException($"value not can be null!", nameof(envValue));
            }

            gmpDbBaseOption.ConfigConnectString(envValue);

            return gmpDbBaseOption;
        }

        /// <summary>
        /// [连接字符串加密过]配置连接字符串从环境变量中获取
        /// </summary>
        /// <param name="gmpDbBaseOption"></param>
        /// <param name="envName">环境变量名</param>
        /// <param name="encryptionKey">加密秘钥</param>
        /// <returns></returns>
        public static GmpDbBaseOption ConfigConnectStringFromEnvWithEncryption(
            this GmpDbBaseOption gmpDbBaseOption,
            string envName = DbBaseConst.MySql.ConnectStringKey,
            string encryptionKey = EncryptionConst.Defualt_Key_DES)
        {
            if (gmpDbBaseOption == null)
            {
                throw new ArgumentNullException(nameof(gmpDbBaseOption));
            }

            if (envName == null || envName.Length == 0)
            {
                throw new ArgumentException($"env name not can be null!", nameof(envName));
            }

            if (encryptionKey == null || encryptionKey.Length == 0)
            {
                throw new ArgumentException($"encryption Key not can be null!", nameof(encryptionKey));
            }

            GmpDbBaseOption tempOpt = GmpDbBaseOptionExtension.ConfigConnectStringFromEnv(gmpDbBaseOption, envName);
            string newConnStr = ConfigurationDecrypt.Decrypt(tempOpt.ConnectString);
            gmpDbBaseOption.ConfigConnectString(newConnStr);

            return gmpDbBaseOption;
        }

        /// <summary>
        /// 按环境启用控制台日志
        /// </summary>
        /// <param name="gmpDbBaseOption"></param>
        /// <param name="maxEnv"></param>
        /// <returns></returns>
        public static GmpDbBaseOption EnableConsoleLogByEnv(
            this GmpDbBaseOption gmpDbBaseOption,
            AppEnvType maxEnv = AppEnvType.Test)
        {
            if (EnvHelper.EnvInfo.AppEnvType > maxEnv)
            {
                gmpDbBaseOption.DisableConsoleLog();
            }
            else
            {
                gmpDbBaseOption.EnableConsoleLog();
            }

            return gmpDbBaseOption;
        }
    }
}