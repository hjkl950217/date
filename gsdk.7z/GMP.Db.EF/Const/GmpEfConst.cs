﻿namespace GMP.Db.EF.Const
{
    /// <summary>
    ///
    /// </summary>
    public static class GmpEfConst
    {
        /// <summary>
        /// 是否启用ef日志
        /// </summary>
        public const string Env_Enable_EfLog = "EF_LOG_ENABLE";
    }
}
