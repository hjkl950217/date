﻿using System;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace GMP.Db.EF.Converts
{
    /// <summary>
    /// 默认的自定义属性转换器
    /// </summary>
    /// <typeparam name="TSourceType"></typeparam>
    /// <typeparam name="TTargetType"></typeparam>
    public class DefaultCustomPropertyConvert<TSourceType, TTargetType> : ValueConverter<TSourceType, TTargetType>
    {
        private readonly Type propertyClrType;

        /// <summary>
        /// 初始化<see cref="DefaultCustomPropertyConvert{TSourceType, TTargetType}"/>
        /// </summary>
        /// <param name="propertyClrType">属性的运行时类型</param>
        /// <param name="sourceToTarget">源类型 -> 存Db前的类型 如:xxEnum.A=1 -> "1"</param>
        /// <param name="targetToSource">读取DB后转换成的类型 -> 源类型 如: "1" -> xxEnum.A </param>
        public DefaultCustomPropertyConvert(
            Type propertyClrType,
            Expression<Func<TSourceType, TTargetType>> sourceToTarget,
            Expression<Func<TTargetType, TSourceType>> targetToSource)
            : base(
                sourceToTarget,
                targetToSource)
        {
            this.propertyClrType = propertyClrType;
        }

        public override Type ModelClrType => this.propertyClrType;
    }
}