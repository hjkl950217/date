﻿using System;
using System.Linq.Expressions;

namespace GMP.Db.EF.Converts
{
    /// <summary>
    /// 枚举转换为值的字符串形式的转换器
    /// </summary>
    public class EnumToValueStringConvert : DefaultCustomPropertyConvert<object, string>
    {
        public EnumToValueStringConvert(Type enumType)
            : base(
                 enumType,
                 GetSourceToTarget(enumType),
                 v => Enum.Parse(enumType, v.ToString()))
        {
        }

        public static Expression<Func<object, string>> GetSourceToTarget(Type enumType)
        {
            /*
             * 空值
             *      值类型 创建默认值 然后 尝试转换为对应枚举值
             *      非值类型 返回空字符串
             * 非空值 尝试转换为对应枚举值
             *
             */

            return v => v == null
            ? (v.GetType().IsValueType
                ? Enum.Format(enumType, Activator.CreateInstance(enumType), "D")
                : string.Empty)
            : Enum.Format(enumType, v, "D");
        }
    }
}