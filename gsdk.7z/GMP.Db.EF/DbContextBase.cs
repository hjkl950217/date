﻿using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GMP.Db.EF
{
    /// <summary>
    /// GMP DbContext 基本类
    /// </summary>
    public abstract class DbContextBase<TDbContext> : DbContext
        where TDbContext : DbContextBase<TDbContext>
    {
        protected DbContextBase()
        {
        }

        protected DbContextBase(DbContextOptions<TDbContext> options) : base(options)
        {
        }

        protected GmpDbEFOption GmpDbEFOption { get; private set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            GmpDbEFOptionsExtension optExt = optionsBuilder.Options.FindExtension<GmpDbEFOptionsExtension>();
            this.GmpDbEFOption = optExt?.GmpDbEFOption;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            if (this.GmpDbEFOption == null)
            {
                return;
            }

            //针对实体的设置
            foreach (IMutableEntityType entityType in modelBuilder.Model.GetEntityTypes())
            {
                #region 针对实体的设置

                //数据有效性过滤器
                if (this.GmpDbEFOption.IsSoftDelete)
                {
                    entityType.AddValidityFilter();
                }

                #endregion 针对实体的设置

                #region 针对属性的设置

                foreach (IMutableProperty property in entityType.GetProperties())
                {
                    //属性转换器
                    if (this.GmpDbEFOption.CustomValueConverters != null
                        && this.GmpDbEFOption.CustomValueConverters.Any())
                    {
                        property.AddCustomPropConvert(this.GmpDbEFOption);
                    }
                }

                #endregion 针对属性的设置
            }
        }
    }
}