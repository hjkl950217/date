﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace GMP.Db.EF
{
    public static class DbContextOptionsBuilderExtensions
    {
        public static TExtension GetOrCreateExtension<TExtension>(
            this DbContextOptionsBuilder optionsBuilder)
            where TExtension : class, IDbContextOptionsExtension, new()
        {
            return optionsBuilder.Options.FindExtension<TExtension>() ?? new TExtension();
        }
    }
}