﻿using GMP.Db.Abstractions;
using GMP.Db.EF;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Ef上下文建造者
    /// </summary>
    public class EFDbContextBuilder : DbContextBuilder<GmpDbEFOption>
    {
        /// <summary>
        /// 初始化<see cref="EFDbContextBuilder"/>
        /// </summary>
        /// <param name="gmpEFOption"></param>
        /// <param name="services"></param>
        public EFDbContextBuilder(
            GmpDbEFOption gmpEFOption,
            IServiceCollection services) : base(gmpEFOption, services)
        {
        }
    }
}