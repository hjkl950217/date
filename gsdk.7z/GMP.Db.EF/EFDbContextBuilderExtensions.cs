﻿using System;
using GMP.Db.Abstractions;
using GMP.Db.Abstractions.Enum;
using GMP.Db.EF;
using GMP.Db.EF.EFLogger;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Logging;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// <see cref="EFDbContextBuilder"/>扩展
    /// </summary>
    public static class EFDbContextBuilderExtensions
    {
        private static ILoggerFactory internalLoggerFactory;
        private static ILoggerProvider internalLoggerProvider;
        private static readonly object lockObj = new object();

        private static ILoggerFactory GetLoggerFactory(GmpDbEFOption gmpDbEFOption)
        {
            if (internalLoggerFactory != null)
            {
                return internalLoggerFactory;
            }

            lock (EFDbContextBuilderExtensions.lockObj)
            {
                internalLoggerProvider = new EFLoggerProvider(isEnableLog: gmpDbEFOption.IsConsoleLog);
                internalLoggerFactory = new LoggerFactory();
                internalLoggerFactory.AddProvider(internalLoggerProvider);
                return internalLoggerFactory;
            }

            /*
             * 如果出现：More than twenty 'IServiceProvider' instances have been created for internal use by Entity Framework.
             * 参考 http://t.zoukankan.com/jiangyunfeng-p-12572529.html
             *
             * 为了解决这个问题，可以用静态 LoggerFactory，也可以用内部DI。但为了扩展性，以后要改成用内部DI的方式。
             *
             * ServiceProviderCache.Instance
             *  optionsBuilder.UseApplicationServiceProvider(internalServiceProvider);
             *
             */
        }

        /// <summary>
        /// 添加mysql支持
        /// </summary>
        /// <typeparam name="TContext"></typeparam>
        /// <param name="dbContextBuilder"></param>
        /// <param name="configAction"></param>
        /// <param name="mySqlOptionsAction"></param>
        /// <returns></returns>
        public static EFDbContextBuilder AddMySql<TContext>(
            this EFDbContextBuilder dbContextBuilder,
            Action<GmpDbEFOption> configAction = null,
            Action<MySqlDbContextOptionsBuilder> mySqlOptionsAction = null)
            where TContext : DbContextBase<TContext>
        {
            //准备配置
            GmpDbEFOption configObj = dbContextBuilder.CloneOption();
            configObj.DbType = DbType.MySql;
            configObj.EnableLogByEnv();//应用一次按环境变量启用日志
            configAction?.Invoke(configObj);

            //连接字符串检查
            if (!configObj.CheckConnectString(out _))
            {
                configObj.ConfigConnectStringFromEnvWithEncryption();
            }
            if (!configObj.CheckConnectString(out string errorMsg))
            {
                throw new Exception(errorMsg);
            }

            //进行配置
            dbContextBuilder.Services.AddDbContextPool<TContext>(
                optionsBuilder =>
                {
                    optionsBuilder.UseMySql(configObj.ConnectString, mySqlOptionsAction);

                    //注册配置的扩展实例
                    GmpDbEFOptionsExtension optExt = optionsBuilder.GetOrCreateExtension<GmpDbEFOptionsExtension>();
                    optExt.GmpDbEFOption = configObj;
                    ((IDbContextOptionsBuilderInfrastructure)optionsBuilder).AddOrUpdateExtension(optExt);

                    //配置日志
                    if (configObj.IsLog)
                    {
                        ILoggerFactory loggerFactory = GetLoggerFactory(configObj);
                        optionsBuilder.UseLoggerFactory(loggerFactory);
                    }

                    //配置日志中记录数据值
                    if (configObj.IsLog && configObj.EnableSensitiveDataLogging)
                    {
                        optionsBuilder.EnableSensitiveDataLogging();
                    }

                    //调用项目中的配置
                    configObj.OptionsAction?.Invoke(optionsBuilder);
                });

            dbContextBuilder.Services.AddSingleton(configObj);

            return dbContextBuilder;
        }
    }
}