﻿using System;
using GMP.Db.Abstractions;
using GMP.Db.EF;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// EF支持
    /// </summary>
    public static class EFExtension
    {
        /// <summary>
        /// 添加mysql的DB支持
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configEfAction"></param>
        public static EFDbContextBuilder AddGmpDbSupportByEF(
               this IServiceCollection services,
               Action<GmpDbEFOption> configEfAction = null)
        {
            //准备配置
            GmpDbEFOption configObj = new GmpDbEFOption();
            configObj.EnableConsoleLogByEnv().EnableFilterSoftDelete();
            configEfAction?.Invoke(configObj);

            //准备builder
            EFDbContextBuilder dbContextBuilder = new EFDbContextBuilder(configObj, services);

            return dbContextBuilder;
        }
    }
}