﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/20 16:18:24
*
***************************************************************************/

using System;
using Microsoft.Extensions.Logging;

namespace GMP.Db.EF.EFLogger
{
    public class EFLogger : ILogger
    {
        private readonly string categoryName;
        private readonly bool isEnableLog;

        public EFLogger(string categoryName)
            : this(categoryName, true)
        {
        }

        public EFLogger(string categoryName, bool isEnableLog)
        {
            this.categoryName = categoryName;
            this.isEnableLog = isEnableLog;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return this.isEnableLog;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            //ef core执行数据库查询时的categoryName为Microsoft.EntityFrameworkCore.Database.Command,日志级别为Information
            if (this.categoryName == "Microsoft.EntityFrameworkCore.Database.Command"
                    && logLevel == LogLevel.Information)
            {
                string logContent = formatter(state, exception);
                // 拿到日志内容想怎么玩就怎么玩吧

                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(logContent);
                Console.ResetColor();
            }
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }
    }
}