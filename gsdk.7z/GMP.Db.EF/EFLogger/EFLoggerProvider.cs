﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/20 16:18:24
*
***************************************************************************/

using Microsoft.Extensions.Logging;

namespace GMP.Db.EF.EFLogger
{
    public class EFLoggerProvider : ILoggerProvider
    {
        private readonly bool isEnableLog;

        public EFLoggerProvider()
        {
            this.isEnableLog = true;
        }

        public EFLoggerProvider(bool isEnableLog)
        {
            this.isEnableLog = isEnableLog;
        }

        public ILogger CreateLogger(string categoryName)
        {
            return new EFLogger(categoryName, this.isEnableLog);
        }

        public void Dispose()
        {
        }
    }
}