﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-31 星期一 16:37:19
*
***************************************************************************/

using System;
using GMP.Db.Abstractions.Entity;
using GMP.Db.EF.Helper;

namespace Microsoft.EntityFrameworkCore
{
    /// <summary>
    /// <see cref="DbContext"/>的扩展
    /// </summary>
    public static class DataContextExtensions
    {
        /// <summary>
        /// 更新
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="Tid"></typeparam>
        /// <param name="dbContext"></param>
        /// <param name="id">id</param>
        /// <param name="setter">传递一个委托,指示如何更新实体</param>
        public static void GmpUpdate<T, Tid>(
            this DbContext dbContext,
            Tid id,
            Action<T> setter)
            where T : IDbAuditEntity<Tid>, new()
        {
            if (setter is null)
            {
                throw new ArgumentNullException(nameof(setter));
            }

            T obj = new T() { Id = id, ModifiedTime = DateTime.Now };
            dbContext.Attach(obj);
            setter.Invoke(obj);
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dbContext"></param>
        /// <param name="id">id</param>
        /// <param name="setter">传递一个委托,指示如何更新实体</param>
        public static void GmpUpdate<T>(
            this DbContext dbContext,
            string id,
            Action<T> setter)
            where T : IDbAuditEntity<string>, new()
        {
            if (setter is null)
            {
                throw new ArgumentNullException(nameof(setter));
            }

            DataContextExtensions.GmpUpdate<T, string>(dbContext, id, setter);
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="Tid"></typeparam>
        /// <param name="dbContext"></param>
        /// <param name="obj">实体</param>
        /// <param name="setter">传递一个委托,指示如何更新实体</param>
        public static void GmpUpdate<T, Tid>(
            this DbContext dbContext,
            T obj,
            Action<T> setter)
            where T : IDbAuditEntity<Tid>, new()
        {
            if (setter is null)
            {
                throw new ArgumentNullException(nameof(setter));
            }

            DataContextExtensions.GmpUpdate<T, Tid>(dbContext, obj.Id, setter);
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dbContext"></param>
        /// <param name="obj">实体</param>
        /// <param name="setter">传递一个委托,指示如何更新实体</param>
        public static void GmpUpdate<T>(
            this DbContext dbContext,
            T obj,
            Action<T> setter)
            where T : IDbAuditEntity<string>, new()
        {
            if (setter is null)
            {
                throw new ArgumentNullException(nameof(setter));
            }

            if (obj is null)
            {
                throw new ArgumentNullException(nameof(obj));
            }

            if (obj.Id is null)
            {
                throw new ArgumentNullException(nameof(obj.Id));
            }

            DataContextExtensions.GmpUpdate<T, string>(dbContext, obj.Id, setter);
        }

        /// <summary>
        /// 获取变更数据,一个类型为一组,默认过滤掉未更改状态的数据
        /// </summary>
        /// <param name="dbContext"></param>
        /// <param name="includeAll"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static EfChangeData[] GetChangeData(
           this DbContext dbContext,
           bool includeAll = false)
        {
            if (dbContext is null)
            {
                throw new ArgumentNullException(nameof(dbContext));
            }

            return DbContextHelper.GetChangeData(dbContext, includeAll);
        }
    }
}