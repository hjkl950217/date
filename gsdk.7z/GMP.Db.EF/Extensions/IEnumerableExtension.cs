﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-25 星期二 11:10:21
*
***************************************************************************/

namespace System.Linq
{
    public static class IEnumerableExtension
    {
    }
}