﻿using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Db.EF;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Microsoft.EntityFrameworkCore.Metadata
{
    public static class IMutablePropertyExtensions
    {
        public static IMutableProperty AddCustomPropConvert(
            this IMutableProperty property,
            GmpDbEFOption gmpDbEFOption)
        {
            if (gmpDbEFOption is null)
            {
                throw new ArgumentNullException(nameof(gmpDbEFOption));
            }

            if (gmpDbEFOption.CustomValueConverters != null
                && gmpDbEFOption.CustomValueConverters.Any())
            {
                //获取当前属性对应的转换器
                IEnumerable<KeyValuePair<Func<Type, bool>, Func<Type, ValueConverter>>> propConverts = gmpDbEFOption.CustomValueConverters
                    .Where(t => t.Key(property.ClrType));

                //设置转换器
                foreach (KeyValuePair<Func<Type, bool>, Func<Type, ValueConverter>> convertItem in propConverts)
                {
                    property.SetValueConverter(convertItem.Value(property.ClrType));
                }
            }

            return property;
        }
    }
}