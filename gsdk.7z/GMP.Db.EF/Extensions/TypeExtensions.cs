﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Db.EF.Extensions
{
    public static class TypeExtensions
    {
        /// <summary>
        /// 获取类型的显示名
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static string GetShowTypeName(this Type type)
        {
            if (type.IsGenericType)
            {
                IEnumerable<string> gArgs = type.GetGenericArguments()
                    ?.Select(t => t.Name)
                    ?? Array.Empty<string>();

                return $"{type.Name}<{string.Join(",", gArgs)}>";
            }
            else
            {
                return type.Name;
            }
        }
    }
}
