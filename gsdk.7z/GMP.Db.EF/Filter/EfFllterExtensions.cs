﻿using System;
using System.Linq.Expressions;

namespace Microsoft.EntityFrameworkCore.Metadata
{
    public static class EfFllterExtensions
    {
        public static void AddQueryFilter(
            this IMutableEntityType entityData,
            LambdaExpression lambdaExpression)
        {
            entityData.SetQueryFilter(lambdaExpression);
        }

        public static void AddQueryFilter<TEntity>(
           this IMutableEntityType entityData,
           Expression<Func<TEntity, bool>> filterFunc)
        {
            EfFllterExtensions.AddQueryFilter(
                    entityData,
                    (LambdaExpression)filterFunc);
        }
    }
}