﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using GMP.Db.Abstractions.Entity;
using GMP.Db.Abstractions.Enum;

namespace Microsoft.EntityFrameworkCore.Metadata
{
    /// <summary>
    /// Ef Validity 过滤器扩展
    /// </summary>
    public static class ValidityFilterExtension
    {
        public static void AddValidityFilter(
            this IMutableEntityType entityType)
        {
            Type typeInfo = typeof(IValidity);

            //类型检查
            if (!typeInfo.IsAssignableFrom(entityType.ClrType))
            {
                return;
            }

            //添加全局过滤器
            MethodInfo methodToCall = typeof(ValidityFilterExtension)
                .GetMethod(nameof(GetSoftDeleteFilter),
                    BindingFlags.NonPublic | BindingFlags.Static)
                .MakeGenericMethod(entityType.ClrType);
            object filter = methodToCall.Invoke(null, new object[] { });
            entityType.SetQueryFilter((LambdaExpression)filter);
        }

        private static LambdaExpression GetSoftDeleteFilter<TEntity>()
            where TEntity : class, IValidity
        {
            Expression<Func<TEntity, bool>> filter = x => x.Validity == ((int)Validity.Effective).ToString();
            return filter;
        }
    }
}