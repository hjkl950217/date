﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

using System;
using System.Collections.Generic;
using GMP.Db.Abstractions;
using GMP.Db.Abstractions.Enum;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace GMP.Db.EF
{
    /// <summary>
    /// 配置EF的模型
    /// </summary>
    public class GmpDbEFOption : GmpDbBaseOption
    {
        /// <summary>
        /// 初始化一个<see cref="GmpDbEFOption"/>实例
        /// </summary>
        public GmpDbEFOption()
        {
            this.CustomValueConverters = new Dictionary<Func<Type, bool>, Func<Type, ValueConverter>>();
        }

        #region 配置

        /// <summary>
        /// [由框架指定]数据库类型
        /// </summary>
        public DbType DbType { get; internal set; }

        /// <summary>
        /// 数据库上下文配置action
        /// </summary>
        public Action<DbContextOptionsBuilder> OptionsAction { get; set; }

        /// <summary>
        /// 是否在日志中记录参数值,默认false
        /// </summary>
        public bool EnableSensitiveDataLogging { get; set; }

        /// <summary>
        /// 自定义类型转换
        /// </summary>
        public Dictionary<Func<Type, bool>, Func<Type, ValueConverter>> CustomValueConverters { get; set; }

        #endregion 配置

        /// <summary>
        /// 检查连接字符口里是否为空
        /// </summary>
        /// <param name="errorMsg"></param>
        /// <returns></returns>
        protected override bool CheckConnectStrEmpty(ref string errorMsg)
        {
            //可能会有多种数据库，所以报更详细一点
            bool checkResult = base.CheckConnectStrEmpty(ref errorMsg);
            if (errorMsg != string.Empty)
            {
                errorMsg = "未配置Mysql的连接字符串";
            }

            return checkResult;
        }
    }
}