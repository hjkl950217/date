﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-29 星期二 10:34:29
*
***************************************************************************/

using System;
using System.Linq.Expressions;
using GMP.Db.Abstractions;
using GMP.Db.EF.Const;
using GMP.Db.EF.Converts;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace GMP.Db.EF
{
    public static class GmpDbEFOptionExtensions
    {
        /// <summary>
        /// 配置连接字符串从环境变量中获取
        /// </summary>
        /// <param name="gmpDbEFOption"></param>
        /// <param name="envName"></param>
        /// <returns></returns>
        public static GmpDbEFOption ConfigConnectStringFromEnv(
            this GmpDbEFOption gmpDbEFOption,
            string envName = DbBaseConst.MySql.ConnectStringKey)
        {
            return GmpDbBaseOptionExtension.ConfigConnectStringFromEnv(gmpDbEFOption, envName) as GmpDbEFOption;
        }

        /// <summary>
        /// 按环境变量是否启用日志<para></para>
        /// 如果<see cref="GmpEfConst.Env_Enable_EfLog"/>配置为true,才会启用日志。<para></para>
        /// 如果<see cref="GmpEfConst.Env_Enable_EfLog"/>获取不到值,则默认不开启日志。<para></para>
        /// </summary>
        /// <param name="gmpDbEFOption"></param>
        /// <param name="envName"></param>
        /// <returns></returns>
        public static GmpDbEFOption EnableLogByEnv(
            this GmpDbEFOption gmpDbEFOption,
            string envName = GmpEfConst.Env_Enable_EfLog)
        {
            string enableStr = Environment.GetEnvironmentVariable(envName)?.Trim()?.ToLower();
            bool isEnable = enableStr != null && enableStr.Length != 0 && enableStr == "true";

            return isEnable
                ? gmpDbEFOption.EnableConsoleLog() as GmpDbEFOption
                : gmpDbEFOption.DisableConsoleLog() as GmpDbEFOption;
        }

        #region 转换器

        /// <summary>
        /// 添加自定义的属性转换器
        /// </summary>
        /// <param name="gmpDbEFOption"></param>
        /// <param name="isType">指示要针对什么类型创建转换器</param>
        /// <param name="convertCreater">指时框架如何获得转换器</param>
        /// <returns></returns>
        public static GmpDbEFOption AddPropertyConvert(
            this GmpDbEFOption gmpDbEFOption,
            Func<Type, bool> isType,
            Func<Type, ValueConverter> convertCreater)
        {
            if (isType is null)
            {
                throw new ArgumentNullException(nameof(isType));
            }

            if (convertCreater is null)
            {
                throw new ArgumentNullException(nameof(convertCreater));
            }

            gmpDbEFOption.CustomValueConverters.Add(isType, convertCreater);

            return gmpDbEFOption;
        }

        /// <summary>
        /// 添加转换器-枚举转换为值的字符串形式的转换器
        /// </summary>
        /// <param name="gmpDbEFOption"></param>
        /// <returns></returns>
        public static GmpDbEFOption AddEnumToValueStringConvert(
            this GmpDbEFOption gmpDbEFOption)
        {
            return GmpDbEFOptionExtensions.AddPropertyConvert(
                gmpDbEFOption,
                t => t.IsEnum,
                t => new EnumToValueStringConvert(t));
        }

        /// <summary>
        /// 添加一个属性转换器
        /// </summary>
        /// <typeparam name="TSourceType"></typeparam>
        /// <typeparam name="TTargetType"></typeparam>
        /// <param name="gmpDbEFOption"></param>
        /// <param name="sourceToTarget"></param>
        /// <param name="targetToSource"></param>
        /// <returns></returns>
        public static GmpDbEFOption AddPropertyConvert<TSourceType, TTargetType>(
            this GmpDbEFOption gmpDbEFOption,
            Expression<Func<TSourceType, TTargetType>> sourceToTarget,
            Expression<Func<TTargetType, TSourceType>> targetToSource
            )
        {
            Type propertyClrType = typeof(TSourceType);
            return GmpDbEFOptionExtensions.AddPropertyConvert(
                gmpDbEFOption,
                t => t == propertyClrType,
                t => new DefaultCustomPropertyConvert<TSourceType, TTargetType>(
                    t,
                    sourceToTarget,
                    targetToSource));
        }

        #endregion 转换器
    }
}