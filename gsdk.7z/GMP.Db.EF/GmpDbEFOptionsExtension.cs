﻿using System.Collections.Generic;
using System.Globalization;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.Db.EF
{
    /// <summary>
    /// GMP EF 的配置扩展实例
    /// </summary>
    public class GmpDbEFOptionsExtension : IDbContextOptionsExtension
    {
        private sealed class ExtensionInfo : DbContextOptionsExtensionInfo
        {
            public ExtensionInfo(IDbContextOptionsExtension extension) : base(extension)
            {
            }

            public override bool IsDatabaseProvider { get; }
            public override string LogFragment { get; }
            private new GmpDbEFOptionsExtension Extension => (GmpDbEFOptionsExtension)base.Extension;

            private long _serviceProviderHash = 0L;

            public override long GetServiceProviderHashCode()
            {
                long[] hashCodes = new long[]
                {
                        this.Extension.GmpDbEFOption?.ConnectString?.GetHashCode() ?? 0L,
                        this.Extension.GmpDbEFOption?.DbType.GetHashCode()?? 0L,
                        this.Extension.GmpDbEFOption?.IsSoftDelete.GetHashCode()?? 0L,
                        this.Extension.GmpDbEFOption?.IsConsoleLog.GetHashCode()?? 0L,
                        this.Extension.GmpDbEFOption?.IsLog.GetHashCode()?? 0L
                };

                foreach (int item in hashCodes)
                {
                    this._serviceProviderHash = (this._serviceProviderHash * 397) ^ item;
                }

                return this._serviceProviderHash;
            }

            public override void PopulateDebugInfo(IDictionary<string, string> debugInfo)
            {
                Dictionary<string, long> tempDic = new Dictionary<string, long>()
                {
                    [nameof(GmpDbEFOption.ConnectString)] = this.Extension.GmpDbEFOption?.ConnectString?.GetHashCode() ?? 0L,
                    [nameof(GmpDbEFOption.DbType)] = this.Extension.GmpDbEFOption?.DbType.GetHashCode() ?? 0L,
                    [nameof(GmpDbEFOption.IsSoftDelete)] = this.Extension.GmpDbEFOption?.IsSoftDelete.GetHashCode() ?? 0L,
                    [nameof(GmpDbEFOption.IsConsoleLog)] = this.Extension.GmpDbEFOption?.IsConsoleLog.GetHashCode() ?? 0L,
                    [nameof(GmpDbEFOption.IsLog)] = this.Extension.GmpDbEFOption?.IsLog.GetHashCode() ?? 0L
                };

                foreach (KeyValuePair<string, long> item in tempDic)
                {
                    debugInfo["MySql:" + item.Key] = item.Value.ToString(CultureInfo.InvariantCulture);
                }
            }
        }

        private DbContextOptionsExtensionInfo info;

        public DbContextOptionsExtensionInfo Info
        {
            get
            {
                if (this.info == null) this.info = new ExtensionInfo(this);
                return this.info;
            }
        }

        public GmpDbEFOption GmpDbEFOption { get; internal set; }

        public void ApplyServices(IServiceCollection services)
        {
        }

        public void Validate(IDbContextOptions options)
        {
        }
    }
}