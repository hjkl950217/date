﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System;
using GMP.Db.EF.Extensions;

namespace GMP.Db.EF.Helper
{
    /// <summary>
    /// ef变化数据-改变后的属性详细信息
    /// </summary>
    public class EfChangeDataEntry
    {
        /// <summary>
        /// 属性名
        /// </summary>
        public string PropName { get; set; }

        /// <summary>
        /// 类型名
        /// </summary>
        public string PropTypeName { get; set; }

        /// <summary>
        /// 原始值
        /// </summary>
        public object SourValue { get; set; }

        /// <summary>
        /// 当前值
        /// </summary>
        public object CurrValue { get; set; }
    }

    /// <summary>
    /// ef变化数据-一个数据代表一个实体对象的改变数据
    /// </summary>
    public class EfChangeDataItem
    {
        /// <summary>
        /// 实体类型名
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// 追踪状态
        /// </summary>
        public EntityState State { get; set; }

        /// <summary>
        /// Id集合-如果实体没有id则没值
        /// </summary>
        public EfChangeDataEntry[] Ids { get; set; }

        /// <summary>
        /// 变更属性详细信息
        /// </summary>
        public EfChangeDataEntry[] ChangeProps { get; set; }
    }

    /// <summary>
    /// ef变化数据
    /// </summary>
    public class EfChangeData
    {
        /// <summary>
        /// 实体类型名
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// 变化的数据
        /// </summary>
        public LinkedList<EfChangeDataItem> ChangeData { get; set; }
    }

    /// <summary>
    /// DbContextHelper
    /// </summary>
    public static class DbContextHelper
    {
        #region 获取变更数据,一个类型为一组

        /// <summary>
        /// 获取变更数据,一个类型为一组,默认过滤掉未更改状态的数据
        /// </summary>
        /// <param name="context"></param>
        /// <param name="includeAll"></param>
        /// <returns></returns>
        public static EfChangeData[] GetChangeData(
            DbContext context,
            bool includeAll = false)
        {
            IEnumerable<EntityEntry> changeData = context.ChangeTracker.Entries();
            if (changeData == null && !changeData.Any())
            {
                return Array.Empty<EfChangeData>();
            }

            LinkedList<EfChangeData> result = new LinkedList<EfChangeData>();
            foreach (EntityEntry item in changeData)
            {
                //默认情况下排除 没有改变+后来标记为不追踪的
                if (!includeAll
                    && (item.State == EntityState.Detached
                        || item.State == EntityState.Unchanged))
                {
                    continue;
                }

                #region 初始化变更数据

                EfChangeDataItem chageItem = new EfChangeDataItem
                {
                    TypeName = item.Entity.GetType().Name,
                    State = item.State,
                    Ids = Array.Empty<EfChangeDataEntry>(),
                    ChangeProps = Array.Empty<EfChangeDataEntry>()
                };

                #endregion 初始化变更数据

                #region id

                chageItem.Ids = item.Metadata.FindPrimaryKey()
                    .Properties
                    .Select(t => new EfChangeDataEntry()
                    {
                        PropName = t.Name,
                        PropTypeName = t.ClrType.Name,
                        SourValue = null,
                        CurrValue = item.Property(t.Name).CurrentValue
                    })
                    .ToArray();

                #endregion id

                #region 改变值集合

                //修改 只显示不一样的
                if (item.State == EntityState.Modified)
                {
                    chageItem.ChangeProps = item.Properties
                         .Where(t => !includeAll
                             && Convert.ToString(t.OriginalValue) != Convert.ToString(t.CurrentValue))
                         .Select(t => new EfChangeDataEntry()
                         {
                             PropName = t.Metadata.Name,
                             PropTypeName = t.Metadata.ClrType.GetShowTypeName(),
                             SourValue = t.OriginalValue,
                             CurrValue = t.CurrentValue
                         })
                        .ToArray();
                }

                // 添加 显示所有
                if (item.State == EntityState.Added)
                {
                    chageItem.ChangeProps = item.Properties
                             .Select(t => new EfChangeDataEntry()
                             {
                                 PropName = t.Metadata.Name,
                                 PropTypeName = t.Metadata.ClrType.GetShowTypeName(),
                                 SourValue = null,
                                 CurrValue = t.CurrentValue
                             })
                          .ToArray();
                }

                //其它的不附加 ChangeProps

                #endregion 改变值集合

                #region 添加到结果集合

                EfChangeData resultNode = result.FirstOrDefault(t => t.TypeName == chageItem.TypeName);
                if (resultNode == null)
                {
                    LinkedList<EfChangeDataItem> changeDataLink = new LinkedList<EfChangeDataItem>();
                    changeDataLink.AddLast(chageItem);

                    resultNode = new EfChangeData()
                    {
                        TypeName = chageItem.TypeName,
                        ChangeData = changeDataLink
                    };
                    result.AddLast(resultNode);
                }
                else
                {
                    resultNode.ChangeData.AddLast(chageItem);
                }

                //bool isExist = resultDic.TryGetValue(chageItem.TypeName, out List<EfChangeDataItem> entryList);
                //if (!isExist)
                //{
                //    entryList = new List<EfChangeDataItem>() { chageItem };
                //    resultDic.Add(chageItem.TypeName, entryList);
                //}
                //else
                //{
                //    entryList.Add(chageItem);
                //}

                #endregion 添加到结果集合
            }

            return result.ToArray();
        }

        #endregion 获取变更数据,一个类型为一组
    }
}
