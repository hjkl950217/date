﻿namespace GMP.HttpReport
{
    /// <summary>
    ///
    /// </summary>
    public static class GmpHttpReportConst
    {
        /// <summary>
        /// 是否启用环境收集地址
        /// </summary>
        public const string Env_CollectorAddress = "HTTP_REPORT_COLLECTOR_ADDRESS";

        /// <summary>
        /// 是否启用httpReport
        /// </summary>
        public const string Env_Enable_HttpReport = "HTTP_REPORT_ENABLE";
    }
}