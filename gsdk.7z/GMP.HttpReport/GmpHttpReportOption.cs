﻿namespace GMP.HttpReport
{
    /// <summary>
    ///  配置HttpReport模型
    /// </summary>
    public class GmpHttpReportOption
    {
        /// <summary>
        /// 收集数据的服务端地址环境变量名
        /// </summary>
        public string CollectorAddressEnvName { get; set; }

        /// <summary>
        /// 收集数据的服务端地址
        /// </summary>
        public string CollectorAddress { get; set; }

        /// <summary>
        /// 判断是否为空
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
            return this == null || this.CollectorAddressEnvName == null
                || this.CollectorAddress == null;
        }
    }
}