﻿using System;
using GMP.HttpReport;
using HttpReports;
using HttpReports.Transport.Http;
using Microsoft.AspNetCore.Builder;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// HttpReport
    /// </summary>
    public static class HttpReportExtension
    {
        /// <summary>
        /// 添加HttpReport服务.<para></para>
        /// 如果<see cref="GmpHttpReportConst.Env_Enable_HttpReport"/>配置为true,才会启用服务。<para></para>
        /// 如果<see cref="GmpHttpReportConst.Env_Enable_HttpReport"/>获取不到值,则默认不开启服务。<para></para>
        /// 默认管理员账户 admin 123456
        /// </summary>
        /// <param name="services"></param>
        /// <param name="collectorAddressEnvName"></param>
        /// <param name="reportConfigAction"></param>
        /// <param name="transportConfigAction"></param>
        /// <returns></returns>
        public static IServiceCollection AddGmpHttpReport(
            this IServiceCollection services,
            string collectorAddressEnvName = GmpHttpReportConst.Env_CollectorAddress,
            Action<HttpReportsOptions> reportConfigAction = null,
            Action<HttpTransportOptions> transportConfigAction = null)
        {
            //参数检查
            string collectorAddress = Environment.GetEnvironmentVariable(collectorAddressEnvName)?.Trim()?.ToLower();
            string enableHttpReport = Environment.GetEnvironmentVariable(GmpHttpReportConst.Env_Enable_HttpReport)?.Trim()?.ToLower();

            bool isNotAddress = collectorAddress == null || collectorAddress.Length == 0;
            bool isEnable = enableHttpReport != null && enableHttpReport.Length != 0 && enableHttpReport == "true";
            if (isNotAddress || !isEnable)
            {
                // throw new Exception($"http report collectorAddress is null or empty.Env Name:{collectorAddressEnvName}");
                Console.WriteLine($"[Warn]httpReport env is null or empty or httpReport not enable,Please check env:[{GmpHttpReportConst.Env_CollectorAddress}],[{GmpHttpReportConst.Env_Enable_HttpReport}]");
                return services;//没有环境变量时跳过服务
            }

            //准备配置
            GmpHttpReportOption config = new GmpHttpReportOption()
            {
                CollectorAddressEnvName = collectorAddressEnvName,
                CollectorAddress = collectorAddress
            };
            services.AddSingleton<GmpHttpReportOption>(t => { return config; });

            //注册服务
            services
                .AddHttpReports(opt =>
                {
                    //opt.Server = "http://localhost:80";
                    //opt.Service = "GMP.Core";
                    opt.Switch = true;
                    opt.RequestFilter = new string[] { "/api/health/*", "/HttpReports*" };
                    opt.MaxBytes = 65500;
                    opt.WithRequest = true;
                    opt.WithResponse = true;
                    opt.WithCookie = true;
                    opt.WithHeader = true;

                    reportConfigAction?.Invoke(opt);
                })
                .AddHttpTransport(opt =>
                {
                    opt.CollectorAddress = new Uri(collectorAddress);
                    //opt.CollectorAddress = new System.Uri("http://192.168.1.110:8500/");
                    opt.DeferSecond = 10;
                    opt.DeferThreshold = 100;

                    transportConfigAction?.Invoke(opt);
                });

            return services;
        }

        public static IApplicationBuilder UseGmpHttpReport(
            this IApplicationBuilder app)
        {
            //参数检查
            GmpHttpReportOption config = app.ApplicationServices.GetService<GmpHttpReportOption>();

            if (config?.IsEmpty() ?? true)
            {
                return app;//没有服务时跳过中间件
            }

            app.UseHttpReports();

            return app;
        }
    }
}