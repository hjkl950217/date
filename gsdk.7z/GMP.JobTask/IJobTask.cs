﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/17 星期六 16:10:21
*
***************************************************************************/

namespace GMP.JobTask
{
    /// <summary>
    /// 定时任务接口
    /// </summary>
    public interface IJobTask
    {
        /// <summary>
        /// 运行任务
        /// </summary>
        void Run();
    }
}