﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/17 星期六 16:10:21
*
***************************************************************************/

using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.JobTask
{
    /// <summary>
    /// 定时任务基类
    /// </summary>
    public abstract class JobTaskBase : IJobTask
    {
        private readonly object diLocker = new object();
        private IServiceProvider di = null;
        private Func<IServiceCollection, IServiceCollection> commSerRegistration = null;

        #region 对外暴露

        /// <summary>
        /// 运行
        /// </summary>
        public void Run()
        {
            // 2022-01-04 因ef不能共享的问题,现在di改为 Scoped ,每次运行获取新的Di
            // this.InitServiceRegistration(false);//初始化服务注册
            JobTaskOption taskOption = this.ConfigJobTaskOption(new JobTaskOption());
            this.TryLoopRun(this.InvokeTask, taskOption);
        }

        /// <summary>
        /// 设置公共服务注册
        /// </summary>
        /// <param name="setCommonFunc"></param>
        internal void SetCommonServiceRegistration(Func<IServiceCollection, IServiceCollection> setCommonFunc)
        {
            this.commSerRegistration = setCommonFunc;
        }

        #endregion 对外暴露

        #region 私有逻辑

        /// <summary>
        /// 初始化服务注册
        /// </summary>
        /// <param name="isCreate">是否一定初始化,默认true,初始化后就不再初始化</param>
        /// <returns></returns>
        private IServiceProvider InitServiceRegistration(bool isCreate = true)
        {
            if(!isCreate && this.di != null)
                return this.di;

            lock(this.diLocker)
            {
                //配置服务
                ServiceCollection services = new ServiceCollection();
                this.commSerRegistration?.Invoke(services);  //注册公共的服务配置
                this.ConfigServices(services);//注册由子类配置的服务

                //构建DI
                IServiceProvider di = services
                    .BuildServiceProvider();

                this.di = di;
            }

            return this.di;
        }

        /// <summary>
        /// 尝试循环执行,发生异常时输出日志。
        /// </summary>
        /// <param name="taskAction"></param>
        /// <param name="jobTaskOption"></param>
        private void TryLoopRun(Action<IServiceProvider> taskAction, JobTaskOption jobTaskOption)
        {
            jobTaskOption.CheckNullWithException(nameof(jobTaskOption));

            string jobTakName = jobTaskOption?.JobTaskName ?? this.GetType().Name;

            while(true)
            {
                try
                {
                    Console.WriteLine($"{jobTakName}开始执行");
                    this.InitServiceRegistration(true);
                    taskAction(this.di);//执行具体的业务代码
                    Console.WriteLine($"{jobTakName}结束执行");
                }
                catch(Exception e)
                {
                    Console.WriteLine($"运行[{jobTakName}]发生异常: {e}");
                }
                finally
                {
                    Task.Delay(jobTaskOption.MillisecondsDelay).Wait(); //休眠
                }
            }
        }

        #endregion 私有逻辑

        /// <summary>
        /// [由子类实现]开始执行定时任务
        /// </summary>
        /// <param name="serviceProvider"></param>
        protected abstract void InvokeTask(IServiceProvider serviceProvider);

        /// <summary>
        /// [由子类实现]开始执行定时任务
        /// </summary>
        /// <param name="serviceProvider"></param>
        [Obsolete("改用 InvokeTask ,这个方法不再被调用了")]
        protected virtual void StartJobTask(IServiceProvider serviceProvider)
        { }

        /// <summary>
        ///  [由子类实现]配置服务运行时的服务依赖
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        protected abstract IServiceCollection ConfigServices(IServiceCollection services);

        /// <summary>
        /// [由子类实现]配置服务运行时的基础配置
        /// </summary>
        /// <param name="jobTaskOption"></param>
        /// <returns></returns>
        protected abstract JobTaskOption ConfigJobTaskOption(JobTaskOption jobTaskOption);
    }
}