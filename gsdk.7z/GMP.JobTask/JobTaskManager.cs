﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xun.zhang 2020/01/21 09:11:34
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.JobTask
{
    /// <summary>
    /// 定时任务管理器
    /// </summary>
    public class JobTaskManager
    {
        private static readonly CancellationTokenSource tokenSource = new CancellationTokenSource();

        private IJobTask[] JobTasks;
        private Func<IServiceCollection, IServiceCollection> commSerRegistration = null;

        /// <summary>
        /// 载入定时任务实例
        /// </summary>
        /// <param name="jobTasks"></param>
        public void LoadJobTasks(IEnumerable<IJobTask> jobTasks)
        {
            this.JobTasks = jobTasks.ToArray();
        }

        /// <summary>
        /// 批量运行
        /// </summary>
        public void BatchRun()
        {
            if(this.JobTasks.IsNullOrEmpty())
            { return; }

            Console.WriteLine("开始执行定时任务");

            AutoResetEvent autoResetEvent = new AutoResetEvent(false);

            foreach(IJobTask item in this.JobTasks)
            {
                //尝试设置公共服务注册
                if(item is JobTaskBase tempItem)
                {
                    tempItem.SetCommonServiceRegistration(this.commSerRegistration);
                }

                //执行任务
                Task.Factory
                    .StartNew(
                        item.Run,
                        tokenSource.Token)
                    .ConfigureAwait(false);
            }

            autoResetEvent.WaitOne();//当前线程阻塞
            Console.WriteLine("定时任务结束");
        }

        /// <summary>
        /// 设置公共服务注册
        /// </summary>
        /// <param name="setCommonFunc"></param>
        public void SetCommonServiceRegistration(Func<IServiceCollection, IServiceCollection> setCommonFunc)
        {
            this.commSerRegistration = setCommonFunc;
        }
    }
}