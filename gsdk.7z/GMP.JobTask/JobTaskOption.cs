﻿namespace GMP.JobTask
{
    /// <summary>
    /// 定时任务配置对象
    /// </summary>
    public class JobTaskOption
    {
        /// <summary>
        /// 定时任务名
        /// </summary>
        public string JobTaskName { get; set; }

        /// <summary>
        /// 获取或更新每个定时任务之间的延迟(毫秒)
        /// </summary>
        public int MillisecondsDelay { get; set; }
    }
}