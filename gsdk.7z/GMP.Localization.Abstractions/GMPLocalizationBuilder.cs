﻿using Microsoft.Extensions.DependencyInjection;

namespace GMP.Localization.Abstractions
{
    /// <summary>
    /// 多语言建造者
    /// </summary>
    public class GMPLocalizationBuilder
    {
        /// <summary>
        /// 初始化<see cref="GMPLocalizationBuilder"/>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="option"></param>
        public GMPLocalizationBuilder(
            GmpLocalizationOption option,
            IServiceCollection services)
        {
            this.Services = services;
            this.GmpLocalizationOption = option;
        }

        /// <summary>
        /// IOC配置集合
        /// </summary>
        public IServiceCollection Services { get; }

        /// <summary>
        /// gmp localization 配置对象
        /// </summary>
        public GmpLocalizationOption GmpLocalizationOption { get; }
    }
}