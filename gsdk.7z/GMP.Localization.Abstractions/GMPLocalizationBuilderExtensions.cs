﻿using System;

namespace GMP.Localization.Abstractions
{
    /// <summary>
    /// <see cref="GMPLocalizationBuilder"/> 扩展
    /// </summary>
    public static class GMPLocalizationBuilderExtensions
    {
        /// <summary>
        /// 设置任一业务枚举的type信息,用于框架查找相同命名空间下的业务枚举结构
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="bizEnumType"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder SetBizEnum(
            this GMPLocalizationBuilder builder,
            Type bizEnumType)
        {
            LocalInfoService.bizEnumTypeInfo = bizEnumType;

            return builder;
        }

        /// <summary>
        /// 设置任一业务枚举的type信息,用于框架查找相同命名空间下的业务枚举结构
        /// </summary>
        /// <typeparam name="TType"></typeparam>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder SetBizEnum<TType>(
            this GMPLocalizationBuilder builder)
            where TType : Enum
        {
            LocalInfoService.bizEnumTypeInfo = typeof(TType);

            return builder;
        }

        /// <summary>
        /// 额外追加业务枚举
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="bizEnumType"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder AppendEnum(
            this GMPLocalizationBuilder builder,
            Type bizEnumType)
        {
            LocalInfoService.appendEnumTypeInoList.Add(bizEnumType);
            return builder;
        }

        /// <summary>
        /// 额外追加多个业务枚举
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="bizEnumTypes"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder AppendEnums(
            this GMPLocalizationBuilder builder,
            params Type[] bizEnumTypes)
        {
            if (bizEnumTypes.IsNullOrEmpty()) return builder;

            LocalInfoService.appendEnumTypeInoList.AddRange(bizEnumTypes);
            return builder;
        }

        /// <summary>
        /// 额外追加业务枚举
        /// </summary>
        /// <typeparam name="TType"></typeparam>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder AppendEnum<TType>(
            this GMPLocalizationBuilder builder)
            where TType : Enum
        {
            LocalInfoService.appendEnumTypeInoList.Add(typeof(TType));
            return builder;
        }
    }
}