﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Localization.Abstractions
{
    /// <summary>
    /// 多语言配置模型
    /// </summary>
    public sealed class GmpLocalizationOption : ICloneable
    {
        #region 多语言定义的类

        /// <summary>
        ///  是否软删除
        /// </summary>
        public List<Type> LocalizationTypeList { get; private set; }

        /// <summary>
        /// 添加多语言定义类
        /// </summary>
        /// <returns></returns>
        public GmpLocalizationOption AddLocalizationType(params Type[] types)
        {
            this.LocalizationTypeList ??= new List<Type>();

            if (types.IsNullOrEmpty()) return this;

            //不存在则添加
            foreach (Type item in types)
            {
                bool isExists = this.LocalizationTypeList.Any(t => t == item);
                if (!isExists) this.LocalizationTypeList.Add(item);
            }

            return this;
        }

        #endregion 多语言定义的类

        /// <summary>
        /// 浅拷贝(this为空时报错)
        /// </summary>
        /// <returns></returns>
        public GmpLocalizationOption Clone()
        {
            return (this as ICloneable).Clone() as GmpLocalizationOption;
        }

        object ICloneable.Clone()
        {
            if (this == null)
            {
                throw new ArgumentNullException(" object is null in clone!");
            }
            return this.MemberwiseClone();
        }
    }
}