﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-08 星期二 10:02:56
*
***************************************************************************/

using System;
using GMP.Localization.Abstractions.LocalContainer;

namespace GMP.Localization.Abstractions.Helper
{
    /// <summary>
    /// 多语言帮助类
    /// </summary>
    public static class GmpLocalHelper
    {
        internal static ILocalContainer localContainer = null;

        /// <summary>
        /// 获取消息容器
        /// </summary>
        /// <returns></returns>
        public static ILocalContainer GetLocalContainer()
        {
            return localContainer ?? throw new Exception($"{nameof(GmpLocalHelper)}.{nameof(GmpLocalHelper.localContainer)} 未初始化");
        }

        /// <summary>
        /// 注册多语言容器
        /// </summary>
        /// <param name="localContainer"></param>
        public static void InitContainer(ILocalContainer localContainer)
        {
            localContainer.CheckNullOrEmptyWithException(nameof(localContainer));
            GmpLocalHelper.localContainer = localContainer;
        }
    }
}