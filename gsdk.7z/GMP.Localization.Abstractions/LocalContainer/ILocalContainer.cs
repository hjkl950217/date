﻿using System.Collections.Generic;

namespace GMP.Localization.Abstractions.LocalContainer
{
    /// <summary>
    /// 信息容器
    /// </summary>
    public interface ILocalContainer
    {
        /// <summary>
        ///  检查Code是否配置
        /// </summary>
        /// <param name="code"></param>
        bool ChekcCode(int code);

        /// <summary>
        /// 添加或更新消息
        /// </summary>
        /// <param name="code">消息码</param>
        /// <param name="msg">消息</param>
        /// <returns></returns>
        string AddOrUpdateMsg(int code, string msg);

        /// <summary>
        /// 获取消息,获取失败时返回null
        /// </summary>
        /// <param name="code">消息码</param>
        /// <returns></returns>
        string GetMsg(int code);

        /// <summary>
        /// 获取所有消息集合
        /// </summary>
        /// <returns></returns>
        Dictionary<int, string> GetAllMsg();
    }
}