﻿using System;
using GMP.Exceptions;

namespace GMP.Localization.Abstractions.LocalContainer
{
    public static class ILocalContainerExtensions
    {
        /// <summary>
        ///  检查Code是否配置,未配置时抛出异常
        /// </summary>
        /// <param name="localContainer"></param>
        /// <param name="code"></param>
        public static void ChekcCodeWithException(this ILocalContainer localContainer, int code)
        {
            localContainer.CheckNullOrEmptyWithException(nameof(localContainer));

            bool isExist = localContainer.ChekcCode(code);
            if (!isExist)
            {
                throw new ArgumentException($"消息Key不存在，请检查是否配置", nameof(code));
            }
        }

        #region 获取消息

        /// <summary>
        /// 尝试获取消息,获取失败时返回默认值
        /// </summary>
        /// <param name="localContainer"></param>
        /// <param name="code"></param>
        /// <param name="defaultMsg"></param>
        /// <returns></returns>
        public static string TryGetMsg(
            this ILocalContainer localContainer,
            int code,
            string defaultMsg = "")
        {
            localContainer.CheckNullOrEmptyWithException(nameof(localContainer));

            return localContainer.GetMsg(code) ?? defaultMsg;
        }

        /// <summary>
        /// 获取消息,失败时抛出异常
        /// </summary>
        /// <param name="code"></param>
        /// <param name="localContainer"></param>
        /// <exception cref="ArgumentException"></exception>
        /// <returns></returns>
        public static string GetMsgWithException(
            this ILocalContainer localContainer,
            int code)
        {
            localContainer.ChekcCodeWithException(code);
            return localContainer.GetMsg(code);
        }

        #endregion 获取消息

        /// <summary>
        /// 快速构建<see cref="GmpException"/>
        /// </summary>
        /// <param name="code"></param>
        /// <param name="localContainer"></param>
        /// <param name="errorData"></param>
        /// <returns></returns>
        public static GmpException Throw(
            this ILocalContainer localContainer,
            int code,
            object errorData = null)
        {
            localContainer.ChekcCodeWithException(code);
            throw GmpException.New(code, localContainer.GetMsg(code), errorData ?? new object());
        }
    }
}