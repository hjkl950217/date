﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-29 星期二 15:38:20
*
***************************************************************************/

using System.Collections.Generic;

namespace GMP.Localization.Abstractions
{
    /// <summary>
    /// 多语言信息服务
    /// </summary>
    public interface ILocalInfoService
    {
        /// <summary>
        /// 获取所有消息集合
        /// </summary>
        /// <returns>消息集合</returns>
        public Dictionary<int, string> GetErrorCodes();

        /// <summary>
        /// 获取所有业务枚举结构
        /// </summary>
        /// <param name="isZhKey">是否返回中文key</param>
        /// <returns>枚举结构</returns>
        Dictionary<string, IDictionary<string, string>> GetBizEnum(bool isZhKey = true);
    }
}