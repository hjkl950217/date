﻿using System;
using System.Collections.Generic;
using System.Text;
using GMP.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace GMP.Localization.Abstractions.LocalInfo
{
    public static class ILocalInfoServiceExtensions
    {
        private static readonly JsonSerializerSettings jsonSetting;

        static ILocalInfoServiceExtensions()
        {
            jsonSetting = JsonSerializerSettingConst.SetOrCreateSettingForStorage();
            jsonSetting.ContractResolver = new CamelCasePropertyNamesContractResolver();
            jsonSetting.Formatting = Formatting.Indented;
        }

        /// <summary>
        /// 获取所有业务枚举结构转换成字符串
        /// </summary>
        /// <param name="localInfoService"></param>
        /// <param name="isZhKey">是否返回中文key</param>
        /// <returns>枚举结构</returns>
        public static string GetBizEnumToString(
            this ILocalInfoService localInfoService,
            bool isZhKey = true)
        {
            //查询枚举结构
            Dictionary<string, IDictionary<string, string>> enumInfos = localInfoService.GetBizEnum(isZhKey);

            //转换
            string result;
            if (!isZhKey)
            {
                result = enumInfos.ToJsonStorageExt(ILocalInfoServiceExtensions.jsonSetting);
            }
            else
            {
                StringBuilder stringBuilder = new StringBuilder();
                foreach (KeyValuePair<string, IDictionary<string, string>> item in enumInfos)
                {
                    stringBuilder.AppendLine(item.Key);

                    foreach (KeyValuePair<string, string> valueItem in item.Value)
                    {
                        stringBuilder.AppendLine($"    {valueItem.Key}={valueItem.Value}");
                    }
                    stringBuilder.AppendLine();
                }

                result = stringBuilder.ToString();
            }

            //返回
            return result;
        }
    }
}