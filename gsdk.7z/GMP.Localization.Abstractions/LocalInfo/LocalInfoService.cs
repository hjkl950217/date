﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-29 星期二 15:38:20
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using GMP.Helper;
using GMP.Helper.Model;
using GMP.Localization.Abstractions.LocalContainer;

namespace GMP.Localization.Abstractions
{
    /// <summary>
    /// 多语言信息服务-实现
    /// </summary>
    public class LocalInfoService : ILocalInfoService
    {
        /// <summary>
        /// 【由框架注册】项目中其中一个业务枚举的type信息,用于查找业务枚举结构
        /// </summary>
        public static Type bizEnumTypeInfo = null;

        public static List<Type> appendEnumTypeInoList = new List<Type>();

        private readonly ILocalContainer localContainer;

        public LocalInfoService(ILocalContainer localContainer)
        {
            this.localContainer = localContainer;
        }

        /// <summary>
        /// 获取所有消息集合
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, string> GetErrorCodes()
        {
            return this.localContainer.GetAllMsg();
        }

        #region 获取所有业务枚举结构

        /// <summary>
        /// 业务枚举结构-中文
        /// </summary>
        private static readonly Lazy<Dictionary<string, IDictionary<string, string>>> bizEnum_ZH = new Lazy<Dictionary<string, IDictionary<string, string>>>(() =>
                                                                                         {
                                                                                             return BuildBizEnumStruct(true);
                                                                                         });

        /// <summary>
        /// 业务枚举结构-英文
        /// </summary>
        private static readonly Lazy<Dictionary<string, IDictionary<string, string>>> bizEnum_EN = new Lazy<Dictionary<string, IDictionary<string, string>>>(() =>
                                                                                         {
                                                                                             return BuildBizEnumStruct(false);
                                                                                         });

        private static IDictionary<string, string> GetEnumStructZH(Type type)
        {
            IReadOnlyList<EnumValueData> enumInfos = EnumHelper.GetEnumInfo(type);
            Type desAttrType = typeof(KeyDescriptionAttribute);

            Dictionary<string, string> result = new Dictionary<string, string>();
            int errorCount = 0;
            foreach (EnumValueData item in enumInfos)
            {
                KeyDescriptionAttribute keyDescr = item.AttributeList
                    ?.FirstOrDefault(t => t is KeyDescriptionAttribute) as KeyDescriptionAttribute;
                if (keyDescr == null)
                {
                    errorCount++;
                    break;
                }

                try
                {
                    result.Add(keyDescr.Name, item.BaseValueString);
                }
                catch (Exception ex)
                {
                    throw new Exception($"添加中文键值对描述出错,类型:{type.Name},键:{keyDescr.Name}");
                }
            }

            //提示错误-如果有
            if (errorCount > 0)
            {
                throw new Exception("生成中文描述失败,请检查KeyDescriptionAttribute是否添加完毕。类型为:" + type.Name);
            }

            return result;
        }

        /// <summary>
        /// 构建业务枚举结构
        /// </summary>
        /// <param name="isZhKey"></param>
        /// <returns></returns>
        private static Dictionary<string, IDictionary<string, string>> BuildBizEnumStruct(bool isZhKey)
        {
            if (LocalInfoService.bizEnumTypeInfo == null)
            {
                return new Dictionary<string, IDictionary<string, string>>();
            }

            Func<Type, bool> isBizEnum = t => t.FullName.StartsWith(LocalInfoService.bizEnumTypeInfo.Namespace);
            Func<Type, bool> typeJudge = t =>
                t.IsEnum
                && isBizEnum(t);

            Func<Type, string> buildKey = t => isZhKey
                ? t.GetCustomAttribute<DescriptionAttribute>()?.Description
                : t.Name;

            Func<Type, string> tryBuildKey = t =>
            {
                string key = buildKey(t);
                if (key.IsNullOrEmpty())
                {
                    throw new ArgumentException(t.FullName + "  key is null");
                }

                return key;
            };

            Func<Type, IDictionary<string, string>> buildValue = t => isZhKey
                ? GetEnumStructZH(t)
                : EnumHelper.GetEnumStruct(t);

            //查找
            IEnumerable<Type> typeList = LocalInfoService.bizEnumTypeInfo.Assembly.GetExportedTypes()
                .Where(typeJudge)
                .Concat(LocalInfoService.appendEnumTypeInoList)
                .Distinct()
                .OrderBy(t => t.Name);

            Dictionary<string, IDictionary<string, string>> result = typeList
                .ToDictionary(
                k => tryBuildKey(k),
                v => buildValue(v));

            return result;
        }

        /// <summary>
        /// 获取所有业务枚举结构
        /// </summary>
        /// <param name="isZhKey">是否返回中文key</param>
        /// <returns>枚举结构</returns>
        Dictionary<string, IDictionary<string, string>> ILocalInfoService.GetBizEnum(bool isZhKey)
        {
            Dictionary<string, IDictionary<string, string>> result = isZhKey
                ? bizEnum_ZH.Value
                : bizEnum_EN.Value;

            return result;
        }

        #endregion 获取所有业务枚举结构
    }
}