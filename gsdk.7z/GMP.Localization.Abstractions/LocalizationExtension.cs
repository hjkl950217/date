﻿using System;
using GMP.Localization.Abstractions;
using GMP.Localization.Abstractions.Helper;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Localization扩展
    /// </summary>
    public static class LocalizationExtension
    {
        /// <summary>
        /// 添加Localization服务-程序内
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configAction"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder AddGmpLocalization(
            this IServiceCollection services,
             Action<GmpLocalizationOption> configAction = null)
        {
            //准备配置
            GmpLocalizationOption configObj = new GmpLocalizationOption();
            configAction?.Invoke(configObj);

            //准备builder
            GMPLocalizationBuilder localizationBuilder = new GMPLocalizationBuilder(configObj, services);

            //注册基本服务
            localizationBuilder.Services.AddTransient(di => GmpLocalHelper.GetLocalContainer());
            localizationBuilder.Services.AddSingleton<ILocalInfoService, LocalInfoService>();

            return localizationBuilder;
        }
    }
}