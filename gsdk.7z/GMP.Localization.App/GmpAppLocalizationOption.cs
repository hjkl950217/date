﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

using System;
using System.Collections.Generic;

namespace GMP.Localization.App
{
    /// <summary>
    /// 多语言配置模型-程序内
    /// </summary>
    public class GmpAppLocalizationOption : ICloneable
    {
        public GmpAppLocalizationOption()
        {
            this.LocalizationTypeList = new List<Type>();
        }

        #region 多语言定义的类

        /// <summary>
        ///  是否软删除
        /// </summary>
        public List<Type> LocalizationTypeList { get; }

        #endregion 多语言定义的类

        /// <summary>
        /// 浅拷贝(this为空时报错)
        /// </summary>
        /// <returns></returns>
        public GmpAppLocalizationOption Clone()
        {
            return (this as ICloneable).Clone() as GmpAppLocalizationOption;
        }

        object ICloneable.Clone()
        {
            if (this == null)
            {
                throw new ArgumentNullException(" object is null in clone!");
            }

            return this.MemberwiseClone();
        }
    }
}