﻿using System;
using System.Linq;
using GMP.Localization.App.Helper;

namespace GMP.Localization.App
{
    public static class GmpAppLocalizationOptionExtensions
    {
        public static GmpAppLocalizationOption InitContainerByScan(
            this GmpAppLocalizationOption option,
            params Type[] types)
        {
            option.CheckNullOrEmptyWithException(nameof(option));

            if (types.IsNullOrEmpty()) return option;

            //不存在才添加,存在时不需要覆盖 type信息全局是一样的
            foreach (Type item in types)
            {
                bool isExists = option.LocalizationTypeList.Any(t => t == item);
                if (!isExists) option.LocalizationTypeList.Add(item);
            }

            //扫描添加
            GmpAppLocalInitHelper.InitContainerByScan(option.LocalizationTypeList);

            return option;
        }
    }
}