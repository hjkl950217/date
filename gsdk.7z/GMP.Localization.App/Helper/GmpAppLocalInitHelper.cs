﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-08 星期二 10:02:56
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using GMP.Localization.Abstractions.Helper;
using GMP.Localization.Abstractions.LocalContainer;
using GMP.Localization.App.MsgContainer;

namespace GMP.Localization.App.Helper
{
    /// <summary>
    /// 应用多语言初始化帮助类
    /// </summary>
    internal static class GmpAppLocalInitHelper
    {
        #region 初始化

        internal static void InitContainer(ILocalContainer localContainer = null)
        {
            localContainer ??= new DefaultLocalContainer();
            GmpLocalHelper.InitContainer(localContainer);
        }

        internal static void InitContainerByScan(IEnumerable<Type> types)
        {
            //初始化
            GmpAppLocalInitHelper.InitContainer(new DefaultLocalContainer());
            if (types.IsNullOrEmpty()) return;

            //扫描
            IEnumerable<FieldInfo> msgQuery = types.SelectMany(t => t
                    .GetFields(BindingFlags.Public
                    | BindingFlags.Static
                    | BindingFlags.FlattenHierarchy))
                .Where(fi => fi.IsLiteral && !fi.IsInitOnly);//查找常量

            foreach (FieldInfo item in msgQuery)
            {
                int key = (int)item.GetValue(null);

                DescriptionAttribute msgAttr = item.GetCustomAttributes<DescriptionAttribute>()
                    .FirstOrDefault();
                if (msgAttr == null || msgAttr.Description.IsNullOrEmpty())
                {
                    throw new SystemException($"初始化信息失败,存在常量未配置{nameof(DescriptionAttribute)},类:{item.DeclaringType.Name} 字段:{item.Name}");
                }
                string value = msgAttr.Description;

                GmpLocalHelper.GetLocalContainer().AddOrUpdateMsg(key, value);
            }

            GmpLocalHelper.GetLocalContainer().AddOrUpdateMsg(200, "操作成功");//200是定义在GMP.ApiClient.ErrorCodes 中的默认值
        }

        #endregion 初始化
    }
}