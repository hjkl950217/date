﻿using System.Collections.Generic;
using GMP.Localization.Abstractions.LocalContainer;

namespace GMP.Localization.App.MsgContainer
{
    /// <summary>
    /// 默认消息集合
    /// </summary>
    public class DefaultLocalContainer : ILocalContainer
    {
        /// <summary>
        /// 消息集合
        /// </summary>
        /// <remarks>
        /// 由框架启动时生成,代码中保持new即可
        /// </remarks>
        protected Dictionary<int, string> MsgDic { get; private set; }

        public DefaultLocalContainer()
        {
            this.MsgDic = new Dictionary<int, string>();
        }

        public string AddOrUpdateMsg(int code, string msg)
        {
            this.MsgDic.AddOrUpdate(code, msg);
            return msg;
        }

        public bool ChekcCode(int code)
        {
            return this.MsgDic.ContainsKey(code);
        }

        public Dictionary<int, string> GetAllMsg()
        {
            return this.MsgDic;
        }

        public string GetMsg(int code)
        {
            return this.MsgDic.GetOrDefault(code);
        }
    }
}