﻿using System;
using GMP.Localization.Abstractions;
using GMP.Localization.App;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Localization扩展
    /// </summary>
    public static class LocalizationExtension
    {
        /// <summary>
        /// 添加Localization服务-程序内
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="configAction"></param>
        /// <returns></returns>
        public static GMPLocalizationBuilder AddAppLocalization(
            this GMPLocalizationBuilder builder,
             Action<GmpAppLocalizationOption> configAction = null)
        {
            //准备配置
            GmpAppLocalizationOption configObj = new GmpAppLocalizationOption();
            configAction?.Invoke(configObj);

            return builder;
        }
    }
}