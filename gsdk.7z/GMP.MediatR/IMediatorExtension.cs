﻿using System;
using System.Threading.Tasks;
using GMP.MsgBus.MediatR;

namespace MediatR
{
    public static class IMediatorExtension
    {
        /// <summary>
        /// 发送消息，自适应单播或多播
        /// </summary>
        /// <param name="mediator"></param>
        /// <param name="msgInfo"></param>
        /// <returns></returns>
        /// <exception cref="NotSupportedException"></exception>
        public static Task PushAsync(
            this IMediator mediator,
            IMsgInfo msgInfo)
        {
            if(msgInfo is NfBase nf)
            {
                return mediator.Publish(nf);
            }

            if(msgInfo is InfoBase ib)
            {
                return mediator.Send(ib);
            }

            throw new NotSupportedException("不支持的消息类型");
        }
    }
}