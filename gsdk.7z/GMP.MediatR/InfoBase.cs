﻿using MediatR;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// [单播]消息总线-消息基类
    /// </summary>
    public abstract class InfoBase : MsgInfo, IRequest<Unit>
    {
        protected InfoBase(string sendSource) : base(sendSource)
        {
        }
    }
}