﻿using System.Reflection;
using MediatR;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Swagger配置
    /// </summary>
    public static class MediatRExtenison
    {
        /// <summary>
        /// 注册swagger文档服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="assemblies">handle所在的程序集</param>
        public static IServiceCollection AddGmpMediatR(
            this IServiceCollection services,
            params Assembly[] assemblies
            )
        {
            services.AddMediatR(assemblies);

            return services;
        }
    }
}