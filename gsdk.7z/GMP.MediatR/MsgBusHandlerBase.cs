﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// 消息处理器-基类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class MsgBusHandlerBase<T>
        where T : IMsgInfo
    {
        protected readonly IServiceScopeFactory scopeFactory;

        public MsgBusHandlerBase(IServiceScopeFactory scopeFactory)
        {
            this.scopeFactory = scopeFactory;
        }

        public async Task Handle(T request)
        {
            try
            {
                //准备参数
                await using AsyncServiceScope scope = this.scopeFactory.CreateAsyncScope();//创建Scope
                this.ResolveService(scope.ServiceProvider);//让子类从DI获取服务
                using DbContext ctx = scope.ServiceProvider
                    .GetRequiredService<DbContext>();//获取数据上下文

                //执行
                await this.HandleInternalAsync(request, ctx);
            }
            catch(Exception e)
            {
                Console.Error.WriteLine($"[{this.GetType().Name}执行处理时出错]:{e}");
            }
        }

        #region 子类方法

        /// <summary>
        /// [由子类实现] 在这个方法中配置需要从DI中获取的服务，不能从构造方法配置注入
        /// </summary>
        /// <param name="di"></param>
        protected abstract void ResolveService(IServiceProvider di);

        /// <summary>
        /// [由子类实现] 具体的处理逻辑
        /// </summary>
        /// <param name="request"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        protected abstract Task HandleInternalAsync(T request, DbContext context);

        #endregion 子类方法
    }
}