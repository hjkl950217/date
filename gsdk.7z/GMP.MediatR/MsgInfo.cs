﻿using System;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// 消息总线-通知基类
    /// </summary>
    public abstract class MsgInfo : IMsgInfo
    {
        /// <summary>
        /// 发送源头,一般为类名+方法,用于debug时溯源
        /// </summary>
        public string SendSource { get; }

        /// <summary>
        /// 发送时间,用于debug排查使用。一般为构建消息体的时间
        /// </summary>
        public DateTime SendTime { get; }

        /// <summary>
        ///
        /// </summary>
        /// <param name="sendSource">发送源头,一般为类名+方法,用于debug时溯源</param>
        protected MsgInfo(string sendSource)
        {
            this.SendSource = sendSource ?? throw new ArgumentNullException(nameof(sendSource));

            this.SendTime = DateTime.Now;
        }
    }
}