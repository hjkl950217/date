﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// 消息处理器-多播基类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class MulticastHandlerBase<T>
        : MsgBusHandlerBase<T>, INotificationHandler<T>
        where T : NfBase
    {
        public MulticastHandlerBase(IServiceScopeFactory scopeFactory)
            : base(scopeFactory)
        {
        }

        Task INotificationHandler<T>.Handle(T notification, CancellationToken cancellationToken)
        {
            return base.Handle(notification);
        }
    }
}