﻿using MediatR;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// [多播]消息总线-通知基类
    /// </summary>
    public abstract class NfBase : MsgInfo, INotification
    {
        protected NfBase(string sendSource) : base(sendSource)
        {
        }
    }
}