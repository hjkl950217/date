﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.MsgBus.MediatR
{
    /// <summary>
    /// 消息处理器-单播基类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class UnicastHandlerBase<T>
        : MsgBusHandlerBase<T>, IRequestHandler<T>
        where T : InfoBase
    {
        public UnicastHandlerBase(IServiceScopeFactory scopeFactory) : base(scopeFactory)
        {
        }

        async Task<Unit> IRequestHandler<T, Unit>.Handle(T request, CancellationToken cancellationToken)
        {
            await base.Handle(request);
            return Unit.Value;
        }
    }
}