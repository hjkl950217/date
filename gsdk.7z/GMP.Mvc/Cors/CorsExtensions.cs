﻿using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Mvc;

namespace Microsoft.AspNetCore.Builder
{
    /// <summary>
    /// cors扩展
    /// </summary>
    public static class CorsExtension
    {
        /// <summary>
        /// 启用跨域中间件
        /// </summary>
        /// <param name="builder"></param>
        /// <param name="otherOrigin">设置newegg以外的来源允许站点,如"gmpsoft.net"</param>
        /// <param name="preflightMaxAgeTicks">
        /// 指定可以缓存对预检请求的响应的时间。<para></para>
        /// 以tick为单位，默认为10分钟
        /// </param>
        /// <param name="isAlowAll">是否允许所有</param>
        /// <returns></returns>
        public static IApplicationBuilder UseGmpCors(
            this IApplicationBuilder builder,
            Action<List<string>> otherOrigin = null,
            long preflightMaxAgeTicks = 6000000000,
            bool isAlowAll = true)
        {
            #region 处理允许集合

            // 早期CORS是使用中间件重写响应头的
            //context.Response.Headers.Add("Access-Control-Allow-Origin" , "*");
            //context.Response.Headers.Add("Access-Control-Allow-Method" , new[] { "*" });
            //context.Response.Headers.Add("Content-Security-Policy" ,
            //    "default-src 'self' *.gmpsoft.com *.gmpsoft.cn 10.1.24.130:3000");

            string[] originList = CorsScriptMethod.BuildAllowOriginList(otherOrigin);

            #endregion 处理允许集合

            //配置
            builder.UseCors(t =>
            {
                //预检请求免请求的时间
                TimeSpan time = preflightMaxAgeTicks == 6000000000
                    ? new TimeSpan(TimeSpan.TicksPerMinute * 10)
                    : new TimeSpan(preflightMaxAgeTicks);

                //来源判断规则
                Func<string, bool> isOriginAllowed = null;
                if (isAlowAll)
                {
                    isOriginAllowed = t => true;
                }
                else
                {
                    isOriginAllowed = t => originList.Any(item => t.ToLower().Contains(item));
                }

                //配置规则
                t.AllowAnyHeader()//对应Access-Control-Expose-Headers
                 .AllowAnyMethod()//对应Access-Control-Allow-Methods
                 .AllowCredentials()//对应Access-Control-Allow-Credentials
                 .SetPreflightMaxAge(time)//对应Access-Control-Max-Age
                 .SetIsOriginAllowed(isOriginAllowed);//对应Access-Control-Allow-Origin
            });

            return builder;
        }
    }
}