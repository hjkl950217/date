﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Mvc
{
	/// <summary>
	/// 为跨域中间件准备的**脚本**代码
	/// <para>跨域配置是静态代码，内部方法是静态的。为方便测试才独立出来</para>
	/// </summary>
	public static class CorsScriptMethod
	{
		/// <summary>
		/// 构建允许的跨域集合
		/// <para>最后的白名单：默认允许+项目中配置的+其它来源 的交集</para>
		/// </summary>
		/// <param name="originConfigAction">配置来源的委托</param>
		/// <param name="otherAllowOrigin">要添加的允许列表集合</param>
		/// <returns></returns>
		public static string[] BuildAllowOriginList(
			Action<List<string>> originConfigAction = null,
			params string[] otherAllowOrigin)
		{
			// [1]默认允许集合
			List<string> originList = new List<string>()
			{
				"gmpsoft.net",
				"gmpsoft.com",
				"gmpsoft.cn",
				"localhost"
			};
			// [2]项目中配置的
			originConfigAction?.Invoke(originList);//不为空则用委托附加

			// [3]其它来源
			if (otherAllowOrigin != null)
			{
				originList.AddRange(otherAllowOrigin);
			}

			// [4] 去重
			string[] result = originList.Distinct().ToArray();

			// [5]返回
			return result;
		}
	}
}