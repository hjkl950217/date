﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2022/8/17 15:57:01
*
***************************************************************************/

namespace GMP
{
    /// <summary>
    /// Define commonly used <see cref="DataResult"/> return values.
    /// </summary>
    public partial class DataResult<T>
    {
        /// <summary>
        /// Indicates that the operation succeeded.
        /// </summary>
        new public static DataResult<T> OK { get { return new DataResult<T>("OK"); } }

        /// <summary>
        /// Indicates an error occurred during a client request.
        /// </summary>
        new public static DataResult<T> RequestError
        { get { return new DataResult<T>(ErrorCodes.REQUEST_FAILED, "An error occurred during a client request."); } }

        /// <summary>
        /// Indicates that the required parameters are missing.
        /// </summary>
        new public static DataResult<T> ArgumentsMissing
        { get { return new DataResult<T>(ErrorCodes.REQUEST_PARAMS_MISSING, "The required parameters are missing."); } }

        /// <summary>
        /// Indicates an internal server error.
        /// </summary>
        new public static DataResult<T> ServerError
        { get { return new DataResult<T>(ErrorCodes.SERVER_ERROR, "An internal server error."); } }
    }
}
