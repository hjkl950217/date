﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 11:41:48
*
***************************************************************************/

using Newtonsoft.Json;

namespace GMP
{
    /// <summary>
    /// Provides a wrapper type for data returned by an API interface.
    /// </summary>
    public partial class DataResult : IDataResult
    {
        /// <summary>
        /// Gets the error code.
        /// </summary>
        public int Code { get; protected set; }

        /// <summary>
        /// Gets the error message.
        /// </summary>
        public string Message { get; protected set; }

        /// <summary>
        /// 请求路径
        /// </summary>
        [JsonIgnore]
        public string RequestPath { get; protected set; }

        /// <summary>
        /// 调用堆栈
        /// </summary>
        [JsonIgnore]
        public string StackTrace { get; protected set; }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        public DataResult() : this(ErrorCodes.GLOBAL_SUCCESSED, string.Empty) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        public DataResult(int code) : this(code, string.Empty) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="message">Result message.</param>
        public DataResult(string message) : this(ErrorCodes.GLOBAL_SUCCESSED, message) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        /// <param name="message">Result message.</param>
        /// <param name="requestPath">request Path</param>
        /// <param name="stackTrace">stack Trace</param>
        [JsonConstructor]
        public DataResult(
            int code = ErrorCodes.GLOBAL_SUCCESSED,
            string message = "",
            string requestPath = "",
            string stackTrace = "")
        {
            this.Code = code;
            this.Message = message;
            this.RequestPath = requestPath;
            this.StackTrace = stackTrace;
        }

        /// <summary>
        /// Append the parameter name to <see cref="Message"/>.
        /// </summary>
        /// <param name="name">The parameter name.</param>
        /// <returns>The current <see cref="DataResult"/> instance.</returns>
        public DataResult Args(string name)
        {
            this.Message += $" Params is {name}.";
            return this;
        }
    }
}