﻿using System;
using GMP.Mvc.ErrorHandle;
using Microsoft.Extensions.DependencyInjection;

namespace Microsoft.AspNetCore.Builder
{
    /// <summary>
    /// 异常处理配置
    /// </summary>
    public static class ErrorHandlingExtension
    {
        /// <summary>
        /// 添加错误处理中间件服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configAction"></param>
        /// <returns></returns>
        public static IServiceCollection AddGmpGlobalErrorHandle(
            this IServiceCollection services,
            Action<GmpErrorHandleOption> configAction = null)
        {
            #region 准备配置

            GmpErrorHandleOption config = new GmpErrorHandleOption();
            configAction?.Invoke(config);

            services.AddSingleton<GmpErrorHandleOption>(t => { return config; });

            services.AddSingleton<GlobalErrorHandleMiddleware>();

            #endregion 准备配置

            return services;
        }

        /// <summary>
        /// 注册错误处理中间件
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseGmpGlobalErrorHandle(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GlobalErrorHandleMiddleware>();
        }
    }
}