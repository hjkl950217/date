﻿using System;
using System.Net;
using System.Threading.Tasks;
using GMP.Configuration.Env;
using GMP.Exceptions;
using GMP.Json;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace GMP.Mvc.ErrorHandle
{
    /// <summary>
    /// 错误中间件
    /// </summary>
    public class GlobalErrorHandleMiddleware : IMiddleware
    {
        private readonly GmpErrorHandleOption gmpErrorHandleOption;
        private readonly ILogger logger;

        /// <summary>
        /// 错误中间件写json时使用的配置
        /// </summary>
        internal static JsonSerializerSettings jsonSerializerSettings = JsonSerializerSettingConst.DefaultSetting;

        /// <summary>
        /// 初始化错误处理中间件
        /// </summary>
        /// <param name="next"></param>
        /// <param name="gmpErrorHandleOption"></param>
        /// <param name="logger"></param>
        public GlobalErrorHandleMiddleware(

            GmpErrorHandleOption gmpErrorHandleOption,
            ILogger<GlobalErrorHandleMiddleware> logger)
        {
            this.logger = logger;
            this.gmpErrorHandleOption = gmpErrorHandleOption ?? new GmpErrorHandleOption();
        }

        /// <summary>
        /// 执行中间件逻辑
        /// </summary>
        /// <param name="context"></param>
        /// <param name="next"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                //调用下一个中间件
                await next(context);
            }
            catch(GmpException ex)
            {
                //业务异常处理
                await this.HandleBusinessExceptionAsync(context, ex);
                this.logger.LogError(ex.ToString());
            }
            catch(Exception ex)
            {
                //程序异常处理
                string errorId = "0";
                switch(EnvHelper.GetEnvInfo().AppEnvType)
                {
                    case AppEnvType.Development:
                        await this.HandleExceptionAsync(context, ex, errorId);
                        this.logger.LogError(ex.ToString());
                        throw ex;

                    case AppEnvType.Develop:
                    case AppEnvType.Test:
                    case AppEnvType.AutoTest:
                    case AppEnvType.PerformanceTest:
                    case AppEnvType.Verification:
                    case AppEnvType.Product:

                        await this.HandleExceptionAsync(context, ex, errorId);
                        this.logger.LogError(ex.ToString());
                        break;

                    default:
                        break;
                }
            }
            finally
            {
                //其它异常
                IExceptionHandlerPathFeature data = context.Features.Get<IExceptionHandlerPathFeature>();
                if(data != null && data.Error != null)
                {
                    await this.HandleExceptionAsync(context, data.Error);
                }
            }
        }

        #region 异常处理

        /// <summary>
        /// 业务异常抛出
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        private Task HandleBusinessExceptionAsync(HttpContext context, GmpException ex)
        {
            context.Response.StatusCode = 200;
            context.Response.ContentType = ContentTypeConst.Json;

            IDataResult response = new DataResult<object>(
                code: ex.Code,
                message: ex.Message,
                data: ex.Data,
                requestPath: context.Request.Path,
                stackTrace: ex.StackTrace);

            return context.Response.WriteAsync(response.ToJsonExt(jsonSerializerSettings));
        }

        /// <summary>
        /// 原始异常抛出
        /// </summary>
        /// <param name="context">http上下文</param>
        /// <param name="ex">捕捉到的异常</param>
        /// <param name="errorId">已经纪录下日志的错误号</param>
        /// <returns></returns>
        private Task HandleExceptionAsync(HttpContext context, Exception ex, string errorId = null)
        {
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = ContentTypeConst.Json;

            IDataResult response = new DataResult<object>(
                code: context.Response.StatusCode,
                message: ex.Message,
                data: ex.Data,
                requestPath: context.Request.Path,
                stackTrace: ex.StackTrace);

            response = this.PrdMessage(response, errorId);
            return context.Response.WriteAsync(response.ToJsonExt(jsonSerializerSettings));
        }

        #endregion 异常处理

        #region 其它处理

        /// <summary>
        /// 针对PRD做的异常处理
        /// </summary>
        /// <param name="exceptionOut">要返回出去的异常对象</param>
        ///  <param name="errorId">已经记录日志的错误ID，方便找错</param>
        /// <returns></returns>
        private IDataResult PrdMessage(IDataResult exceptionOut, string errorId)
        {
            //如果以后需要区分环境，就需要写这里的代码
            //比如客户机不显示堆栈
            //if (true)
            //{
            //	exceptionOut.StackTrace = string.Empty;
            //	exceptionOut.Message = $"There are some exception in our system,We apologize for your inconvenience，please contact with our system administrator.[ErrorId:{errorId}]";
            //}

            return exceptionOut;
        }

        #endregion 其它处理
    }
}