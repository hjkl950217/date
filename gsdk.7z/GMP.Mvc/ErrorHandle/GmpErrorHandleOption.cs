﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

namespace GMP.Mvc.ErrorHandle
{
    /// <summary>
    /// 配置ErrorHandle的模型
    /// </summary>
    public class GmpErrorHandleOption
    {
        /// <summary>
        /// 初始化一个<see cref="GmpErrorHandleOption"/>实例
        /// </summary>
        public GmpErrorHandleOption()
        {
            // this.EnableCustomHttpStatusCode = false;
        }

        ///// <summary>
        ///// 启用自定义的HttpStatusCode,默认为false
        ///// </summary>
        ///// <remarks>
        ///// 默认情况下<see cref="GmpException"/>中的<see cref="GmpException.HttpStatusCode"/>会强制写为200,前端通过<see cref="GmpException.Code"/>去判断。开启此选项之后，发生<see cref="GmpException"/>时使用异常内的<see cref="GmpException.HttpStatusCode"/>
        ///// </remarks>
        //public bool EnableCustomHttpStatusCode { get; set; }
    }
}