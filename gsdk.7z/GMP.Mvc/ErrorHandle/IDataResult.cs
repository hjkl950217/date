﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 10:10:47
*
***************************************************************************/

namespace GMP
{
    /// <summary>
    /// Represents a return result.
    /// </summary>
    public interface IDataResult
    {
        /// <summary>
        /// Gets the error code.
        /// </summary>
        int Code { get; }

        /// <summary>
        /// Gets the error message.
        /// </summary>
        string Message { get; }

        /// <summary>
        /// 请求路径
        /// </summary>
        string RequestPath { get; }

        /// <summary>
        /// 调用堆栈
        /// </summary>
        string StackTrace { get; }
    }
}