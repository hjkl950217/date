﻿using System;
using System.Net;
using System.Reflection;
using FluentValidation.AspNetCore;
using GMP.Json;
using GMP.Mvc.ErrorHandle;
using GMP.Mvc.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Newtonsoft.Json.Serialization;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// MVC配置
    /// </summary>
    public static class MvcExtenstion
    {
        /// <summary>
        /// 注册路由、MVC和对应的服务配置
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setup">Setup类实例，一般在Setup类中使用传this即可</param>
        /// <param name="mvcCoreBuilderAction">自定义设置<see cref="IMvcCoreBuilder"/>，用于某些情况下可追加新的配置</param>
        /// <param name="mvcOptionAction">自定义设置<see cref="MvcOptions"/>，用于某些情况下可追加新的配置</param>
        public static IMvcCoreBuilder AddGmpMvcCore(
            this IServiceCollection services,
            object setup,
            Action<IMvcCoreBuilder> mvcCoreBuilderAction = null,
            Action<MvcOptions> mvcOptionAction = null)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            //配置路由匹配忽略大小写
            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
            });

            #region 配置MvcCore

            IMvcCoreBuilder mvcCore = services
                .AddMvcCore(opt =>
                {
                    //添加绑定模型时的验证
                    opt.Filters.Add<GmpValidationFilter>();

                    mvcOptionAction?.Invoke(opt);//追加自定义的配置
                })
                .AddControllersAsServices()
                .SetCompatibilityVersion(CompatibilityVersion.Latest)
                .AddApiExplorer()
                .ConfigureApiBehaviorOptions(options =>
                {
                    //支持模型状态过滤器（2.2以上需要手动配置）
                    //资料：https://docs.microsoft.com/en-us/aspnet/core/web-api/?view=aspnetcore-5.0#automatic-http-400-responses
                    options.SuppressModelStateInvalidFilter = true;
                });

            //配置Json序列化
            mvcCore.AddNewtonsoftJson(options =>
            {
                JsonSerializerSettingConst.SetOrCreateDefaultSetting(options.SerializerSettings);
                options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();//小写

                //同步配置异常中间件的json配置
                GlobalErrorHandleMiddleware.jsonSerializerSettings = options.SerializerSettings;
            });

            //添加请求参数验证器-注册webapi程序集的所有验证规则
            mvcCore.AddFluentValidation(fv =>
            {
                //这里setup实例对应的程序集才是webapi那个程序集
                //所以这样取才能取到最正确的
                fv.RegisterValidatorsFromAssembly(Assembly.GetAssembly(setup.GetType()));

                //兼容ASP.NET的内置验证
                fv.RunDefaultMvcValidationAfterFluentValidationExecutes = true;

                //隐式子属性验证
                //fv.ImplicitlyValidateChildProperties = true;

                //隐式验证集合类型
                //如果开启隐式子属性验证,则自动包括了验证集合。此时设置此属性，会忽略子属性验证配置
                //fv.ImplicitlyValidateRootCollectionElements = true;
            });

            //配置其它服务
            mvcCore.AddDataAnnotations();
            mvcCore.AddFormatterMappings();
            mvcCore.AddAuthorization();

            #endregion 配置MvcCore

            //添加CORS服务
            services.AddCors();

            //配置HTTP上下文访问器
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            //追加自定义配置
            mvcCoreBuilderAction?.Invoke(mvcCore);

            //配置https验证
            ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

            return mvcCore;
        }
    }
}