﻿using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using System.Threading;

namespace GMP.Mvc.StartTask
{
    /// <summary>
    /// 在启动前异步执行的任务
    /// </summary>
    /// <remarks>
    /// 任务开始运行的时机在进入中间件管道之前,可以使用到‘ConfigureServices’ 中配置的服务。<para></para>
    /// 服务实例是以<see cref="ServiceLifetime.Transient"/>注册的
    /// </remarks>
    public interface IOnStartupTaskAsync
    {
        Task ExecuteAsync(CancellationToken cancellationToken = default);
    }

    /* 用法 demo  原文是Lamond Lu的博客中的 ，地址：https://www.cnblogs.com/lwqlun/p/10354149.html
    public class AuditOrgInitStartupTask : IOnStartupTaskAsync
    {
        private readonly IServiceProvider serviceProvider;

        public AuditOrgInitStartupTask(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }

        public async Task ExecuteAsync(CancellationToken cancellationToken = default)
        {
            using IServiceScope scope = this.serviceProvider.CreateScope();
            RMSContext context = scope.ServiceProvider.GetRequiredService<RMSContext>();

            await Task.Run(() =>
            {
                AuditHelper.InitOrgDataByDb(context);
            });
        }
    }
     *
     */
}