﻿using GMP.Mvc.StartTask;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// 添加启动前执行的任务
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddOnStartupTask<T>(this IServiceCollection services)
            where T : class, IOnStartupTaskAsync
            => services.AddTransient<IOnStartupTaskAsync, T>();
    }
}