﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Extensions.DependencyInjection;
using GMP.Mvc.StartTask;

namespace Microsoft.Extensions.Hosting
{
    public static class StartupTaskWebHostExtensions
    {
        /// <summary>
        /// 异步启动,并且异步开始启动要执行的任务.需要将本方法替换掉 Program.Main中的Run. Main方法也需要修改成异步版本
        /// </summary>
        /// <param name="hostObj"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task RunWithTasksAsync(
            this IHost hostObj,
            CancellationToken cancellationToken = default)
        {
            IEnumerable<IOnStartupTaskAsync> startupTasks = hostObj.Services.GetServices<IOnStartupTaskAsync>();

            foreach (IOnStartupTaskAsync startupTask in startupTasks)
            {
                await startupTask.ExecuteAsync(cancellationToken);
            }

            await hostObj.RunAsync(cancellationToken);
        }
    }
}