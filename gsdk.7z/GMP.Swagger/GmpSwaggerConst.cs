﻿namespace GMP.Swagger
{
    /// <summary>
    ///
    /// </summary>
    public static class GmpSwaggerConst
    {
        /// <summary>
        /// 是否启用Swagger
        /// </summary>
        public const string Env_Enable_Swagger = "SWAGGER_ENABLE";
    }
}
