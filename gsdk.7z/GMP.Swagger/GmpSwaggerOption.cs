﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/19 星期一 18:10:27
*
***************************************************************************/

using System.Collections.Generic;
using Microsoft.OpenApi.Models;

namespace GMP.Swagger
{
    /// <summary>
    /// 配置Swagger的模型
    /// </summary>
    public class GmpSwaggerOption
    {
        /// <summary>
        /// 是否启用Swagger
        /// </summary>
        public bool IsEnbaleSwagger { get; set; }

        /// <summary>
        /// 分组的数据
        /// </summary>
        /// <remarks>
        /// 1.项目中有几个GroupName就需要写几乎个
        /// 2.Info的版本信息格式为:v1 v2  需要小写
        /// 3.版本建议传递对应Group中支持的最高版本
        /// 4.没有写GroupName特性的会在所有分组中
        /// </remarks>
        public IList<OpenApiInfo> ConfigList { get; set; }

        /// <summary>
        /// 需要包括的XML注释文件名,需要和对应的WebApi.Dll同级目录
        /// </summary>
        /// <remarks>
        /// 1.不要传递完全限定名
        /// 2.要让注释完整显示，需要让web项目的启动根目录有这些文件
        /// 3.默认扫描启动目录下的所有xml文件并注册，所以不用传递。如果你传递了值，则以你传递的为准
        /// </remarks>
        public IList<string> XmlFileNameList { get; set; }
    }
}