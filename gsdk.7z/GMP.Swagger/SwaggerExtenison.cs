﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using GMP.Configuration.Env;
using GMP.Swagger;
using Microsoft.AspNetCore.Builder;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;
using Swashbuckle.AspNetCore.Swagger;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Swagger配置
    /// </summary>
    public static class SwaggerExtenison
    {
        /// <summary>
        /// 默认swagger访问前缀
        /// </summary>
        public const string DefaultRoutPrefix = "doc";

        /// <summary>
        /// 注册swagger文档服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="setConfigAction"></param>
        public static IServiceCollection AddGmpSwagger(
            this IServiceCollection services,
            Action<GmpSwaggerOption> setConfigAction = null)
        {
            #region 是否开启判断和初始化数据

            if (services.Any(t => t.ServiceType == typeof(ISwaggerProvider)))
            {
                return services;//已经配置过 直接跳出
            }

            //初始化配置
            GmpSwaggerOption config = SwaggerExtenison.InitConfig();//获取一个初始化过的配置
            if (setConfigAction == null) setConfigAction = t => { };
            setConfigAction(config);//用传入的委托把config 初始化
            services.AddSingleton<GmpSwaggerOption>(t => { return config; });

            //文件和环境判断，不存在则不开启
            if (CheckXmlFile(config) == false) return services;
            //services.AddTransient(t => { return config; });//把配置放入服务集合中

            #endregion 是否开启判断和初始化数据

            #region swagger服务配置

            services.AddSwaggerGen(options =>
            {
                //options.DescribeAllEnumsAsStrings();//在描述枚举类型时使用枚举名称，而不是它们的整数值
                //新版的不支持，需要配置swagger的Newtonsoft.json支持,然后MVC使用Newtonsoft.json并且配置StringEnumConverter

                options.DescribeAllParametersInCamelCase();//让请求中的参数以驼峰命名出现
                //options.DescribeStringEnumsInCamelCase();//让枚举类型使用驼峰命名

                //启用swagger注释(并开启支持继承和多态支持)
                options.EnableAnnotations(enableAnnotationsForInheritance: true, enableAnnotationsForPolymorphism: true);

                //默认是以控制器名分组，暂时关闭这个
                //options.TagActionsBy(api => api.RelativePath);//API分组显示

                //按配置生成swagger文档
                foreach (OpenApiInfo item in config.ConfigList)
                {
                    /*
                     *  第一个参数：路由json文件时要用
                     *  第二个参数：页面上显示的数据。而API中配置的版本参数也需要后这里对应上
                     */

                    options.SwaggerDoc(item.Title, item);
                }

                //options.SwaggerDoc("v2", new Info
                //{
                //    Title = "MyApiDocV2",
                //    Version = "v2",
                //    Description = "第二版API",
                //    TermsOfService = "服务条款：巴拉巴拉巴拉...",
                //    Contact = new Contact() { Name = "wxy", Email = "wxy@a", Url = "http://a.com" }
                //});

                //用生成的XML注释文档增强SwaggerUI
                string basePath = AppContext.BaseDirectory;
                //string basePath = PlatformServices.Default.Application.ApplicationBasePath;
                foreach (string item in config.XmlFileNameList)
                {
                    string apiPath = Path.Combine(basePath, item);
                    options.IncludeXmlComments(apiPath, includeControllerXmlComments: true);//第2个参数为包括控制器注释
                }

                //是否忽略没有标记HTTP动词的方法
                //options.DocInclusionPredicate( ( docName , apiDesc ) =>
                //{
                //    if( apiDesc.HttpMethod == null ) return false;
                //    return true;
                //} );

                // 开启加权小锁
                options.OperationFilter<AddResponseHeadersFilter>();
                options.OperationFilter<AppendAuthorizeToSummaryOperationFilter>();

                // 在header中添加token，传递到后台
                options.OperationFilter<SecurityRequirementsOperationFilter>();

                // Jwt Bearer 认证，必须是 oauth2
                options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
                {
                    Description = "JWT授权(数据将在请求头中进行传输) 直接在下框中输入Bearer {token}（注意两者之间是一个空格）\"",
                    Name = "Authorization",//jwt默认的参数名称
                    In = ParameterLocation.Header,//jwt默认存放Authorization信息的位置(请求头中)
                    Type = SecuritySchemeType.ApiKey
                });
            });

            #endregion swagger服务配置

            //swagger添加Newtonsoft.json支持
            services.AddSwaggerGenNewtonsoftSupport();

            return services;
        }

        /// <summary>
        /// 配置Swagger请求
        /// </summary>
        /// <param name="app"></param>
        /// <param name="projectName">项目名,小写</param>
        /// <param name="routePrefix">
        /// 需要指定的路由前缀，默认为<see cref="SwaggerExtenison.DefaultRoutPrefix"/>，指定后的访问格式为{routPrefix}/
        /// </param>
        /// <remarks>
        /// <para>注意：需要配置的环境与注释文件同时满足才可以开启</para>
        /// 从GLOBAL_ROUTE_PREFIX环境变量或routPrefix参数中都取不到时默认路由前缀为<see cref="SwaggerExtenison.DefaultRoutPrefix"/>
        /// <para>优先级：</para>
        /// <para>1.routPrefix参数，访问格式为<paramref name="projectName"/>/<paramref name="routePrefix"/>/</para>
        /// <para>2.环境变量，访问格式为<see cref="SwaggerExtenison.GLOBAL_ROUTE_PREFIX"/>/<paramref name="routePrefix"/>/</para>
        /// <para>3.默认前缀，访问格式为 {host}/<paramref name="projectName"/>/<see cref="SwaggerExtenison.DefaultRoutPrefix"/></para>
        /// </remarks>
        /// <returns></returns>
        public static IApplicationBuilder UseGmpSwagger(
            this IApplicationBuilder app,
            string projectName,
            string routePrefix = SwaggerExtenison.DefaultRoutPrefix)
        {
            #region 是否开启判断和初始化数据

            //获取配置
            GmpSwaggerOption config = app.ApplicationServices.GetService<GmpSwaggerOption>();

            //文件和环境判断，不存在则不开启
            if (CheckXmlFile(config) == false) return app;

            #endregion 是否开启判断和初始化数据

            #region 处理Swagger访问前缀

            /*
             * 这一步生成的routeStr
             * 是直接在页面中输入{host}/{routeStr}访问Swagger用的
             *
             * GLOBAL_ROUTE_PREFIX是以前DAE1.0的路由前缀，新版不需要
             *
             */
            projectName = projectName?.Trim().ToLower();
            string routeStr = (routePrefix == null || routePrefix.Length == 0) == true
                     ? SwaggerExtenison.DefaultRoutPrefix
                     : $"{routePrefix}";
            routeStr ??= string.Empty;
            routeStr = routeStr?.Trim().ToLower();

            Console.WriteLine($"Swagger RoutePrefix：-{routeStr}-");

            #endregion 处理Swagger访问前缀

            #region json文件生成

            string jsonPrefix = string.Empty;

            /*
             * json文件前缀的处理
             *
             *
             * 这个前缀是生成的html js中访问数据时，使用的json地址
             *
             * 资源文件的生成不需要处理这个前缀
             * 但json的访问路径是生成在swagger的html js文件中的，所以要处理
             *
             *
             */

            //部署在开发环境时需要增加前缀
            string gRoutePrE = EnvHelper.EnvInfo.AppEnvType switch
            {
                AppEnvType.Develop => $"gmp/{projectName}",
                _ => string.Empty
            };
            if (!string.IsNullOrWhiteSpace(gRoutePrE)) jsonPrefix = $"{gRoutePrE}/{routeStr}";
            else jsonPrefix = routeStr;

            // 生成JSON文件的模版，生成json文件时的一些配置
            app.UseSwagger(c =>
            {
                //[swagger]这里的{documentName}就是注册服务时  SwaggerDoc方法的第一个参数
                c.RouteTemplate = routeStr + "/{documentName}/swagger.json";

                //处理swagger中发请求时的前缀
                /*
                 * swagger中请求时，curl中使用的地址，是从swagger.json文件中获取的
                 * 这里的处理就是当有全局前缀时，让生成的json文件中带上这个ID
                 */
                if (!string.IsNullOrWhiteSpace(gRoutePrE))
                {
                    c.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        swaggerDoc.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"/{gRoutePrE}" } };
                    });
                }
            });

            //允许中间件使用swagger-ui（HTML，JS，CSS等），指定SwaggerUI所需要的JSON文件路径。
            //地址不能与控制器的路由重复
            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = routeStr;//swagger首页地址，写1就是{host}/1
                foreach (OpenApiInfo item in config.ConfigList)
                {
                    //第二个参数 是右上角下拉框里面的数据
                    c.SwaggerEndpoint($"/{jsonPrefix}/{item.Title}/swagger.json", item.Title);
                }
            });

            #endregion json文件生成

            return app;
        }

        #region 私有工具方法

        /// <summary>
        /// 是否开启Swagger，需要环境或文件都要同时满足
        /// </summary>
        /// <returns></returns>
        private static bool CheckXmlFile(GmpSwaggerOption optObj)
        {
            //判断文件
            bool existList = optObj.XmlFileNameList
                .Select(t =>
                {
                    string basePath = AppDomain.CurrentDomain.BaseDirectory;//获取程序的基目录
                    string xmlPath = Path.Combine(basePath, t);//组合成完全限定名
                    return File.Exists(xmlPath);//判断是否存在
                })
                .All(t => t == true);

            return existList;//文件都要在才可以开启
        }

        /// <summary>
        /// 初始化一个Swagger配置
        /// </summary>
        /// <param name="option">初始化一个配置</param>
        /// <returns></returns>
        private static GmpSwaggerOption InitConfig(GmpSwaggerOption option = null)
        {
            option = option ?? new GmpSwaggerOption();

            //是否启用swagger
            string env_EnbaleSwagger = Environment.GetEnvironmentVariable(GmpSwaggerConst.Env_Enable_Swagger)?.Trim()?.ToLower();
            option.IsEnbaleSwagger = env_EnbaleSwagger != null && env_EnbaleSwagger.Length != 0 && env_EnbaleSwagger == "true";

            //xml文件-只有文件名
            option.XmlFileNameList = option.XmlFileNameList
                ?? Directory
                    .GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.xml")
                    .ToList();

            //api描述配置
            option.ConfigList = option.ConfigList ?? new List<OpenApiInfo>()
            {
                new OpenApiInfo (){ Title ="Api",Version="v1"}
            };

            return option;
        }

        #endregion 私有工具方法
    }
}