#生成的shell文件

ls -al
pwd #
