﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:07:01
*
***************************************************************************/

using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace GMP.Data.Audit
{
	public class AuditDbContext : DbContextBase
	{
		/// <summary>
		/// Represents all events.
		/// </summary>
		public DbSet<EformEagleEvents> Events { get; set; }

		/// <summary>
		/// Represents all actions.
		/// </summary>
		public DbSet<EformEagleActions> Actions { get; set; }

		/// <summary>
		/// Represents all signers.
		/// </summary>
		public DbSet<EformEagleSigners> Signers { get; set; }

		/// <summary>
		/// Represents all changed data.
		/// </summary>
		public DbSet<EformEagleChangeddata> ChangedDatas { get; set; }

		/// <summary>
		/// Represents all metadata.
		/// </summary>
		public DbSet<EformEagleMetadata> MetaDatas { get; set; }

		/// <summary>
		/// Gets all actions.
		/// </summary>
		/// <returns>All actions.</returns>
		public List<EformEagleActions> GetAllActions()
		{
			IQueryable<EformEagleActions> query = from a in this.Actions
												  where a.Validity == 1
												  select a;

			return query.ToList();
		}
	}
}