/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:14:06
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Audit
{
    /// <summary>
    /// eform_eagle_actions
    /// </summary>
    [Table("eform_eagle_actions")]
    public partial class EformEagleActions
    {
        /// <summary>
        /// Id
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("Id")]
        public string Id { get; set; }

        /// <summary>
        /// createTime
        /// </summary>
        [Column("createTime")]
        public DateTime CreateTime { get; set; }

        /// <summary>
        /// modifiedTime
        /// </summary>
        [Column("modifiedTime")]
        public DateTime ModifiedTime { get; set; }

        /// <summary>
        /// createId
        /// </summary>
        [Column("createId")]
        public string CreateId { get; set; }

        /// <summary>
        /// updateId
        /// </summary>
        [Column("updateId")]
        public string UpdateId { get; set; }

        /// <summary>
        /// Code
        /// </summary>
        [Column("Code")]
        public string Code { get; set; }

        /// <summary>
        /// Cn
        /// </summary>
        [Column("Cn")]
        public string Cn { get; set; }

        /// <summary>
        /// Tw
        /// </summary>
        [Column("Tw")]
        public string Tw { get; set; }

        /// <summary>
        /// En
        /// </summary>
        [Column("En")]
        public string En { get; set; }

        /// <summary>
        /// Ja
        /// </summary>
        [Column("Ja")]
        public string Ja { get; set; }

        /// <summary>
        /// Validity
        /// </summary>
        [Column("Validity")]
        public decimal? Validity { get; set; }

        /// <summary>
        /// Confirmation
        /// </summary>
        [Column("Confirmation")]
        public int? Confirmation { get; set; }

        /// <summary>
        /// Signature
        /// </summary>
        [Column("Signature")]
        public int? Signature { get; set; }

        /// <summary>
        /// Remarks
        /// </summary>
        [Column("Remarks")]
        public string Remarks { get; set; }
    }
}