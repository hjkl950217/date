/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:14:06
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Audit
{
	/// <summary>
	/// eform_eagle_changeddata
	/// </summary>
	[Table("eform_eagle_changeddata")]
	public partial class EformEagleChangeddata
	{
		/// <summary>
		/// Id
		/// </summary>
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Column("Id")]
		public string Id { get; set; }

		/// <summary>
		/// createTime
		/// </summary>
		[Column("createTime")]
		public DateTime CreateTime { get; set; }

		/// <summary>
		/// modifiedTime
		/// </summary>
		[Column("modifiedTime")]
		public DateTime ModifiedTime { get; set; }

		/// <summary>
		/// createId
		/// </summary>
		[Column("createId")]
		public string CreateId { get; set; }

		/// <summary>
		/// updateId
		/// </summary>
		[Column("updateId")]
		public string UpdateId { get; set; }

		/// <summary>
		/// EventId
		/// </summary>
		[Column("EventId")]
		public string EventId { get; set; }

		/// <summary>
		/// Filed
		/// </summary>
		[Column("Filed")]
		public string Filed { get; set; }

		/// <summary>
		/// Name
		/// </summary>
		[Column("Name")]
		public string Name { get; set; }

		/// <summary>
		/// OldValue
		/// </summary>
		[Column("OldValue")]
		public string OldValue { get; set; }

		/// <summary>
		/// OldText
		/// </summary>
		[Column("OldText")]
		public string OldText { get; set; }

		/// <summary>
		/// NewValue
		/// </summary>
		[Column("NewValue")]
		public string NewValue { get; set; }

		/// <summary>
		/// NewText
		/// </summary>
		[Column("NewText")]
		public string NewText { get; set; }

		/// <summary>
		/// Reason
		/// </summary>
		[Column("Reason")]
		public string Reason { get; set; }
	}
}