/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:14:07
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Audit
{
    /// <summary>
    /// eform_eagle_events
    /// </summary>
    [Table("eform_eagle_events")]
    public partial class EformEagleEvents
    {
        /// <summary>
        /// Id
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("Id")]
        public string Id { get; set; }

        /// <summary>
        /// createTime
        /// </summary>
        [Column("createTime")]
        public DateTime CreateTime { get; set; }

        /// <summary>
        /// modifiedTime
        /// </summary>
        [Column("modifiedTime")]
        public DateTime ModifiedTime { get; set; }

        /// <summary>
        /// createId
        /// </summary>
        [Column("createId")]
        public string CreateId { get; set; }

        /// <summary>
        /// updateId
        /// </summary>
        [Column("updateId")]
        public string UpdateId { get; set; }

        /// <summary>
        /// AppId
        /// </summary>
        [Column("AppId")]
        public string AppId { get; set; }

        /// <summary>
        /// OrgId
        /// </summary>
        [Column("OrgId")]
        public string OrgId { get; set; }

        /// <summary>
        /// OrgName
        /// </summary>
        [Column("OrgName")]
        public string OrgName { get; set; }

        /// <summary>
        /// UserName
        /// </summary>
        [Column("UserName")]
        public string UserName { get; set; }

        /// <summary>
        /// UserAccount
        /// </summary>
        [Column("UserAccount")]
        public string UserAccount { get; set; }

        /// <summary>
        /// OpTime
        /// </summary>
        [Column("OpTime")]
        public DateTime? OpTime { get; set; }

        /// <summary>
        /// Source
        /// </summary>
        [Column("Source")]
        public string Source { get; set; }

        /// <summary>
        /// ActionCode
        /// </summary>
        [Column("ActionCode")]
        public string ActionCode { get; set; }

        /// <summary>
        /// EventName
        /// </summary>
        [Column("EventName")]
        public string EventName { get; set; }

        /// <summary>
        /// Result
        /// </summary>
        [Column("Result")]
        public decimal? Result { get; set; }

        /// <summary>
        /// Remarks
        /// </summary>
        [Column("Remarks")]
        public string Remarks { get; set; }

        /// <summary>
        /// SnapshotId
        /// </summary>
        [Column("SnapshotId")]
        public string SnapshotId { get; set; }
    }
}