/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:14:08
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Audit
{
	/// <summary>
	/// eform_eagle_metadata
	/// </summary>
	[Table("eform_eagle_metadata")]
	public partial class EformEagleMetadata
	{
		/// <summary>
		/// Id
		/// </summary>
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Column("Id")]
		public string Id { get; set; }

		/// <summary>
		/// createTime
		/// </summary>
		[Column("createTime")]
		public DateTime CreateTime { get; set; }

		/// <summary>
		/// modifiedTime
		/// </summary>
		[Column("modifiedTime")]
		public DateTime ModifiedTime { get; set; }

		/// <summary>
		/// createId
		/// </summary>
		[Column("createId")]
		public string CreateId { get; set; }

		/// <summary>
		/// updateId
		/// </summary>
		[Column("updateId")]
		public string UpdateId { get; set; }

		/// <summary>
		/// EventId
		/// </summary>
		[Column("EventId")]
		public string EventId { get; set; }

		/// <summary>
		/// Key
		/// </summary>
		[Column("Key")]
		public string Key { get; set; }

		/// <summary>
		/// Value
		/// </summary>
		[Column("Value")]
		public string Value { get; set; }

		/// <summary>
		/// Category
		/// </summary>
		[Column("Category")]
		public string Category { get; set; }
	}
}