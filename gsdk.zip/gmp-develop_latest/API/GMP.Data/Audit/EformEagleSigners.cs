﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/24 15:14:24
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Audit
{
	[Table("eform_eagle_signers")]
	public partial class EformEagleSigners
	{
		/// <summary>
		/// Id
		/// </summary>
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Column("Id")]
		public string Id { get; set; }

		/// <summary>
		/// createTime
		/// </summary>
		[Column("createTime")]
		public DateTime CreateTime { get; set; }

		/// <summary>
		/// modifiedTime
		/// </summary>
		[Column("modifiedTime")]
		public DateTime ModifiedTime { get; set; }

		/// <summary>
		/// createId
		/// </summary>
		[Column("createId")]
		public string CreateId { get; set; }

		/// <summary>
		/// updateId
		/// </summary>
		[Column("updateId")]
		public string UpdateId { get; set; }

		/// <summary>
		/// EventId
		/// </summary>
		[Column("EventId")]
		public string EventId { get; set; }

		/// <summary>
		/// UserId
		/// </summary>
		[Column("UserId")]
		public string UserId { get; set; }

		/// <summary>
		/// Code
		/// </summary>
		[Column("Code")]
		public string Code { get; set; }

		/// <summary>
		/// Account
		/// </summary>
		[Column("Account")]
		public string Account { get; set; }

		/// <summary>
		/// Name
		/// </summary>
		[Column("Name")]
		public string Name { get; set; }

		/// <summary>
		/// SignTime
		/// </summary>
		[Column("SignTime")]
		public DateTime? SignTime { get; set; }
	}
}