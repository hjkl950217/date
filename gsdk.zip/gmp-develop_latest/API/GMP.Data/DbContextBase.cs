﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/13 9:37:39
*
***************************************************************************/

using GMP.Configuration;
using Microsoft.EntityFrameworkCore;

//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Logging.Debug;

namespace GMP.Data
{
	/// <summary>
	/// Provides a context base class to configure the database used by this context.
	/// </summary>
	public class DbContextBase : DbContext
	{
		/// <summary>
		/// Override this method to configure the database (and other options) to be used for this context.
		/// </summary>
		/// <param name="optionsBuilder">
		/// A builder used to create or modify options for this context. Databases (and other
		/// extensions) typically define extension methods on this object that allow you
		/// to configure the context.
		/// </param>
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			string conn = AppSettings.GetSection("mysql.conn").Value;
			//var logger = new LoggerFactory(new[] { new DebugLoggerProvider() });

			optionsBuilder.UseMySQL(conn);//.UseLoggerFactory(logger)
		}
	}
}