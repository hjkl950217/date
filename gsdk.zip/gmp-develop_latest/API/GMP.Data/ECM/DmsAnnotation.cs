﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/10 11:14:22
*
***************************************************************************/
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.ECM
{
    [Table("dms_annotation")]
    public partial class DmsAnnotation
    {

        /// <summary>
        /// auto_increment
        /// </summary>
        [Key]
        [Column("AnnotationId")]
        public int AnnotationId { get; set; }

        /// <summary>
        /// FileVerId
        /// </summary>
        [Column("FileVerId")]
        public int? FileVerId { get; set; }

        /// <summary>
        /// FileId
        /// </summary>
        [Column("FileId")]
        public int? FileId { get; set; }

        /// <summary>
        /// UserId
        /// </summary>
        [Column("UserId")]
        public string UserId { get; set; }

        /// <summary>
        /// UserIdentityId
        /// </summary>
        [Column("UserIdentityId")]
        public int? UserIdentityId { get; set; }

        /// <summary>
        /// UserName
        /// </summary>
        [Column("UserName")]
        public string UserName { get; set; }

        /// <summary>
        /// DateTimeCreated
        /// </summary>
        [Column("DateTimeCreated")]
        public DateTime? DateTimeCreated { get; set; }

        /// <summary>
        /// AnnotationPageNo
        /// </summary>
        [Column("AnnotationPageNo")]
        public int? AnnotationPageNo { get; set; }

        /// <summary>
        /// AnnotationTop
        /// </summary>
        [Column("AnnotationTop")]
        public decimal? AnnotationTop { get; set; }

        /// <summary>
        /// AnnotationLeft
        /// </summary>
        [Column("AnnotationLeft")]
        public decimal? AnnotationLeft { get; set; }

        /// <summary>
        /// AnnotationWidth
        /// </summary>
        [Column("AnnotationWidth")]
        public decimal? AnnotationWidth { get; set; }

        /// <summary>
        /// AnnotationHeight
        /// </summary>
        [Column("AnnotationHeight")]
        public decimal? AnnotationHeight { get; set; }

        /// <summary>
        /// AnnotationType
        /// </summary>
        [Column("AnnotationType")]
        public int? AnnotationType { get; set; }

        /// <summary>
        /// AnnotationContent
        /// </summary>
        [Column("AnnotationContent")]
        public string AnnotationContent { get; set; }
    }
}