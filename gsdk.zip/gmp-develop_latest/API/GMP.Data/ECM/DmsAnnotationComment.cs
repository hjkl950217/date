﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/10 11:20:48
*
***************************************************************************/
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.ECM
{
    [Table("dms_annotationcomment")]
    public partial class DmsAnnotationComment
    {

        /// <summary>
        /// auto_increment
        /// </summary>
        [Key]
        [Column("CommentId")]
        public int CommentId { get; set; }

        /// <summary>
        /// FileVerId
        /// </summary>
        [Column("FileVerId")]
        public int? FileVerId { get; set; }

        /// <summary>
        /// FileId
        /// </summary>
        [Column("FileId")]
        public int? FileId { get; set; }

        /// <summary>
        /// UserId
        /// </summary>
        [Column("UserId")]
        public string UserId { get; set; }

        /// <summary>
        /// UserIdentityId
        /// </summary>
        [Column("UserIdentityId")]
        public int? UserIdentityId { get; set; }

        /// <summary>
        /// UserName
        /// </summary>
        [Column("UserName")]
        public string UserName { get; set; }

        /// <summary>
        /// AnnotationId
        /// </summary>
        [Column("AnnotationId")]
        public int? AnnotationId { get; set; }

        /// <summary>
        /// ReplyToCommentId
        /// </summary>
        [Column("ReplyToCommentId")]
        public int? ReplyToCommentId { get; set; }

        /// <summary>
        /// DateTimeCreated
        /// </summary>
        [Column("DateTimeCreated")]
        public DateTime? DateTimeCreated { get; set; }

        /// <summary>
        /// CommentAnonymous
        /// </summary>
        [Column("CommentAnonymous")]
        public int? CommentAnonymous { get; set; }

        /// <summary>
        /// CommentContent
        /// </summary>
        [Column("CommentContent")]
        public string CommentContent { get; set; }
    }
}