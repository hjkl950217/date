﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/10 11:28:10
*
***************************************************************************/

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace GMP.Data.ECM
{
    public class DmsDbContext : DbContextBase
    {
        public DbSet<DmsAnnotation> Annotations { get; set; }
        public DbSet<DmsAnnotationComment> AnnotationComments { get; set; }

        public List<DmsAnnotation> GetAnnotationsByFileVerId(int fileVerId)
        {
            var query = from ann in Annotations 
                        where ann.FileVerId == fileVerId 
                        select ann;

            return query.ToList();
        }

        public List<DmsAnnotationComment> GetCommentsByAnnotationId(int annotationId)
        {
            var query = from comment in AnnotationComments
                        where comment.AnnotationId == annotationId
                        select comment;

            return query.ToList();
        }
    }
}