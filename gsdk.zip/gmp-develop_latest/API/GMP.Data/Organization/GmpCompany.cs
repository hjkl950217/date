/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/17 20:14:55
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	/// <summary>
	/// org_department
	/// </summary>
	[Table("gmp_org_company")]
	public partial class GmpCompany
	{
		[Key]
		[Column("id")]
		public string Id { get; set; }

		/// <summary>
		/// org_id
		/// </summary>
		[Column("org_id")]
		public string OrgId { get; set; }

		[Column("org_identityID")]
		public int OrgIdentityID { get; set; }

		/// <summary>
		/// org_code
		/// </summary>
		[Column("org_code")]
		public string OrgCode { get; set; }

		/// <summary>
		/// org_thirdPartId
		/// </summary>
		[Column("org_thirdPartId")]
		public string OrgThirdPartId { get; set; }

		/// <summary>
		/// org_masterPositionId
		/// </summary>
		[Column("org_masterPositionId")]
		public string OrgMasterPositionId { get; set; }

		/// <summary>
		/// org_masterPositionIdentityId
		/// </summary>
		[Column("org_masterPositionIdentityId")]
		public int? OrgMasterPositionIdentityId { get; set; }

		/// <summary>
		/// org_name
		/// </summary>
		[Column("org_name")]
		public string OrgName { get; set; }

		/// <summary>
		/// org_sort
		/// </summary>
		[Column("org_sort")]
		public int? OrgSort { get; set; }

		/// <summary>
		/// org_createTime
		/// </summary>
		[Column("org_createTime")]
		public DateTime? OrgCreateTime { get; set; }

		/// <summary>
		/// org_enableTime
		/// </summary>
		[Column("org_enableTime")]
		public DateTime? OrgEnableTime { get; set; }

		/// <summary>
		/// org_expirationTime
		/// </summary>
		[Column("org_expirationTime")]
		public DateTime? OrgExpirationTime { get; set; }

		/// <summary>
		/// org_path
		/// </summary>
		[Column("org_path")]
		public string OrgPath { get; set; }

		/// <summary>
		/// org_parentid
		/// </summary>
		[Column("org_parentid")]
		public string OrgParentId { get; set; }

		/// <summary>
		/// org_parentidentityId
		/// </summary>
		[Column("org_parentidentityId")]
		public int? OrgParentidentityId { get; set; }

		/// <summary>
		/// org_remark
		/// </summary>
		[Column("org_remark")]
		public string OrgRemark { get; set; }

		/// <summary>
		/// group
		/// </summary>
		[Column("group")]
		public int Group { get; set; }
	}
}