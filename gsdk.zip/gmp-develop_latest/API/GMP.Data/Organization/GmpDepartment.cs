/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/17 20:14:55
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	/// <summary>
	/// org_department
	/// </summary>
	[Table("gmp_org_department")]
	public partial class GmpDepartment
	{
		[Key]
		[Column("id")]
		public string Id { get; set; }

		[Column("dept_id")]
		public string DeptId { get; set; }

		[Column("dept_identityID")]
		public int DeptIdentityID { get; set; }

		[Column("dept_code")]
		public string DeptCode { get; set; }

		[Column("dept_thirdPartId")]
		public string DeptThirdPartId { get; set; }

		[Column("dept_masterPositionId")]
		public string DeptMasterPositionId { get; set; }

		[Column("dept_masterPositionIdentityId")]
		public int DeptMasterPositionIdentityId { get; set; }

		[Column("dept_name")]
		public string DeptName { get; set; }

		[Column("dept_sort")]
		public int DeptSort { get; set; }

		[Column("dept_createTime")]
		public DateTime? DeptCreateTime { get; set; }

		[Column("dept_enableTime")]
		public DateTime? DeptEnableTime { get; set; }

		[Column("dept_expirationTime")]
		public DateTime? DeptExpirationTime { get; set; }

		[Column("dept_path")]
		public string DeptPath { get; set; }

		[Column("dept_parentid")]
		public string DeptParentId { get; set; }

		[Column("dept_parentidentityId")]
		public int? DeptParentIdentityId { get; set; }

		[Column("dept_remark")]
		public string DeptRemark { get; set; }

		/// <summary>
		/// org_id
		/// </summary>
		[Column("org_id")]
		public string OrgId { get; set; }

		/// <summary>
		/// org_identityID
		/// </summary>
		[Column("org_identityID")]
		public int OrgIdentityID { get; set; }

		/// <summary>
		/// org_name
		/// </summary>
		[Column("org_name")]
		public string OrgName { get; set; }

		/// <summary>
		/// org_path
		/// </summary>
		[Column("org_path")]
		public string OrgPath { get; set; }

		/// <summary>
		/// group
		/// </summary>
		[Column("group")]
		public int Group { get; set; }
	}
}