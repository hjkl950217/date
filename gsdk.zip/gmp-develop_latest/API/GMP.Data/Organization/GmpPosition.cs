﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: long.wei 2020/12/30 17:02:08
*
***************************************************************************/

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	/// <summary>
	/// gmp_org_company
	/// </summary>
	[Table("gmp_org_position")]
	public partial class GmpPosition
	{
		/// <summary>
		/// id
		/// </summary>
		[Key]
		[Column("id")]
		public string Id { get; set; }

		/// <summary>
		/// position_id
		/// </summary>
		[Column("position_id")]
		public string PositionId { get; set; }

		/// <summary>
		/// position_identityID
		/// </summary>
		[Column("position_identityID")]
		public int PositionIdentityID { get; set; }

		/// <summary>
		/// position_code
		/// </summary>
		[Column("position_code")]
		public string PositionCode { get; set; }

		/// <summary>
		/// position_thirdPartId
		/// </summary>
		[Column("position_thirdPartId")]
		public string PositionThirdPartId { get; set; }

		/// <summary>
		/// position_parentId
		/// </summary>
		[Column("position_parentId")]
		public string PositionParentId { get; set; }

		/// <summary>
		/// position_name
		/// </summary>
		[Column("position_name")]
		public string PositionName { get; set; }

		/// <summary>
		/// position_levelId
		/// </summary>
		[Column("position_levelId")]
		public string PositionLevelId { get; set; }

		/// <summary>
		/// position_type
		/// </summary>
		[Column("position_type")]
		public string PositionType { get; set; }

		/// <summary>
		/// position_sort
		/// </summary>
		[Column("position_sort")]
		public string PositionSort { get; set; }

		/// <summary>
		/// position_createTime
		/// </summary>
		[Column("position_createTime")]
		public string EositionCreateTime { get; set; }

		/// <summary>
		/// position_enableTime
		/// </summary>
		[Column("position_enableTime")]
		public string PositionEnableTime { get; set; }

		/// <summary>
		/// position_expirationTime
		/// </summary>
		[Column("position_expirationTime")]
		public string PositionExpirationTime { get; set; }

		/// <summary>
		/// position_remark
		/// </summary>
		[Column("position_remark")]
		public string PositionRemark { get; set; }

		/// <summary>
		/// dept_id
		/// </summary>
		[Column("dept_id")]
		public string DeptId { get; set; }

		/// <summary>
		/// dept_parentId
		/// </summary>
		[Column("dept_parentId")]
		public string DeptParentId { get; set; }

		/// <summary>
		/// position_path
		/// </summary>
		[Column("position_path")]
		public string PositionPath { get; set; }

		/// <summary>
		/// dept_path
		/// </summary>
		[Column("dept_path")]
		public string DeptPath { get; set; }

		/// <summary>
		/// org_id
		/// </summary>
		[Column("org_id")]
		public string OrgId { get; set; }

		/// <summary>
		/// org_identityID
		/// </summary>
		[Column("org_identityID")]
		public int OrgIdentityID { get; set; }

		/// <summary>
		/// org_name
		/// </summary>
		[Column("org_name")]
		public string OrgName { get; set; }

		/// <summary>
		/// org_path
		/// </summary>
		[Column("org_path")]
		public string OrgPath { get; set; }

		/// <summary>
		/// group
		/// </summary>
		[Column("group")]
		public int Group { get; set; }
	}
}