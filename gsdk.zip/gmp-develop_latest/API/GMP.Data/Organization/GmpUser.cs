﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/11 16:18:32
*
***************************************************************************/

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	[Table("gmp_org_user")]
	public class GmpUser
	{
		[Key]
		[Column("id")]
		public string Id { get; set; }

		[Column("user_id")]
		public string UserId { get; set; }

		[Column("user_identityID")]
		public int UserIdentityID { get; set; }

		[Column("user_code")]
		public string UserCode { get; set; }

		[Column("user_account")]
		public string UserAccount { get; set; }

		[Column("user_name")]
		public string UserName { get; set; }

		[Column("user_email")]
		public string UserEmail { get; set; }

		[Column("user_mobile")]
		public string UserMobile { get; set; }

		[Column("user_telephone")]
		public string UserTelephone { get; set; }

		[Column("user_gender")]
		public int UserGender { get; set; }

		[Column("user_status")]
		public int UserStatus { get; set; }

		[Column("position_id")]
		public string PositionId { get; set; }

		[Column("position_identityID")]
		public int? PositionIdentityId { get; set; }

		[Column("position_code")]
		public string PositionCode { get; set; }

		[Column("position_name")]
		public string PositionName { get; set; }

		[Column("position_path")]
		public string PositionPath { get; set; }

		[Column("dept_id")]
		public string DeptId { get; set; }

		[Column("dept_identityID")]
		public int? DeptIdentityId { get; set; }

		[Column("dept_code")]
		public string DeptCode { get; set; }

		[Column("dept_name")]
		public string DeptName { get; set; }

		[Column("dept_path")]
		public string DeptPath { get; set; }

		[Column("org_id")]
		public string OrgId { get; set; }

		[Column("org_identityID")]
		public int? OrgIdentityId { get; set; }

		[Column("org_code")]
		public string OrgCode { get; set; }

		[Column("org_name")]
		public string OrgName { get; set; }

		[Column("org_path")]
		public string OrgPath { get; set; }

		[Column("main")]
		public int Main { get; set; }

		/// <summary>
		/// group
		/// </summary>
		[Column("group")]
		public int Group { get; set; }
	}
}