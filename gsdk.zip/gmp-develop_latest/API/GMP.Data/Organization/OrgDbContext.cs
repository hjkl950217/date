﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/11 19:04:39
*
***************************************************************************/

using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace GMP.Data.Organization
{
	public class OrgDbContext : DbContextBase
	{
		public DbSet<GmpCompany> Companies { get; set; }
		public DbSet<GmpDepartment> Departments { get; set; }
		public DbSet<GmpPosition> Positions { get; set; }
		public DbSet<GmpUser> Users { get; set; }
		public DbSet<OrgGroup> Groups { get; set; }
		public DbSet<OrgGroupMember> GroupMembers { get; set; }

		public GmpUser GetUserInfoById(string userId)
		{
			IQueryable<GmpUser> query = from u in this.Users
										where u.UserId == userId && u.Main == 1
										select u;

			return query.FirstOrDefault();
		}

		public GmpUser GetUserInfoByAccount(string account)
		{
			IQueryable<GmpUser> query = from u in this.Users
										where u.UserAccount == account && u.Main == 1
										select u;

			return query.FirstOrDefault();
		}

		public IEnumerable<GmpCompany> GetCompaniesByUserId(string userId)
		{
			IQueryable<GmpCompany> query = from c in this.Companies
										   join u in this.Users on c.OrgId equals u.OrgId
										   where u.UserId == userId
										   orderby c.OrgIdentityID ascending
										   select c;

			return query.ToList().Distinct();
		}

		public IEnumerable<GmpDepartment> GetDepartmentsByUserId(string userId)
		{
			IQueryable<GmpDepartment> query = from d in this.Departments
											  join u in this.Users on d.DeptId equals u.DeptId
											  where u.UserId == userId
											  select d;

			return query.ToList().Distinct();
		}

		public IEnumerable<GmpPosition> GetPositionsByUserId(string userId)
		{
			IQueryable<GmpPosition> query = from p in this.Positions
											join u in this.Users on p.PositionId equals u.PositionId
											where u.UserId == userId
											select p;

			return query.ToList().Distinct();
		}

		public IEnumerable<OrgGroup> GetGroupsByUserId(string userId)
		{
			IQueryable<OrgGroup> query = from g in this.Groups
										 join m in this.GroupMembers on g.GroupId equals m.GroupId
										 where m.MemberId == userId
										 select g;

			return query.ToList().Distinct();
		}
	}
}