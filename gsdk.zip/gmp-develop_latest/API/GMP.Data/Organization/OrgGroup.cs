/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/17 20:14:57
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	/// <summary>
	/// org_group
	/// </summary>
	[Table("org_group")]
	public partial class OrgGroup
	{
		/// <summary>
		/// auto_increment
		/// </summary>
		[Key]
		[Column("group_identityID")]
		public int GroupIdentityID { get; set; }

		/// <summary>
		/// group_id
		/// </summary>
		[Column("group_id")]
		public string GroupId { get; set; }

		/// <summary>
		/// group_code
		/// </summary>
		[Column("group_code")]
		public string GroupCode { get; set; }

		/// <summary>
		/// group_thirdPartId
		/// </summary>
		[Column("group_thirdPartId")]
		public string GroupThirdPartId { get; set; }

		/// <summary>
		/// group_name
		/// </summary>
		[Column("group_name")]
		public string GroupName { get; set; }

		/// <summary>
		/// group_type
		/// </summary>
		[Column("group_type")]
		public int? GroupType { get; set; }

		/// <summary>
		/// group_createTime
		/// </summary>
		[Column("group_createTime")]
		public DateTime GroupCreateTime { get; set; }

		/// <summary>
		/// group_creatorId
		/// </summary>
		[Column("group_creatorId")]
		public string GroupCreatorId { get; set; }

		/// <summary>
		/// group_sort
		/// </summary>
		[Column("group_sort")]
		public int? GroupSort { get; set; }

		/// <summary>
		/// group_remark
		/// </summary>
		[Column("group_remark")]
		public string GroupRemark { get; set; }
	}
}