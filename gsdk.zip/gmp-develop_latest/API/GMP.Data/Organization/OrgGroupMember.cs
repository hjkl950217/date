/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/17 20:14:57
*
***************************************************************************/

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Organization
{
	/// <summary>
	/// org_groupmember
	/// </summary>
	[Table("org_groupmember")]
	public partial class OrgGroupMember
	{
		/// <summary>
		/// auto_increment
		/// </summary>
		[Key]
		[Column("id")]
		public int Id { get; set; }

		/// <summary>
		/// group_id
		/// </summary>
		[Column("group_id")]
		public string GroupId { get; set; }

		/// <summary>
		/// member_id
		/// </summary>
		[Column("member_id")]
		public string MemberId { get; set; }

		/// <summary>
		/// member_type
		/// </summary>
		[Column("member_type")]
		public int MemberType { get; set; }
	}
}