﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/19 14:51:38
*
***************************************************************************/

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Process
{
	[Table("act_re_procdef")]
	public partial class ActReProcdef
	{
		/// <summary>
		/// ID_
		/// </summary>
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.None)]
		[Column("ID_")]
		public string ID { get; set; }

		/// <summary>
		/// REV_
		/// </summary>
		[Column("REV_")]
		public int? REV { get; set; }

		/// <summary>
		/// CATEGORY_
		/// </summary>
		[Column("CATEGORY_")]
		public string CATEGORY { get; set; }

		/// <summary>
		/// NAME_
		/// </summary>
		[Column("NAME_")]
		public string NAME { get; set; }

		/// <summary>
		/// KEY_
		/// </summary>
		[Column("KEY_")]
		public string KEY { get; set; }

		/// <summary>
		/// VERSION_
		/// </summary>
		[Column("VERSION_")]
		public int VERSION { get; set; }

		/// <summary>
		/// DEPLOYMENT_ID_
		/// </summary>
		[Column("DEPLOYMENT_ID_")]
		public string DEPLOYMENTID { get; set; }

		/// <summary>
		/// RESOURCE_NAME_
		/// </summary>
		[Column("RESOURCE_NAME_")]
		public string RESOURCENAME { get; set; }

		/// <summary>
		/// DGRM_RESOURCE_NAME_
		/// </summary>
		[Column("DGRM_RESOURCE_NAME_")]
		public string DGRMRESOURCENAME { get; set; }

		/// <summary>
		/// DESCRIPTION_
		/// </summary>
		[Column("DESCRIPTION_")]
		public string DESCRIPTION { get; set; }

		/// <summary>
		/// HAS_START_FORM_KEY_
		/// </summary>
		[Column("HAS_START_FORM_KEY_")]
		public int? HASSTARTFORMKEY { get; set; }

		/// <summary>
		/// HAS_GRAPHICAL_NOTATION_
		/// </summary>
		[Column("HAS_GRAPHICAL_NOTATION_")]
		public int? HASGRAPHICALNOTATION { get; set; }

		/// <summary>
		/// SUSPENSION_STATE_
		/// </summary>
		[Column("SUSPENSION_STATE_")]
		public int? SUSPENSIONSTATE { get; set; }

		/// <summary>
		/// TENANT_ID_
		/// </summary>
		[Column("TENANT_ID_")]
		public string TENANTID { get; set; }
	}
}