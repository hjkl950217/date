﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/10 9:52:19
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Process
{
    [Table("act_ru_task")]
    public partial class ActRuTask
    {

        /// <summary>
        /// ID_
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("ID_")]
        public string ID { get; set; }

        /// <summary>
        /// REV_
        /// </summary>
        [Column("REV_")]
        public int? REV { get; set; }

        /// <summary>
        /// EXECUTION_ID_
        /// </summary>
        [Column("EXECUTION_ID_")]
        public string EXECUTIONID { get; set; }

        /// <summary>
        /// PROC_INST_ID_
        /// </summary>
        [Column("PROC_INST_ID_")]
        public string PROCINSTID { get; set; }

        /// <summary>
        /// PROC_DEF_ID_
        /// </summary>
        [Column("PROC_DEF_ID_")]
        public string PROCDEFID { get; set; }

        /// <summary>
        /// NAME_
        /// </summary>
        [Column("NAME_")]
        public string NAME { get; set; }

        /// <summary>
        /// PARENT_TASK_ID_
        /// </summary>
        [Column("PARENT_TASK_ID_")]
        public string PARENTTASKID { get; set; }

        /// <summary>
        /// DESCRIPTION_
        /// </summary>
        [Column("DESCRIPTION_")]
        public string DESCRIPTION { get; set; }

        /// <summary>
        /// TASK_DEF_KEY_
        /// </summary>
        [Column("TASK_DEF_KEY_")]
        public string TASKDEFKEY { get; set; }

        /// <summary>
        /// OWNER_
        /// </summary>
        [Column("OWNER_")]
        public string OWNER { get; set; }

        /// <summary>
        /// ASSIGNEE_
        /// </summary>
        [Column("ASSIGNEE_")]
        public string ASSIGNEE { get; set; }

        /// <summary>
        /// DELEGATION_
        /// </summary>
        [Column("DELEGATION_")]
        public string DELEGATION { get; set; }

        /// <summary>
        /// PRIORITY_
        /// </summary>
        [Column("PRIORITY_")]
        public int? PRIORITY { get; set; }

        /// <summary>
        /// CREATE_TIME_
        /// </summary>
        [Column("CREATE_TIME_")]
        public DateTime? CREATETIME { get; set; }

        /// <summary>
        /// DUE_DATE_
        /// </summary>
        [Column("DUE_DATE_")]
        public DateTime? DUEDATE { get; set; }

        /// <summary>
        /// CATEGORY_
        /// </summary>
        [Column("CATEGORY_")]
        public string CATEGORY { get; set; }

        /// <summary>
        /// SUSPENSION_STATE_
        /// </summary>
        [Column("SUSPENSION_STATE_")]
        public int? SUSPENSIONSTATE { get; set; }

        /// <summary>
        /// TENANT_ID_
        /// </summary>
        [Column("TENANT_ID_")]
        public string TENANTID { get; set; }

        /// <summary>
        /// FORM_KEY_
        /// </summary>
        [Column("FORM_KEY_")]
        public string FORMKEY { get; set; }
    }
}

