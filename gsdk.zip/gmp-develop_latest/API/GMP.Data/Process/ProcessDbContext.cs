﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/13 14:44:38
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace GMP.Data.Process
{
    public class ProcessDbContext : DbContextBase
    {
        public DbSet<ActReProcdef> Definitions { get; set; }
        public DbSet<ActRuTask> Tasks { get; set; }

        public ActReProcdef GetProcessDefinitionByKey(string processKey)
        {
            if (string.IsNullOrEmpty(processKey)) throw new ArgumentException(nameof(processKey));

            IOrderedQueryable<ActReProcdef> query = from def in this.Definitions
                                                    where def.KEY == processKey
                                                    orderby def.VERSION descending
                                                    select def;

            return query.FirstOrDefault();
        }

        public List<ActRuTask> GetTaskByIncident(string incident)
        {
            var query = from task in Tasks
                        where task.PROCINSTID == incident
                        select task;

            return query.ToList();
        }


        private DbSet<ProcessInfo> _ProcessInfo { get; set; }

        public IQueryable<ProcessInfo> ProcessInfo
        {
            get
            {
                return this._ProcessInfo.FromSqlInterpolated(@$"
                    SELECT * from 
                    act_hi_procinst a
                    LEFT JOIN ext_deploy_info e on a.PROC_DEF_ID_=e.processDefId
                    ");
            }
        }
    }
}