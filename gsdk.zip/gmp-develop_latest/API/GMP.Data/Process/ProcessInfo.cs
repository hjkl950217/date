﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: C0620 2021/9/24 16:01:46
*
***************************************************************************/

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GMP.Data.Process
{
    public class ProcessInfo
    {
        [Key]
        [Column("ID_")]
        public int Id { get; set; }

        [Column("PROC_INST_ID_")]
        public string Incident { get; set; }

        [Column("BUSINESS_KEY_")]
        public string DataSourceId { get; set; }

        [Column("PROC_DEF_ID_")]
        public string Process { get; set; }

        [Column("START_TIME_")]
        public DateTime? StartTime { get; set; }

        [Column("END_TIME_")]
        public DateTime? EndTime { get; set; }

        [Column("START_USER_ID_")]
        public string CreateUserId { get; set; }

        [Column("formId")]
        public string FormId { get; set; }

        [Column("formVersion")]
        public string FormVersion { get; set; }

    }
}
