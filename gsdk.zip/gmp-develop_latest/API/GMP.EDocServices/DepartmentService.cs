﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/2 17:02:38
*
***************************************************************************/

using System;
using System.Collections.Generic;
using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.Model.Organization;
using EDoc2.Sdk;
using GMP.EDocServices.Model;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 department service.
	/// </summary>
	public class DepartmentService
	{
		private static readonly IOrgDepartmentAppService service = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Static constructor.
		/// </summary>
		static DepartmentService()
		{
			service = ServiceContainer.GetService<IOrgDepartmentAppService>();
		}

		/// <summary>
		///  Get a list of departments based on the user id.
		/// </summary>
		/// <param name="userId">The user id.</param>
		/// <returns>The user's department list.</returns>
		/// <exception cref="ArgumentNullException">The token or userId is empty or null.</exception>
		public static ReturnValueResult<List<DepartmentExtensionInfo>> GetDepartmentsByUserId(string userId)
		{
			if (string.IsNullOrEmpty(userId)) throw new ArgumentNullException(nameof(userId));

			string mainPositionId = "";
			List<string> deptIds = new List<string>();
			List<DepartmentExtensionInfo> depts = new List<DepartmentExtensionInfo>();

			//Get user position list.
			ReturnValueResult<List<PositionExtensionInfo>> positionRes = PositionService.GetPositionListByUserId(userId);
			if (positionRes.Result != 0)
			{
				throw new InvalidOperationException(positionRes.Message);
			}

			//Remove duplicates by department id.
			foreach (PositionExtensionInfo position in positionRes.Data)
			{
				if (deptIds.Contains(position.DepartmentId)) continue;
				deptIds.Add(position.DepartmentId);

				if (position.IsMain) mainPositionId = position.ID;
			}

			//Get department information based on department id.
			foreach (string deptId in deptIds)
			{
				ReturnValueResult<DepartmentInfo> deptRes = service.GetDepartmentInfoById(token, deptId);
				if (deptRes.Result != 0) continue;

				//Mark the main department.
				DepartmentExtensionInfo dept = ConvertDepartmentEntity(deptRes.Data);
				if (dept.ManagerPositionId == mainPositionId)
				{
					dept.IsMain = true;
				}

				depts.Add(dept);
			}

			return new ReturnValueResult<List<DepartmentExtensionInfo>>()
			{
				Result = ResultType.Success,
				Data = depts
			};
		}

		/// <summary>
		/// Coverts the <see cref="DepartmentInfo"/> to <see cref="DepartmentExtensionInfo"/>.
		/// </summary>
		/// <param name="info">A <see cref="DepartmentInfo"/>.</param>
		/// <returns>A <see cref="DepartmentExtensionInfo"/>.</returns>
		private static DepartmentExtensionInfo ConvertDepartmentEntity(DepartmentInfo info)
		{
			DepartmentExtensionInfo department = new DepartmentExtensionInfo();
			department.ID = info.ID;
			department.ParentId = info.ParentId;
			department.ParentIdentityId = info.ParentIdentityId;
			department.ParentName = info.ParentName;
			department.IdentityId = info.IdentityId;
			department.ThirdPartId = info.ThirdPartId;
			department.Code = info.Code;
			department.ManagerPositionId = info.ManagerPositionId;
			department.ManagerPositionIdentityId = info.ManagerPositionIdentityId;
			department.Name = info.Name;
			department.Sort = info.Sort;
			department.Remark = info.Remark;
			department.HaveChildren = info.HaveChildren;
			department.CreateTime = info.CreateTime;
			department.EnableTime = info.EnableTime;
			department.ExpirationTime = info.ExpirationTime;
			department.IsMain = false;

			return department;
		}
	}
}