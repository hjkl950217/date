﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: jiasong.ding 2020/11/18 9:22:03
*
***************************************************************************/

using System;
using System.Collections.Generic;
using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 document service.
	/// </summary>
	public class DocService
	{
		private static readonly IDocAppService docAppService = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Static constructor.
		/// </summary>
		static DocService()
		{
			docAppService = ServiceContainer.GetService<IDocAppService>();
		}

		/// <summary>
		/// Move the list of files and folders to a folder.
		/// </summary>
		/// <param name="token">The interface invokes the token.</param>
		/// <param name="targetFolderId">Target folder id.</param>
		/// <param name="folderIdList">List of folder ids that need to be moved.</param>
		/// <param name="fileIdList">List of file ids that need to be moved.</param>
		/// <returns></returns>
		public static ReturnValueResult<string> MoveFolderListAndFileList(int targetFolderId, List<int> folderIdList, List<int> fileIdList)
		{
			if (targetFolderId < 1) throw new ArgumentNullException(nameof(targetFolderId));
			//if ((folderIdList == null || folderIdList.Length < 1) && (fileIdList == null || fileIdList.Length < 1)) throw new ArgumentNullException(nameof(targetFolderId));

			MoveFileListAndFolderListDto dto = new MoveFileListAndFolderListDto()
			{
				TargetFolderId = targetFolderId,
				FileIdList = fileIdList,
				FolderIdList = folderIdList,
				Token = token
			};

			return docAppService.MoveFolderListAndFileList(dto);
		}

		public static ReturnValueResult<List<PermSummaryInfo>> GetFolderPermCatesByEntryType(int entryType, string lang = "")
		{
			if (entryType < 1) throw new ArgumentNullException(nameof(entryType));
			return docAppService.GetFolderPermCatesByEntryType(token, entryType, lang);
		}

		public static FileResult GetDocInfoByFileId(FileDto dto)
		{
			//    FileDto dto = new FileDto();
			//    dto.FileId = fileId;
			if (dto.FileId < 1) throw new ArgumentNullException(nameof(dto.FileId));
			return docAppService.GetFileById(dto);
		}

		/// <summary>
		/// Delete file and folder list
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> RemoveFolderListAndFileList(FileListAndFolderListDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return docAppService.RemoveFolderListAndFileList(dto);
		}
	}
}