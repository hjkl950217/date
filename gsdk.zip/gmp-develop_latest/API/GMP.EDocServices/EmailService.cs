﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: ty 2021/2/1 10:00:35
*
***************************************************************************/

using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
	public class EmailService
	{
		private static readonly IEmailAppService emailAppService = null;

		private static readonly string token = ServiceConfig.Token;

		static EmailService()
		{
			emailAppService = ServiceContainer.GetService<IEmailAppService>();
		}

		/// <summary>
		/// send email
		/// </summary>
		/// <param name="dto">email dto</param>
		/// <returns></returns>
		public static object SendEmail(SendSysMailMessageDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;

			return emailAppService.SendSysMailMessage(dto);
		}
	}
}