﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: jiasong.ding 2020/11/18 8:52:43
*
***************************************************************************/

using System.Collections.Generic;
using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.ResultModel;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 file service.
	/// </summary>
	public class FileService
	{
		private static readonly IFileAppService fileAppService = null;
		private static readonly IFilePermissionAppService filePermissionAppService = null;
		private static readonly IFileRelatedFileAppService fileRelatedFileAppService = null;
		private static readonly IFileAttachAppService fileAttachAppService = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Static constructor.
		/// </summary>
		static FileService()
		{
			fileAppService = ServiceContainer.GetService<IFileAppService>();
			filePermissionAppService = ServiceContainer.GetService<IFilePermissionAppService>();
			fileAttachAppService = ServiceContainer.GetService<IFileAttachAppService>();
			fileRelatedFileAppService = ServiceContainer.GetService<IFileRelatedFileAppService>();
		}

		/// <summary>
		/// 根据文件ID更新文件属性
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> ChangeFileById(UpdateFileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAppService.ChangeFileById(dto);
		}

		/// <summary>
		/// 发布文件版本
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<FileVersionInfoResult> PublishFileVersion(FileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAppService.PublishFileVersion(dto);
		}

		/// <summary>
		/// Customize the file version number
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<int> CustomFileVersionNumber(SetFileVerNumerDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAppService.CustomFileVersionNumber(dto);
		}

		/// <summary>
		/// 创建关联文件
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> CreateRelatedFileList(FileRelatedFileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileRelatedFileAppService.CreateRelatedFileList(dto);
		}

		/// <summary>
		/// Gets a list of associated files for a file
		/// </summary>
		/// <param name="fileId">file id</param>
		/// <param name="pageNumber">page index</param>
		/// <param name="pageSize">page size</param>
		/// <returns></returns>
		public static ReturnValueResult<GetRelatedFileListResult> GetRelatedFileList(int fileId, int pageNumber, int pageSize)
		{
			return fileRelatedFileAppService.GetBeRelatedFileList(token, fileId, pageNumber, pageSize);
		}

		/// <summary>
		/// Removes a list of associated files for a file
		/// </summary>
		/// <param name="dto">Associated file data model objects</param>
		/// <returns></returns>
		public static ReturnValueResult<string> RemoveRelatedFileList(FileRelatedFileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileRelatedFileAppService.RemoveRelatedFileList(dto);
		}

		/// <summary>
		/// 创建关联文件
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> CreateAttachFileList(FileAttachFileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAttachAppService.CreateAttachFileList(dto);
		}

		/// <summary>
		/// Gets a list of attachment files for a file
		/// </summary>
		/// <param name="fileId">file id</param>
		/// <param name="pageNumber">page index</param>
		/// <param name="pageSize">page size</param>
		/// <returns></returns>
		public static ReturnValueResult<GetAttachFileListResult> GetAttachFileList(int fileId, int pageNumber, int pageSize)
		{
			return fileAttachAppService.GetAttachFileList(token, fileId, pageNumber, pageSize);
		}

		/// <summary>
		/// Removes a list of attachment files to a file
		/// </summary>
		/// <param name="dto">Attach file data model objects</param>
		/// <returns></returns>
		public static ReturnValueResult<string> RemoveAttachFileList(FileAttachFileDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAttachAppService.RemoveAttachFileList(dto);
		}

		/// <summary>
		/// 批量设置文件权限
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> SetPermission(SetFilePermDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return filePermissionAppService.SetPermission(dto);
		}

		/// <summary>
		/// Get the file information based on the file ID
		/// </summary>
		/// <param name="fileId">fileId</param>
		/// <returns></returns>
		public static ReturnValueResult<FileInfoForSdkResult> GetFileInfoById(int fileId)
		{
			return fileAppService.GetFileInfoById(token, fileId);
		}

		/// <summary>
		/// Gets a list of files in the specified folder based on the folder ID
		/// </summary>
		/// <param name="folderId">folder Id</param>
		/// <returns></returns>
		public static ReturnValueResult<List<EDoc2File>> GetChildFileListByFolderId(int folderId)
		{
			return fileAppService.GetChildFileListByFolderId(token, folderId);
		}

		/// <summary>
		/// Modify file name
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> RenameFile(RenameDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return fileAppService.RenameFile(dto);
		}

		/// <summary>
		/// Get all file information under the folder by its ID
		/// </summary>
		/// <param name="token">token</param>
		/// <param name="folderId">folder id</param>
		/// <returns></returns>
		public static ReturnValueResult<List<EDoc2File>> GetChildFileListByFolderId(string token,int folderId) 
		{
			if (string.IsNullOrEmpty(token)) token = FileService.token;
			return fileAppService.GetChildFileListByFolderId(token, folderId);
		}

		/// <summary>
		/// 签入文件（解锁文件）
		/// </summary>
		/// <param name="fileId">文件ID</param>
		/// <returns></returns>
		public static ReturnValueResult<CheckInFileResult> CheckInFile(int fileId) 
		{
			CheckInFileDto checkInFile = new CheckInFileDto();
			checkInFile.Token = token;
			checkInFile.IsFileContentUpdate = true;
			checkInFile.FileId = fileId;
			return fileAppService.CheckInFile(checkInFile);
		}

		/// <summary>
		/// 删除文件历史版本
		/// </summary>
		/// <param name="fileId"></param>
		/// <param name="fileVerId"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> DeleteFileVersion(int fileId, int fileVerId) 
		{
			return fileAppService.DeleteFileVersion(fileId, fileVerId, token);
		}
	}
}