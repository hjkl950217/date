﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: jiasong.ding 2021/2/6 16:08:43
*
***************************************************************************/

using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.ResultModel;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
    public class FolderPermissionService
    {
        private static readonly IFolderPermissionAppService folderPermissionAppService = null;
        private static readonly string token = ServiceConfig.Token;

        static FolderPermissionService()
        {
            folderPermissionAppService = ServiceContainer.GetService<IFolderPermissionAppService>();
        }

        public static ReturnValueResult<string> SetPermissions(SetPermissionDto dto)
        {
            if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
            return folderPermissionAppService.SetPermissions(dto);
        }

        public static ReturnValueResult<GetFolderPermissionResult> GetFolderPermission(int folderId)
        {
            return folderPermissionAppService.GetFolderPermission(token, folderId);
        }
    }
}