﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: jiasong.ding 2020/11/18 8:59:52
*
***************************************************************************/

using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.ResultModel;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 folder service.
	/// </summary>
	public class FolderService
	{
		private static readonly IFolderAppService folderAppService = null;
		private static readonly IFolderPermissionAppService folderPermissionAppService = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Initializes a new insntance of the <see cref="FolderService"/> class.
		/// </summary>
		static FolderService()
		{
			folderAppService = ServiceContainer.GetService<IFolderAppService>();
			folderPermissionAppService = ServiceContainer.GetService<IFolderPermissionAppService>();
		}

		/// <summary>
		/// Create folder.
		/// </summary>
		/// <param name="folderName">Folder name.</param>
		/// <param name="parentFolderId">Parent folder id.</param>
		/// <param name="folderCode">Folder code,The default is an empty string.</param>
		/// <param name="remark">Remark,The default is an empty string.</param>
		/// <returns></returns>
		public static ReturnValueResult<CreateFolderResult> CreateFolder(CreateFolderDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			//if (string.IsNullOrEmpty(dto.Name)) throw new ArgumentNullException(nameof(dto.Name));
			//if (dto.parentFolderId < 1) throw new ArgumentNullException(nameof(parentFolderId));
			//dto
			//CreateFolderDto dto = new CreateFolderDto()
			//{
			//    Name = folderName,
			//    FolderCode = folderCode,
			//    Remark = remark,
			//    ParentFolderId = parentFolderId,
			//    Token = apiToken
			//};
			return folderAppService.CreateFolder(dto);
		}

		/// <summary>
		/// Set folder permissions according to permission category
		/// </summary>
		/// <param name="folderId">folder id</param>
		/// <param name="cateId">cate id</param>
		/// <param name="memberId">member id</param>
		/// <param name="memberType">member type</param>
		/// <param name="startTime">start time</param>
		/// <param name="expiredTime">expired time</param>
		/// <returns></returns>
		public static ReturnValueResult<string> SetFolderPermissionByCateId(FolderPermissionSetDto dto)
		{
			if (string.IsNullOrEmpty(dto.Applicant)) dto.Applicant = "admin";
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;

			return folderAppService.SetFolderPermissionByCateId(dto);
		}

		/// <summary>
		/// Delete folder permissions
		/// </summary>
		/// <param name="FolderId">folder id</param>
		/// <param name="Mermbers">The permission object to be deleted</param>
		/// <returns></returns>
		public static ReturnValueResult<string> DeleteFolderPermission(DeleteFolderPermissionDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return folderPermissionAppService.DeleteFolderPermission(dto);
		}

		/// <summary>
		/// Clear the folder permissions
		/// </summary>
		/// <param name="token">token</param>
		/// <param name="folderId">folder id</param>
		/// <returns></returns>
		public static ReturnValueResult<string> ClearPermissionByFolder(string token, int folderId)
		{
			if (string.IsNullOrEmpty(token)) token = FolderService.token;
			return folderPermissionAppService.ClearPermissionByFolder(token, folderId);
		}

		/// <summary>
		/// Modify folder information
		/// </summary>
		/// <param name="dto"></param>
		/// <returns></returns>
		public static ReturnValueResult<string> ChangeFolderInfo(ChangeFolderInfoDto dto)
		{
			if (string.IsNullOrEmpty(dto.Token)) dto.Token = token;
			return folderAppService.ChangeFolderInfo(dto);
		}

		/// <summary>
		/// Get the folder ID based on the folder name and parent folder id
		/// </summary>
		/// <param name="token">token</param>
		/// <param name="folderName">folder name</param>
		/// <param name="folderId">foler id</param>
		/// <returns></returns>
		public static ReturnValueResult<int> GetFolderIdInFolderByfolderName(string token,string folderName,int folderId) 
		{
			if (string.IsNullOrEmpty(token)) token = FolderService.token;
			return folderAppService.GetFolderIdInFolderByfolderName(token, folderName, folderId);
		}
	}
}