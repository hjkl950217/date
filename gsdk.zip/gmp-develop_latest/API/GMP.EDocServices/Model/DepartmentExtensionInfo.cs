﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 9:11:56
*
***************************************************************************/

using EDoc2.IAppService.Model.Organization;

namespace GMP.EDocServices.Model
{
	/// <summary>
	/// Extend the <see cref="DepartmentInfo"/>.
	/// </summary>
	public class DepartmentExtensionInfo : DepartmentInfo
	{
		/// <summary>
		/// Gets or sets a value indicating whether the department is the user main department.
		/// </summary>
		public bool IsMain { get; set; }
	}
}