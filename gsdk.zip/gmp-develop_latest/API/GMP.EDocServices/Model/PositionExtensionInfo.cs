﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 9:21:05
*
***************************************************************************/

using EDoc2.IAppService.Model.Organization;

namespace GMP.EDocServices.Model
{
	/// <summary>
	/// Extends the <see cref="PositionInfo"/>.
	/// </summary>
	public class PositionExtensionInfo : PositionInfo
	{
		/// <summary>
		/// Gets or set a value indicating whether the position is the user main position.
		/// </summary>
		public bool IsMain { get; set; }
	}
}