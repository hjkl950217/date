﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/2 17:02:26
*
***************************************************************************/

using System;
using System.Collections.Generic;
using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.Model.Organization;
using EDoc2.Sdk;
using GMP.EDocServices.Model;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 position service.
	/// </summary>
	public class PositionService
	{
		private static readonly IOrgPositionAppService service = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Static Constructor.
		/// </summary>
		static PositionService()
		{
			service = ServiceContainer.GetService<IOrgPositionAppService>();
		}

		/// <summary>
		/// Get a list of positions based on the user id.
		/// </summary>
		/// <param name="userId">The user id.</param>
		/// <returns>The user's position list.</returns>
		/// <exception cref="ArgumentNullException">The token or userId is empty or null.</exception>
		public static ReturnValueResult<List<PositionExtensionInfo>> GetPositionListByUserId(string userId)
		{
			if (string.IsNullOrEmpty(userId)) throw new ArgumentNullException(nameof(userId));

			//Get the main position based on user id.
			IOrgUserAppService userService = ServiceContainer.GetService<IOrgUserAppService>();
			ReturnValueResult<UserInfo> userRes = userService.GetUserInfoByUserGuid(ServiceConfig.Token, userId);
			if (userRes.Result != 0)
			{
				return new ReturnValueResult<List<PositionExtensionInfo>>()
				{
					Result = userRes.Result,
					Message = userRes.Message
				};
			}

			//Get the position list based on user id.
			ReturnValueResult<List<PositionInfo>> positionRes = service.GetChildPositionListByUserId(ServiceConfig.Token, userId);
			if (positionRes.Result != 0)
			{
				return new ReturnValueResult<List<PositionExtensionInfo>>()
				{
					Result = positionRes.Result,
					Message = positionRes.Message
				};
			}

			//Convert the position info.
			List<PositionExtensionInfo> positions = new List<PositionExtensionInfo>();
			foreach (PositionInfo info in positionRes.Data)
			{
				//Mark the main position.
				PositionExtensionInfo position = ConvertPositionEntity(info);
				if (info.ID == userRes.Data.MainPositionId)
				{
					position.IsMain = true;
				}

				positions.Add(position);
			}

			return new ReturnValueResult<List<PositionExtensionInfo>>()
			{
				Result = ResultType.Success,
				Data = positions
			};
		}

		/// <summary>
		/// Convert the <see cref="PositionInfo"/> to <see cref="PositionExtensionInfo"/>.
		/// </summary>
		/// <param name="info">A <see cref="PositionInfo"/>.</param>
		/// <returns>A <see cref="PositionExtensionInfo"/>.</returns>
		private static PositionExtensionInfo ConvertPositionEntity(PositionInfo info)
		{
			PositionExtensionInfo position = new PositionExtensionInfo();
			position.ID = info.ID;
			position.IdentityId = info.IdentityId;
			position.Code = info.Code;
			position.ThirdPartId = info.ThirdPartId;
			position.ParentId = info.ParentId;
			position.ParentName = info.ParentName;
			position.ParentIdentityId = info.ParentIdentityId;
			position.LevelId = info.LevelId;
			position.Name = info.Name;
			position.PositionType = info.PositionType;
			position.Sort = info.Sort;
			position.Remark = info.Remark;
			position.DepartmentId = info.DepartmentId;
			position.DepartmentIdentityId = info.DepartmentIdentityId;
			position.DepartmentName = info.DepartmentName;
			position.HaveChildren = info.HaveChildren;
			position.CreateTime = info.CreateTime;
			position.EnableTime = info.EnableTime;
			position.ExpirationTime = info.ExpirationTime;
			position.IsMain = false;

			return position;
		}
	}
}