﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/14 16:42:49
*
***************************************************************************/

using System.Collections.Generic;
using EDoc2.Sdk;
using GMP.Configuration;

namespace GMP.EDocServices
{
	/// <summary>
	/// Provide a service base class to configure the service.
	/// </summary>
	public static class ServiceConfig
	{
		/// <summary>
		/// Gets a token to service the request.
		/// </summary>
		public static string Token { get; }

		/// <summary>
		/// Static constructor.
		/// </summary>
		static ServiceConfig()
		{
			string token = AppSettings.GetValue("ECM.SDK.TOKEN");
			if (string.IsNullOrEmpty(token))
			{
				throw new KeyNotFoundException("Configuration key 'ECM.SDK.TOKEN' was not found.");
			}

			string baseUrl = AppSettings.GetValue("ECM.SDK.URL");
			if (string.IsNullOrEmpty(baseUrl))
			{
				throw new KeyNotFoundException("Configuration key 'ECM.SDK.URL' was not found.");
			}

			Token = token;
			SdkBaseInfo.BaseUrl = baseUrl;
		}
	}
}