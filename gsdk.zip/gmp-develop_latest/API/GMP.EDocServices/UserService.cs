﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/30 11:44:38
*
***************************************************************************/

using System;
using EDoc2.IAppService;
using EDoc2.IAppService.Model;
using EDoc2.IAppService.Model.Organization;
using EDoc2.Sdk;

namespace GMP.EDocServices
{
	/// <summary>
	/// EDoc2 User service.
	/// </summary>
	public class UserService
	{
		private static readonly IOrgAppService service = null;
		private static readonly string token = ServiceConfig.Token;

		/// <summary>
		/// Static Constructor.
		/// </summary>
		static UserService()
		{
			service = ServiceContainer.GetService<IOrgAppService>();
		}

		/// <summary>
		/// Verify that the specified account and password is valid.
		/// </summary>
		/// <param name="account">The user account.</param>
		/// <param name="password">The user password.</param>
		/// <returns>
		/// True if the account and password is valid,
		/// otherwise an error code is returned.
		/// </returns>
		/// <exception cref="ArgumentNullException">The account or password is null.</exception>
		public static ReturnValueResult<bool> Authentication(string account, string password)
		{
			if (string.IsNullOrEmpty(account)) throw new ArgumentNullException(nameof(account));
			if (string.IsNullOrEmpty(password)) throw new ArgumentNullException(nameof(password));

			UserLoginDto entity = new UserLoginDto();
			entity.UserName = account;
			entity.Password = password;
			entity.ClientType = "4";
			entity.Secure = false;

			ReturnValueResult<string> res = service.UserLogin(entity);
			if (res.Result == 0 && !string.IsNullOrEmpty(res.Data))
			{
				return new ReturnValueResult<bool>()
				{
					Result = 0,
					Message = res.Message,
					DataDescription = res.DataDescription,
					Data = true
				};
			}

			return new ReturnValueResult<bool>()
			{
				Result = res.Result,
				Message = res.Message,
				DataDescription = res.DataDescription,
				Data = false
			};
		}

		/// <summary>
		/// Login using the specified account and password.
		/// </summary>
		/// <param name="account">The user account.</param>
		/// <param name="password">The user password.</param>
		/// <returns>
		/// Login success returns user token, failure returns an error code.
		/// </returns>
		/// <exception cref="ArgumentNullException">The account or password is null.</exception>
		public static ReturnValueResult<string> Login(string account, string password)
		{
			if (string.IsNullOrEmpty(account)) throw new ArgumentNullException(nameof(account));
			if (string.IsNullOrEmpty(password)) throw new ArgumentNullException(nameof(password));

			UserLoginDto entity = new UserLoginDto();
			entity.UserName = account;
			entity.Password = password;
			entity.ClientType = "4";
			entity.Secure = false;

			return service.UserLogin(entity);
		}

		/// <summary>
		/// Gets user information based on the specified account.
		/// </summary>
		/// <param name="account">The user account.</param>
		/// <returns>The user information.</returns>
		public static ReturnValueResult<UserInfo> GetUserInfoByAccount(string account)
		{
			if (string.IsNullOrEmpty(account)) throw new ArgumentNullException(nameof(account));

			IOrgUserAppService userService = ServiceContainer.GetService<IOrgUserAppService>();
			return userService.GetUserInfoByAccount(token, account);
		}

		/// <summary>
		/// Gets user information based on the specified user id.
		/// </summary>
		/// <param name="userId">The user id.</param>
		/// <returns>The user information.</returns>
		public static ReturnValueResult<UserInfo> GetUserInfoByUserId(int userId)
		{
			if (userId <= 0) throw new ArgumentNullException(nameof(userId));

			IOrgUserAppService userService = ServiceContainer.GetService<IOrgUserAppService>();
			return userService.GetUserInfoByUserId(token, userId);
		}

		/// <summary>
		/// Gets user information based on the specified account.
		/// </summary>
		/// <param name="userGuid">The user guid.</param>
		/// <returns>The user information.</returns>
		public static ReturnValueResult<UserInfo> GetUserInfoByUserGuid(string userGuid)
		{
			if (string.IsNullOrEmpty(userGuid)) throw new ArgumentNullException(nameof(userGuid));

			IOrgUserAppService userService = ServiceContainer.GetService<IOrgUserAppService>();
			return userService.GetUserInfoByUserGuid(token, userGuid);
		}

		/// <summary>
		/// Verifies that the token is valid
		/// </summary>
		/// <param name="token">User token.</param>
		/// <returns>Whether the token is valid</returns>
		public static ReturnValueResult<bool> CheckUserTokenValidity(string token)
		{
			if (string.IsNullOrEmpty(token)) throw new ArgumentNullException(nameof(token));
			IOrgAppService orgService = ServiceContainer.GetService<IOrgAppService>();
			return orgService.CheckUserTokenValidity(token);
		}
	}
}