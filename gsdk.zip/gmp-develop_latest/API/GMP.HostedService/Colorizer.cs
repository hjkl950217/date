﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:28:23 Created
*
***************************************************************************/

using System;

namespace GMP.HostedService
{
	/// <summary>
	/// Provide colorize console standard input and output procedures.
	/// </summary>
	public static class Colorizer
	{
		/// <summary>
		/// Writes the specified string value to the standard output stream.
		/// </summary>
		/// <param name="message">The value to write.</param>
		public static void Write(string message)
		{
			Console.Write(message);
		}

		/// <summary>
		/// Writes the specified string value to the standard output stream using the specified color.
		/// </summary>
		/// <param name="color">The foreground and background colors for the console.</param>
		/// <param name="message">The value to write.</param>
		public static void Write(ConsoleColor color, string message)
		{
			Console.ForegroundColor = color;
			Console.Write(message);
			Console.ForegroundColor = ConsoleColor.White;
		}

		/// <summary>
		/// Writes the specified string value to the standard output stream.
		/// </summary>
		/// <param name="message">The value to write.</param>
		public static void WriteLine(string message)
		{
			Console.WriteLine(message);
		}

		/// <summary>
		/// Writes the specified string value to the standard output stream using the specified color.
		/// </summary>
		/// <param name="color">The foreground and background colors for the console.</param>
		/// <param name="message">The value to write.</param>
		public static void WriteLine(ConsoleColor color, string message)
		{
			Console.ForegroundColor = color;
			Console.WriteLine(message);
			Console.ForegroundColor = ConsoleColor.White;
		}

		/// <summary>
		/// Outputs a validation text to the standard output stream and waits for validation results.
		/// </summary>
		/// <param name="message">The value to write.</param>
		/// <returns></returns>
		public static bool Confirm(string message)
		{
			return Colorizer.Confirm(ConsoleColor.White, message);
		}

		/// <summary>
		/// Prints a validation text to the standard output stream
		/// using the specified color and waits for the validation result.
		/// </summary>
		/// <param name="color">The foreground and background colors for the console.</param>
		/// <param name="message">The value to write.</param>
		/// <returns></returns>
		public static bool Confirm(ConsoleColor color, string message)
		{
			Colorizer.WriteLine(color, message + "(y/n)");

			ConsoleKeyInfo keyInfo = Console.ReadKey();
			return keyInfo.Key == ConsoleKey.Y;
		}

		/// <summary>
		/// Reads the next line of characters from the standard input stream.
		/// </summary>
		/// <returns>
		/// The next line of characters from the input stream,
		/// or null if no more lines are available.
		/// </returns>
		public static string ReadLine()
		{
			return Console.ReadLine();
		}

		/// <summary>
		/// Gets the next character or function key pressed by the user.
		/// </summary>
		/// <returns>A <see cref="ConsoleKeyInfo"/>.</returns>
		public static ConsoleKeyInfo ReadKey()
		{
			return Console.ReadKey();
		}
	}
}