﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:57:06 Created
*
***************************************************************************/

using System;

namespace GMP.HostedService
{
	/// <summary>
	/// Provide a generic implementation of the <see cref="HostService"/> class.
	/// </summary>
	/// <typeparam name="TService">The type derived from the <see cref="HostService"/>.</typeparam>
	public abstract class HostService<TService> : HostService where TService : HostService, new()
	{
		/// <summary>
		///  Registers a host service of the specified <typeparamref name="TService"/>.
		/// </summary>
		public static new void RegisterHostService()
		{
			Activator.CreateInstance<TService>().Run();
		}
	}
}