﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 15:48:43 Created
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Threading;

namespace GMP.HostedService
{
	/// <summary>
	/// Provides abstract base class for host services application.
	/// </summary>
	public abstract class HostService : IHostedService
	{
		/// <summary>
		/// Gets or sets the name of the service.
		/// </summary>
		public string ServiceName { get; set; }

		/// <summary>
		/// Gets or sets the display name of the service.
		/// </summary>
		public string DisplayName { get; set; }

		/// <summary>
		/// Gets or sets the description of the service.
		/// </summary>
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets the depend of the service.
		/// </summary>
		public List<string> DependOnService { get; set; }

		/// <summary>
		/// Gets or sets the start type of the service.
		/// </summary>
		public ServiceStartMode StartType { get; set; }

		/// <summary>
		/// Gets or sets the help text of the serfvice.
		/// </summary>
		public string HelpText { get; }

		/// <summary>
		/// Gets or sets the account of the service.
		/// </summary>
		public ServiceAccount Account { get; set; }

		/// <summary>
		/// Gets or sets the user of the service.
		/// </summary>
		public string Username { get; set; }

		/// <summary>
		/// Gets or sets the password of the service.
		/// </summary>
		public string Password { get; set; }

		/// <summary>
		/// Gets or sets the execute file path of the service.
		/// </summary>
		public string BinPath { get; set; }

		/// <summary>
		/// Gets a signal token to cancel the thread.
		/// </summary>
		public CancellationTokenSource CancelTokenSource { get; private set; }

		/// <summary>
		/// Initialize a new instance of the <see cref="HostService"/> class.
		/// </summary>
		public HostService()
		{
			string[] args = Environment.GetCommandLineArgs();

			this.DependOnService = new List<string>();
			this.StartType = ServiceStartMode.Auto;
			this.Account = ServiceAccount.LocalSystem;
			this.BinPath = args[0];
			this.CancelTokenSource = new CancellationTokenSource();
		}

		/// <summary>
		/// Register the current instance as a service.
		/// </summary>
		public void RegisterHostService()
		{
			this.Run();
		}

		/// <summary>
		/// Registers a host service of the specified <see cref="Type"/>.
		/// </summary>
		/// <param name="type">The type derived from the <see cref="HostService"/>.</param>
		public static void RegisterHostService(Type type)
		{
			if (typeof(HostService).IsAssignableFrom(type))
			{
				HostService instance = Activator.CreateInstance(type) as HostService;
				instance.Run();
			}
		}

		/// <summary>
		/// Registers a host service of the specified <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">The type derived from the <see cref="HostService"/>.</typeparam>
		public static void RegisterHostService<TService>() where TService : HostService, new()
		{
			Activator.CreateInstance<TService>().Run();
		}

		/// <summary>
		/// Running the current service.
		/// </summary>
		public void Run()
		{
			ServiceManager manager = new ServiceManager(this);
			manager.ApplyCommandLine();
		}

		/// <summary>
		/// When implemented in a derived class, executes when a start command
		/// is sent to the service by the service control manager.
		/// Specifies the actions to take when the service starts.
		/// </summary>
		/// <param name="args">The command line arguments.</param>
		public virtual void OnStart(string[] args) { }

		/// <summary>
		/// When implemented in a derived class, executes when a stop command
		/// is sent to the service by the service control manager.
		/// Specifies the actions to take when a service stops running.
		/// </summary>
		public virtual void OnStop() { }

		/// <summary>
		/// When implemented in a derived class,executes when the system is shutting down.
		/// Specifies the actions to take when the system shutting down.
		/// </summary>
		public virtual void OnShutdown() { }
	}
}