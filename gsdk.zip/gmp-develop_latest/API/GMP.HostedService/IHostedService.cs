﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/29 18:55:58 Created
*
***************************************************************************/

using System.Threading;

namespace GMP.HostedService
{
	/// <summary>
	/// Provides registration, startup, and running of hosting services.
	/// </summary>
	public interface IHostedService
	{
		/// <summary>
		/// Gets a signal token to cancel the thread.
		/// </summary>
		CancellationTokenSource CancelTokenSource { get; }

		/// <summary>
		/// Running the current service.
		/// </summary>
		void Run();

		/// <summary>
		/// Register the current instance as a service.
		/// </summary>
		void RegisterHostService();

		/// <summary>
		/// When implemented in a derived class, executes when a start command
		/// is sent to the service by the service control manager.
		/// Specifies the actions to take when the service starts.
		/// </summary>
		/// <param name="args">The command line arguments.</param>
		void OnStart(string[] args);

		/// <summary>
		/// When implemented in a derived class, executes when a stop command
		/// is sent to the service by the service control manager.
		/// Specifies the actions to take when a service stops running.
		/// </summary>
		void OnStop();

		/// <summary>
		/// When implemented in a derived class,executes when the system is shutting down.
		/// Specifies the actions to take when the system shutting down.
		/// </summary>
		void OnShutdown();
	}
}