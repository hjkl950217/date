﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:10:41 Created
*
***************************************************************************/

namespace GMP.HostedService
{
	/// <summary>
	/// Provides a unified implementation for the management of host services.
	/// </summary>
	public interface IHostedServiceController
	{
		/// <summary>
		/// Gets the current status of the service.
		/// </summary>
		ServiceStatus ServiceStatus { get; }

		/// <summary>
		/// Run in debug mode.
		/// </summary>
		void Debug();

		/// <summary>
		/// Runs the current program immediately.
		/// </summary>
		void Run();

		/// <summary>
		/// Install the specified service.
		/// </summary>
		void Install();

		/// <summary>
		/// Uninstall the specified service.
		/// </summary>
		void Uninstall();

		/// <summary>
		/// Starts the specified service.
		/// </summary>
		void Start();

		/// <summary>
		/// Stops the specified service
		/// </summary>
		void Stop();
	}
}