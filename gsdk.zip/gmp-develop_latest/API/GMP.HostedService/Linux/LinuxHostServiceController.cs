﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/31 14:36:05 Created
*
***************************************************************************/

using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace GMP.HostedService.Linux
{
	/// <summary>
	/// Provides instance methods for installing, uninstalling, starting,
	/// stopping, and running services on the Linux platform.
	/// This class cannot be inherited.
	/// </summary>
	internal sealed class LinuxHostServiceController : IHostedServiceController
	{
		private readonly HostService service;

		/// <summary>
		/// Gets the current status of the service.
		/// </summary>
		public ServiceStatus ServiceStatus { get; private set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="LinuxHostServiceController"/> class.
		/// </summary>
		/// <param name="service">An instance of the host service.</param>
		public LinuxHostServiceController(HostService service)
		{
			this.service = service;
			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Run in debug mode.
		/// </summary>
		public void Debug()
		{
			string[] args = Environment.GetCommandLineArgs().Skip(1).ToArray();
			this.service.OnStart(args);
		}

		/// <summary>
		/// Runs now the current program.
		/// </summary>
		public void Run()
		{
			string[] args = Environment.GetCommandLineArgs().Skip(1).ToArray();

			Task task = Task.Factory.StartNew(() =>
			{
				this.service.OnStart(args);
			}, this.service.CancelTokenSource.Token);

			task.Wait(this.service.CancelTokenSource.Token);
		}

		/// <summary>
		/// Install the specified service.
		/// </summary>
		public void Install()
		{
			if (this.ServiceStatus != ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is installed and cannot perform this operation.");
				return;
			}

			string template = string.Empty;
			string servicePath = $"/usr/lib/systemd/system/{this.service.ServiceName}.service";

			Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream($"{this.GetType().Namespace}.template.service");
			using (StreamReader reader = new StreamReader(stream))
			{
				template = reader.ReadToEnd();
			}

			template = template.Replace("{Description}", this.service.Description)
							   .Replace("{BinPath}", $"{this.service.BinPath} -r");

			File.WriteAllText(servicePath, template);

			Colorizer.WriteLine(ConsoleColor.DarkGreen, "The service is running");

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Uninstall the specified service.
		/// </summary>
		public void Uninstall()
		{
			if (this.ServiceStatus == ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkRed, "The service not installed and cannot perform this operation.");
				return;
			}

			if (this.ServiceStatus == ServiceStatus.Running)
			{
				this.Stop();
			}

			string res = Processer.Execute("rm", $"/usr/lib/systemd/system/{this.service.ServiceName}.service -f");
			// /etc/systemd/system/multi-user.target.wants/PasswordResetService.service
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "The service is uninstalled.");
			Processer.Execute("systemctl", "daemon-reload");

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Starts the specified service.
		/// </summary>
		public void Start()
		{
			if (this.ServiceStatus == ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkRed, "The service not installed and cannot perform this operation.");
				return;
			}

			if (this.ServiceStatus == ServiceStatus.Running)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is started and cannot perform this operation.");
				return;
			}

			string res = Processer.Execute("service", $"{this.service.ServiceName} start");
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "The service is started.");
			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Stops the specified service.
		/// </summary>
		public void Stop()
		{
			if (this.ServiceStatus == ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkRed, "The service not installed and cannot perform this operation.");
				return;
			}

			if (this.ServiceStatus == ServiceStatus.Stopped)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is stopped and cannot perform this operation.");
				return;
			}

			string res = Processer.Execute("service", $"{this.service.ServiceName} stop");
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "The service is stopped.");

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Refreshes the current status of the service.
		/// </summary>
		private void RefreshServiceStatus()
		{
			string res = Processer.Execute("service", $"{this.service.ServiceName} status");

			if (res.Contains("not be found")) this.ServiceStatus = ServiceStatus.Uninstalled;
			if (res.Contains("Active: active")) this.ServiceStatus = ServiceStatus.Running;
			if (res.Contains("Active: inactive")) this.ServiceStatus = ServiceStatus.Stopped;
			if (res.Contains("Active: failed")) this.ServiceStatus = ServiceStatus.Stopped;
		}
	}
}