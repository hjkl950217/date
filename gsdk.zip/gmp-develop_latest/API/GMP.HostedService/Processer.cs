﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:21:05 Created
*
***************************************************************************/

using System.Diagnostics;

namespace GMP.HostedService
{
	/// <summary>
	/// Provides a static method for executing external programs.
	/// </summary>
	public static class Processer
	{
		/// <summary>
		/// Executes the specified program and returns the result.
		/// </summary>
		/// <param name="fileName">The name of an application file to run in the process.</param>
		/// <param name="arguments">Command line arguments to pass when starting the process.</param>
		/// <returns>The execution result.</returns>
		public static string Execute(string fileName, string arguments, bool output = true)
		{
			string result = string.Empty;

			Process processer = new Process();
			processer.StartInfo.UseShellExecute = false;
			processer.StartInfo.RedirectStandardInput = true;
			processer.StartInfo.RedirectStandardOutput = true;
			processer.StartInfo.RedirectStandardError = true;
			processer.StartInfo.CreateNoWindow = true;

			processer.StartInfo.FileName = fileName;
			processer.StartInfo.Arguments = arguments;
			processer.Start();

			if (output) result = processer.StandardOutput.ReadToEnd();
			return result;
		}
	}
}