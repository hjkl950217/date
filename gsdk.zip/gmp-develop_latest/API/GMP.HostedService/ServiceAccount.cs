﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 15:54:34 Created
*
***************************************************************************/

namespace GMP.HostedService
{
	/// <summary>
	/// Specifies the running account for the service.
	/// </summary>
	public enum ServiceAccount
	{
		/// <summary>
		/// An account that can be used as an unprivileged user on a local computer and provides anonymous credentials to any remote server.
		/// </summary>
		LocalService = 0,

		/// <summary>
		/// An account that provides multiple local privileges and provides credentials to all computers on remote servers.
		/// </summary>
		NetworkService = 1,

		/// <summary>
		/// An account, using the service control manager, that has many privileges on the local computer and ACTS as a computer on the network.
		/// </summary>
		LocalSystem = 2,

		/// <summary>
		/// Define a specific user's account on the network.
		/// </summary>
		User = 3
	}
}