﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 18:18:25 Created
*
***************************************************************************/

namespace GMP.HostedService
{
	/// <summary>
	/// Specifies the command of the service.
	/// </summary>
	internal enum ServiceCommand
	{
		Debug,
		Run,
		Install,
		Uninstall,
		Start,
		Stop
	}
}