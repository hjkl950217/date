﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 18:14:23 Created
*
***************************************************************************/

using System.Runtime.InteropServices;
using GMP.HostedService.Linux;
using GMP.HostedService.Windows;

namespace GMP.HostedService
{
	/// <summary>
	/// Provides the creation of different platform service controllers.
	/// </summary>
	internal static class ServiceFactory
	{
		/// <summary>
		/// Creates the service controller of the specified platform.
		/// </summary>
		/// <param name="service">An instance of the <see cref="HostService"/>.</param>
		/// <returns>The service controller for the current platform.</returns>
		public static IHostedServiceController CreateServiceController(HostService service)
		{
			if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
			{
				return new LinuxHostServiceController(service);
			}

			if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
			{
				return new WindowsHostServiceController(service);
			}

			return null;
		}
	}
}