﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 17:11:25 Created
*
***************************************************************************/

using System;
using System.Runtime.InteropServices;

namespace GMP.HostedService
{
	/// <summary>
	/// Provides service managment and command execution.
	/// </summary>
	internal class ServiceManager
	{
		private readonly HostService service;
		private readonly IHostedServiceController controller;

		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceManager"/> class.
		/// </summary>
		/// <param name="service">An instance of the <see cref="HostService"/>.</param>
		public ServiceManager(HostService service)
		{
			this.service = service;
			this.controller = ServiceFactory.CreateServiceController(service);
		}

		/// <summary>
		/// Parse the command line and execute the command.
		/// </summary>
		public void ApplyCommandLine()
		{
			ServiceCommand command = new ServiceCommand();
			string[] args = Environment.GetCommandLineArgs();
			if (args.Length == 1)
			{
				this.ShowUsage(); return;
			}

			string arg = args[1].ToLower();
			if (arg == "-r" || arg == "run") command = ServiceCommand.Run;
			if (arg == "-i" || arg == "install") command = ServiceCommand.Install;
			if (arg == "-u" || arg == "uninstall") command = ServiceCommand.Uninstall;
			if (arg == "-s" || arg == "start") command = ServiceCommand.Start;
			if (arg == "-q" || arg == "stop") command = ServiceCommand.Stop;

			this.ExcuteCommand(command);
		}

		/// <summary>
		/// Executes the specified service command.
		/// </summary>
		/// <param name="command">The service command.</param>
		private void ExcuteCommand(ServiceCommand command)
		{
			switch (command)
			{
				case ServiceCommand.Debug: this.controller.Debug(); break;
				case ServiceCommand.Run: this.controller.Run(); break;
				case ServiceCommand.Install: this.controller.Install(); break;
				case ServiceCommand.Uninstall: this.controller.Uninstall(); break;
				case ServiceCommand.Start: this.controller.Start(); break;
				case ServiceCommand.Stop: this.controller.Stop(); break;
			}

			this.ShowService();
			this.ShowOptions();
		}

		/// <summary>
		/// Show usage guide.
		/// </summary>
		private void ShowUsage()
		{
			this.ShowCopyright();
			this.ShowService();
			this.ShowOptions();

			string args = "";
			ServiceCommand command = new ServiceCommand();

			while ((args = Console.ReadLine()) != "0")
			{
				switch (args)
				{
					case "1": command = ServiceCommand.Debug; break;
					case "2": command = ServiceCommand.Install; break;
					case "3": command = ServiceCommand.Uninstall; break;
					case "4": command = ServiceCommand.Start; break;
					case "5": command = ServiceCommand.Stop; break;
				}

				this.ExcuteCommand(command);
			}
		}

		/// <summary>
		/// Show copyright information.
		/// </summary>
		private void ShowCopyright()
		{
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "Macrowing Pharmaceutical GMP Management Platform.");
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "http://www.macrowing.com");
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "Copyright(c) Macrowing Pharmaceutical Corporation.");
			Colorizer.WriteLine(ConsoleColor.DarkGreen, "All Rights Reserved.");
			Console.WriteLine(Environment.NewLine);
		}

		/// <summary>
		/// Show service description.
		/// </summary>
		private void ShowService()
		{
			string platform = RuntimeInformation.IsOSPlatform(OSPlatform.Linux) ? "Linux" : "Windows";

			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Service Name\t: {this.service.ServiceName}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Display Name\t: {this.service.DisplayName}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Start\t\t: {this.service.StartType}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"BinPath\t\t: {this.service.BinPath}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Account\t\t: {this.service.Account}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Depend\t\t: {string.Join("/", this.service.DependOnService)}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Description\t: {this.service.Description}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Status\t\t: {this.controller.ServiceStatus}");
			Colorizer.WriteLine(ConsoleColor.DarkCyan, $"Platform\t: {platform}");
			Console.WriteLine(Environment.NewLine);
		}

		/// <summary>
		/// Show action options of the service.
		/// </summary>
		private void ShowOptions()
		{
			Console.WriteLine("[0]Exit [1]Only Run [2]Install [3]Uninstall [4]Start [5]Stop");
		}
	}
}