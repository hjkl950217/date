﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 15:53:39 Created
*
***************************************************************************/

namespace GMP.HostedService
{
	/// <summary>
	/// Specifies the start mode of the service.
	/// </summary>
	public enum ServiceStartMode
	{
		/// <summary>
		/// Indicates that the service is started manually only by the user (using the service control manager) or by the application.
		/// </summary>
		Demand,

		/// <summary>
		/// Device drivers that indicate that the service is loaded by the boot loader.
		/// </summary>
		Boot,

		/// <summary>
		/// Indicates the device driver that the service starts during kernel initialization.
		/// </summary>
		System,

		/// <summary>
		/// Indicates that the service will be started by (or has been started by) the operating system at system startup.
		/// If an automatically started service depends on a manually started service,
		/// the manually started service will also start automatically when the system starts.
		/// </summary>
		Auto,

		/// <summary>
		/// Indicates that the service is disabled and therefore cannot be enabled by the user or the application.
		/// </summary>
		Disabled,

		/// <summary>
		/// Indicates that the service will be delayed until other automatically started services complete.
		/// </summary>
		DelayedAuto
	}
}