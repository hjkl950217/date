﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:14:05 Created
*
***************************************************************************/

namespace GMP.HostedService
{
	/// <summary>
	/// Specifies the status of the service.
	/// </summary>
	public enum ServiceStatus
	{
		/// <summary>
		/// Indicates that the current service has not been installed.
		/// </summary>
		Uninstalled,

		/// <summary>
		/// Indicates that the current service is running.
		/// </summary>
		Running,

		/// <summary>
		/// Indicates that the current service has stopped.
		/// </summary>
		Stopped,

		/// <summary>
		/// Indicates that the current service is disabled.
		/// </summary>
		Disabled
	}
}