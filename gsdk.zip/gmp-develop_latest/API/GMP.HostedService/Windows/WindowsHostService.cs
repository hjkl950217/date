﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 15:59:34 Created
*
***************************************************************************/

using System.ServiceProcess;
using System.Threading.Tasks;

namespace GMP.HostedService.Windows
{
	/// <summary>
	/// Provides abstract base class for host services application.
	/// </summary>
	internal class WindowsHostService : ServiceBase
	{
		private readonly HostService service;

		/// <summary>
		/// Initializes a new instance of the <see cref="WindowsHostService"/> class.
		/// </summary>
		public WindowsHostService(HostService service)
		{
			this.service = service;

			base.CanStop = true;
			base.CanShutdown = true;
			base.CanPauseAndContinue = false;
			base.CanHandlePowerEvent = true;
			base.CanHandleSessionChangeEvent = true;
			base.AutoLog = true;
		}

		/// <summary>
		/// Specifies the actions to take when the service starts.
		/// </summary>
		/// <param name="args">Command lines.</param>
		protected override void OnStart(string[] args)
		{
			Task task = Task.Factory.StartNew(() =>
			{
				this.service.OnStart(args);
			}, this.service.CancelTokenSource.Token);
		}

		/// <summary>
		/// Specifies the actions to take when a service stops running.
		/// </summary>
		protected override void OnStop()
		{
			this.service.CancelTokenSource.Cancel();
			this.service.OnStop();
		}

		/// <summary>
		/// Specifies the actions to take when the system shutting down.
		/// </summary>
		protected override void OnShutdown()
		{
			this.service.CancelTokenSource.Cancel();
			this.service.OnShutdown();
		}
	}
}