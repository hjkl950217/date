﻿/***************************************************************************
*
* Macrowing Pharmaceutical GMP Management Platform
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharmaceutical Corporation.
* All Rights Reserved.
*
* History:
* heng.yang 2019/8/30 16:16:29 Created
*
***************************************************************************/

using System;
using System.Linq;
using System.ServiceProcess;

namespace GMP.HostedService.Windows
{
	/// <summary>
	/// Provides instance methods for installing, uninstalling, starting,
	/// stopping, and running services on the Windows platform.
	/// This class cannot be inherited.
	/// </summary>
	internal sealed class WindowsHostServiceController : IHostedServiceController
	{
		private readonly HostService service;

		/// <summary>
		/// Gets the current status of the service.
		/// </summary>
		public ServiceStatus ServiceStatus { get; private set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="WindowsHostServiceController"/> class.
		/// </summary>
		/// <param name="service">An instance of the <see cref="HostService"/>.</param>
		public WindowsHostServiceController(HostService service)
		{
			this.service = service;
			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Run in debug mode.
		/// </summary>
		public void Debug()
		{
			string[] args = Environment.GetCommandLineArgs().Skip(1).ToArray();
			this.service.OnStart(args);
		}

		/// <summary>
		/// Runs now the current program.
		/// </summary>
		public void Run()
		{
			ServiceBase[] ServicesToRun;
			ServicesToRun = new ServiceBase[]
			{
				new WindowsHostService(this.service)
			};
			ServiceBase.Run(ServicesToRun);
		}

		/// <summary>
		/// Registers the specified services with the Service Control Manager.
		/// </summary>
		public void Install()
		{
			if (this.ServiceStatus != ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is installed and cannot perform this operation.");
				return;
			}

			string res = Processer.Execute("sc", $"create {this.service.ServiceName} binPath= \"dotnet.exe \\\"{this.service.BinPath}\\\" -r\" DisplayName= {this.service.ServiceName} start= auto");
			if (res.IndexOf("成功") > -1)
			{
				Processer.Execute("sc", $"description {this.service.ServiceName} \"{this.service.Description}\"");
			}

			this.ShowMessage(res);
			this.RefreshServiceStatus();

			this.Start();
		}

		/// <summary>
		/// Removes the specified service from the service control manager.
		/// </summary>
		public void Uninstall()
		{
			if (this.ServiceStatus == ServiceStatus.Uninstalled)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is not installed,cannot be uninstalled.");
				return;
			}

			if (this.ServiceStatus == ServiceStatus.Running)
			{
				this.Stop();
			}

			string res = Processer.Execute("sc", $"delete {this.service.ServiceName}");
			this.ShowMessage(res);

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Starts the specified service.
		/// </summary>
		public void Start()
		{
			if (this.ServiceStatus == ServiceStatus.Running)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is started and cannot perform this operation.");
				return;
			}

			string res = Processer.Execute("sc", $"start {this.service.ServiceName}");
			this.ShowMessage(res);

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Stops the specified service
		/// </summary>
		public void Stop()
		{
			if (this.ServiceStatus == ServiceStatus.Stopped)
			{
				Colorizer.WriteLine(ConsoleColor.DarkYellow, "The service is stopped and cannot perform this operation.");
				return;
			}

			string res = Processer.Execute("sc", $"stop {this.service.ServiceName}");
			this.ShowMessage(res);

			this.RefreshServiceStatus();
		}

		/// <summary>
		/// Writes the specified message to the console window.
		/// </summary>
		/// <param name="message">A string of the message.</param>
		private void ShowMessage(string message)
		{
			if (message.IndexOf("5:") > -1
				|| message.IndexOf("1053:") > -1
				|| message.IndexOf("1056:") > -1
				|| message.IndexOf("1058:") > -1
				|| message.IndexOf("1060:") > -1
				|| message.IndexOf("1062:") > -1
				|| message.IndexOf("1072:") > -1)
			{
				Colorizer.WriteLine(ConsoleColor.DarkRed, message);
			}
			else
			{
				Colorizer.WriteLine(message);
			}

			Console.ForegroundColor = ConsoleColor.Gray;
		}

		/// <summary>
		/// Refreshes the current status of the service.
		/// </summary>
		private void RefreshServiceStatus()
		{
			string res = Processer.Execute("sc", $"query {this.service.ServiceName}");

			if (res.IndexOf("1060:") > -1)
			{
				this.ServiceStatus = ServiceStatus.Uninstalled;
			}

			if (res.IndexOf("START_PENDING") > -1 || res.IndexOf("RUNNING") > -1)
			{
				this.ServiceStatus = ServiceStatus.Running;
			}

			if (res.IndexOf("STOP_PENDING") > -1 || res.IndexOf("STOPPED") > -1)
			{
				this.ServiceStatus = ServiceStatus.Stopped;

				res = Processer.Execute("sc", $"qc {this.service.ServiceName}");
				if (res.IndexOf("DISABLED") > -1)
				{
					this.ServiceStatus = ServiceStatus.Disabled;
				}
			}
		}
	}
}