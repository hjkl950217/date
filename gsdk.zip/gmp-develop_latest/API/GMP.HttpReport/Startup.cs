using System;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.HttpReport
{
    public class Startup
    {
        public const string DefaultConnStrEnvKey = "HTTP_REPORT_MYSQL_CONN";
        private readonly IConfiguration configuration;

        public Startup(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            string connString = GMP.Configuration.AppSettings
                .GetSection(DefaultConnStrEnvKey.ToLower().Replace("_", "."))
                .Value;
            if (connString == null || connString == string.Empty)
            {
                throw new Exception("DataBase connectString is null or empty");
            }

            services
                .AddHttpReportsDashboard(opt =>
                {
                    opt.ExpireDay = 3;
                    opt.Check.Mode = "Self";
                    opt.Check.Switch = true;
                    opt.Check.Endpoint = "";
                    opt.Check.Range = "500,200";

                    opt.Mail.Server = "smtp.163.com";
                    opt.Mail.Port = 465;
                    opt.Mail.Account = "a@qq.com";
                    opt.Mail.Password = "";
                    opt.Mail.EnableSsl = true;
                    opt.Mail.Switch = true;
                })
                .AddMySqlStorage(opt =>
                {
                    opt.ConnectionString = connString;
                    opt.DeferSecond = 10;
                    opt.DeferThreshold = 100;
                });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}

            app.UseHttpReportsDashboard();
        }
    }
}