﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/28 10:36:44
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace GMP.IAppServices.Annotation
{
    public class CommentPermissionResponse
    {
        public bool Comment { get; set; }
        public List<RemovableObject> Comments { get; set; } = new List<RemovableObject>();
    }
}
