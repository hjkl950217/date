﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/28 10:35:36
*
***************************************************************************/

using GMP.ApiClient;
using GMP.ApiClient.Attributes;

namespace GMP.IAppServices.Annotation
{
    [Route("[controller]")]
    public interface IAnnotationAppService : IAppService
    {
        [Route("permission")]
        DataResult<AnnotationPermissionResponse> CheckAnnotationPermission();
    }
}