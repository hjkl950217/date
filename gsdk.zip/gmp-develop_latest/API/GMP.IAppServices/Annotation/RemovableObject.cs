﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/28 10:49:14
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace GMP.IAppServices.Annotation
{
    public class RemovableObject
    {
        public int Id { get; set; }
        public bool Deletable { get; set; }
    }
}
