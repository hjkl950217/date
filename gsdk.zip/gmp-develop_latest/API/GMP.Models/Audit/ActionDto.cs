﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:27:27
*
***************************************************************************/

namespace GMP.Models.Audit
{
    public class ActionDto
    {
        public string Id { get; set; }
        public string Code { get; set; }
        public bool Confirmation { get; set; }
        public string Remarks { get; set; }
        public bool Signature { get; set; }
        public string Cn { get; set; }
        public string Tw { get; set; }
        public string En { get; set; }
        public string Ja { get; set; }
    }
}