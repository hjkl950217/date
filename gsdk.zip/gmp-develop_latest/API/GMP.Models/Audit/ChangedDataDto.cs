﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 13:28:16
*
***************************************************************************/

namespace GMP.Models.Audit
{
	public class ChangedDataDto
	{
		public string Id { get; set; }
		public string EventId { get; set; }
		public string Field { get; set; }
		public string Name { get; set; }
		public string OldValue { get; set; }
		public string OldText { get; set; }
		public string NewValue { get; set; }
		public string NewText { get; set; }
		public string Reason { get; set; }
	}
}