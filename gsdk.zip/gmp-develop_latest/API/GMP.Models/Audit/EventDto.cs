﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 13:24:33
*
***************************************************************************/

using System;
using System.Collections.Generic;

namespace GMP.Models.Audit
{
    public class EventDto
    {
        public EventDto()
        {
            this.Signers = new List<SignerDto>();
            this.ChangedData = new List<ChangedDataDto>();
            this.MetaData = new List<MetaDataDto>();
        }

        public string Id { get; set; }
        public string AppId { get; set; }
        public DateTime? OpTime { get; set; }
        public string Source { get; set; }
        public string ActionCode { get; set; }

        public string OrgId { get; set; }
        public string OrgName { get; set; }
        public string UserName { get; set; }
        public string UserAccount { get; set; }

        public string SnapshotId { get; set; }
        public bool Result { get; set; }
        public string Remarks { get; set; }
        public List<SignerDto> Signers { get; set; }
        public List<ChangedDataDto> ChangedData { get; set; }
        public List<MetaDataDto> MetaData { get; set; }
    }
}