﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 13:34:19
*
***************************************************************************/

namespace GMP.Models.Audit
{
	public class MetaDataDto
	{
		public string Id { get; set; }
		public string EventId { get; set; }
		public string Key { get; set; }
		public string Value { get; set; }
		public string Category { get; set; } = "custom";
	}
}