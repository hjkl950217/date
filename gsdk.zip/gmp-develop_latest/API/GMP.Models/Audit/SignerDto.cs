﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/24 14:37:22
*
***************************************************************************/

using System;

namespace GMP.Models.Audit
{
	public class SignerDto
	{
		public string Id { get; set; }
		public string EventId { get; set; }
		public string UserId { get; set; }
		public string Code { get; set; }
		public string Account { get; set; }
		public string Name { get; set; }
		public DateTime SignTime { get; set; }
	}
}