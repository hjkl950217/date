﻿namespace GMP.Models.Cache
{
    /// <summary>
    /// 定义缓存Key
    /// </summary>
    public static class CacheKeys
    {
        public const string AUDIT_CODE = "Cache_AuditCode";
    }
}