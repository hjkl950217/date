﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/12 10:28:50
*
***************************************************************************/

namespace GMP.Models.Organization
{
	public class CompanyDto
	{
		public string Id { get; set; }
		public int IdentityId { get; set; }
		public string Code { get; set; }
		public string ThirdPartId { get; set; }
		public string Name { get; set; }
		public string Path { get; set; }
		public bool Group { get; set; }
		public string ParentId { get; set; }
		public int ParentIdentityId { get; set; }
		public string PositionId { get; set; }
		public int PositionIdentityId { get; set; }
		public bool IsMain { get; set; }
	}
}