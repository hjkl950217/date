﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/14 13:02:10
*
***************************************************************************/

namespace GMP.Models.Organization
{
	public class GroupDto
	{
		public string Id { get; set; }
		public int IdentityId { get; set; }
		public string Code { get; set; }
		public string ThirdPartId { get; set; }
		public string Name { get; set; }
	}
}