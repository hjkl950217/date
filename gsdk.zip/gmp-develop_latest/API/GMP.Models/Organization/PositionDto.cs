﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/12 10:30:05
*
***************************************************************************/

namespace GMP.Models.Organization
{
	public class PositionDto
	{
		public string Id { get; set; }
		public int IdentityId { get; set; }
		public string Code { get; set; }
		public string ThirdPartId { get; set; }
		public string ParentId { get; set; }
		public string Name { get; set; }
		public string Path { get; set; }
		public bool Group { get; set; }
		public bool IsMain { get; set; }
		public string DeptId { get; set; }
		public string DeptParentId { get; set; }
		public string DeptPath { get; set; }
		public string OrgId { get; set; }
		public int OrgIdentityId { get; set; }
		public string OrgName { get; set; }
		public string OrgPath { get; set; }
	}
}