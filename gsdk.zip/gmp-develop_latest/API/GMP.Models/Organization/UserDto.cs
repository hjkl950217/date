﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/12 10:23:33
*
***************************************************************************/

using System.Collections.Generic;

namespace GMP.Models.Organization
{
	public class UserDto
	{
		public string Id { get; set; }
		public int IdentityId { get; set; }
		public string Code { get; set; }
		public string Account { get; set; }
		public string Name { get; set; }

		public string Email { get; set; }

		public string Mobile { get; set; }

		public string Telephone { get; set; }

		public int Gender { get; set; }

		public int Status { get; set; }

		public string PositionId { get; set; }

		public int PositionIdentityId { get; set; }

		public string PositionCode { get; set; }

		public string PositionName { get; set; }

		public string PositionPath { get; set; }

		public string DeptId { get; set; }

		public int DeptIdentityId { get; set; }

		public string DeptCode { get; set; }

		public string DeptName { get; set; }

		public string DeptPath { get; set; }

		public string OrgId { get; set; }

		public int OrgIdentityId { get; set; }

		public string OrgCode { get; set; }

		public string OrgName { get; set; }

		public string OrgPath { get; set; }

		public List<CompanyDto> Companies { get; set; } = new List<CompanyDto>();
		public List<DepartmentDto> Departments { get; set; } = new List<DepartmentDto>();
		public List<PositionDto> Positions { get; set; } = new List<PositionDto>();
		public List<GroupDto> Groups { get; set; } = new List<GroupDto>();
	}
}