﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/10 11:40:40
*
***************************************************************************/

using GMP.Data.ECM;
using System;
using System.Collections.Generic;
using System.Text;

namespace GMP.Services
{
    public class AnnotationService
    {
        private readonly DmsDbContext context = new DmsDbContext();

        /// <summary>
        /// Get the file annotation according to the file version ID.
        /// </summary>
        /// <param name="fileVerId">The file version id.</param>
        /// <returns>A collection of annotations that specify the version of a file.</returns>
        public List<DmsAnnotation> GetAnnotationsByFileVerId(int fileVerId)
        {
            return context.GetAnnotationsByFileVerId(fileVerId);
        }

        /// <summary>
        /// Gets all comments under the specified annotation.
        /// </summary>
        /// <param name="annotationId">The annotation id.</param>
        /// <returns>All comments of specified annotation.</returns>
        public List<DmsAnnotationComment> GetCommentsByAnnotationId(int annotationId)
        {
            return context.GetCommentsByAnnotationId(annotationId);
        }
    }
}
