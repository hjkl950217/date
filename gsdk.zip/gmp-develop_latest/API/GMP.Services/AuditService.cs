﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:05:07
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Cache.Memory;
using GMP.Data.Audit;
using GMP.Models.Audit;
using GMP.Models.Cache;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Caching.Memory;

namespace GMP.Services
{
    public class AuditService : IAuditService
    {
        private readonly AuditDbContext context = new AuditDbContext();
        private readonly IMemoryCache memoryCache;

        public AuditService(IMemoryCache memoryCache)
        {
            //设置缓存
            this.memoryCache = memoryCache;
            this.RefreshCacheAuditCode();
        }

        private void RefreshCacheAuditCode()
        {
            Func<Dictionary<string, string>> getAllEventName = () =>
            {
                return this.context.Actions.AsNoTracking()
                .Select(t => new { t.Code, t.Cn })
                .ToList()
                .ToDictionary(k => k.Code, v => v.Cn);
            };
            this.memoryCache.SetAbsolute(
                key: CacheKeys.AUDIT_CODE,
                value: getAllEventName(),
                absoluteExpirationRelativeToNow: TimeSpan.FromMinutes(5),
                itemFactory: k => getAllEventName());
        }

        public List<ActionDto> GetAllActions()
        {
            List<ActionDto> actions = new List<ActionDto>();

            List<EformEagleActions> list = this.context.GetAllActions();
            foreach (EformEagleActions action in list)
            {
                ActionDto dto = new ActionDto
                {
                    Id = action.Id,
                    Code = action.Code,
                    Confirmation = action.Confirmation == 1,
                    Signature = action.Signature == 1,
                    Remarks = action.Remarks,
                    Cn = action.Cn,
                    Tw = action.Tw,
                    En = action.En,
                    Ja = action.Ja
                };

                actions.Add(dto);
            }

            return actions;
        }

        #region SaveAuditEvent

        public void SaveAuditEvent(EventDto eventData)
        {
            IDbContextTransaction transaction = this.context.Database.BeginTransaction();

            try
            {
                string eventId = Guid.NewGuid().ToString();
                eventData.Id = eventId;

                this.SaveEventData(eventData);
                this.SaveSigners(eventData.Signers, eventId);
                this.SaveChangedData(eventData.ChangedData, eventId);
                this.SaveMetaData(eventData.MetaData, eventId);

                transaction.Commit();
            }
            catch (Exception e)
            {
                transaction.Rollback();
                throw e;
            }
        }

        private void SaveEventData(EventDto eventData)
        {
            Dictionary<string, string> eventNameDic = this.memoryCache.Get<Dictionary<string, string>>(CacheKeys.AUDIT_CODE);

            EformEagleEvents entity = new EformEagleEvents();
            entity.Id = eventData.Id;
            entity.CreateTime = DateTime.Now;
            entity.ModifiedTime = DateTime.Now;
            entity.CreateId = "system";
            entity.UpdateId = "system";
            entity.AppId = eventData.AppId;
            entity.OrgId = eventData.OrgId;
            entity.OrgName = eventData.OrgName;
            entity.UserName = eventData.UserName;
            entity.UserAccount = eventData.UserAccount;
            entity.OpTime = eventData.OpTime;
            entity.Source = eventData.Source;
            entity.ActionCode = eventData.ActionCode;
            entity.EventName = eventNameDic[eventData.ActionCode];
            entity.Result = eventData.Result ? 1 : 0;
            entity.Remarks = eventData.Remarks;
            entity.SnapshotId = eventData.SnapshotId;

            this.context.Events.Add(entity);
            this.context.SaveChanges();
        }

        private void SaveSigners(List<SignerDto> signers, string eventId)
        {
            List<EformEagleSigners> entities = new List<EformEagleSigners>();

            foreach (SignerDto signer in signers)
            {
                EformEagleSigners entity = new EformEagleSigners();
                entity.Id = Guid.NewGuid().ToString();
                entity.CreateTime = DateTime.Now;
                entity.ModifiedTime = DateTime.Now;
                entity.CreateId = "system";
                entity.UpdateId = "system";
                entity.EventId = eventId;
                entity.UserId = signer.UserId;
                entity.Code = signer.Code;
                entity.Account = signer.Account;
                entity.Name = signer.Name;
                entity.SignTime = signer.SignTime;

                entities.Add(entity);
            }

            this.context.Signers.AddRange(entities);
            this.context.SaveChanges();
        }

        private void SaveChangedData(List<ChangedDataDto> changedData, string eventId)
        {
            List<EformEagleChangeddata> entities = new List<EformEagleChangeddata>();

            foreach (ChangedDataDto data in changedData)
            {
                EformEagleChangeddata entity = new EformEagleChangeddata();
                entity.Id = Guid.NewGuid().ToString();
                entity.CreateTime = DateTime.Now;
                entity.ModifiedTime = DateTime.Now;
                entity.CreateId = "system";
                entity.UpdateId = "system";
                entity.EventId = eventId;
                entity.Filed = data.Field;
                entity.Name = data.Name;
                entity.OldValue = data.OldValue;
                entity.OldText = data.OldText;
                entity.NewValue = data.NewValue;
                entity.NewText = data.NewText;
                entity.Reason = data.Reason;

                entities.Add(entity);
            }

            this.context.ChangedDatas.AddRange(entities);
            this.context.SaveChanges();
        }

        private void SaveMetaData(List<MetaDataDto> metaData, string eventId)
        {
            List<EformEagleMetadata> entities = new List<EformEagleMetadata>();

            foreach (MetaDataDto data in metaData)
            {
                EformEagleMetadata entity = new EformEagleMetadata();
                entity.Id = Guid.NewGuid().ToString();
                entity.CreateTime = DateTime.Now;
                entity.ModifiedTime = DateTime.Now;
                entity.CreateId = "system";
                entity.UpdateId = "system";
                entity.EventId = eventId;
                entity.Key = data.Key;
                entity.Value = data.Value;
                entity.Category = data.Category;

                entities.Add(entity);
            }

            this.context.MetaDatas.AddRange(entities);
            this.context.SaveChanges();
        }

        #endregion SaveAuditEvent
    }
}