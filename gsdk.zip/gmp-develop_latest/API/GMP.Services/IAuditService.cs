﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/19 11:05:07
*
***************************************************************************/

using System.Collections.Generic;
using GMP.Models.Audit;

namespace GMP.Services
{
    public interface IAuditService
    {
        List<ActionDto> GetAllActions();
        void SaveAuditEvent(EventDto eventData);
    }
}