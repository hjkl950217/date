﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/11 11:24:44
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Data.Organization;
using GMP.Models.Organization;

namespace GMP.Services
{
    public class OrganizationService
    {
        private readonly OrgDbContext context = new OrgDbContext();

        public UserDto GetUserInfoById(string userId)
        {
            if (string.IsNullOrEmpty(userId)) throw new ArgumentNullException(nameof(userId));

            UserDto dto = new UserDto();
            GmpUser user = this.context.GetUserInfoById(userId);
            if (!string.IsNullOrEmpty(user.Id))
            {
                dto.Id = user.Id;
                dto.IdentityId = user.UserIdentityID;
                dto.Code = user.UserCode;
                dto.Account = user.UserAccount;
                dto.Name = user.UserName;
                dto.Email = user.UserEmail;
                dto.Mobile = user.UserMobile;
                dto.Telephone = user.UserTelephone;
                dto.Gender = user.UserGender;
                dto.Status = user.UserStatus;

                dto.DeptId = user.DeptId;
                dto.DeptIdentityId = user.DeptIdentityId ?? 0;
                dto.DeptCode = user.DeptCode;
                dto.DeptName = user.DeptName;
                dto.DeptPath = user.DeptPath;

                dto.PositionId = user.PositionId;
                dto.PositionIdentityId = user.PositionIdentityId ?? 0;
                dto.PositionCode = user.PositionCode;
                dto.PositionName = user.PositionName;
                dto.PositionPath = user.PositionPath;

                dto.OrgId = user.OrgId;
                dto.OrgIdentityId = user.OrgIdentityId ?? 0;
                dto.OrgCode = user.OrgCode;
                dto.OrgName = user.OrgName;
                dto.OrgPath = user.OrgPath;

                dto.Companies = this.GetCompaniesByUserId(user.UserId, user.OrgId).ToList();
                dto.Departments = this.GetDepartmentsByUserId(user.UserId, user.DeptId).ToList();
                dto.Positions = this.GetPositionsByUserId(user.UserId, user.PositionId).ToList();
                dto.Groups = this.GetGroupsByUserId(user.UserId).ToList();
            }

            return dto;
        }

        public UserDto GetUserInfoByAccount(string account)
        {
            if (string.IsNullOrEmpty(account)) throw new ArgumentException(nameof(account));

            UserDto dto = new UserDto();
            GmpUser user = this.context.GetUserInfoByAccount(account);
            if (user == null || string.IsNullOrEmpty(user.Id)) return null;

            dto.Id = user.Id;
            dto.IdentityId = user.UserIdentityID;
            dto.Code = user.UserCode;
            dto.Account = user.UserAccount;
            dto.Name = user.UserName;
            dto.Email = user.UserEmail;
            dto.Mobile = user.UserMobile;
            dto.Telephone = user.UserTelephone;
            dto.Gender = user.UserGender;
            dto.Status = user.UserStatus;

            dto.DeptId = user.DeptId;
            dto.DeptIdentityId = user.DeptIdentityId ?? 0;
            dto.DeptCode = user.DeptCode;
            dto.DeptName = user.DeptName;
            dto.DeptPath = user.DeptPath;

            dto.PositionId = user.PositionId;
            dto.PositionIdentityId = user.PositionIdentityId ?? 0;
            dto.PositionCode = user.PositionCode;
            dto.PositionName = user.PositionName;
            dto.PositionPath = user.PositionPath;

            dto.OrgId = user.OrgId;
            dto.OrgIdentityId = user.OrgIdentityId ?? 0;
            dto.OrgCode = user.OrgCode;
            dto.OrgName = user.OrgName;
            dto.OrgPath = user.OrgPath;

            dto.Companies = this.GetCompaniesByUserId(user.UserId, user.OrgId).ToList();
            dto.Departments = this.GetDepartmentsByUserId(user.UserId, user.DeptId).ToList();
            dto.Positions = this.GetPositionsByUserId(user.UserId, user.PositionId).ToList();
            dto.Groups = this.GetGroupsByUserId(user.UserId).ToList();

            return dto;
        }

        public IEnumerable<CompanyDto> GetCompaniesByUserId(string userId, string mainOrgId = null)
        {
            List<CompanyDto> list = new List<CompanyDto>();

            IEnumerable<GmpCompany> companies = this.context.GetCompaniesByUserId(userId);
            foreach (GmpCompany company in companies)
            {
                CompanyDto dto = new CompanyDto();
                dto.Id = company.OrgId;
                dto.IdentityId = company.OrgIdentityID;
                dto.Code = company.OrgCode;
                dto.Name = company.OrgName;
                dto.Path = company.OrgPath;
                dto.ThirdPartId = company.OrgThirdPartId;
                dto.Group = company.Group == 1;
                dto.ParentId = company.OrgParentId;
                dto.ParentIdentityId = company.OrgParentidentityId ?? 0;
                dto.PositionId = company.OrgMasterPositionId;
                dto.PositionIdentityId = company.OrgMasterPositionIdentityId ?? 0;

                if (mainOrgId != null && company.Id == mainOrgId)
                {
                    dto.IsMain = true;
                }

                list.Add(dto);
            }

            return list;
        }

        public IEnumerable<DepartmentDto> GetDepartmentsByUserId(string userId, string mainDeptId = null)
        {
            List<DepartmentDto> list = new List<DepartmentDto>();

            IEnumerable<GmpDepartment> departments = this.context.GetDepartmentsByUserId(userId);
            foreach (GmpDepartment dept in departments)
            {
                DepartmentDto dto = new DepartmentDto();
                dto.Id = dept.DeptId;
                dto.IdentityId = dept.DeptIdentityID;
                dto.Code = dept.DeptCode;
                dto.Name = dept.DeptName;
                dto.Path = dept.DeptPath;
                dto.ThirdPartId = dept.DeptThirdPartId;
                dto.Group = dept.Group == 1;
                dto.ParentId = dept.DeptParentId;
                dto.ParentIdentityId = dept.DeptParentIdentityId ?? 0;
                dto.PositionId = dept.DeptMasterPositionId;
                dto.PositionIdentityId = dept.DeptMasterPositionIdentityId;
                dto.OrgId = dept.OrgId;
                dto.OrgIdentityId = dept.OrgIdentityID;
                dto.OrgName = dept.OrgName;
                dto.OrgPath = dept.OrgPath;

                if (mainDeptId != null && dept.Id == mainDeptId)
                {
                    dto.IsMain = true;
                }

                list.Add(dto);
            }

            return list;
        }

        public IEnumerable<PositionDto> GetPositionsByUserId(string userId, string mainPositionId = null)
        {
            List<PositionDto> list = new List<PositionDto>();

            IEnumerable<GmpPosition> positions = this.context.GetPositionsByUserId(userId);
            foreach (GmpPosition position in positions)
            {
                PositionDto dto = new PositionDto();
                dto.Id = position.PositionId;
                dto.IdentityId = position.PositionIdentityID;
                dto.Code = position.PositionCode;
                dto.Name = position.PositionName;
                dto.Path = position.PositionPath;
                dto.ThirdPartId = position.PositionThirdPartId;
                dto.Group = position.Group == 1;
                dto.ParentId = position.PositionParentId;
                dto.DeptId = position.DeptId;
                dto.DeptParentId = position.DeptParentId;
                dto.DeptPath = position.DeptPath;
                dto.OrgId = position.OrgId;
                dto.OrgIdentityId = position.OrgIdentityID;
                dto.OrgName = position.OrgName;
                dto.OrgPath = position.OrgPath;

                if (mainPositionId != null && position.Id == mainPositionId)
                {
                    dto.IsMain = true;
                }

                list.Add(dto);
            }

            return list;
        }

        public IEnumerable<GroupDto> GetGroupsByUserId(string userId)
        {
            List<GroupDto> list = new List<GroupDto>();

            IEnumerable<OrgGroup> groups = this.context.GetGroupsByUserId(userId);
            foreach (OrgGroup group in groups)
            {
                GroupDto dto = new GroupDto();
                dto.Id = group.GroupId;
                dto.IdentityId = group.GroupIdentityID;
                dto.Code = group.GroupCode;
                dto.Name = group.GroupName;
                dto.ThirdPartId = group.GroupThirdPartId;

                list.Add(dto);
            }

            return list;
        }
    }
}