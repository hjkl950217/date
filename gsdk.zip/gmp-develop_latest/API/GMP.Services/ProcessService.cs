﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/13 15:57:15
*
***************************************************************************/

using GMP.Data.Process;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Services
{
    public class ProcessService
    {
        private readonly ProcessDbContext context = new ProcessDbContext();

        /// <summary>
        /// Get the latest version of the process id according to the process key.
        /// </summary>
        /// <param name="processKey">The key of the process definition.</param>
        /// <returns>The latest process id.</returns>
        public string GetLatestProcessIdByKey(string processKey)
        {
            ActReProcdef def = this.context.GetProcessDefinitionByKey(processKey);
            if (def != null) return def.ID;

            return null;
        }

        public DataResult<string> GetProcessPreviewUrl(string incident)
        {
            var url = "";
            var processInfo = context.ProcessInfo.FirstOrDefault(t => t.Incident == incident);
            if (processInfo == null)
            {
                return url;
            }
            url = $"/eform/Default/default?formId={processInfo.FormId}&processId={processInfo.Process}&taskType=archivetask&incidentId={processInfo.Incident}&id={processInfo.DataSourceId}";
            return url;
        }

        /// <summary>
        /// Finds the user task under the specified process instance.
        /// </summary>
        /// <param name="incident">Process instance number.</param>
        /// <param name="userId">The user id.</param>
        /// <returns>Specify the user's tasks.</returns>
        public ActRuTask GetTaskByUserId(string incident, string userId)
        {
            List<ActRuTask> tasks = this.context.GetTaskByIncident(incident);
            if (tasks.Count == 0) return null;

            var task = tasks.Find(v => v.ASSIGNEE == userId);

            // Used to determine whether it is an initiating node
            //var task = tasks.Find(v => v.ASSIGNEE == userId && v.EXECUTIONID != incident);
            return task;
        }
    }
}