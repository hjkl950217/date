﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/30 12:45:15
*
***************************************************************************/

using System;
using System.Collections.Concurrent;

namespace GMP.Services
{
    /// <summary>
    /// Provides a token lock service to check whether a specified token is expired.
    /// </summary>
    public class TokenLockService
    {
        private static readonly ConcurrentDictionary<string, DateTime> dateCache = new ConcurrentDictionary<string, DateTime>();
        private static readonly ConcurrentDictionary<string, bool> lockCache = new ConcurrentDictionary<string, bool>();

        /// <summary>
        /// Refresh the expiration time of the token.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns>True if the refresh succeeds, otherwise, false.</returns>
        public static dynamic Refresh(string token)
        {
            CacheToken(token);
            if (lockCache[token]) return false;

            dateCache[token] = DateTime.Now;
            lockCache[token] = false;

            return DataResult(token, true);
        }

        /// <summary>
        /// Check the token lock status.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <param name="freetime">Lock screen interval.</param>
        /// <returns>True if the token is locked, otherwise, false.</returns>
        public static dynamic Check(string token, int freetime)
        {
            CacheToken(token);
            if (lockCache[token]) return DataResult(token, true);

            DateTime now = DateTime.Now;
            DateTime cache = dateCache[token];
            double diff = (now - cache).TotalMinutes;
            if (diff >= freetime)
            {
                lockCache[token] = true;
                return DataResult(token, true);
            }

            return DataResult(token, false);
        }

        /// <summary>
        /// Unlocks the specified token.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns>True if the token is unlocked, otherwise, false.</returns>
        public static bool Unlock(string token)
        {
            CacheToken(token);
            dateCache[token] = DateTime.Now;
            lockCache[token] = false;

            return true;
        }

        /// <summary>
        /// Cache the token and skip it if it already exists.
        /// </summary>
        /// <param name="token">The token.</param>
        private static void CacheToken(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new ArgumentNullException(nameof(token), "The lack of the user token.");
            }

            //Record the cache date, which is used to refresh the cache.
            if (!dateCache.ContainsKey("CacheDate"))
            {
                dateCache.TryAdd("CacheDate", DateTime.Now.Date);
            }

            //The cache is flushed if it has lasted more than one day.
            if (dateCache["CacheDate"] != DateTime.Now.Date)
            {
                dateCache.Clear();
                lockCache.Clear();
                dateCache.TryAdd("CacheDate", DateTime.Now.Date);
            }

            //If the token is not cached, cache it.
            if (!lockCache.ContainsKey(token))
            {
                dateCache.TryAdd(token, DateTime.Now);
                lockCache.TryAdd(token, false);
            }
        }

        /// <summary>
        /// Returns an object containing a Boolean value and the last cache date.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <param name="result">A Boolean result.</param>
        /// <returns>An object containing a Boolean value and the last cache date.</returns>
        private static dynamic DataResult(string token, bool result)
        {
            var state = result;
            var cacheDate = dateCache[token];
            var currDate = DateTime.Now;
            var lockState = lockCache[token];

            return new { state, cacheDate, currDate, lockState };
        }
    }
}