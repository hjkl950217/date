﻿using System.Collections.Generic;
using GMP.EDocServices;
using GMP.IAppServices.Annotation;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AnnotationController : ControllerBase
    {
        /// <summary>
        /// Verifies the permission of the specified user to annotation on the specified file.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="fileVerId"></param>
        /// <param name="userId"></param>
        /// <param name="incident"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("permission")]
        public DataResult<AnnotationPermissionResponse> CheckAnnotationPermission(int fileId, int fileVerId, string userId, string incident)
        {
            AnnotationPermissionResponse response = new AnnotationPermissionResponse();
            response.Annotate = false;

            //Required parameter check.
            //if (fileId == 0 || fileVerId == 0 || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(incident))
            if (fileId == 0 || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(incident))
            {
                return new DataResult<AnnotationPermissionResponse>(ErrorCodes.PERCONDITION_FAILED_412);
            }

            //Verify the existence of the file.
            EDoc2.IAppService.Model.ReturnValueResult<EDoc2.IAppService.ResultModel.FileInfoForSdkResult> fileInfoRes = FileService.GetFileInfoById(fileId);
            if (fileInfoRes.Result != 0)
            {
                return new DataResult<AnnotationPermissionResponse>(ErrorCodes.FILE_NOT_FOUND_430);
            }

            //Annotate on the latest version only.
            if (fileVerId != 0 && fileVerId != fileInfoRes.Data.LastVersionId) return response;

            //Verifies whether the user exists.
            EDoc2.IAppService.Model.ReturnValueResult<EDoc2.IAppService.Model.Organization.UserInfo> userRes = UserService.GetUserInfoByUserGuid(userId);
            if (userRes.Result != 0)
            {
                return new DataResult<AnnotationPermissionResponse>(ErrorCodes.USER_NOT_FOUND_450);
            }

            //Get the user process task.
            ProcessService processService = new ProcessService();
            Data.Process.ActRuTask task = processService.GetTaskByUserId(incident, userId);
            if (task != null) response.Annotate = true;

            //Verifies the user's permission to delete the specified annotation.
            AnnotationService annotationService = new AnnotationService();
            List<Data.ECM.DmsAnnotation> annotations = annotationService.GetAnnotationsByFileVerId(fileVerId);
            foreach (Data.ECM.DmsAnnotation annotation in annotations)
            {
                bool deletable = false;
                if (annotation.UserIdentityId == userRes.Data.IdentityId
                    && annotation.DateTimeCreated >= task?.CREATETIME)
                {
                    deletable = true;
                }

                response.Annotations.Add(new RemovableObject()
                {
                    Id = annotation.AnnotationId,
                    Deletable = deletable
                });
            }

            return response;
        }
    }
}