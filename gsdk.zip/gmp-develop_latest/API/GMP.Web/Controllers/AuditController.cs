﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/02/19 13:15:57
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using GMP.Models.Audit;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AuditController : ControllerBase
    {
        private readonly IAuditService auditService;

        public AuditController(IAuditService auditService)
        {
            this.auditService = auditService;
        }

        [HttpGet]
        [Route("actions")]
        public DataResult<List<ActionDto>> GetAllActions()
        {
            return this.auditService.GetAllActions();
        }

        [HttpPost]
        [Route("event")]
        public DataResult<bool> SaveAuditEvent(EventDto eventData)
        {
            eventData.OpTime ??= DateTime.Now;
            this.auditService.SaveAuditEvent(eventData);

            return true;
        }

        /// <summary>
        /// 添加审计活动(为后端服务)
        /// </summary>
        /// <param name="eventData"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("eventbyservice")]
        public DataResult<bool> SaveAuditEventByService([FromQuery] int id, EventDto eventData)
        {
            return this.SaveAuditEvent(eventData);
        }

        [HttpPost]
        [Route("snapshot")]
        public DataResult<bool> CreateSnapshot([FromQuery] string snapshotId, [FromForm] string image)
        {
            if (string.IsNullOrEmpty(image))
                return false;
            if (!image.Contains("image/png"))
                return false;

            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            string year = DateTime.Now.Year.ToString();
            string month = DateTime.Now.Month.ToString();
            string day = DateTime.Now.Day.ToString();

            string fileName = Path.Combine(appDir, "snapshots", year, month, day, $"{snapshotId}.png");
            string filePath = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }

            image = image.Replace("data:image/png;base64,", "").Trim();
            byte[] imageBytes = Convert.FromBase64String(image);
            System.IO.File.WriteAllBytes(fileName, imageBytes);

            return true;
        }

        [HttpGet]
        [Route("snapshot")]
        public ActionResult GetSnapshot([FromQuery] string snapshotId, [FromQuery] long t)
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            DateTimeOffset dateTime = DateTimeOffset.FromUnixTimeMilliseconds(t);
            string year = dateTime.Year.ToString();
            string month = dateTime.Month.ToString();
            string day = dateTime.Day.ToString();
            string fileName = Path.Combine(appDir, "snapshots", year, month, day, $"{snapshotId}.png");
            FileStream image = System.IO.File.OpenRead(fileName);
            return this.File(image, "image/png");
        }
    }
}