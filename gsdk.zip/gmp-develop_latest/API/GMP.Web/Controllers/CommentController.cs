﻿using System.Collections.Generic;
using GMP.EDocServices;
using GMP.IAppServices.Annotation;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CommentController : ControllerBase
    {
        [HttpGet]
        [Route("permission")]
        public DataResult<CommentPermissionResponse> CheckAnnotationPermission(int fileId, int fileVerId, string userId, string incident, int annotationId)
        {
            CommentPermissionResponse response = new CommentPermissionResponse();
            response.Comment = false;

            //Required parameter check.
            //if (fileId == 0
            //    || fileVerId == 0
            //    || string.IsNullOrEmpty(userId)
            //    || string.IsNullOrEmpty(incident)
            //    || annotationId == 0)
            if (fileId == 0
                || string.IsNullOrEmpty(userId)
                || string.IsNullOrEmpty(incident)
                || annotationId == 0)
            {
                return new DataResult<CommentPermissionResponse>(ErrorCodes.PERCONDITION_FAILED_412);
            }

            //Verify the existence of the file.
            EDoc2.IAppService.Model.ReturnValueResult<EDoc2.IAppService.ResultModel.FileInfoForSdkResult> fileInfoRes = FileService.GetFileInfoById(fileId);
            if (fileInfoRes.Result != 0)
            {
                return new DataResult<CommentPermissionResponse>(ErrorCodes.FILE_NOT_FOUND_430);
            }

            //Comment on the latest version only.
            if (fileVerId != 0 && fileVerId != fileInfoRes.Data.LastVersionId) return response;

            //Verifies whether the user exists.
            EDoc2.IAppService.Model.ReturnValueResult<EDoc2.IAppService.Model.Organization.UserInfo> userRes = UserService.GetUserInfoByUserGuid(userId);
            if (userRes.Result != 0)
            {
                return new DataResult<CommentPermissionResponse>(ErrorCodes.USER_NOT_FOUND_450);
            }

            //Get the user process task.
            ProcessService processService = new ProcessService();
            Data.Process.ActRuTask task = processService.GetTaskByUserId(incident, userId);
            if (task == null) return response;
            if (task != null) response.Comment = true;

            //Verifies the user's permission to delete the specified comments.
            AnnotationService annotationService = new AnnotationService();
            List<Data.ECM.DmsAnnotationComment> comments = annotationService.GetCommentsByAnnotationId(annotationId);
            foreach (Data.ECM.DmsAnnotationComment comment in comments)
            {
                bool deletable = false;
                if (comment.UserIdentityId == userRes.Data.IdentityId
                    && comment.DateTimeCreated >= task?.CREATETIME)
                {
                    deletable = true;
                }

                response.Comments.Add(new RemovableObject()
                {
                    Id = comment.CommentId,
                    Deletable = deletable
                });
            }

            return response;
        }
    }
}