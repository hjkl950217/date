﻿using EDoc2.IAppService.Model;
using GMP.EDocServices;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class DocController : ControllerBase
    {
        /// <summary>
        /// 创建文件夹
        /// </summary>
        /// <param name="name">文件夹名称</param>
        /// <param name="parentFolderId">父级文件夹Id</param>
        /// <param name="folderCode">文件夹编号</param>
        /// <param name="remark">文件夹备注</param>
        /// <returns></returns>
        [HttpPost]
        public DataResult<object> CreateFolder(CreateFolderDto dto)
        // public DataResult<object> CreateFolder( string folderName)
        {
            return FolderService.CreateFolder(dto);
        }

        /// <summary>
        /// 移动文件和文件夹列表到某个文件夹
        /// </summary>
        /// <param name="targetFolderId">目标文件夹id</param>
        /// <param name="folderIdList">需要移动的文件夹id列表</param>
        /// <param name="fileIdList">需要移动的文件id列表</param>
        /// <returns></returns>
        [HttpPost]
        public DataResult<object> MoveFolderListAndFileList(MoveFileListAndFolderListDto dto)
        {
            return DocService.MoveFolderListAndFileList(dto.TargetFolderId, dto.FolderIdList, dto.FileIdList);
            //return DocService.MoveFolderListAndFileList(targetFolderId,folderIdList,fileIdList).Data;
        }

        /// <summary>
        /// 获取权限类别
        /// </summary>
        /// <param name="entryType">实体类型，1：文档文件夹，2：文档文件，16：团队文件夹，32：中台</param>
        /// <param name="lang">多语言，默认是中文(zh-cn)，繁体中文：zh-tw，日文：ja，英文：en</param>
        /// <returns></returns>
        [HttpGet]
        public DataResult<object> GetFolderPermCatesByEntryType(int entryType, string lang = "")
        {
            return DocService.GetFolderPermCatesByEntryType(entryType, lang);
        }

        /// <summary>
        /// 根据权限类别设置文件夹权限
        /// </summary>
        /// <param name="folderId">文件夹ID</param>
        /// <param name="cateId">权限类别ID</param>
        /// <param name="memberId">成员ID</param>
        /// <param name="memberType">成员类型</param>
        /// <param name="startTime">开始时间</param>
        /// <param name="expiredTime">到期时间</param>
        [HttpPost]
        public DataResult<object> SetFolderPermissionByCateId(FolderPermissionSetDto dto)
        {
            return FolderService.SetFolderPermissionByCateId(dto);
        }

        /// <summary>
        /// 删除文件夹权限
        /// </summary>
        /// <param name="FolderId">文件夹ID</param>
        /// <param name="Mermbers">需删除的权限对象</param>
        /// <returns></returns>
        [HttpPost]
        public DataResult<object> DeleteFolderPermission(DeleteFolderPermissionDto dto)
        {
            return FolderService.DeleteFolderPermission(dto);
        }

        /// <summary>
        /// 清楚文件夹权限缓存
        /// </summary>
        /// <param name="FolderId">文件夹ID</param>
        /// <param name="Mermbers">需删除的权限对象</param>
        /// <returns></returns>
        [HttpGet]
        public DataResult<object> ClearPermissionByFolder(string token, int folderId)
        {
            return FolderService.ClearPermissionByFolder(token, folderId);
        }

        [HttpGet]
        public DataResult<object> GetDocInfoByFileId(int fileId)
        {
            FileDto fileDto = new FileDto();
            fileDto.FileId = fileId;
            return DocService.GetDocInfoByFileId(fileDto);
        }
        [HttpPost]
        public DataResult<int> SetPermissions(SetPermissionDto setPermissionDto) {
            return FolderPermissionService.SetPermissions(setPermissionDto).Result;
        }
    }
}