﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/23 ‏‎16:18:56
*
***************************************************************************/

using System;
using EDoc2.IAppService.Model;
using GMP.EDocServices;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class LockController : ControllerBase
    {
        /// <summary>
        /// Refresh the expiration time of the user token.
        /// </summary>
        /// <param name="token">The user token.</param>
        /// <returns>True if the refresh succeeds, otherwise, false.</returns>
        [HttpGet]
        [Route("Refresh/{token}")]
        [Obsolete]
        public DataResult<object> Refresh(string token)
        {
            return TokenLockService.Refresh(token);
        }

        [HttpGet]
        [Route("Refresh")]
        public DataResult<object> Refresh2([FromQuery] string token)
        {
            return TokenLockService.Refresh(token);
        }

        /// <summary>
        /// Check the user token lock status.
        /// </summary>
        /// <param name="token">The user token.</param>
        /// <param name="freetime">Lock screen interval.</param>
        /// <returns>True if the user token is locked, otherwise, false.</returns>
        [HttpGet]
        [Route("Check/{freetime}/{token}")]
        [Obsolete]
        public DataResult<object> Check(string token, int freetime = 7)
        {
            return TokenLockService.Check(token, freetime);
        }

        /// <summary>
        /// Check the user token lock status.
        /// </summary>
        /// <param name="token">The user token.</param>
        /// <param name="freetime">Lock screen interval.</param>
        /// <returns>True if the user token is locked, otherwise, false.</returns>
        [HttpPost]
        [Route("Check")]
        public DataResult<object> Check2([FromQuery] string token, [FromQuery] int freetime)
        {
            if (freetime == 0)
                freetime = 7;//默认7 待拿掉上面的API后， freetime改为可选参数
            return TokenLockService.Check(token, freetime);
        }

        /// <summary>
        /// Unlock with the specified account and password.
        /// </summary>
        /// <param name="token">The user token.</param>
        /// <param name="act">The user account.</param>
        /// <param name="pwd">The user password.</param>
        /// <returns>True if the user token is unlocked, otherwise, false.</returns>
        [HttpPost]
        [Route("Unlock/{token}")]
        [Obsolete]
        public DataResult<bool> Unlock(string token, [FromForm] string act, [FromForm] string pwd)
        {
            return this.Unlock2(token, act, pwd);
        }

        [HttpPost]
        [Route("Unlock")]
        public DataResult<bool> Unlock2(
            [FromQuery] string token,
            [FromForm] string act,
            [FromForm] string pwd)
        {
            ReturnValueResult<bool> result = UserService.Authentication(act, pwd);

            //Flush the cache after unlocking.
            if (result.Result == 0)
            {
                TokenLockService.Unlock(token);
            }

            result.Result = result.Result == 0 ? 200 : result.Result;
            return new DataResult<bool>(result.Result, result.Message, result.Data);
        }
    }
}