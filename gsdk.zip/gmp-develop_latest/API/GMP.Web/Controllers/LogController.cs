﻿using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
	[Route("[controller]")]
	[ApiController]
	public class LogController : ControllerBase
	{
		[HttpPost]
		[Route("push")]
		public void Push(int level, string message, string group, string ex, string appid)
		{
		}
	}
}