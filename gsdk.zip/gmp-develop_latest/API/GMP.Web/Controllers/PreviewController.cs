﻿using EDoc2.IAppService.Model;
using EDoc2.IAppService.Model.Organization;
using EDoc2.IAppService.ResultModel;
using GMP.ApiClient;
using GMP.Configuration;
using GMP.EDocServices;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;
using TMS.IAppServices;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PreviewController : ControllerBase
    {
        [HttpGet]
        [Route("permission/{fileId}/{fileVerId}")]
        public DataResult<bool> CheckPreviewPermission(int fileId, int fileVerId, string userId, string gpc)
        {
            try
            {
                //Required parameter check.
                //update by long.wei
                //date 2021-07-06 16:07:03
                //reason Remove file version ID check
                if (fileId == 0 || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(gpc))
                //if (fileId == 0 || fileVerId == 0 || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(gpc))
                {
                    return new DataResult<bool>(ErrorCodes.PERCONDITION_FAILED_412);
                }

                //Verify the existence of the file.
                ReturnValueResult<FileInfoForSdkResult> fileInfoRes = FileService.GetFileInfoById(fileId);
                if (fileInfoRes == null || fileInfoRes.Result != 0)
                {
                    return new DataResult<bool>(ErrorCodes.FILE_NOT_FOUND_430);
                }

                //Verifies whether the user exists.
                ReturnValueResult<UserInfo> userRes = UserService.GetUserInfoByUserGuid(userId);
                if (userRes.Result != 0)
                {
                    return new DataResult<bool>(ErrorCodes.USER_NOT_FOUND_450);
                }

                var datas = gpc.Split("-");
                if (datas.Length < 2) return false;

                var code = datas[0];
                var data = gpc.Replace($"{code}-", "");

                //if (gpc.Length < 6) return false;

                //string code = gpc.Substring(0, 4);
                //string data = gpc.Substring(5, gpc.Length - 5);

                /* 说明
                 * 这个接口会被ECM(定制包)调用,用于确认权限
                 * 不同的code对应不同的验证模式,如果要扩展，继续添加不同的代码与调用方法即可
                 *
                 * 注:不同的code对应的data部分是不同的
                 *
                 */

                if (code == "CAPP") return this.CheckApproverPreviewPermission(fileId, fileVerId, userId, data);
                if (code == "CTPP") return this.CheckTrainingPreviewPermission(userId, data);

                return false;
            }
            catch (System.Exception e)
            {
                return new DataResult<bool>(ErrorCodes.INNER_ERROR_500, e.Message, false);
            }
        }

        /// <summary>
        /// Checks whether the user is the current owner of the specified process task.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="fileVerId"></param>
        /// <param name="userId"></param>
        /// <param name="incident"></param>
        /// <returns></returns>
        private bool CheckApproverPreviewPermission(int fileId, int fileVerId, string userId, string incident)
        {
            ProcessService processService = new ProcessService();
            Data.Process.ActRuTask task = processService.GetTaskByUserId(incident, userId);
            if (task == null) return false;

            return true;
        }

        /// <summary>
        /// Checks whether the user is the current owner of the specified training task.
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="fileVerId"></param>
        /// <param name="userId"></param>
        /// <param name="taskId"></param>
        /// <returns></returns>
        private bool CheckTrainingPreviewPermission(string userId, string taskId)
        {
            string baseUrl = AppSettings.GetValue("TMS.SDK.URL");
            IDocumentPreviewService docPreviewService = ServiceClient.GetService<IDocumentPreviewService>(baseUrl);
            return docPreviewService.CheckDocPreviewPermission(userId, taskId);
        }
    }
}