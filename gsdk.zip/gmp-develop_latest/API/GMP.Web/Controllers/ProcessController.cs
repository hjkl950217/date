﻿using System;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProcessController : ControllerBase
    {
        /// <summary>
        /// Get the latest process id based on the process key.
        /// </summary>
        /// <param name="key">The key of the process definition.</param>
        /// <returns>The latest process id.</returns>
        [HttpGet]
        [Route("processid/{key}")]
        public DataResult<string> GetLatestProcessIdByKey(string key)
        {
            if (string.IsNullOrEmpty(key)) throw new ArgumentException(nameof(key));

            ProcessService service = new ProcessService();
            return service.GetLatestProcessIdByKey(key);
        }

        /// <summary>
        /// 通过实例号获取该流程的预览URL地址
        /// </summary>
        /// <param name="incident">实例号</param>
        /// <returns></returns>
        [HttpGet]
        [Route("processPreviewUrl/{incident}")]
        public DataResult<string> GetProcessPreviewUrl(string incident)
        {
            if (string.IsNullOrEmpty(incident)) throw new ArgumentException(nameof(incident));

            ProcessService service = new ProcessService();
            return service.GetProcessPreviewUrl(incident);
        }
    }
}