﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/23 14:37:57
*
***************************************************************************/

using System;
using GMP.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SystemController : ControllerBase
    {
        /// <summary>
        /// Returns the current datetime from the server.
        /// </summary>
        /// <returns>The current datetime.</returns>
        [HttpGet]
        [Route("datetime/now")]
        public void CurrentDate()
        {
            HttpContext.Response.ContentType = "text/plain;charset=utf-8";
            HttpContext.Response.WriteAsync(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        }

        [HttpGet]
        [Route("/ConfigEncrypt/{val}")]
        public string ConfigEncrypt(string val)
        {
            return this.ConfigEncrypt2(val);
        }

        [HttpGet]
        [Route("/ConfigEncrypt")]
        public string ConfigEncrypt2([FromQuery] string val)
        {
            return ConfigurationDecrypt.Encrypt(val);
        }
    }
}