﻿using System;
using System.Collections.Generic;
using System.Linq;
using GMP.EDocServices;
using GMP.Models.Organization;
using GMP.Services;
using Microsoft.AspNetCore.Mvc;

namespace GMP.Web.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        /// <summary>
        /// Verify that the specified account and password is valid.
        /// </summary>
        /// <param name="account">The user account.</param>
        /// <param name="password">The user password.</param>
        /// <returns>
        /// True if the account and password is valid,
        /// otherwise an error code is returned.
        /// </returns>
        [HttpPost]
        [Route("auth")]
        public DataResult<bool> Authentication([FromForm] string account, [FromForm] string password)
        {
            if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(password))
            {
                return new DataResult<bool>(ErrorCodes.PERCONDITION_FAILED_412);
            }

            EDoc2.IAppService.Model.ReturnValueResult<bool> res = UserService.Authentication(account, password);
            if (res.Result == 0)
                return res.Data;

            return new DataResult<bool>(res.Result, res.Message);
        }

        /// <summary>
        /// Login using the specified account and password.
        /// </summary>
        /// <param name="account">The user account.</param>
        /// <param name="password">The user password.</param>
        /// <returns>
        /// Login success returns user token, failure returns an error code.
        /// </returns>
        [HttpPost]
        [Route("login")]
        public DataResult<string> Login([FromForm] string account, [FromForm] string password)
        {
            if (string.IsNullOrEmpty(account))
                throw new ArgumentException(nameof(account));
            if (string.IsNullOrEmpty(password))
                throw new ArgumentException(nameof(password));

            EDoc2.IAppService.Model.ReturnValueResult<string> res = UserService.Login(account, password);
            if (res.Result == 0)
                return res.Data;

            return new DataResult<string>(res.Result, res.Message);
        }

        /// <summary>
        /// Gets user information based on the user account.
        /// </summary>
        /// <param name="account">The user account.</param>
        /// <returns>The user information.</returns>
        [HttpGet]
        [Route("{account}")]
        [Obsolete]
        public DataResult<UserDto> GetUserInfoByAccount(string account)
        {
            return this.GetUserInfoByAccount2(account);
        }

        [HttpGet]
        public DataResult<UserDto> GetUserInfoByAccount2([FromQuery] string account)
        {
            if (string.IsNullOrEmpty(account))
                new ArgumentException(nameof(account));

            OrganizationService service = new OrganizationService();
            UserDto userInfo = service.GetUserInfoByAccount(account);

            if (userInfo == null)
            {
                return new DataResult<UserDto>(ErrorCodes.USER_NOT_FOUND_450);
            }

            return userInfo;
        }

        /// <summary>
        /// Gets the company listing for the specified user.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns>A company list.</returns>
        [HttpGet]
        [Route("companies/{userId}")]
        public DataResult<List<CompanyDto>> GetCompaniesByUserId(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException(nameof(userId));

            OrganizationService service = new OrganizationService();
            return service.GetCompaniesByUserId(userId).ToList();
        }

        /// <summary>
        /// Gets the department listing for the specified user.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns>A department list.</returns>
        [HttpGet]
        [Route("departments/{userId}")]
        public DataResult<List<DepartmentDto>> GetDepartmentsByUserId(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException(nameof(userId));

            OrganizationService service = new OrganizationService();
            UserDto user = service.GetUserInfoById(userId);
            return user.Departments;
        }

        /// <summary>
        /// Gets the position listing for the specified user.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns>A postion list.</returns>
        [HttpGet]
        [Route("positions/{userId}")]
        public DataResult<List<PositionDto>> GetPositionsByUserId(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException(nameof(userId));

            OrganizationService service = new OrganizationService();
            UserDto user = service.GetUserInfoById(userId);
            return user.Positions;
        }

        /// <summary>
        /// Gets the group listing for the specified user.
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns>A group list.</returns>
        [HttpGet]
        [Route("groups/{userId}")]
        public DataResult<List<GroupDto>> GetGroupsByUserId(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException(nameof(userId));

            OrganizationService service = new OrganizationService();
            return service.GetGroupsByUserId(userId).ToList();
        }

        /// <summary>
        /// Gets the specified user information
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <returns>A group list.</returns>
        [HttpGet]
        [Route("userinfo/{userId}")]
        public DataResult<UserDto> GetUserInfoByUserId(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException(nameof(userId));

            OrganizationService service = new OrganizationService();
            return service.GetUserInfoById(userId);
        }
    }
}