﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 10:45:45
*
***************************************************************************/

using GMP.Services;
using Microsoft.Extensions.DependencyInjection;

namespace DMS.HostedServices
{
    public static class ServicesRegistration
    {
        public static IServiceCollection RegistrationServices(this IServiceCollection services)
        {
            //注册服务
            services.AddGmpCacheMemory();

            services.AddScoped<IAuditService, AuditService>();

            return services;
        }
    }
}