/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/29 09:09:07
*
***************************************************************************/

using DMS.HostedServices;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace GMP.Web
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.RegistrationServices();
            services.AddGmpGlobalErrorHandle();
            services.AddGmpMvcCore(this);
            services.AddGmpHttpReport();
            services.AddGmpSwagger();

            services.AddGmpHttpReport(reportConfigAction: opt =>
            {
                opt.Server = "http://gmp:8050";
                opt.Service = "GMP.Core";
            });
        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseGmpHttpReport();
            app.UseGmpGlobalErrorHandle();
            app.UseGmpSwagger(GmpConst.AppId.GMP);
            app.UseGmpCors();
            app.UseRouting();
            app.UseStaticFiles();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}