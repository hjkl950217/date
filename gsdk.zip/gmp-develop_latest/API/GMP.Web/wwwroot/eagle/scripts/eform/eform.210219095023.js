﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/6/21 11:26:05
*
***************************************************************************/

/**
 * Audit events list.
 * @module gmp/eagle/scripts/eform/eform.210219095023
 * @requires gmp/system
 * @requires gmp/eform/exts/edoc2ListGridExtension
 */
define([
    'gmp/env'
    , 'gmp/eform/parser'
    , 'gmp/eform/form'
    , 'gmp/system'
    , 'gmp/eform/exts/edoc2ListGridExtension'
], function (env, parser, form, system, dataGridExt) {
    var queryStr = " Id in (SELECT EventId from eform_eagle_metadata where {0}) ";
    var metaDataReg = /[mM]:(.*?)=(.*)/;

    /**
     * Override search condition method for quick query to support metadata search.
     * @override
     * @param {string} query query condition.
     * @returns {string} The query condition after processing.
     */
    dataGridExt.attachSearchCondition = function (query) {
        var condition = "";

        //Specified metadata field query.
        if (metaDataReg.test(query)) {
            filter = this.filterInfo.default;
            var matchs = query.match(metaDataReg);
            condition = system.format(" `Key`='{0}' and `Value` like '%{1}%' ", matchs[1], matchs[2]);
        }

        //Full field query.
        if (query.indexOf("=") < 0) {
            condition = system.format(" `Value` like '%{0}%' ", query);
        }

        if (!condition) return condition;
        return system.format(queryStr, condition);
    }

    /************************************************** Form Before Parsing Events **************************************************/

    parser.onLoadBefore = function (title, index, easyTabs) {
        BasicForm.bindFormatter();
        form.controls.edoc2ListGrid1.drawBefore = BasicForm.ondrawBefore;
    }

    /************************************************** Form After Parsing Events **************************************************/

    parser.onLoaded = function (title, index, easyTabs) {
        BasicForm.init();
        BasicForm.bindEvents();
    }

    /************************************************** Basic Form **************************************************/

    window.BasicForm = function () {
        var self = {};

        //Initialize
        self.init = function () {
            form.controls.edoc2ListGrid1.hideSearchBlock();
        }

        //Bind events
        self.bindEvents = function () {
        }

        //Bind formatter
        self.bindFormatter = function () {
            form.controls.edoc2ListGrid1.customColumnsFormatter = self.customColumnsFormatter;
        }

        self.ondrawBefore = function () {
            this.data.FilterInfo.filterStr = system.format(" OrgId='{0}' ",env.user.orgId);
        }

        //ListGrid formatter
        self.customColumnsFormatter = function (value, row, index, field, fieldName) {
            //UserName
            if (field == "UserName" && value != "") {
                value = value + "(" + row.UserAccount + ")";
            }

            //Event Snapshort
            if (field == "SnapshotId") {
                var timestamp = new Date(row.OpTime).getTime();
                value = "<a title='" + Edoc2FormSR.Eagle_Snapshot + "' target='_blank' href='/gmp/audit/snapshot?snapshotId=" + value + "&t=" + timestamp + "'><i class='fa fa-picture-o'></i></a>"
            }

            return value;
        }

        return self;
    }();
})