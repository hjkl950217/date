﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/26 10:40:15
*
***************************************************************************/

require(['require.config'], function () {
    require(['css!../styles/gmp.css']);
    require(['css!../styles/icons.css']);
    require(['css!../scripts/lib/font-awesome/css/font-awesome.min.css']);

    require(['knockout', 'login/model', 'layui/core'], function (ko, model,_) {
        ko.applyBindings(model);
    })
})