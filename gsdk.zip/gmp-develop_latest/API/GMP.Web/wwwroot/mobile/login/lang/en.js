﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
	return {
        account: "Account",
        password: "Password",
        company: "Company",
        rememberAccount: "Remember account",
        forgotPassword: "Forgot password?",
        submit: "Login",
        accountNotEmptyTip: "The account cannot be empty.",
        passwordErrorTip: "Please enter the correct password.",
        companyNotEmptyTip: "Please select your company.",
        men: "Men",
        women: "Women",
	}
})