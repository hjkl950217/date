﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
	return {
        account: "ユーザー名",
        password: "パスワード",
        company: "所属会社",
        rememberAccount: "ユーザー名を覚える",
        forgotPassword: "パスワードを忘れる？",
        submit: "ログイン",
        accountNotEmptyTip: "ユーザー名を空にできない",
        passwordErrorTip: "正しいパスワードを入力してください",
        companyNotEmptyTip: "所属会社を選んでください選んでください",
        men: "男",
        women: "女",
	}
})