﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        account: "用户名",
        password: "密  码",
        company: "所属公司",
        rememberAccount: "记住用户名",
        forgotPassword: "忘记密码？",
        submit: "登录",
        accountNotEmptyTip: "用户名不能为空",
        passwordErrorTip: "请输入正确的密码",
        companyNotEmptyTip: "请选择所属公司",
        men: "男",
        women: "女",
    }
})