﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        account: "用戶名",
        password: "密  碼",
        company: "所屬公司",
        rememberAccount: "記住用戶名",
        forgotPassword: "忘記密碼？",
        submit: "登錄",
        accountNotEmptyTip: "用戶名不能爲空",
        passwordErrorTip: "請輸入正確的密碼",
        companyNotEmptyTip: "請選額所屬公司",
        men: "男",
        women: "女",
    }
})