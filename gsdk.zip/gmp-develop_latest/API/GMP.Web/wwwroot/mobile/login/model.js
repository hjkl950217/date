﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/26 11:32:02
*
***************************************************************************/

define(['knockout', 'i18n!./lang', 'css!./login.css'], function (ko, lang, _) {
    var vm = {};
    vm.lang = lang;
    vm.logo = "../images/logo_black_180x58.png";

    vm.account = ko.observable();
    vm.password = ko.observable();
    vm.company = ko.observable();
    vm.language = ko.observable();
    vm.companies = ko.observableArray([]);
    vm.languages = ko.observableArray([{ text: '', lang: '', icon: '' }]);
    vm.langIcon = ko.pureComputed(function () {
        var curr = vm.languages().find((o) => o.lang == vm.language());
        if (!curr) curr = vm.languages()[0];

        return curr.icon + " fa";
    }, vm)

    vm.submiting = ko.observable(false);
    vm.accountError = ko.observable(false);
    vm.passwordError = ko.observable(false);
    vm.companyError = ko.observable(false);
    vm.rememberAccount = ko.observable(true);

    vm.onenter = function () {
        console.info('onenter')
    }

    vm.onaccountBlur = function () {

    }

    vm.onsubmit = function () {

    }

    return vm;
})