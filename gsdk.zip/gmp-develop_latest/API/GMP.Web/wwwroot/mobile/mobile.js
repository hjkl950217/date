﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/26 14:34:06
*
***************************************************************************/

//iphone5:320 iphone6:375
!function () {
    var recalculate = function () {
        var clientWidth = document.documentElement.clientWidth || document.body.clientWidth;
        if (!clientWidth) return;
        document.documentElement.style.fontSize = 34 * (clientWidth / 750) + 'px';
    };

    if (!document.addEventListener) return;
    var eventName = 'orientationchange' in window ? 'orientationchange' : 'resize';
    window.addEventListener(eventName, recalculate, false);
    document.addEventListener('DOMContentLoaded', recalculate, false);
}();
