﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/26 10:49:18
*
***************************************************************************/

var config = {
    baseUrl: '',
    paths: {
        'gmp': '../scripts',
        'css': '../scripts/lib/require/css',
        'i18n': '../scripts/lib/require/i18n',
        'text': '../scripts/lib/require/text',
        'durandal': '../scripts/lib/durandal',
        'plugins': '../scripts/lib/durandal/plugins',
        'knockout': '../scripts/lib/knockout/knockout',
        'bootstrap': '../scripts/lib/bootstrap/bootstrap',
        'transitions': '../scripts/lib/durandal/transitions',
        'jquery': '../scripts/lib/jquery/jquery',
        'layui': '../scripts/lib/layui'
    },
    shim: {
        'bootstrap': {
            deps: ['jquery'],
            exports: 'jQuery'
        },
        'layui/layer': {
            deps: ['layui/core'],
            exports: 'layer'
        }
    },
    urlArgs: function (id, url) {
        return (url.indexOf('?') === -1 ? '?' : '&') + "t=" + Math.floor(new Date().getTime() / 100000);
    }
}

requirejs.config(config);