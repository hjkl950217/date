﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: long.wei 2020/12/25 10:34:57
*
***************************************************************************/

define(['gmp/xhr', 'gmp/env'], function (xhr, env) {
	var gmp = {};

	/************************************************** 组织信息 **************************************************/
	gmp.org = function () {
		var self = {}

		/**
		* 通过用户token和永久token的账号获取永久token.
		* @param   {string}    token            token
		* @param   {string}    account          永久token账号.
		* @returns {object}    Returns a string.
		*/
		self.getAppIntgegByAccount = function (token, account) {
			if (!account) account = "admin";
			if (!token) token = $.cookie("token");
			var result;
			xhr.sync.get(env.path.origin + "/api/services/Org/GetAppIntgegByAccount?token=" + token + "&account=" + account, null, function (res) {
				if (res.data) result = res.data;
			})
			return result;
		}

		/**
		* 通过部门identityId获取下级职位信息.
		* @param   {string}    token            token
		* @param   {string}    account          永久token账号.
		* @returns {object}    Returns a string.
		*/
		self.getGmpOrgPositionsByDeptIdentityId = function (deptIdentityId) {
			var result;
			xhr.sync.get("/User/GetGmpOrgPositionsByDeptIdentityId", { deptIdentityId: deptIdentityId }, function (res) {
				if (res.code == "200") {
					result = res.data;
				}
			})
			return result;
		}

		/**
		* 通过用户账号获取用户信息.
		* @param   {string}    account          账号.
		* @returns {object}    Returns a object.
		*/
		self.getUserInfoByAccount = function (account) {
			var result;
			xhr.sync.get("/User?account=" + account, null, function (res) {
				if (res.code == "200") {
					result = res.data;
				}
			})
			return result;
		}

		self.getUserInfoByUserId = function (userId) {
			var result;
			xhr.sync.get("/User/userinfo/" + userId, null, function (res) {
				if (res.code == "200") {
					result = res.data;
				}
			})
			return result;
		}
		return self;
	}

	/************************************************** 文件信息 **************************************************/
	gmp.doc = function () {
		var self = {}

		/**
		* 通过文件Id获取文件信息.
		* @param   {string}    token            token
		* @param   {string}    fileId           文件夹Id.
		* @returns {object}    Returns a object.
		*/
		self.getFileInfoById = function (token, fileId) {
			if (!token) {
				token = api.org.getAppIntgegByAccount($.cookie("token"), "admin").split('|')[0];
			}
			var result;
			xhr.sync.get(env.path.origin + "/api/services/File/GetFileInfoById?token=" + token + "&fileId=" + fileId, null, function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 创建文件夹
		* @param   {string}    token            token
		* @param   {string}    folderName       文件名称
		* @param   {number}    parentFolderId   父文件夹Id
		* @param   {string}    remark           备注
		* @returns {object}    Returns a object.
		*/
		self.createFolder = function (token, folderName, parentFolderId, remark) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"Name": folderName,
				"FolderCode": "",
				"Remark": remark,
				"ParentFolderId": parentFolderId,
				"Token": token
			}
			var result;
			xhr.sync.post(env.path.origin + "/api/services/Folder/CreateFolder", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 移动文件和文件夹列表到某个文件夹
		* @param   {string}    token                token
		* @param   {number[]}  targetFolderId       目标文件夹Id
		* @param   {number[]}  fileIds              文件Id数组
		* @param   {number[]}  folderIds            文件夹Id数组
		* @returns {object}    Returns a object.
		*/
		self.moveFolderListAndFileList = function (token, targetFolderId, fileIds, folderIds) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"TargetFolderId": targetFolderId,
				"FileIdList": fileIds,
				"FolderIdList": folderIds,
				"Token": token
			}
			var result;

			xhr.post(env.path.origin + "/api/services/Doc/MoveFolderListAndFileList", JSON.stringify(params), function (res) {
				//xhr.sync.post(env.path.origin + "/api/services/Folder/CreateFolder", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 删除文件
		* @param   {string}    token                token
		* @param   {number[]}  fileIds              文件Id数组
		* @returns {object}    Returns a object.
		*/
		self.deleteFile = function (token, fileIds) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"FileIdList": fileIds,
				"Token": token
			}
			var result;
			xhr.post(env.path.origin + "/api/services/Doc/RemoveFolderListAndFileList", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			
			return result;
		}

		/**
		* 获取文件夹权限
		* @param   {string}    token                token
		* @param   {number}    folderId             文件夹Id
		* @returns {object}    Returns a object.
		*/
		self.getFolderPermission = function (token, folderId) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var result;
			xhr.sync.get(env.path.origin + "/api/services/FolderPermission/GetFolderPermission?token=" + token + "&folderId=" + folderId, null, function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 删除文件夹权限
		* @param   {string}    token                token
		* @param   {number}    folderId             文件夹Id
		* @param   {object[]}   [{
		*                       "MemberId": 0,      成员Int型ID
		*                       "MemberType": 0,    成员类型 1:用户;2:部门;4:职位;8:用户组
		*                       "PermType": 0       权限类型(非必填可为空，默认分配权限) 10:分配权限 20：流程权限
		*                       }]
		* @returns {object}    Returns a object.
		*/
		self.deleteFolderPermission = function (token, folderId, mermbers) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"FolderId": folderId,
				"Mermbers": mermbers,
				"Token": token
			}
			var result;
			xhr.post(env.path.origin + "/api/services/FolderPermission/DeleteFolderPermission", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 批量设置文件权限
		* @param   {string}      token                token
		* @param   {number}      folderId             文件夹Id
		* @param   {object[]}    [{
		*                          "MemberId": 0,                                成员Int型ID
		*                          "MemberType": 0,                              成员类型 1:用户;2:部门;4:职位;8:用户组
		*                          "PermType": 0,                                权限类型(非必填可为空，默认分配权限) 10:分配权限 20：流程权限
		*                          "PermCateId": 0,                              权限类别ID
		*                          "StartTime": "2020-12-25T06:22:03.816Z",      权限开始时间(可不填)
		*                          "ExpiredTime": "2020-12-25T06:22:03.816Z"     权限过期时间(可不填)
		*                        }]
		* @returns {object}      Returns a object.
		*/
		self.setFilePermission = function (token, fileId, Permissions) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"FileId": fileId,
				"Permissions": Permissions,
				"Token": token
			}
			var result;
			xhr.sync.post(env.path.origin + "/api/services/FilePermission/SetPermission", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}
		/**
		* 给用户设置文件权限
		* @param   {string}    token                token
		* @param   {number}    fileId               文件Id
		* @param   {number}    fileId               文件Id
		* @param   {string}    userId               用户Guid型ID
		* @param   {number}    permCateId           权限类别ID
		* @param   {string}    startTime            权限开始时间(可不填)
		* @param   {string}    expiredTime          权限过期时间(可不填)
		* @param   {number}    permType             权限类型(非必填可为空，默认分配权限) 10:分配权限 20：流程权限
		* @returns {object}    Returns a object.
		*/
		self.setFilePermissionByUserGuid = function (token, fileId, userId, permCateId, startTime, expiredTime, permType) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"UserId": userId,
				"FileId": fileId,
				"PermCateId": permCateId,
				"StartTime": startTime,
				"ExpiredTime": expiredTime,
				"PermType": permType,
				"Token": token
			}
			var result;
			xhr.sync.post(env.path.origin + "/api/services/FilePermission/SetUserPermissionByGuid", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 给用户设置文件权限
		* @param   {string}    Applicant              申请人账号
		* @param   {number}    FolderId               文件夹ID
		* @param   {string}    CateId                 权限类别
		* @param   {number}    PermType               权限类型 10 ：分配权限 20：流程权限
		* @param   {number}    MemberType             用户类型
		* @param   {number}    MemberId               用户ID
		* @param   {string}    StartTime              权限开始时间
		* @param   {string}    ExpiredTime            权限结束时间
		* @param   {string}    Token                  token
		* @returns {object}    Returns a object.
		*/
		self.setFolderPermissionByCateId = function (token, applicant, folderId, cateId, permType, memberType, memberId, startTime, expiredTime) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var params = {
				"Applicant": applicant,
				"FolderId": folderId,
				"CateId": cateId,
				"PermType": permType,
				"MemberType": memberType,
				"MemberId": memberId,
				"StartTime": startTime,
				"ExpiredTime": expiredTime,
				"Token": token
			}
			var result;
			xhr.sync.post(env.path.origin + "/api/services/Folder/SetFolderPermissionByCateId", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		* 清除指定文件夹所有用户权限
		* @param   {string}    Token                  token
		* @param   {number}    folderId               文件夹Id
		* @returns {object}    Returns a object.
		*/
		self.clearPermissionByFolder = function (token, folderId) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var result;
			xhr.sync.get(env.path.origin + "/api/services/FolderPermission/ClearPermissionByFolder?token=" + token + "&folderId=" + folderId, null, function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		 * 获取目标文件夹下的所有子文件夹
		 * @param {string} token                  token
		 * @param {number} folderId               文件夹Id
		 * @returns {object[]}    Returns a object.
		 */
		self.getChildrenFolders = function (token, folderId) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];

			var result;
			xhr.sync.get(env.path.origin + "/api/services/Folder/GetChildrenFolders?token=" + token + "&topFolderId=" + folderId, null, function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}

		/**
		 * delete folder
		 * @param {string} token            token
		 * @param {string} folderId         folderId
		 */
		self.deleteFolder = function (token, folderId) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var folderList = [];
			folderList.push(folderId);
			var params = {
				"FolderIdList": folderList,
				"Token": token
			}
			var result;
			xhr.post(env.path.origin + "/api/services/Doc/RemoveFolderListAndFileList", JSON.stringify(params), function (res) {
				if (res) {
					result = res;
				}
			})
			return result;
		}
		/**
		 * 获取权限类别
		 * @param {number} entryType        实体类型，1：文档文件夹，2：文档文件，16：团队文件夹，32：中台
		 */
		self.getFolderPermCatesByEntryType = function (token, entryType) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var result
			xhr.sync.get(env.path.origin + "/api/services/doc/GetFolderPermCatesByEntryType?token=" + token + "&entryType=" + entryType, null, function (res) {
				result = res.data;
			});
			return result;
		}

		self.setPermissions = function (token, id, memberId, memberType, caceId, startTime, expiredTime) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var result
			var dto = {
				ID: id,
				Permissions: [{
					MemberId: memberId,
					MemberType: memberType,
					PermType: 10,
					PermCateId: caceId,
					StartTime: startTime,
					ExpiredTime: expiredTime
				}],
				Token: token
			}
			xhr.sync.post("/doc/SetPermissions", JSON.stringify(dto), function (res) {
				result = res.data;
			});
			return result;
		}

		/**
		 * 获取文件夹目录
		 * @param {any} token
		 * @param {any} folderId
		 */
		self.getFolderPathByFolderId = function (token, folderId) {
			if (!token) token = api.org.getAppIntgegByAccount($.cookie("token"), 'admin').split('|')[0];
			var result;
			xhr.sync.get(env.path.origin + "/api/services/Folder/GetFolderPathByFolderId?token=" + token + "&folderId=" + folderId, null, function (res) {
				result = res.data;
			});
			return result;
		}
		return self;
	}

	var Api = function () { }
	var api = new Api();
	api.org = new gmp.org();
	api.doc = new gmp.doc();
	return api;
})