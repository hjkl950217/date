﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/6 13:43:58
*
***************************************************************************/

/**
 * App module.
 * @module gmp/app
 * @requires gmp/env
 * @requires gmp/events
 * @requires gmp/store
 */
define(['gmp/env', 'gmp/events', 'gmp/store'], function (env, events, store) {
	var gmp = {}
	gmp.version = "5.6.0";
	gmp.build = "211122";
	gmp.isdebug = env.isdebug;
	gmp.platform = env.platform;
	gmp.browser = env.browser;

	//Enable debug mode.
	gmp.debug = function () {
		if (gmp.isdebug) return;

		var type = arguments.length == 0 ? "app" : "gmp";
		var url = "&isdebug=1&debug=" + type;
		window.location.href = window.location.href + url;
	}

	/**
	 * Update user information in the environment variable as the company changed.
	 * @event company.change
	 */
	events.on("company.change").then(function (company) {
		var user = env.user;
		user.orgId = company.id;
		user.orgIdentityId = company.identityId;
		user.orgCode = company.code;
		user.orgName = company.name;
		user.orgPositionId = company.positionId;
		user.orgPositionIdentityId = company.positionIdentityId;
		user.orgPath = company.path;
		user.orgParentId = company.parentId;
		user.orgParentidentityId = company.parentIdentityId;

		store.set("user", user);
	})

	return gmp;
})