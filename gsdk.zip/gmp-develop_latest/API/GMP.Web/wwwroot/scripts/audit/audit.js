﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/21 16:38:21
*
***************************************************************************/

define([
    'gmp/env',
    'gmp/system',
    'gmp/xhr',
    'gmp/audit/confirm',
    'gmp/audit/signature',
    'gmp/audit/snapshot',
    'css!./audit.css'
], function (env, system, xhr, confirm, signature, snapshot, _css) {
    /**
     * Provide a system-wide record of audit activity.
     * @param {string} action Define audit events within the system.
     * @param {boolean} autosave True is automatically saved after the action method is called.Default is true.
     */
    var Audit = function (action, autosave) {
        var self = this;
        self.ongoing = false;

        var inner = {};
        inner.snapshotId = "";
        inner.promise = null;
        inner.data = {};
        inner.action = action;
        inner.actions = top.actions;
        inner.autosave = autosave == undefined || autosave;

        /**
         * Record specified audit activities and audit data.
         * @param {string} action   Define audit events within the system.
         * @param {object} data     Audit data to be saved.
         */
        self.action = function (action, data) {
            var promise = system.defer();
            inner.promise = promise;

            inner.data = data;
            if (system.isString(action)) inner.action = action;
            if (system.isObject(action)) inner.data = action;

            //Debug mode.
            if (env.isdebug) self.data = inner.data;

            //The action and params.source are required.
            if (!inner.action) return promise.reject();
            if (!inner.data) return promise.reject();
            if (!inner.data.source) return promise.reject();
            if (!inner.actions[inner.action]) return promise.reject();

            self.ongoing = true;
            inner.data.action = inner.action;

            //Create a snapshot for the current page.
            inner.snapshotId = snapshot.create(document.body);

            //Displays change confirmation and electronic signature.
            confirm.show(inner.data).done(function () {
                signature.show(inner.data).done(function () {
                    if (inner.autosave) self.save(true);
                    promise.resolve(self, inner.data.signers, inner.data);
                }).fail(function () {
                    if (inner.autosave) self.save(false);
                    promise.reject(self, inner.data.signers, inner.data);
                }).always(function () {
                    self.ongoing = false;
                });
            }).fail(function () {
                if (inner.autosave) self.save(false);
                promise.reject(self, inner.data.signers, inner.data);
                self.ongoing = false;
            });

            promise.audit = self;
            return promise;
        }

        /**
         * Save the audit data.
         * @param {boolean} result Operating results.
         */
        self.save = function (result) {
            var data = inner.data;
            data.result = result != undefined ? !!result : data.result;

            var event = {
                appId: data.appId || env.appid,
                userName: data.userName || env.user.name,
                userAccount: data.userAccount || env.user.account,
                opTime: data.opTime || system.currentDateTime(),
                source: data.source || '',
                actionCode: data.action,
                eventName: inner.actions[data.action].cn || data.action,
                result: data.result || true,
                remarks: data.remarks || '',
                signers: data.signers || [],
                changedData: data.changedData || [],
                metaData: data.metaData || [],
                snapshotId: inner.snapshotId,
                orgId: env.user.orgId,
                orgName: env.user.orgName
            }

            xhr.post("/audit/event", JSON.stringify(event))
        }

        /**
         * Close the audit dialog.
         */
        self.close = function () {
            confirm.close();
            signature.close();
        }
    }

    /**
     * Create an instance of the audit.
     * @param {string} action Define audit events within the system.
     * @param {boolean} autosave Whether to automatically save audit data.
     */
    Audit.new = function (/* optional */ action,/* optional */ autosave) {
        if (system.isBoolean(action)) {
            autosave = action;
            action = "";
        }

        if (Audit.current && Audit.current.ongoing) Audit.current.close();
        Audit.current = new Audit(action, autosave);

        return Audit.current;
    }

    /**
     * Create an audit instance and execute the audit action.
     * @param {string} action Define audit events within the system.
     * @param {object} data Audit data to be saved.
     * @param {boolean} autosave Whether to automatically save audit data.
     */
    Audit.action = function (action, data, autosave) {
        return Audit.new(action, autosave).action(data);
    }

    /**
     * Returns the data object structure required by the audit.
     * @param {string} action Define audit events within the system.
     * @returns {object} The data object structure required by the audit.
     */
    Audit.template = function (/* optional */ action) {
        return {
            appId: env.appid,
            userName: env.user.name,
            userAccount: env.user.account,
            opTime: undefined,
            source: undefined,
            actionCode: action,
            eventName: top.actions[action].cn,
            result: true,
            remarks: undefined,
            signers: [],
            changedData: [],
            metaData: []
        }
    }

    /**
     * Initialize all audit actions and cache them in top's window.actions.
     * If cached data already exists in top.actions, it will not be loaded from the server.
     */
    if (!top.actions || Object.keys(top.actions).length == 0) {
        xhr.get(env.path.gmp + "/audit/actions").done(function (res) {
            if (res.code == 200) {
                top.actions = {};
                system.each(res.data, function (index, obj) {
                    top.actions[obj.code] = obj;
                })
            }
        })
    }

    return Audit;
})