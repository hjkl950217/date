﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 17:51:30
*
***************************************************************************/

define([
    'gmp/system',
    'jquery',
    'layui/layer',
    'i18n!./lang',
    'text!./confirm.html'
], function (system, $, layer, lang, html) {
    html = html.replace(/<!--[\s\S]*-->/, "").trim();
    var win = window;

    //If the parent page also supports require, then the parent page's layer is used.
    if (parent.require) {
        parent.require(['layui/layer'], function (obj) {
            layer = obj;
            win = parent;
        });
    }

    var ChangeConfirm = function () {
        var self = this;
        var inner = {};

        /**
         * Displays the change data confirmation box.
         * @param {array} data The changed data.
         */
        self.show = function (data) {
            var promise = system.defer();
            var changedData = data.changedData;
            var actionOptions = top.actions[data.action];

            //Don't show the change confirmation dialog.
            if (!actionOptions.confirmation) {
                return promise.resolve();
            }

            //No changes.
            if (!changedData || !changedData.length) {
                return promise.resolve();
            }

            var content = inner.combine(changedData);
            inner.dialog = layer.open({
                type: 1,
                title: false,
                content: content,
                closeBtn: 0,
                shadeClose: false,
                area: ['1000px', '400px'],
                btn: [lang.confirm, lang.cancel],
                btn1: function () {
                    inner.update(changedData);
                    promise.resolve();
                    layer.close(inner.dialog);
                },
                btn2: function () {
                    promise.reject();
                }
            })

            return promise;
        }

        /**
         * Close the dialog.
         */
        self.close = function () {
            layer.close(inner.dialog);
        }

        /**
         * Generates HTML code for the change data.
         * @param {array} data The changed data.
         */
        inner.combine = function (data) {
            var el = $(html);
            el.find("thead tr td:eq(0)").text(lang.changeItem);
            el.find("thead tr td:eq(1)").text(lang.oldValue);
            el.find("thead tr td:eq(2)").text(lang.newValue);
            el.find("thead tr td:eq(3)").text(lang.changeReason);
            el.find("tbody").html("");

            system.each(data, function (index, obj) {
                var tr = $("<tr></tr>").attr("id", obj.field);
                $("<td></td>").text(obj.name).appendTo(tr);
                $("<td></td>").text(obj.oldText).appendTo(tr);
                $("<td></td>").text(obj.newText).appendTo(tr);
                $("<td><input placeholder='" + lang.changeReasonTips +"' /></td>").appendTo(tr);

                el.find("tbody").append(tr);
            })

            return el[0].outerHTML;
        }

        /**
         * Update the change reason.
         * @param {array} data The changed data.
         */
        inner.update = function (data) {
            var el = win.$(".gui-change-confirm table");

            system.each(data, function (index, obj) {
                var reason = el.find("#" + obj.field).find("input").val();
                obj.reason = reason;
            })
        }
    }

    var change = new ChangeConfirm();
    return change;
})