﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        changeItem: "Change Item",
        oldValue: "Old Value",
        newValue: "New Value",
        changeReason: "Change Reason",
        changeReasonTips:"Input change reason",
        userNotFound: "User not found.",
        inutAccountAndPassword: "Please enter the correct account and password.",
        confirm: "Confirm",
        cancel: "Cancel",
        signature:"Signature",
        action: "Action",
        userName: "User Name",
        account: "Account",
        password: "Password",
        switchInputMethodTips:"Please switch English input method.",
    }
})