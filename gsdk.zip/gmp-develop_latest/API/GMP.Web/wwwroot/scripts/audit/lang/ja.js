﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        changeItem: "変更項",
        oldValue: "変更前",
        newValue: "変更後",
        changeReason: "説明を変更します",
        changeReasonTips:"変更の説明を入力するをクリックします",
        userNotFound: "ユーザーは存在しない",
        inutAccountAndPassword: "正しい口座名とパスワードを入力してください。",
        confirm: "確認する",
        cancel: "キャンセル",
        signature:"電子署名",
        action: "監査活動",
        userName: "名前",
        account: "アカウント",
        password: "パスワード",
        switchInputMethodTips:"英語入力に切り替えてください",
    }
})