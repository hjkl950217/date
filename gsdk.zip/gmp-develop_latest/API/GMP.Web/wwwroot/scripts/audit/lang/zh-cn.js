﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        changeItem: "变更项",
        oldValue: "变更前",
        newValue: "变更后",
        changeReason: "变更说明",
        changeReasonTips:"点击录入变更说明",
        userNotFound: "用户不存在",
        inutAccountAndPassword: "请输入正确的账户名和密码",
        confirm: "确认",
        cancel: "取消",
        signature:"电子签名",
        action: "审计活动",
        userName: "姓名",
        account: "账户",
        password: "密码",
        switchInputMethodTips:"请切换至英文输入法",
    }
})