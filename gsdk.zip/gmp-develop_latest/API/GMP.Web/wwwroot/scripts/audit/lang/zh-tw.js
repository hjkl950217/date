﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 11:31:53
*
***************************************************************************/

define(function () {
    return {
        changeItem: "變更項",
        oldValue: "變更前",
        newValue: "變更后",
        changeReason: "變更説明",
        changeReasonTips:"點擊錄入變更説明",
        userNotFound: "用戶不存在",
        inutAccountAndPassword: "請輸入正確的用戶名和密碼",
        confirm: "確認",
        cancel: "取消",
        signature:"電子簽名",
        action: "審計活動",
        userName: "姓名",
        account: "賬戶",
        password: "密碼",
        switchInputMethodTips:"請切換至英文輸入法",
    }
})