﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/20 16:33:02
*
***************************************************************************/

define([
	'gmp/system',
	'gmp/xhr',
	'jquery',
	'layui/layer',
	'gmp/utils/password',
	'i18n!./lang',
	'text!./signature.html'], function (system, xhr, $, layer, Password, lang, html) {
		html = html.replace(/<!--[\s\S]*-->/, "").trim();
		var win = window;

		//If the parent page also supports require, then the parent page's layer is used.
		if (parent.require) {
			parent.require(['layui/layer'], function (obj) {
				layer = obj;
				win = parent;
			});
		}

		var Signature = function () {
			var self = this;
			var inner = {};
			inner.width = 380;

			/**
			 * The display electronic signature dialog box
			 * will automatically adjust the size and display content
			 * of the signature window according to the number of signers.
			 * @param {object} data The audit data.
			 * @returns {object} The jQuery Promise object.
			 */
			self.show = function (data) {
				var promise = system.defer();
				var actionOptions = top.actions[data.action];

				//No electronic signature is required.
				if (!actionOptions.signature) {
					data.signers = [];
					return promise.resolve();
				}

				//No signers.
				if (!data.signers || !data.signers.length) {
					return promise.resolve();
				}

				//Support up to two signatures at the same time.
				if (data.signers.length > 2) data.signers.splice(2);

				var content = inner.combine(data);

				inner.dialog = layer.open({
					type: 1,
					title: lang.signature,
					content: content,
					closeBtn: 0,
					shadeClose: false,
					area: [inner.width * data.signers.length + 'px', '300px'],
					btn: [lang.confirm, lang.cancel],
					btn1: function () {
						inner.onenter(inner.dialog, data, content, promise);
					},
					btn2: function () {
						promise.reject();
					},
					end: function () {
						content.remove();
					}
				})

				//Disable the `blur` event of the edoc2SelectMember control
				//to resolve the problem that the password box cannot get focus
				//when electronic signature.
				$(".select2-search input").unbind("blur");

				//Select the first password box.
				//And bind the carriage return event for the last password box.
				content.find(".password input:first").focus();
				var pwd = content.find(".password input:last").data("password");
				pwd.onenter = function () {
					inner.onenter(inner.dialog, data, content, promise);
				}

				return promise;
			}

			/**
			 * Close the dialog.
			 */
			self.close = function () {
				layer.close(inner.dialog);
			}

			/**
			 * Generates HTML code for the signature data.
			 * @private
			 * @param {array} data The audit data.
			 * @returns {object} JQuery wrapped element object.
			 */
			inner.combine = function (data) {
				var el = $(html);
				el.find(".action label").text(lang.action + " : ");
				el.find(".username label").text(lang.userName + " : ");
				el.find(".account label").text(lang.account + " : ");
				el.find(".password label").text(lang.password + " : ");
				el.find(".password div").text(lang.switchInputMethodTips);

				el.find(".action span").text(top.actions[data.action].cn);

				var signbox = el.find(".signbox")[0].outerHTML;
				el.find(".signbox").remove();

				system.each(data.signers, function (index, signer) {
					var box = $(signbox);

					box.find(".account input").bind("blur", inner.onblur);
					if (signer) {
						box.find(".account input").val(signer).attr("disabled", "disabled");
						box.find(".account input").blur();
					}

					var password = new Password(box.find(".password input"), true, layer);
					box.find(".password input").data("password", password);

					el.append(box);
				});

				win.$("body").append(el);
				return el;
			}

			/**
			 * Account textbox lost focus event,
			 * query the user information according to the account.
			 * @event
			 * @param {object} event The event object that triggers the event.
			 */
			inner.onblur = function (event) {
				var element = event.target;
				var container = $(element).closest(".signbox");
				var span = container.find(".username span");
				var account = element.value;
				if (!account) {
					span.text("");
					container.data("user", null);
					return;
				}

				xhr.get("/User?account=" + account, null, function (res) {
					if (res.code == 200) {
						container.data("user", res.data);
						span.text(res.data.name + "（" + res.data.code + "）");
					}
					else if (res.code == 450) {
						span.text("");
						element.value = "";
						container.data("user", null);
						layer.msg(lang.userNotFound);
					}
					else {
						span.text("");
						element.value = "";
						container.data("user", null);
						layer.msg(res.message);
					}
				});
			}

			/**
			 *
			 * @param {any} dialog
			 * @param {any} data
			 * @param {any} content
			 * @param {any} promise
			 */
			inner.onenter = function (dialog, data, content, promise) {
				if (inner.validate(content)) {
					inner.update(content, data);
					promise.resolve();
					layer.close(dialog);
				}
			}

			/**
			 * Verify that the signer's account and password are correct.
			 * @private
			 * @param {object} el JQuery wrapped element object.
			 * @returns {boolean} True if all the signers' signatures are correct.
			 */
			inner.validate = function (el) {
				var flag = true;

				$.each(el.find(".signbox"), function (index, element) {
					if (!flag) return;

					var user = $(element).data("user");
					if (!user) {
						flag = false;
						layer.msg(lang.inutAccountAndPassword);
						return;
					}
					var password = $(element).find(".password input").data("password");

					var promise = xhr.sync.post("/user/auth", {
						account: user.account,
						password: password.value
					});

					promise.done(function (res) {
						if (res.code == 412) {
							flag = false;
							layer.msg(lang.inutAccountAndPassword);
						}
						else if (res.code != 200 || res.data == false) {
							flag = false;
							layer.msg(lang.account + " " + user.account + " " + res.message);
						}
					})
				})

				return flag;
			}

			/**
			 * Update the signature data.
			 * @private
			 * @param {array} data The audit data.
			 */
			inner.update = function (el, data) {
				var signers = [];
				$.each(el.find(".signbox"), function (index, element) {
					var user = $(element).data("user");

					signers.push({
						userId: user.id,
						code: user.code,
						name: user.name,
						account: user.account,
						signTime: system.currentDateTime()
					})
				})

				data.signers = signers;
			}
		}

		return new Signature();
	})