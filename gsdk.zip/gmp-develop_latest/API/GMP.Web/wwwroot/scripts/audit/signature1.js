﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 17:50:37
*
***************************************************************************/

define(["gmp/env", "gmp/utils", "gmp/xhr"], function (env, utils, xhr) {
	var Signature = function () {
		var self = this;
		var inner = {};
		inner.width = 380;
		inner.height = 330;
		inner.data = [];

		//Invalid keycode.
		inner.keyCodes = [
			9, 12, 16, 17, 18, 19, 20, 27, 33, 34,
			35, 36, 37, 38, 39, 40, 45, 46, 91, 92,
			93, 112, 113, 114, 115, 116, 117, 118,
			119, 120, 121, 122, 123, 144, 145, 166,
			167, 255
		];

		/**
		 * Displays the standard signature dialog.
		 * @param {string}  action  System defined audit action code.
		 */
		self.sign = function (action) {
			var html = $("<div></div>").addClass("signature");
			html.append(inner.createIncidentHtml());
			html.append(inner.createDividerHtml());
			html.append(inner.createFirstSigner());
			html.find(".signbox").css("border-left", "1px solid #fff");

			inner.show(inner.width, inner.height, html);
		}

		/**
		 * Displays the counter signature dialog.
		 * @param {string}  action1 System defined audit action code.
		 * @param {string}  action2 System defined audit action code.
		 */
		self.counterSign = function (action1, action2) {
			var html = $("<div></div>").addClass("signature");
			html.append(inner.createIncidentHtml());
			html.append(inner.createDividerHtml());
			html.append(inner.createFirstSigner());
			html.append(inner.createSecondSigner());

			inner.show(inner.width * 2, inner.height, html);
		}

		/**
		 * Displays the free signature dialog.
		 * @param {string}  action  System defined audit action code.
		 */
		self.freeSign = function (action) {
			var html = $("<div></div>").addClass("signature");
			html.append(inner.createIncidentHtml());
			html.append(inner.createDividerHtml());
			html.append(inner.createSecondSigner());
			html.find(".signbox").css("border-left", "1px solid #fff");

			var promise = inner.show(inner.width, inner.height, html);
			promise.then(function (dialog) {
				var data = {
					formId: env.eform.formId,
					recordId: env.eform.recordId,
					userId: env.user.id,
					account: env.user.Account,
					userName: env.user.Name,
					incident: 0,
					processId: 0,
					signTime: 0,
					meaning: 0,
				}

				data = inner.sort(data);
				inner.data.push(data);

				dialog.close();
			})
		}

		//Gets the signature data.
		self.getSignData = function () {
			return inner.data;
		}

		/**
		 * Displays the signature dialog.
		 * @param {number} width    The dialog width.
		 * @param {number} height   The dialog height.
		 * @param {object} content  The dialog content.
		 */
		inner.show = function (width, height, content) {
			var dtd = $.Deferred();
			inner.data = [];

			var config = {
				title: "电子签名",
				type: "target",
				content: content,
				width: width,
				height: height,
				maximizable: false,
				buttons: [{
					id: "sn-success-" + env.times,
					text: "确定",
					handler: function (dialog) {
						dtd.resolve(dialog);
					}
				}]
			}

			inner.loadStyle();
			utils.showDialog(config);

			return dtd.promise();
		}

		/**
		 * Encrypts the specified plaintext as ciphertext.
		 * @param   {string} plaintext Text to be encrypted.
		 * @returns {string} Encrypted ciphertext.
		 */
		inner.encryption = function (plaintext) {
			if (!plaintext) return "";

			var ciphertext = String.fromCharCode(plaintext.charCodeAt(0) + plaintext.length);
			for (var i = 1; i < plaintext.length; i++) {
				ciphertext += String.fromCharCode(plaintext.charCodeAt(i) + plaintext.charCodeAt(i - 1));
			}

			return escape(ciphertext);
		}

		/**
		 * Resolves the specified ciphertext to plaintext.
		 * @param   {string} ciphertext The text to decrypt.
		 * @returns {string} Decrypted plaintext;
		 */
		inner.decryption = function (ciphertext) {
			if (!ciphertext) return "";
			ciphertext = unescape(ciphertext);

			var plaintext = String.fromCharCode(ciphertext.charCodeAt(0) - ciphertext.length);
			for (var i = 1; i < ciphertext.length; i++) {
				plaintext += String.fromCharCode(ciphertext.charCodeAt(i) - plaintext.charCodeAt(i - 1));
			}

			return plaintext;
		}

		/**
		 * Password textbox keyboard press event.
		 * @param {object} event The event object that triggers the event.
		 */
		inner.onkeydown = function (event) {
			var element = event.target;
			var keyCode = window.event.keyCode;         //Current key ASCII code
			var startIndex = element.selectionStart;    //The starting position of the selected text.
			var password = inner.decryption(element.dataset.value);

			if (inner.invalidKeyCode(keyCode)) return;

			//Input in Chinese is not allowed.
			if (keyCode == 229) {
				element.value = password.replace(/[\s\S]/g, "*");
				element.blur();
				setTimeout(function () { element.focus(); }, 300);
				$(element).parent().find(".tips").show();
				return;
			}
			$(element).parent().find(".tips").hide();

			//Enter to complete the password
			if (keyCode == 13) {
				$(".window:visible a[id*=sn-success]").click();
				return;
			}

			//The delete key.
			if (keyCode == 8) {
				//If the starting position of the selected text is equal
				//to the character length, then no text is selected.
				if (startIndex == password.length) {
					startIndex = startIndex - 1;
				}
				password = password.substr(0, startIndex);
			}
			else {
				password = password.substr(0, startIndex);
				password += window.event.key;
			}

			//Replace the password with * to display in the textbox.
			element.dataset.value = inner.encryption(password);
			element.value = password.replace(/[\s\S]/g, "*");
			element.focus();
			element.setSelectionRange(password.length, password.length);
		}

		/**
		 * Password textbox keyboard pop-up event.
		 * @param {object} event The event object that triggers the event.
		 */
		inner.onkeyup = function (event) {
			var element = event.target;
			element.value = element.value.replace(/[^*]/g, "");
		}

		/**
		 * Account textbox lost focus event,
		 * query the user information according to the account.
		 * @param {object} event The event object that triggers the event.
		 */
		inner.onblur = function (event) {
			var element = event.target;
			var span = $(element).closest(".signbox").find(".username span");
			var account = element.value;
			if (!account) {
				span.text("");
				$(element).parent().find(".tips").hide();
				return;
			}

			xhr.get("/user/account/" + account + "/info", null, function (res) {
				if (res.code == 200) {
					span.text(res.data.name + "（" + res.data.code + "）");
					$(element).parent().find(".tips").hide();
				}
				else {
					span.text("");
					$(element).parent().find(".tips").text(res.message);
					$(element).parent().find(".tips").show();
				}
			});
		}

		/**
		 * Returns a value indicating whether an invalid key code is present.
		 * @param   {number} keyCode  The keyboard code.
		 * @returns {boolean} True if the keycode is invalid.
		 */
		inner.invalidKeyCode = function (keyCode) {
			return inner.keyCodes.indexOf(keyCode) > -1;
		}

		/**
		 * The specified data is sorted alphabetically.
		 * @param   {object} data   The data to sort.
		 * @returns {object} A new data.
		 */
		inner.sort = function (data) {
			var newData = {};
			Object.keys(data).sort().map(key => {
				newData[key] = data[key]
			})

			return newData;
		}

		//Create first signer html element.
		inner.createFirstSigner = function () {
			var signbox = $("<div></div>").addClass("signbox");

			var username = inner.createUsernameHtml();
			var account = inner.createAccountHtml();
			var password = inner.createPasswordHtml();
			var meaning = inner.createMeaningHtml();

			username.find("span").text(env.user.Name + "（" + env.user.Code + "）");
			account.find("input").val(env.user.Account).attr("disabled", "disabled");

			signbox.append(username)
				.append(account)
				.append(password)
				.append(meaning);

			return signbox;
		}

		//Create second signer html element.
		inner.createSecondSigner = function () {
			var signbox = $("<div></div>").addClass("signbox");

			var username = inner.createUsernameHtml();
			var account = inner.createAccountHtml();
			var password = inner.createPasswordHtml();
			var meaning = inner.createMeaningHtml();

			signbox.append(username)
				.append(account)
				.append(password)
				.append(meaning);

			return signbox;
		}

		//Create process instance number html element.
		inner.createIncidentHtml = function () {
			var incident = $("<div><label></label></div>");
			incident.addClass("incident");
			incident.find("label").text("实例号 : ");

			return incident;
		}

		//Create divider html element.
		inner.createDividerHtml = function () {
			var divider = $("<div></div>").addClass("divider");
			return divider;
		}

		//Create user name html element.
		inner.createUsernameHtml = function () {
			var username = $("<div><label></label><span></span></div>");
			username.addClass("username");
			username.find("label").text("姓名 : ");

			return username;
		}

		//Create user account html element.
		inner.createAccountHtml = function () {
			var account = $("<div><label></label><input /><div></div></div>");
			account.addClass("account");
			account.find("label").text("工号 : ");
			account.find("input").bind("blur", inner.onblur);
			account.find("div").addClass("tips").hide();

			return account;
		}

		//Create user password html element.
		inner.createPasswordHtml = function () {
			var password = $("<div><label></label><input /><div></div></div>");
			password.addClass("password");
			password.find("label").text("密码 : ");
			password.find("input").attr("autofocus", "autofocus");
			password.find("input").attr("autocomplete", "autocomplete");
			password.find("input").bind("paste", function () { return false; });
			password.find("input").bind("dragenter", function () { return false; });
			password.find("input").bind("keydown", inner.onkeydown);
			password.find("input").bind("keyup", inner.onkeyup);
			password.find("div").addClass("tips").hide();
			password.find("div").text("请切换至英文输入法");

			return password;
		}

		//Create signature meaning html element.
		inner.createMeaningHtml = function () {
			var meaning = $("<div><label></label><select></select></div>");
			meaning.addClass("meaning");
			meaning.find("label").text("含义 : ");
			meaning.find("select").append("<option value='测试数据'>测试数据</option>");

			return meaning;
		}

		//Add the style to the head element.
		inner.loadStyle = function () {
			var url = env.path.gmp + "/styles/signature.css";

			var style = document.createElement('link');
			style.id = "signature";
			style.setAttribute('rel', 'stylesheet');
			style.setAttribute('type', 'text/css');
			style.setAttribute('href', url);

			document.head.appendChild(style);
		}
	}

	var sign = new Signature();
	return sign;
})