﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/10/18 13:03:47
*
***************************************************************************/

define(['gmp/system', 'gmp/xhr', 'html2canvas'], function (system, xhr, html2canvas) {
	return {
		create: function (element) {
			var guid = system.guid();
			html2canvas(element).then(canvas => {
				var base64 = canvas.toDataURL();
				xhr.post("/audit/snapshot?snapshotId=" + guid, { image: base64 });
			});
			return guid;
		}
	}
})