﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/9 16:27:10
*
***************************************************************************/

define(function () {
    return {
        notFound: "Sorry, the page was not found.",
        possibleCause: "Possible Cause:",
        requestTimeout: "The network is too bad.",
        pageNotFound: "The page could not be found.",
        incorrectUrl: "The url entered is incorrect.",
        canTry: "You can try：",
        returnHome: "Retrun home page.",
        leaveMessage: "Leave a message.",
        contactUs: "Contact us.",
    }
})