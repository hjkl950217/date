﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/9 16:27:10
*
***************************************************************************/

define(function () {
    return {
        notFound: "ページを見つけられなくてごめんなさい",
        possibleCause: "可能な原因：",
        requestTimeout: "インターネットが悪い",
        pageNotFound: "ページが見つからない",
        incorrectUrl: "入力されたurlが正しくない",
        canTry: "試してみる：",
        returnHome: "トップページに戻る",
        leaveMessage: "フィードバックを残す",
        contactUs: "私たちに連絡する",
    }
})