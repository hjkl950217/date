﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/9 16:27:10
*
***************************************************************************/

define(function () {
    return {
        notFound:"很抱歉，您要访问的页面不存在！",
        possibleCause: "可能原因：",
        requestTimeout: "网络太差请求超时",
        pageNotFound: "找不到请求的页面",
        incorrectUrl: "输入的网址不正确",
        canTry: "可以尝试：",
        returnHome: "返回首页",
        leaveMessage: "留言反馈",
        contactUs: "联系我们",
    }
})