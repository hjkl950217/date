﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/9 16:27:10
*
***************************************************************************/

define(function () {
    return {
        notFound: "很抱歉，您要訪問的頁面不存在！",
        possibleCause: "可能原因：",
        requestTimeout: "網絡太差請求超時",
        pageNotFound: "找不到請求的頁面",
        incorrectUrl: "輸入的網址不正確",
        canTry: "可以嘗試：",
        returnHome: "返回首頁",
        leaveMessage: "留言反饋",
        contactUs: "聯係我們",
    }
})