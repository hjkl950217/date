﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/15 17:47:08
*
***************************************************************************/

define(function () {
    return {
        welcome: 'Welcome',
        monday: 'Mon.',
        tuesday: 'Tue.',
        wednesday: 'Wed.',
        thursday: 'Thu.',
        friday: 'Fri.',
        saturday: 'Sat.',
        sunday: 'Sun.',
        noPasswordTips: 'Please enter your password and try again.',
        incorrectPasswordTips: 'This password is not correct, please reenter it.',
        illegalOperationTips: 'This operation is illegal. Please enter your password to unlock it.',
        unlockTips: 'Enter password to unlock...'
    }
})