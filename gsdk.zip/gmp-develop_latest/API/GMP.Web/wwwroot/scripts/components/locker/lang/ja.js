﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/15 15:45:41
*
***************************************************************************/

define(function () {
    return {
        welcome: '歓迎',
        monday: '月曜日',
        tuesday: '火曜日',
        wednesday: '水曜日',
        thursday: '木曜日',
        friday: '金曜日',
        saturday: '土曜日',
        sunday: '日',
        noPasswordTips: 'パスワードを入力して再試行してください',
        incorrectPasswordTips: 'このパスワードは正しくありません。入力し直してください',
        illegalOperationTips: '現在の動作は不正です。パスワードを入力してロック解除してください',
        unlockTips:'パスワードを入力して解除する...'
    }
})