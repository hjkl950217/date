﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/15 15:45:41
*
***************************************************************************/

define(function () {
    return {
        welcome: '欢迎',
        monday: '星期一',
        tuesday: '星期二',
        wednesday: '星期三',
        thursday: '星期四',
        friday: '星期五',
        saturday: '星期六',
        sunday: '星期日',
        noPasswordTips: '请输入密码并重试',
        incorrectPasswordTips: '此密码不正确，请重新输入',
        illegalOperationTips: '当前操作是非法的，请输入密码进行解锁',
        unlockTips:'输入密码解锁...'
    }
})