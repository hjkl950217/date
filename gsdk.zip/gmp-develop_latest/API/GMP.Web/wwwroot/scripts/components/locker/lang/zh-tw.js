﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/15 15:45:41
*
***************************************************************************/

define(function () {
    return {
        welcome: '歡迎',
        monday: '星期一',
        tuesday: '星期二',
        wednesday: '星期三',
        thursday: '星期四',
        friday: '星期五',
        saturday: '星期六',
        sunday: '星期日',
        noPasswordTips: '請輸入密碼並重試',
        incorrectPasswordTips: '此密碼不正確，請重新輸入',
        illegalOperationTips: '當前操作是非法的，請輸入密碼進行解鎖',
        unlockTips:'輸入密碼解鎖...'
    }
})