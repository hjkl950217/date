﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/21 16:38:42
*
***************************************************************************/

/**
 * Locker module.
 * @module gmp/locker
 * @requires gmp/env
 * @requires gmp/xhr
 * @requires gmp/events
 * @requires gmp/logger
 * @requires gmp/system
 */
define([
    'gmp/env'
    , 'gmp/xhr'
    , 'gmp/events'
    , 'gmp/system'
    , 'gmp/store'
    , 'gmp/utils/password'
    , 'jquery'
    , 'i18n!./lang'
    , 'text!./locker.html'
    , 'css!./locker.css'
], function (env, xhr, events, system, store, Password, $, lang, html, _) {
    //Environment variable.
    env.locker = env.locker || {};
    env.locker.enable = env.locker.enable || true;      //True if locker enabled, otherwise, false.
    env.locker.freetime = env.locker.freetime || 7;     //Idle time (in minutes) before the system is locked.
    env.locker.polling = env.locker.polling || 30000;   //The polling time for the locked state from the server.

    html = html.replace(/<!--[\s\S]*-->/, "").trim();

    /**
     * Provides a browser lock screen mechanism, if the mouse
     * does not have any action within a specified period of time,
     * the system will be locked to prohibit operation.
     * @class Locker
     */
    var Locker = function () {
        var self = this;
        self.enable = env.locker.enable;
        self.freetime = env.locker.freetime;
        self.polling = env.locker.polling;
        self.background = "";

        var inner = {};
        inner.timer = null;
        inner.locked = false;
        inner.checking = false;
        inner.weeks = [lang.sunday, lang.monday, lang.tuesday, lang.wednesday, lang.thursday, lang.friday, lang.saturday];
        inner.serverUrl = env.path.gmp + "/lock/";

        /**
         * When the screen is locked.
         * @event onlock
         * @param {object} locker   The locker instance.
         * @override
         */
        self.onlock = function (locker) { }

        /**
         * When you unlock the screen.
         * @event onunlock
         * @param {object} locker   The locker instance.
         * @override
         */
        self.onunlock = function (locker) { }

        //Initialize
        inner.init = function () {
            inner.loadSettings();

            if (env.settings.screenLocker) {
                var config = JSON.parse(env.settings.screenLocker);
                self.enable = config.enable;
                self.freetime = config.freeTime;
                self.polling = config.polling * 1000;

                if (config.background) {
                    self.background = "/" + config.background;
                }
            }

            if (!self.enable) return;

            store.set("locker.enable", env.locker.enable);
            store.set("locker.freetime", env.locker.freetime);
            store.set("locker.polling", env.locker.polling);

            inner.registerMouseListener();

            events.on("locker.lock", function () { inner.lockScreen(); })
            events.on("locker.unlock", function () { inner.unlockScreen(); })

            inner.check();
            inner.polling();
        }

        //Load the screen lock configuration and get it from the cache if there is one.
        inner.loadSettings = function () {
            if (env.settings) return;

            xhr.sync.get("/config/settings").done(function (settings) {
                if (!settings) return;
                env.settings = settings;
            })
        }

        //Listen for mouse movement and reset the timer every 30 seconds.
        inner.registerMouseListener = function () {
            //Function of the throttle.
            var refresh = system.throttle(30000, function () {
                inner.refresh();
            }, self);

            //Listen mouse movement.
            $(window.document).mousemove(function () {
                refresh();
            })
        }

        //Check the lock status for the specified token.
        inner.check = function () {
            if (inner.checking) return;
            inner.checking = true;

            var url = inner.serverUrl + "check";
            url += "?token=" + env.token;
            url += "&freetime=" + self.freetime;

            xhr.post(url).done(function (res) {
                if (res.code == 200) {
                    events.emit(res.data.state ? "locker.lock" : "locker.unlock");
                    inner.checking = false;
                }
            }).always(function () {
                inner.checking = false;
            })
        }

        //Polling, synchronized across page state.
        inner.polling = function () {
            clearInterval(inner.timer);
            if (inner.locked) return;
            if (window !== top.window) return;

            inner.timer = setInterval(function () {
                inner.check();
            }, self.polling);
        }

        //Refreshes the time for the specified token.
        inner.refresh = function () {
            if (inner.locked) return;
            xhr.get(inner.serverUrl + "refresh?token=" + env.token);
        }

        /**
         * Unlocks the specified token.
         * @param   {string} act  The user account.
         * @param   {string} pwd  The user password.
         */
        inner.unlock = function (act, pwd) {
            xhr.post(inner.serverUrl + "unlock?token=" + env.token, { act, pwd }, function (res) {
                if (res.code == 200) {
                    events.emit("all:locker.unlock");
                }

                if (res.code == 205) {
                    inner.showMessage(lang.incorrectPasswordTips);
                    inner.loading();
                }
            })
        }

        //Shows the lock screen interface.
        inner.lockScreen = function () {
            //Append locker html to the body.
            var el = $(html);
            if (self.background) {
                el.find(".bg").css("background-image", "url(" + self.background + ")");
            }

            var password = new Password(el.find(".pwd input"), true, { msg: inner.showMessage });
            el.find(".pwd input").data("password", password);
            el.find(".pwd input").attr("placeholder", lang.unlockTips);

            $("body").append(el);

            //Display real-time time on the lock screen.
            inner.refreshTime(1000, false);
            inner.showAvatar();
            inner.showUserName();
            inner.bindEvents();

            inner.locked = true;
            inner.polling();
        }

        //Hides the lock screen interface.
        inner.unlockScreen = function () {
            $(".locker").addClass("fade-out");
            setTimeout(function () { $(".locker").remove() }, 500);

            inner.locked = false;
            inner.polling();
        }

        //Show or hide the load animation.
        inner.loading = function () {
            if ($(".locker .unlock").is(":hidden")) {
                $(".locker .unlock").show();
                $(".locker .loading").hide();
            }
            else {
                this.showMessage(lang.welcome);
                $(".locker .unlock").hide();
                $(".locker .loading").show();
            }
        }

        //Refresh the time on the lock screen.
        inner.refreshTime = function (sleep, tuning) {
            var timer = setInterval(function () {
                var now = new Date();
                var seconds = now.getSeconds();

                //After unlocking, stop the refresh time.
                if (!inner.locked) {
                    clearInterval(timer);
                }

                //The timer is tuned to refresh every minute.
                if (!tuning && seconds == 0) {
                    clearInterval(timer);
                    inner.refreshTime(60000, true);
                }

                inner.showTime();
            }, sleep);
        }

        //Show the current time on the lock screen.
        inner.showTime = function () {
            var now = new Date();
            var month = now.getMonth() + 1;
            var week = now.getDay();
            var day = now.getDate();
            var hour = now.getHours();
            var minutes = now.getMinutes();
            var seconds = now.getSeconds();

            //Hours and minutes make up two.
            hour = ("00" + hour).substr(-2);
            minutes = ("00" + minutes).substr(-2);

            //Show current time.
            $(".locker .time").text(hour + " : " + minutes);
            $(".locker .date").text(month + "月" + day + "日，" + inner.weeks[week]);

            var lang = system.lang();
            if (lang != "zh-cn") {
                $(".locker .date").text(now.toDateString());
            }
        }

        //Show the current user name on the lock screen.
        inner.showUserName = function () {
            $(".locker .name").text(env.user.name);
        }

        //Show the user avatar on the lock screen.
        inner.showAvatar = function () {
            var url = "/ImageType/GetUserAvatar?token=" + env.token + "&userId=" + env.user.identityId;
            $(".locker .avatar").css("background-image", "url(" + url + ")");
        }

        /**
         * Show the message on the lock screen.
         * @param {string} message The message to display.
         */
        inner.showMessage = function (message) {
            $(".locker .message").text(message);
        }

        //Bind unlock event.
        inner.bindEvents = function () {
            $(".locker").on("click", inner.onclick);
            $(".locker .pwd input").on("keydown", inner.onkeydown);
            $(".locker .btn-login").on("click", inner.onunlock);

            //Illegal unlock.
            $(".locker").on("DOMNodeRemoved", function () {
                if (inner.locked && event.target.className == "locker") {
                    alert(lang.illegalOperationTips);

                    //Unable to rerender the DOM under IE.
                    setTimeout(function () { inner.show(); }, 0);
                }
            });
        }

        //he unlock password window is displayed when clicking on the lock screen.
        inner.onclick = function () {
            $(".locker .bg").removeClass("scale-down").addClass("scale-up");
            $(".locker .mask,.locker .container").addClass("fade-in");
            $(".locker .time,.locker .date").addClass("fade-out");
            $(".locker .pwd input").focus();
        }

        /**
         * Unlock it when the enter key is pressed,
         * Ununlock when Esc key is pressed.
         */
        inner.onkeydown = function () {
            //Enter the unlock.
            if (event.keyCode == 13) {
                inner.onunlock(event);
            }

            //Press the ECS button.
            if (event.keyCode == 27) {
                $(".locker .bg").removeClass("scale-up").addClass("scale-down");
                $(".locker .mask,.locker .container").removeClass("fade-in");
                $(".locker .time,.locker .date").removeClass("fade-out");

                var password = $(".locker .pwd input:last").data("password");
                password.clear();
                $(".locker .pwd input").blur();

                inner.showMessage("");
            }
        }

        //Verify that user credentials are valid when unlocking.
        inner.onunlock = function () {
            inner.loading();

            var password = $(".locker .pwd input:last").data("password");
            if (password.value.trim() == "") {
                inner.showMessage(lang.noPasswordTips);
                inner.loading();
                return;
            }

            inner.unlock(env.user.account, password.value);
        }

        inner.init();
    }

    var locker = new Locker();
    return locker;
})