﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/9 10:53:52
*
***************************************************************************/

define(['gmp/env'
    , 'gmp/system'
    , 'gmp/store'
    , 'gmp/xhr'
    , 'gmp/cookie'
    , 'gmp/header/language/language'
    , 'knockout'
    , 'jquery'
    , 'i18n!./lang'
    , 'css!./login'
], function (env, system, store, xhr, cookie, language, ko, $, lang) {
    var Login = function () {
        var self = this;
        var inner = {};

        self.element = null;
        self.settings = {
            showShadow: ko.observable(true),
            hideScrollbar: ko.observable(true),
            rememberAccount: ko.observable(true),
            logo: ko.observable("images/logo_black_180x58.png"),
            loginBg: ko.observable("url(images/login-bg.png)")
        }

        self.userInfo = ko.observable({});
        self.account = ko.observable();
        self.password = ko.observable();
        self.isAdmin = ko.computed(function () { return self.account() == 'admin'; }, self);

        self.company = ko.observable();
        self.companies = ko.observableArray([{ id: "", name: lang.company }]);

        self.lang = lang;
        self.language = ko.observable(system.lang());
        self.languages = ko.observableArray(language.languages);
        self.langIcon = ko.pureComputed(function () {
            var curr = self.languages().find((o) => o.lang == self.language());
            if (!curr) curr = self.languages()[0];

            return curr.icon + " fa";
        }, self);

        self.accountError = ko.observable(false);
        self.passwordError = ko.observable(false);
        self.companyError = ko.observable(false);
        self.submiting = ko.observable(false);

        /**
         * Hook function,initialize the component with custom parameters.
         * @method activate
         * @param {any} params The custom parameters.
         */
        self.activate = function (params) {
            inner.loadSettings();

            for (var key in params) {
                if (!self.settings[key]) return;

                if (ko.isObservable(self.settings[key])) {
                    self.settings[key](params[key]);
                }
                else {
                    self.settings[key] = params[key];
                }
            }

            inner.getAccount();
            if (env.settings.loginLogo) self.settings.logo("/" + env.settings.loginLogo);
            if (env.settings.loginBg) self.settings.loginBg("url(/" + env.settings.loginBg + ")");

            //The login page requires a cookie named clientId whose value is a random value.
            cookie.set("clientId", system.guid(), { path: "/" });
        }

        /**
         * Hook function,triggered when its view is attached to its parent DOM node.
         * @method attached
         * @param {Element} view    Current module view.
         * @param {Element} parent  Parent  module view.
         * @param {object}  context Context object.
         */
        self.attached = function (view, parent, context) {
            self.element = view;
            if (self.settings.hideScrollbar()) {
                document.body.classList.add("login-shadow");
            }
        }

        /**
         * Listen for keyboard enter events.
         * @event onenter
         * @param {object} e The event object.
         */
        self.onenter = function (e) {
            var event = window.event || e;
            var code = event.keyCode || event.which || event.charCode;
            if (code == 13) self.onsubmit();
            return true;
        }

        /**
         * Click the mask layer to remove the login window.
         * @event onshadowClick
         */
        self.onshadowClick = function () {
            self.element.remove();
            document.body.classList.remove("login-shadow");
        }

        /**
         * Get a list of companies based on the account entered.
         * If the account is `admin`, the company selection is disabled.
         * @event onaccountBlur
         */
        self.onaccountBlur = function () {
            self.companies([]);
            self.company("");
            self.userInfo({});
            self.accountError(false);

            if (!self.account()) {
                self.companies([{ id: "", name: lang.company }]);
                return;
            }
            if (self.account() == "admin") self.companies([]);

            var promise = inner.loadUserInfo();
            promise.done(function (res) {
                if (res.code == 200) {
                    inner.loadCompanies();
                    self.company(self.userInfo().orgId);
                }
            })
        }

        /**
         * Submit the login and jump to the specified url.
         * @event onsubmit
         */
        self.onsubmit = function () {
            if (!inner.check()) return;
            self.submiting(true);

            var act = window.edoc2Cryptography.encryptData(self.account());
            var pwd = window.edoc2Cryptography.encryptData(self.password());
            var remember = self.settings.rememberAccount();
            var url = location.origin + "/api/auth/login" + location.search;

            var params = {
                account: act,
                password: pwd,
                rememberAccount: remember,
                domainIp: "",
                validateCodeSms: "",
                Secure: true
            }

            xhr.post(url, params).done(function (res) {
                store.remove("user");
                store.remove("company");
                store.remove("companies");

                if (res.Successed) {
                    cookie.set("lang", self.language(), { path: "/" });

                    var company = self.companies().find(function (obj) {
                        return obj.id == self.company()
                    })

                    if (company) {
                        store.set("company", company);
                        store.set("companies", self.userInfo().companies);
                    }

                    inner.setAccount();
                    inner.setUserCompany(company);

                    var returnUrl = res.Message;
                    location.href = returnUrl;

                    return;
                }

                //Redirect to the Change password page after your first login or password expires.
                if (res.StateCode == "218" || res.StateCode == "219") {
                    var actions = {
                        "Code_218": "NewModifyDefaultPassword",
                        "Code_219": "NewModifyExpiredPassword"
                    }

                    var company = self.companies().find(function (obj) {
                        return obj.id == self.company();
                    })

                    if (company) {
                        store.set("company", company);
                        store.set("companies", self.userInfo().companies);
                    }

                    inner.setAccount();
                    inner.setUserCompany(company);

                    location.href = "/api/auth/passwordexit?action=" + actions["Code_" + res.StateCode];
                    return;
                }

                self.passwordError(true);
                self.submiting(false);
                inner.showMessage(res.Message);
            })
        }

        //Load the configuration and get it from the cache if there is one.
        inner.loadSettings = function () {
            if (env.settings) return;

            xhr.sync.get("/config/settings").done(function (settings) {
                if (!settings) return;
                env.settings = settings;
            })
        }

        /**
         * Loads user information from the account.
         * @method loadUserInfo
         */
        inner.loadUserInfo = function () {
            var promise = xhr.get("/user?account=" + self.account());
            promise.done(function (res) {
                if (res.code == 200) {
                    self.userInfo(res.data);
                }
            })

            return promise;
        }

        /**
         * Loads the list of companies.
         * @method reloadCompanies
         */
        inner.loadCompanies = function () {
            self.companies([]);
            var companies = self.userInfo().companies;
            if (companies.length) {
                self.companies(companies);
            }
        }

        /**
         * Set user company info.
         * @method setUserCompany
         */
        inner.setUserCompany = function (company) {
            var user = env.user = self.userInfo();
            if (company) {
                user.orgId = company.id;
                user.orgIdentityId = company.identityId;
                user.orgCode = company.code;
                user.orgName = company.name;
                user.orgPositionId = company.positionId;
                user.orgPositionIdentityId = company.positionIdentityId;
                user.orgPath = company.path;
                user.orgParentId = company.parentId;
                user.orgParentidentityId = company.parentIdentityId;
            }

            store.set("user", env.user);
        }

        /**
         * If the account is remembered, the account is loaded from the document.cookie.
         * @method setAccount
         */
        inner.getAccount = function () {
            //The account is loaded from the cookie.
            var rememberAccount = cookie.get("rememberAccount");
            var account = cookie.get("account").trim();
            if (rememberAccount == "true") {
                self.settings.rememberAccount(true);
                self.account(decodeURIComponent(account));

                var promise = inner.loadUserInfo();
                promise.done(function (res) {
                    if (res.code == 200) {
                        inner.loadCompanies();
                        self.company(self.userInfo().orgId);
                    }
                })
            }

            if (rememberAccount == "false") {
                self.settings.rememberAccount(false);
            }
        }

        /**
         * Update the account in the cookie.
         * @method setAccount
         */
        inner.setAccount = function () {
            if (self.settings.rememberAccount()) {
                cookie.set("rememberAccount", true, { path: '/' });
                cookie.set("account", self.account().trim(), { path: '/' });
            }
            else {
                cookie.set("rememberAccount", false, { path: '/' });
                cookie.set("account", "", { path: '/' });
            }
        }

        /**
         * Check whether the account, password and company are filled in correctly.
         * @method check
         * @returns {boolean} True if the checksum passes,otherwise,false.
         */
        inner.check = function () {
            self.accountError(false);
            self.passwordError(false);
            self.companyError(false);

            if (!self.account()) {
                self.accountError(true);
                inner.showMessage(lang.accountNotEmptyTip);
                return false;
            }

            if (!self.password()) {
                self.passwordError(true);
                inner.showMessage(lang.passwordErrorTip);
                return false;
            }

            if (!self.company() && !self.isAdmin()) {
                self.companyError(true);
                inner.showMessage(lang.companyNotEmptyTip);
                return false;
            }

            return true;
        }

        /**
         * Display error message.
         * @method showMessage
         * @param {string} message The message string.
         */
        inner.showMessage = function (message) {
            var el = $("<div></div>").addClass("login-message").text(message);
            $("body").append(el);

            setTimeout(function () { el.remove() }, 3000);
        }
    }

    return Login;
})