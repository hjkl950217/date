﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/24 15:08:48
*
***************************************************************************/

define(['knockout', 'i18n!./lang', "css!./password"], function (ko, lang) {
	var Password = function () {
		var self = this;
		var inner = {};

		self.lang = lang;
		self.password = ko.observable("");
		self.showTips = ko.observable(false);

		self.id = new Date().getTime() + Math.round(Math.random() * 100);
		self.name = self.id;
		self.placeholder = "";
		self.value = ko.observable("");

		//Invalid keycode.
		inner.keyCodes = [
			12, 16, 17, 18, 19, 20, 27, 33, 34,
			35, 36, 37, 38, 39, 40, 45, 46, 91, 92,
			93, 112, 113, 114, 115, 116, 117, 118,
			119, 120, 121, 122, 123, 144, 145, 166,
			167, 255
		];

		/**
		 * The hook function when the component is activated.
		 * @param {any} params The custom data.
		 */
		self.activate = function (params) {
			for (var key in params) {
				if (!self.hasOwnProperty(key)) continue;

				if (ko.isObservable(params[key])) {
					self[key] = params[key];
					continue;
				}

				if (ko.isObservable(self[key])) {
					self[key](params[key]);
				}
				else {
					self[key] = params[key];
				}
			}
		}

		//Enter the event.
		self.onenter = function () { }

		/**
		 * Password textbox keyboard press event.
		 * @param {object} event The event object that triggers the event.
		 */
		self.onkeydown = function (model, event) {
			var element = event.target;
			var keyCode = window.event.keyCode;         //Current key ASCII code
			var startIndex = element.selectionStart;    //The starting position of the selected text.
			var password = self.password();

			if (inner.filter(keyCode)) return;

			//Tab
			if (keyCode == 9) return true;

			//Enter to complete the password
			if (keyCode == 13) {
				return self.onenter();
			}

			//Input in Chinese is not allowed.
			if (keyCode == 229) {
				element.value = password.replace(/[\s\S]/g, "*");
				element.blur();
				setTimeout(function () { element.focus(); }, 300);
				self.showTips(true);
				return;
			}
			self.showTips(false);

			//The delete key.
			if (keyCode == 8) {
				//If the starting position of the selected text is equal
				//to the character length, then no text is selected.
				if (startIndex == password.length) {
					startIndex = startIndex - 1;
				}
				password = password.substr(0, startIndex);
			}
			else {
				password = password.substr(0, startIndex);
				password += window.event.key;
			}

			//Replace the password with * to display in the textbox.
			element.value = password.replace(/[\s\S]/g, "*");
			element.focus();
			element.setSelectionRange(password.length, password.length);

			//Pass the value to the parent component.
			self.password(password);
			self.value(password);
		}

		//An empty function that does not perform any action.
		self.noop = function () {
			return false;
		}

		/**
		 * Returns a value indicating whether an invalid key code is present.
		 * @param   {number} keyCode  The keyboard code.
		 * @returns {boolean} True if the keycode is invalid.
		 */
		inner.filter = function (keyCode) {
			return inner.keyCodes.indexOf(keyCode) > -1;
		}
	}

	return Password;
})