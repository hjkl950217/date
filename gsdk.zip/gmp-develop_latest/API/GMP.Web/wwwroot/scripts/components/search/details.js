﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/13 19:09:18
*
***************************************************************************/

define(['gmp/system', 'knockout'], function (system, ko) {
    var url = "/index.html?Panelcontrol=0.0.0#doc/enterprise/1/search?searchkey={0}&searchtype=0|1&searchaccuracy=0&drop=true&location=1&target=allFolder";

    return {
        src: ko.observable(url),
        activate: function () {
            var key = system.querystring("q");
            this.src(system.format(url, key));
        }
    }
})