﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/12 11:03:35
*
***************************************************************************/

define(['gmp/lib/hotkeys', 'gmp/events'], function (hotkeys, events) {
    hotkeys('ctrl+f', function (event) {
        event.preventDefault();
        event.stopPropagation();

        events.emit("top:component.show", {
            model: 'components/search/searchbox'
        })
    })
})