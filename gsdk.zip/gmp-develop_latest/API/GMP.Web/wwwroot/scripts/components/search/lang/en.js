﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/20 10:52:46
*
***************************************************************************/

define(function () {
    return {
        search: 'Searching',
        placeholder: 'Enter what you want to search...'
    }
})