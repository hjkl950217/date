﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/20 10:53:11
*
***************************************************************************/

define(function () {
    return {
        search: '検索',
        placeholder: '検索する内容を入力する...'
    }
})