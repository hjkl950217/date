﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/20 10:52:34
*
***************************************************************************/

define(function () {
    return {
        search: '搜索',
        placeholder: '输入需要检索的内容...'
    }
})