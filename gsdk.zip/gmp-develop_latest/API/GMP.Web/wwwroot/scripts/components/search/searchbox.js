﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/7/12 11:10:22
*
***************************************************************************/

define(['gmp/env'
    , 'gmp/system'
    , 'gmp/events'
    , 'gmp/store'
    , 'layui/layer'
    , 'knockout'
    , 'jquery'
    , 'i18n!./lang'
    , 'css!./searchbox'
], function (env, system, events, store, layer, ko, $, lang) {
    return {
        dialog: null,
        focus: ko.observable(true),
        search: ko.observable(),
        history: ko.observableArray([]),
        placeholder: ko.observable(lang.placeholder),
        /**
         * Searches for the specified content when the user presses `Enter`.
         * If the search content is not in the user's search history, 
         * it is added to the search history.
         * @param {object} instance The current instance.
         * @param {Event} event The KeyboardEvent object.
         */
        onenter: function (instance, event) {
            if (event.keyCode != 13) return;
            if (this.search() == "") return;

            var searchKey = this.search();
            this.search("");
            this.searching(searchKey);

            var index = this.history().findIndex(function (v) {
                return v == searchKey;
            });
            if (index > -1) return;

            this.history.unshift(searchKey);
            store.set("search.history_" + env.user.id, this.history());
        },
        /**
         * Searches using the specified search key.
         * @param {string} searchKey The search key.
         */
        searching: function (searchKey) {
            events.emit("top:searching", searchKey);
            layer.close(this.dialog);
        },
        /**
         * Component hooks,initialize the search history of 
         * the current user when the component is activated.
         */
        activate: function () {
            var searchHistory = store.get("search.history_" + env.user.id);
            if (!searchHistory) return;

            this.history(searchHistory);
        },
        /**
         * Component hooks,After the data binding is complete, 
         * a pop-up dialog box displays the current view.
         * @param {Element} view The component view.
         * @param {Element} parent The parent component view.
         * @param {object} context Component context object.
         */
        attached: function (view, parent, context) {
            this.dialog = layer.open({
                type: 1,
                title: false,
                content: $(view),
                closeBtn: 0,
                shadeClose: true,
                area: ['600px', '400px'],
                end: function () {
                    events.emit("component.show", {})
                }
            })
        },
        /**
         * Component hooks,clean up the mask layer of the dialog box 
         * in the DOM when you remove a component.
         * @param {Element} view The component view.
         * @param {Element} parent The parent component view.
         */
        detached: function (view, parent) {
            $("#layui-layer-shade" + this.dialog).remove();
        }
    }
})