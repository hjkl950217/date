﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/8/30 10:16:43
*
***************************************************************************/

define(['gmp/events', 'i18n!./lang'], function (events, lang) {
    return {
        lang: lang,
        onclick: function () {
            events.emit("top:component.show", {
                model: 'components/search/searchbox'
            })
        }
    }
})