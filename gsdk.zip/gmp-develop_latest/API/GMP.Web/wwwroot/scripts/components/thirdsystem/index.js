﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/28 17:47:34
*
***************************************************************************/

define(['gmp/system', 'knockout', 'plugins/router'], function (system, ko, router) {
    return {
        src: ko.observable(""),
        activate: function (index) {
            var self = this;
            var navs = router.navigationModel();
            system.loading(null, 5000);

            if (!index) {
                app.title = navs[0].title;
                router.navigate(navs[0].hash);
                return;
            }

            setTimeout(function () {
                router.updateDocumentTitle(self, {
                    config: {
                        title: navs[index].title
                    }
                });

                self.src(navs[index].url);
            }, 50);
        },
        attached: function (view) {
            view.onload = function () {
                system.loaded();
            }
        }
    }
})