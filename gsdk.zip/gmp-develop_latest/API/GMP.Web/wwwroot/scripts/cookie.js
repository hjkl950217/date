﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/27 17:08:43
*
***************************************************************************/

/**
 * Cookie module.
 * @module gmp/cookie
 */
define(function () {
    var cookie = {};

    /**
     * Gets the value of the key.
     * @method get
     * @param {string} key The key to get the value.
     * @returns {string} Specifies the value of the key.
     */
    cookie.get = function (key) {
        var reg = new RegExp(key + "=([^;]*)[;]?");
        var m = document.cookie.match(reg);
        if (m && m.length > 0) return m[1];
        return "";
    }

    /**
     * Sets the value of the specified key.
     * @method set
     * @param {string} key      The key to set the value.
     * @param {string} value    The value to set.
     * @param {object} options  Options for specifying the key.
     */
    cookie.set = function (key, value, options) {
        options = options || {};
        value = value == null ? "" : encodeURIComponent(value);
        if (value == "") options.expires = -1;

        if (options.expires && typeof options.expires == 'number') {
            var date = new Date();
            date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            options.expires = date;
        }

        var expires = options.expires ? "; expires=" + date.toUTCString() : "";
        var path = options.path ? "; path=" + (options.path) : "";
        var domain = options.domain ? "; domain=" + (options.domain) : "";
        var secure = options.secure ? "; secure" : "";

        document.cookie = [key, "=", value, expires, path, domain, secure].join("");
    }

    return cookie;
})