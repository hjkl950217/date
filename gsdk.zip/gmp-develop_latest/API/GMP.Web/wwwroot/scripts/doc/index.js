﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/15 16:58:26
*
***************************************************************************/

define(function () {
    return {
        src: "/index.html?Panelcontrol=0.1.1" + location.hash
    }
})