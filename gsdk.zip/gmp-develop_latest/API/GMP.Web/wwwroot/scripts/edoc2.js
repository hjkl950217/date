﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/15 9:54:42
*
***************************************************************************/

/**
 * Edoc2 webcore requests encapsulation.
 * @module gmp/edoc2
 * @requires gmp/xhr
 */
define(['gmp/env', 'gmp/xhr', 'gmp/system', 'gmp/events'], function (env, xhr, system, events) {
    var Edoc2Api = function () {
        var self = this;
        self.serviceUrl = location.origin + "/api/services/{0}/{1}";

        /**
         * Request the edoc2 webcore service to fetch the relevant data.
         * @method service
         * @param {string} module   The module name.
         * @param {string} func     The method name of the request.
         * @param {object} data     The request data.
         * @returns {object} Service response data.
         */
        self.webcore = function (module, func, data) {
            var params = data || {};
            params.module = module;
            params.fun = func;

            var inst = xhr.new();
            inst.headers.Accept = "application/json";
            return inst.post(location.origin + "/WebCore", params);
        }

        /**
         * Request the specified service method of edoc2 using get.
         * @param {string} service The specified service name.
         * @param {string} method Specify methods under the service.
         * @param {object} data The request data.
         * @param {boolean} async True If it's an asynchronous request, otherwise, false.
         * @returns {Promise} Returns a jQuery Pomise object.
         */
        self.get = function (service, method, data, async) {
            var requestUrl = system.format(self.serviceUrl, service, method);
            return xhr.get(requestUrl, data, null, null, async);
        }

        /**
         * Request the specified service method of edoc2 using post.
         * @param {string} service The specified service name.
         * @param {string} method Specify methods under the service.
         * @param {object} data The request data.
         * @param {boolean} async True If it's an asynchronous request, otherwise, false.
         * @returns {Promise} Returns a jQuery Pomise object.
         */
        self.post = function (service, method, data, async) {
            var requestUrl = system.format(self.serviceUrl, service, method);
            return xhr.post(requestUrl, data, null, null, async);
        }

        /**
         * Check the user login status and go to 
         * the login page when the user logs out.
         */
        self.checkLogin = function () {
            self.get("Doc", "GetServerDateTime", { token: env.token }, false).done(function (res) {
                if (!res) return;
                if (res.errorCode && res.errorCode == "ErrorCode4") {
                    events.emit("all:user.logout");
                    var returnUrl = window.location.pathname + window.location.hash;
                    returnUrl = window.encodeURIComponent(returnUrl);
                    window.top.location.href = res.url + "?returnUrl=" + returnUrl;
                }
            })
        }
    }

    return new Edoc2Api();
})