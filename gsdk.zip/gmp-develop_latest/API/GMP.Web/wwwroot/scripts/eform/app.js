﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/9 9:27:26
*
***************************************************************************/

//Lazy loading of formParser.
var parser = window.FormParser;
window.FormParser = function () {
	this.init = function () { }
};

$(function () {
	//Environment variables.
	env.path = env.path || {};
	env.path.gmp = env.path.gmp || location.origin + "/gmp";

	//Enable debugging.
	if (/debug=gmp/.test(location.href)) {
		env.path.gmp = env.debug.origin;
	}
	if (/debug=app/.test(location.href)) {
		env.path.app = env.debug.origin;
	}

	//Appid is a must.
	if (!env.appid) throw "The appid is required.";

	//Remove the original parsing script.
	var scripts = document.scripts;
	var script = scripts[scripts.length - 1];
	var params = /{.*}/.exec(script.innerText)[0];
	script.remove();

	//Reinstantiate FormParser.
	window.FormParser = parser;
	window.instancesFormParams = eval("(" + params + ")");

	//Add the gmp entry script.
	var script = document.createElement('script');
	script.id = "entry";
	script.type = 'text/javascript';
	script.charset = 'utf-8';
	script.async = true;
	script.dataset.main = env.path.gmp + "/scripts/eform/main";
	script.src = env.path.gmp + "/scripts/lib/require/require.js";
	document.head.append(script);
})