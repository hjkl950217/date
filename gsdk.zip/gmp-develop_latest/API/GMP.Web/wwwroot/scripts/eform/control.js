﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/10 17:45:01
*
***************************************************************************/

define(['gmp/xhr', 'gmp/eform/lang'], function (xhr, lang) {
	var Control = function (control, type) {
		var self = this;
		var inner = {};
		self.type = type || "control";

		/**
		 * Displays or hides the specified block.
		 * @private
		 * @method setBlockShow
		 * @param {object}  block   The block to show or hide.
		 * @param {boolean} show    Show is true, hide is false.
		 */
		inner.setBlockShow = function (block, show) {
			var columns = block.columns._hash;
			for (var key in columns) {
				inner.setColumnShow(columns[key], show);
			}

			//Show or hide self.
			show ? block.show() : block.hide();
		}

		/**
		 * Sets the required or non-required controls based on the specified block.
		 * @private
		 * @method setBlockMust
		 * @param {object}  block   The block to set.
		 * @param {boolean} must    Required is true,non-required is true.
		 */
		inner.setBlockMust = function (block, must) {
			var columns = block.columns._hash;
			for (var key in columns) {
				inner.setColumnMust(columns[key], must);
			}
		}

		/**
		 * Gets the value of all controls in the specified block.
		 * @private
		 * @method getBlockValue
		 * @param   {object} block  The block in a form.
		 * @returns {object} A key-value pair object.
		 */
		inner.getBlockValue = function (block) {
			var columns = block.columns._hash;
			var obj = {};

			for (var key in columns) {
				var values = inner.getColumnValue(columns[key]);
				$.extend(obj, values);
			}

			return obj;
		}

		/**
		 * Displays or hides the specified column.
		 * @private
		 * @method setColumnShow
		 * @param {object}  column  The column to show or hide.
		 * @param {boolean} show    Show is true, hide is false.
		 */
		inner.setColumnShow = function (column, show) {
			var controls = column.controls._hash;
			for (var key in controls) {
				show ? controls[key].show()
					: controls[key].hide();
			}

			//Show or hide self.
			show ? column.show() : column.hide();
		}

		/**
		 * Sets the required or non-required controls based on the specified column.
		 * @private
		 * @method setColumnMust
		 * @param {object}  column  The column to set.
		 * @param {boolean} must    Required is true,non-required is true.
		 */
		inner.setColumnMust = function (column, must) {
			var controls = column.controls._hash;
			for (var key in controls) {
				controls[key].required(must);
			}
		}

		/**
		 * Gets the value of all controls in the specified column.
		 * @private
		 * @method getColumnValue
		 * @param   {object} column The column in a form.
		 * @returns {object} A key-value pair object.
		 */
		inner.getColumnValue = function (column) {
			var controls = column.controls._hash;
			var obj = {};

			for (var key in controls) {
				var value = controls[key].getValue();
				obj[key] = value;
			}

			return obj;
		}

		/**
		 * Gets the data source for the edoc2SelectBox control.
		 * @returns {object}
		 */
		inner.getDataSource = function () {
			var source = [];
			var properties = control.property._hash;

			if (properties.datasource.value) {
				var source = JSON.parse(properties.datasource.value);
			}

			if (!source.length) {
				source = inner.getStaticDataSourc(properties.staticDataSource.value);
			}

			var data = {};
			for (var i = 0; i < source.length; i++) {
				var obj = source[i];
				data[obj.value] = lang[obj.text] || obj.text;
			}

			return data;
		}

		/**
		* Gets the static data source based on the specified data source id.
		* @param {string} id The data source id.
		* @returns {array} The static data source.
		*/
		inner.getStaticDataSourc = function (id) {
			var source = [];
			var serviceUrl = env.path.origin + eform.virtualPath + "/StaticDataSource/GetDataSourceItemById?id=" + id;

			xhr.sync.get(serviceUrl).done(function (res) {
				source = res;
			})

			return source;
		}

		/**
		 * Gets or sets a value indicating whether the control is displayed.
		 * @property
		 */
		Object.defineProperty(self, "show", {
			get: function () {
				return control.isShow == true
					|| control.isShow == "true";
			},
			set: function (value) {
				if (self.type == "block") inner.setBlockShow(control, value);
				if (self.type == "column") inner.setColumnShow(control, value);
				if (self.type == "control") {
					value ? control.show() : control.hide();
				}
			}
		})

		/**
		 * Gets or sets a value indicating whether the control is required.
		 * @property
		 */
		Object.defineProperty(self, "required", {
			get: function () {
				if (self.type != "control") return;
				return control.getConfig("must") == "true";
			},
			set: function (value) {
				if (self.type == "block") inner.setBlockMust(control, value);
				if (self.type == "column") inner.setColumnMust(control, value);
				if (self.type == "control") control.required(value);
			}
		})

		/**
		 * Gets or sets a value indicating whether the control is readonly.
		 * @property
		 */
		Object.defineProperty(self, "readonly", {
			get: function () {
				if (self.type != "control") {
					return control.readonly;
				}

				return control.getConfig("readonly") == "true";
			},
			set: function (value) {
				eform.setReadonly(control.controlId || control.id, value, self.type);
			}
		})

		/**
		 * Gets or sets the value of the control
		 * @property
		 */
		Object.defineProperty(self, "value", {
			get: function () {
				if (self.type == "block") return inner.getBlockValue(control);
				if (self.type == "column") return inner.getColumnValue(control);
				if (self.type == "control") return control.getValue();
			},
			set: function (value) {
				if (self.type != "control") return;
				control.setValue(value);
			}
		})

		/**
		 * Gets or sets the text of the control
		 * @property
		 */
		Object.defineProperty(self, "text", {
			get: function () {
				if (control.Const_Type == "edoc2Selectbox") {
					var dataSource = inner.getDataSource();
					return dataSource[self.value];
				}

				return control.getText && control.getText() || "";
			}
		})

		/**
		 * Gets or sets the label of the control.
		 * @property label
		 */
		Object.defineProperty(self, "label", {
			get: function () {
				if (self.type == "block") return control.title;
				if (self.type == "column") return control.title;
				if (self.type == "control") return control.getLabelHtml();
			},
			set: function (value) {
				if (self.type == "block") {
					var title = control.jqBlock.find(".formBlockTitle>span");
					if (title.length == 0) {
						control.jqBlock.prepend("<div class='formBlockTitle'><span></span></div>");
					}

					control.setTitle(value);
				}

				if (self.type == "column") {
					var title = control.jqColumn.find(".colTitle");
					if (title.length == 0) {
						control.jqColumn.prepend("<div class='colTitle'></div>");
					}

					control.jqColumn.find(".colTitle").show();
					control.setTitle(value);
				}

				if (self.type == "control") {
					control.setLabelHtml(value);
				}
			}
		})
	}

	return Control;
})