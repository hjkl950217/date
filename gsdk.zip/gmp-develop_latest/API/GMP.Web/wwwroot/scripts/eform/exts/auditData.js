﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/2/24 16:50:14
*
***************************************************************************/

define([
    'gmp/eform/parser',
    'gmp/eform/workflow',
    'gmp/eform/lang',
    'gmp/xhr',
    'gmp/env',
    'gmp/system'
], function (parser, wf, lang, xhr, env, system) {
    var AuditData = function () {
        var self = this;
        var inner = {};

        /**
         *  Gets the change data for the current form.
         */
        self.getChangedData = function () {
            var changedData = [];
            var eformData = parser.getData();
            var value = "";

            //Cache data before modification.
            if (eformData.findIndex(item => item.key == 'oldValues') >= 0) {
                value = eformData[eformData.length - 1].value;
                eformData = eformData.slice(0, -1);
            }
            var originData = value ? JSON.parse(value) : [];

            for (var i = 0; i < eformData.length; i++) {
                var controlId = eformData[i].key;
                var currentValue = eformData[i].value;
                var originValue = originData[controlId] == undefined ? "" : originData[controlId];

                if (controlId.toLowerCase() == "id") continue;

                //2021.06.24 xueyi.wang Skip dynamically generated controls 
                //because they cannot be obtained through eform(controlId).
                if (!eform(controlId)) continue;

                //Ignore changes to hidden fields and related data in hidden blocks.
                var control = eform(controlId).method("getControl");
                var options = inner.getControlOptions(controlId);
                if (options.constType == "edoc2Hidden"
                    || !options.isShow
                    || !control.column.block.isShow
                    || options.readonly == "true") continue;

                //Fixed an issue caused by different ordering of multiple values.
                if (options.constType == "edoc2DropDownList"
                    && options.mode == "multiple") {
                    originValue = originValue.split(",").sort().join(",");
                    currentValue = currentValue.split(",").sort().join(",");
                }

                //Ignore fields whose values have not changed.
                if (originValue == currentValue) continue;

                var changeEntity = {
                    field: options.fieldName,
                    name: options.name,
                    oldValue: originValue,
                    oldText: inner.getControlText(originValue, options),
                    newValue: currentValue,
                    newText: inner.getControlText(currentValue, options)
                }

                //Attachment control, upload control, date control,
                //if the value before and after the change is the same, ignore.
                if ((options.constType == "edoc2AttachmentList"
                    || options.constType == "edoc2Upload"
                    || options.constType == "edoc2RichText"
                    || options.constType == "edoc2DropDownList"
                    || options.constType == "edoc2RichText"
                    || options.constType == "edoc2Date")
                    && changeEntity.oldText == changeEntity.newText) {
                    continue;
                }

                //Add to the change data.
                changedData.push(changeEntity);
            }

            return changedData;
        }

        /**
         * Gets the audit base metadata.
         */
        self.getMetaData = function () {
            var data = []

            //Current login user.
            var user = env.user;
            data.push({ key: 'UserId', value: user.id, category: 'User' })
            data.push({ key: 'Account', value: user.account, category: 'User' })
            data.push({ key: 'UserName', value: user.name, category: 'User' })
            data.push({ key: 'DeptId', value: user.deptId, category: 'User' })
            data.push({ key: 'DeptName', value: user.deptName, category: 'User' })
            data.push({ key: 'PositionId', value: user.positionId, category: 'User' })
            data.push({ key: 'PositionName', value: user.positionName, category: 'User' })
            data.push({ key: 'OrgId', value: user.orgId, category: 'User' })
            data.push({ key: 'OrgName', value: user.orgName, category: 'User' })

            //Current form info.
            var form = parser.instanceFormConfig;
            data.push({ key: 'FormId', value: form.formId, category: 'Form' })
            data.push({ key: 'FormVer', value: form.formVer, category: 'Form' })
            data.push({ key: 'FormName', value: (lang[parser.formData.FormName] || parser.formData.FormName), category: 'Form' })
            data.push({ key: 'RecordId', value: form.recordId, category: 'Form' })
            data.push({ key: 'MasterRecordId', value: system.querystring("masterrecordid") || 'N/A', category: 'Form' })

            //Current process info.
            if (wf.hasWorkflow) {
                data.push({ key: 'ProcessKey', value: wf.processKey, category: 'WorkFlow' })
                data.push({ key: 'ProcessId', value: wf.processId, category: 'WorkFlow' })
                data.push({ key: 'TaskType', value: wf.taskType, category: 'WorkFlow' })
                data.push({ key: 'Incident', value: wf.incident, category: 'WorkFlow' })
                data.push({ key: 'TaskId', value: wf.taskId, category: 'WorkFlow' })
            }

            return data;
        }

        /**
         * Gets a collection of properties for the specified control.
         * @param {string} controlId The control id.
         * @returns {object} A collection of properties for the specified control.
         */
        inner.getControlOptions = function (controlId) {
            var optionObj = {};

            var control = eform(controlId).method("getControl");
            var options = control.property.array;

            //Array to object
            for (var i = 0; i < options.length; i++) {
                optionObj[options[i].id] = options[i].value;
            }

            optionObj["constType"] = control.Const_Type;
            optionObj["isShow"] = control.isShow == undefined ? true : control.isShow;
            optionObj.name = lang[optionObj.name] || optionObj.name;//The field name.

            return optionObj;
        }

        /**
         * Returns a readable display value based on the control type.
         * @param {string} value The original value.
         * @param {object} options The control options.
         */
        inner.getControlText = function (value, options) {
            if (value === undefined || value === "") return value;

            //Edoc2SelectMember contorl.
            if (options.constType == "edoc2SelectMember") {
                var obj = JSON.parse(value);
                var arr = [];

                for (var i = 0; i < obj.length; i++) {
                    arr.push(obj[i].text);
                }

                return arr.join(",");
            }

            //Edoc2SelectFolder contorl.
            if (options.constType == "edoc2SelectFolder") {
                var obj = JSON.parse(value);
                var arr = [];

                for (var i = 0; i < obj.length; i++) {
                    arr.push(obj[i].folderName);
                }

                return arr.join(",");
            }

            //Edoc2Selectbox control.
            if (options.constType == "edoc2Selectbox") {
                var obj = [];
                var arr = [];
                var source = {};

                //If the static data source is empty, the static data source
                //is obtained based on the data source ID.
                if (options.datasource) {
                    obj = JSON.parse(options.datasource);
                } else {
                    obj = inner.getStaticDataSourc(options.staticDataSource);
                }

                //Data source array to object.
                for (var i = 0; i < obj.length; i++) {
                    source[obj[i].value] = lang[obj[i].text] || obj[i].text;
                }

                var values = value.split(",");
                for (var i = 0; i < values.length; i++) {
                    arr.push(source[values[i]]);
                }

                return arr.join(",");
            }

            //Edoc2DropDownList control.
            if (options.constType == "edoc2DropDownList") {
                var control = eform(options.controlId).method("getControl");
                var currVal = control.getValue();
                if (options.mode == "multiple") {
                    currVal = currVal.split(",").sort().join(",");
                }

                if (currVal == value) return control.getText();
                return control.cacheData && control.cacheData.text || "";
            }

            //Edoc2Switch control.
            if (options.constType == "edoc2Switch") {
                return value == "0" ? lang.Global_No : lang.Global_Yes;
            }

            //edoc2Date control.
            if (options.constType == "edoc2Date") {
                return new Date(value).format(options.dateFormat.replace("-mm-", "-MM-"));
            }

            //Edoc2Upload control.
            if (options.constType == "edoc2Upload") {
                var obj = JSON.parse(value);
                var arr = [];

                for (var i = 0; i < obj.length; i++) {
                    arr.push(obj[i].fileName);
                }

                return arr.join(",");
            }

            //edoc2ImageUpload control.
            if (options.constType == "edoc2ImageUpload") {
                var obj = JSON.parse(value);
                var arr = [];

                for (var i = 0; i < obj.length; i++) {
                    var fileName = obj[i].fileName;
                    fileName = fileName.substr(fileName.lastIndexOf("/") + 1);
                    arr.push(fileName);
                }

                return arr.join(",");
            }

            //The default value is returned.
            return value;
        }

        /**
         * Gets the static data source based on the specified data source id.
         * @param {string} id The data source id.
         * @returns {array} The static data source.
         */
        inner.getStaticDataSourc = function (id) {
            var source = [];
            var serviceUrl = env.path.origin + eform.virtualPath + "/StaticDataSource/GetDataSourceItemById?id=" + id;

            xhr.sync.get(serviceUrl).done(function (res) {
                source = res;
            })

            return source;
        }
    }

    return new AuditData();
})