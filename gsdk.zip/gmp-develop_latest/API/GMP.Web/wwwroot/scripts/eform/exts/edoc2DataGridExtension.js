﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 19:06:26
*
***************************************************************************/

/**
 * The edoc2DataGridExtension control extension module.
 * @module gmp/eform/edoc2DataGridExtension
 * @requires gmp/system
 * @requires gmp/eform/parser
 */
define(['gmp/system', 'gmp/eform/parser', 'gmp/env'], function (system, parser, env) {
	var dataGrid = function () {
		var self = this;
		self.deleteData = function (formControl, rows, operate) {
			var url = edoc2Form.virtualPath + "/ControlService/DeleteGridData";
			var ids = formControl.getSelectedIds(rows, operate.param).join(",");

			parser.ajax(url, { ids: ids, formId: operate.formId }, function (bool, msg) {
				if (!bool && msg !== "true") {
					$.messager.alert(Edoc2FormSR.Global_Tip, msg, "error");
				} else {
					formControl.onAfterDeleteData(rows, operate); // 删除后事件
					var pagerOptions = formControl.control.datagrid("getPager").pagination("options");
					var pageNumber = pagerOptions.pageNumber;//当前页

					// 刷新页，剩下的行为0，则显示前一页的数据
					var remainRows = formControl.control.datagrid("getRows");
					formControl.reload({
						index: remainRows.length == 0 ? pageNumber - 1 : pageNumber
					});
				}
			}, "post", "text");
		}

		self.dataFilter = function (formControl, filterStr, orgField) {
			formControl.drawBefore = function () {
				var filterConn = "({0})";
				if (orgField) {
					var orgFilter = orgField + " = '" + env.user.orgId + "'";
					filterStr = filterStr ? orgFilter + " and (" + filterStr + ")": orgFilter;
				}
				filterConn = system.format(filterConn, filterStr)
				this.data.FilterInfo.filterStr = filterConn;
			}
		}
	}
	/**
	 * Gets the custom button options.
	 * @method getButtonOptions
	 * @param {string} buttonName The button name.
	 * @returns {object} The button options.
	 */
	parser.ControlBase.prototype.getButtonOptions = function (buttonName) {
		var options = {};
		var type = this.Const_Type;
		if (type != "edoc2ListGrid" && type != "edoc2DataTable") return;

		system.each(this.data.Operate, function (i, obj) {
			if (obj.formName === buttonName) {
				options = obj;
				return false;
			}
		});

		return options;
	}

	/**
	 * Gets the subform custom button options.
	 * @method getChildButtonOptions
	 * @param {string} buttonName The child window button name.
	 * @returns {object} The child window button options.
	 */
	parser.ControlBase.prototype.getChildButtonOptions = function (buttonName) {
		var options = {};
		var type = this.Const_Type;
		if (type != "edoc2ListGrid" && type != "edoc2DataTable") return;

		system.each(this.data.customButtons, function (i, obj) {
			if (obj.btnName === buttonName) {
				options = obj;
				return false;
			}
		});

		return options;
	}

	return new dataGrid();
})