﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/3 18:52:56
*
***************************************************************************/

/**
 * The edoc2Dialog component extension module.
 * Enables the dialog box to adapt to the browser window size without exceeding the window boundaries.
 * @module gmp/eform/edoc2DialogExtension
 * @requires gmp/eform/layout
 */
define(['gmp/eform/layout', 'gmp/eform/lang'], function (layout, lang) {
    var getDialogWindow = function () {
        var win = window;

        if (window.top.edoc2Form) win = window.top;
        if (layout.window != window) win = layout.window;
        if (window.parent.edoc2Form) win = window.parent;

        return win;
    }

    var eformDialog = window.edoc2Form.Dialog;
    window.edoc2Form.Dialog = function (options, params) {
        var win = getDialogWindow();

        //edoc2Upload control.
        if (params.target.indexOf("component%2Fupload%2Findex") > -1) {
            var onAfterOpen = params.onAfterOpen;
            params.onAfterOpen = function (e) {
                onAfterOpen.call(this, e);

                win.activeUploaderHost = win.activeUploaderHost || {};
                win.activeUploaderHost.onBeforeFileQueued = window.activeUploaderHost.onBeforeFileQueued;
                win.activeUploaderHost.uploadSkip = window.activeUploaderHost.uploadSkip;
                win.activeUploaderHost.onUploadFinish = window.activeUploaderHost.onUploadFinish;
            }
        }

        params.window = win;
        return eformDialog.call(this, options, params);
    }

    var dialog = $.fn.dialog;
    $.fn.dialog = function (options, params) {
        //Extend the methods.
        if (!$.fn.dialog.methods) $.extend($.fn.dialog, dialog);

        //Calls a method or gets a property.
        if (typeof options == "string") return dialog.call(this, options, params);

        //Window width adaptive.
        var width = parseInt(options.width);
        var clientWidth = window.document.documentElement.clientWidth;
        if (width >= clientWidth) options.width = clientWidth - 100;

        //Window highly adaptive.
        var height = parseInt(options.height);
        var clientHeight = window.document.documentElement.clientHeight;
        if (height >= clientHeight) options.height = clientHeight - 100;

        //Group dialog box buttons.
        if (options && options.buttons && options.buttons.length > 0) {
            for (var i = 0; i < options.buttons.length; i++) {
                //Compatible button event.
                if (options.buttons[i].click) {
                    options.buttons[i].handler = options.buttons[i].click;
                }

                var btnText = options.buttons[i].text;

                //Cancel button.
                if (btnText == lang.Global_Cancel) {
                    options.buttons[i].group = "cancel";
                }

                //Prev button and next button.
                if (btnText == lang.Global_Previous || btnText == lang.Global_Next) {
                    options.buttons[i].group = "switch";
                }
            }
        }

        return dialog.call(this, options, params);
    }

    /**
     * Creates a new dialog object in the specified window.
     * @param {Element} el Jquery element object.
     * @param {any} win Window object for top window or layout window, or current window.
     * @param {any} options Dialog properties object.
     */
    var createTopDialog = function (el, win, options, params) {
        var genId = $.genId();

        el.attr("cid", genId);
        el.appendTo(win.document.body);

        uploadCallbackBoost(win, options);

        el = win.$("[cid=" + genId + "]");
        return el.dialog(options, params);
    }

    /**
     * Appends a callback for the upload control to the specified window.
     * @param {window} win Window object for top window or layout window, or current window.
     * @param {object} options Dialog properties object.
     */
    var uploadCallbackBoost = function (obj, win, options) {
        if (!options.onOpen) return;
        if (options.onOpen.toString().indexOf("window.activeUploaderHost") == -1) return;

        var onOpen = options.onOpen;
        options.onOpen = function () {
            onOpen.call(obj);

            win.activeUploaderHost = win.activeUploaderHost || {};
            win.activeUploaderHost.onBeforeFileQueued = window.activeUploaderHost.onBeforeFileQueued;
            win.activeUploaderHost.uploadSkip = window.activeUploaderHost.uploadSkip;
            win.activeUploaderHost.onUploadFinish = window.activeUploaderHost.onUploadFinish;
        }
    }
})