﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/6/10 17:58:07
*
***************************************************************************/

define(['gmp/eform/parser', 'gmp/system'], function (parser, system) {

    /**
     * Extending the getValue method of the edoc2DropDownList control
     * to fix the problem of not getting the value when readonly.
     * @param {any} callback The original getValue method.
     */
    var getValueEx = function (callback) {
        var values;

        var isSystemStorage = this._getConfig("issystem") === "true";
        var isReadonly = this._getConfig("readonly") === "true";
        var isMultiple = this._getConfig("mode") == "multiple";

        if (!isSystemStorage && isReadonly && isMultiple) {
            values = isMultiple
                ? this.input.Edoc2SelectBox('getValue')
                : this._combogrid.combogrid("getValue");
        }

        return values != undefined ? values.join(',') : callback.call(this);
    }

    //Register parse events.
    var onParseAfter = function () {
        if (edoc2Form.edoc2DropDownList) {
            var controls = parser.controls._hash;
            system.each(controls, function (i, control) {
                if (!(control instanceof edoc2Form.edoc2DropDownList)) return;

                var getValueCache = control.getValue;
                control.getValue = function () {
                    return getValueEx.call(this, getValueCache);
                };

                if (control.cacheSelected) control.cacheData = control.cacheSelected;
            })
        }

        //Re-register after 100 milliseconds delay.
        setTimeout(function () {
            parser.onParseAfter = onParseAfter;
        }, 100);
    }

    parser.onParseAfter = onParseAfter;
})