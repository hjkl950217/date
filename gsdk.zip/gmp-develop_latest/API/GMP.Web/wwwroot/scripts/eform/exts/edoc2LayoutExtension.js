﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/5/31 10:57:23
*
***************************************************************************/

/**
 * edoc2Layout control extions module.
 * @module gmp/eform/edoc2LayoutExtension
 * @requires gmp/eform/parser
 * @requires gmp/system
 */
define(['gmp/eform/parser', 'gmp/system'], function (parser, system) {
    /**
     * Override the onmouseover event of the Layout tree component
     * to filter the HTML tags in the node title attribute.
     * @override
     * @param {Event} e jQuery.Event object.
     * @param {object} node Current node object.
     */
    var onMouseover = function(e, node) {
        var target = $(e.target);

        if (!target.attr("title")) {
            target.attr("title", $.removeHtmlTag(node.text));
        }

        var parent = target.closest(".panel");
        var top = parent.offset().top - $(".layout-title").parent().outerHeight();
        $('.easyui-nav-bar').css({ "opacity": "1", "top": top + "px" });
    }

    parser.onParseAfter = function () {
        if (!edoc2Form.edoc2Layout) return;

        //Find edoc2Layout control.
        var layout = parser.controls.array.find(function (obj) {
            return obj instanceof edoc2Form.edoc2Layout;
        })
        if (!layout) return;

        //Overrides onMouseover events for all trees.
        system.each(layout.trees, function (index, tree) {
            var options = $.data(tree.easyTree[0], 'tree').options;
            options.onMouseover = onMouseover;
        })
    }
})