﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/7 14:34:48
*
***************************************************************************/

define([
    'gmp/system'
    , 'gmp/xhr'
    , 'gmp/eform/parser'
    , 'gmp/eform/lang'
    , 'i18n!components/search/lang'
], function (system, xhr, parser, eformSR, lang) {
    var QuickSearch = function () {
        var self = this;
        var inner = {};
        var element = $("<div class='quickSearch'><input placeholder='" + lang.placeholder + "' /></div>");

        self.listgrid = null;
        self.columns = [];
        self.fields = {};
        self.filterInfo = { default: '', filter: ' and ({0})' };
        self.dataSourceType = 0;//0=Tables 1=Views 2=Stored procedures
        self.dataSource = [];
        self.valueMap = {};

        /**
         * Initialize quick search and bind events.
         */
        self.init = function () {
            if (!parser.isExistListGrid) return;

            self.dataSourceType = parser.formData.DataSourceType;
            self.listgrid = parser.controls.array.find(function (control) {
                return control instanceof edoc2Form.edoc2ListGrid;
            })

            //The default filter condition of the cache.
            //self.filterInfo.default = self.listgrid.data.FilterInfo.filterStr;
            self.filterInfo.default = self.listgrid.queryParams.filterStr;
            if (self.filterInfo.default == "") self.filterInfo.default = " 1=1 ";

            //Initialize the query data source.
            inner.initDataSourceForTablesAndViews();
            inner.initDataSourceForProcedures();

            //Add quick search box element.
            $("#" + self.listgrid.controlId).find(".datagrid-view").before(element);

            self.bindEvent();
        }

        /**
         * Hide quick search box.
         */
        self.hide = function () {
            element.hide();
            window.onscroll = null;
        }

        /**
         * Show quick search box.
         */
        self.show = function () {
            element.show();

            var onscrollCallback = system.throttle(50, function () {
                if (document.documentElement.scrollTop >= 50) {
                    toolbar.addClass("fixed");
                    search.addClass("fixed");
                } else {
                    toolbar.removeClass("fixed");
                    search.removeClass("fixed");
                }
            })
            window.onscroll = onscrollCallback;
        }

        /**
         * Returns a query condition based on the specified query content.
         * @param {string} query Content of the query.
         * @returns {string} The quick query condition.
         */
        self.getQueryCondition = function (query) {
            var params = {};
            params.filter = self.filterInfo.default;
            var search = self.filterInfo.filter;
            if (query === "") return params;

            if (query.indexOf("=") > -1) {
                var field = query.split("=")[0];
                var value = query.split("=")[1];
                if (!self.fields[field]) return params;

                //Gets the value before formatting.
                if (self.valueMap[value] && self.valueMap[value].field == self.fields[field]) {
                    value = self.valueMap[value].value;
                }
                search = " and " + self.fields[field] + " like '%" + value + "%' ";

                if (self.dataSourceType == 2) {
                    params[self.fields[field]] = value;
                }
            }

            //Gets the value before formatting.
            if (self.valueMap[query]) {
                var obj = self.valueMap[query];
                search = search.replace(obj.field + " like '%{0}%'", obj.field + " like '%" + obj.value + "%'");
            }

            params.filter += search;
            params.filter = system.format(params.filter, query);

            return params;
        }

        /**
         * Bind events for the query box.
         */
        self.bindEvent = function () {
            var input = element.find("input");

            //The query is executed when the query condition changes.
            input.bind("change", function () {
                var params = self.getQueryCondition(input.val());
                self.listgrid.load(params);
            })

            //The search box loses focus when the enter key is pressed,
            //triggering an onChange event to execute the query.
            input.bind("enter", function () { input.blur(); })

            //Press ESC to clear the quick search conditions and refresh the list.
            input.bind("focus", function () {
                $(document).unbind("keydown").bind("keydown", function (e) {
                    if (e.key !== "Escape") return;
                    if (input.val() === "") return;

                    var params = self.getQueryCondition(input.val("") && "");
                    self.listgrid.load(params);
                })
            })
        }

        /**
         * Initialize the query data source for the table or view.
         * Tables and views need to get query fields from the column configuration.
         */
        inner.initDataSourceForTablesAndViews = function () {
            if (self.dataSourceType == 2) return;

            var conditions = [];
            var columns = self.listgrid.data.Fields;

            system.each(columns, function (index, obj) {
                if (obj.show == "false") return;
                if (obj.field == "action") return;

                self.fields[obj.fieldName] = obj.field;
                self.fields[obj.field] = obj.field;

                conditions.push(" " + obj.field + " like '%{0}%' ");
                self.dataSource.push(obj.field);

                if (obj.formatter == "selectbox") inner.mapValueData(obj.field);
            })

            var filter = self.filterInfo.filter;
            self.filterInfo.filter = system.format(filter, conditions.join(' or '));
        }

        /**
         * Initialize the query data source for the stored procedure.
         * Stored procedures need to get query fields from the config params.
         */
        inner.initDataSourceForProcedures = function () {
            if (self.dataSourceType !== 2) return;

            var controls = edoc2Form.formParser.controls._hash;
            system.each(controls, function (key, control) {
                if (control.Const_Type == "edoc2ListGrid") return;
                if (control.Const_Type == "edoc2ListButton") return;
                if (control.property._hash.fieldName.value == "") return;

                var title = control.getLabelHtml();
                self.fields[key] = key;
                self.fields[title] = key;
            })
        }

        /**
         * Provides a mapped binding between the formatted value 
         * and the original value for fields bound to the formatter.
         * @param {string} field The field to which the mapping relationship is bound.
         */
        inner.mapValueData = function (field) {
            if (eform(field) == null) return;
            var control = eform(field).method("getControl");
            var property = control.property._hash;
            var sourceType = property.datasourceType.value;
            var datasource = property.datasource.value;

            //Custom data source.
            if (sourceType == "custom") {
                datasource = JSON.parse(datasource);
            }

            //Static data source.
            if (sourceType == "static") {
                var sourceId = property.staticDataSource.value;
                var url = location.origin + "/eform/StaticDataSource/GetDataSourceItemById";
                xhr.sync.post(url, { id: sourceId }).done(function (data) {
                    datasource = data;
                })
            }

            system.each(datasource, function (index, obj) {
                var text = eformSR[obj.text];
                self.valueMap[text] = { field: field, value: obj.value };
            })
        }
    }

    /**
     * Listens for scrollbar scroll events, and when the Toolbar moves out of the window,
     * add a fixed style class to it so that it floats at the top of the page.
     */
    parser.onParseAfter = function () {
        var toolbar = $(".edoc2ListGridContainer .datagrid-toolbar");
        var search = $(".edoc2ListGridContainer .quickSearch");
        if (!toolbar.length) return;

        var onscrollCallback = system.throttle(50, function () {
            if (document.documentElement.scrollTop >= 50) {
                toolbar.addClass("fixed");
                search.addClass("fixed");
            } else {
                toolbar.removeClass("fixed");
                search.removeClass("fixed");
            }
        })

        //#8573 修复导出按钮点击多次时,之前的弹出框未关闭的问题
        //2021-09-13 王学懿
        $(".fas.l-btn-icon.icon-export").parent().parent().on("mousedown", function () {
            $(".eform-export-import-wrap").dialog('close');
        });

        window.onscroll = onscrollCallback;
    }

    /**
     * Gets all the field configurations of the edoc2ListGrid control,
     * marking the showTitle property of the field to true
     * if no formatter is specified for the field.
     * */
    parser.onParseBefore = function () {
        if (!edoc2Form.edoc2ListGrid) return;

        var blocks = parser.formData.Container.Blocks;
        var columns = [];
        var controls = [];

        //All the blocks are traversed to get all the columns.
        system.each(blocks, function (index, block) {
            columns.push.apply(columns, block.Columns);
        })

        //All the columns are traversed to get all the controls.
        system.each(columns, function (index, column) {
            controls.push.apply(controls, column.Controls);
        })

        //Look for the ListGrid control and get its Config property.
        var listgrid = controls.find(control => control.ControlType == 'edoc2ListGrid');
        var config = listgrid && listgrid.Setting.find(v => v.id == 'config');
        var data = config && JSON.parse(config.value) || {};
        if (!data || !data.Fields) return;

        //Add the showTitle property for the list fields.
        system.each(data.Fields, function (index, field) {
            field.showTitle = field.formatter ? 'false' : 'true';
        })

        config.value = JSON.stringify(data);
    }

    var quickSearch = new QuickSearch();
    parser.onParseAfter = quickSearch.init;

    return quickSearch;
})