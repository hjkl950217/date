﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/30 14:52:46
*
***************************************************************************/

/**
 * The edoc2MemberSelect control extension module.
 * Extends multi-position and multi-department selection and display for the control.
 * @module gmp/eform/edoc2MemberSelectExtension
 * @requires gmp/xhr
 * @requires gmp/system
 * @requires gmp/eform/parser
 * @requires gmp/eform/utils
 * @requires gmp/eform/lang
 */
define([
    'gmp/env'
    , 'gmp/xhr'
    , 'gmp/system'
    , 'gmp/eform/parser'
    , 'gmp/eform/utils'
    , 'gmp/eform/lang'
], function (env, xhr, system, parser, utils, lang) {
    //Environment variable.
    env.memberSelect = env.memberSelect || {};
    env.memberSelect.attach = env.memberSelect.attach || false;             //True if you need to attach the member name.
    env.memberSelect.attachType = env.memberSelect.attachType || "position";//The type of member to attach.('department' or 'position')
    env.memberSelect.attachMode = env.memberSelect.attachMode || "custom";  //How Identify multiple departments or positions.('auto' or 'custom')
    env.memberSelect.selectMain = env.memberSelect.selectMain || true;      //Default selected main department or position.

	/**
	 * Extend edoc2MemberSelect control.
	 * @class EDoc2SelectMemberExtension
	 */
    var EDoc2SelectMemberExtension = function () {
        var self = this;
        var inner = {};

		/**
		 * Initialize
		 * @method init
		 */
        self.init = function () {
            inner.extend();

            //Register again to resolve TAB asynchronous loading.
            setTimeout(function () {
                parser.onParseAfter = self.init;
            }, 100);
        }

		/**
		 * Overrides or extends the method of a specified control.
		 * @private
		 * @method extend
		 */
        inner.extend = function () {
            if (!edoc2Form.edoc2SelectMember) return;

            var controls = parser.controls._hash;
            system.each(controls, function (i, control) {
                if (!(control instanceof edoc2Form.edoc2SelectMember)) return;
                if (control.attachType) return;

                inner.getValue(control);        //Override
                inner.renderData(control);      //Override
                inner.attachMember(control);    //Extension
                inner.setDeptRoot(control);    //Extension
            })
            setTimeout(function () {
                //优化组件多语言
                $("body").append("<style>.edoc2SelectMemberContainer .member-left-box::after,.edoc2DropDownListContainer .drop-list-left::after {content: '" +
                    Edoc2FormSR.Global_Add +
                    "';color: #5299b7;position: absolute;top: 0;right: 10px;}</style>");
            });
        }
        inner.setDeptRoot = function (control) {
            //  control.getEasyControl().Edoc2MemberSelect("options").param.DeptIds = [env.user.orgIdentityId];
            control.defaultRootParams.deptRootId = env.user.orgIdentityId;
            control.defaultRootParams.positionRootId = env.user.orgPositionIdentityId;
            control.defaultRootParams.userDeptRootId = env.user.orgIdentityId;
        }

		/**
		 * Override the renderData method of the specified control.
		 * @private
		 * @override
		 * @method getValue
		 * @param {object} control  The edoc2MemberSelect control instance.
		 */
        inner.getValue = function (control) {
            control.getValue = function (flag) {
                var isSystemStorage = control._getConfig("issystem") === "true";
                var isExistListGrid = flag ? false : control.formEngine.isExistListGrid;
                var memberData = control.selectMember.Edoc2MemberSelect("getValue");
                if (!memberData) return "";

                //Wrapped as an array and remove attributes.
                memberData = [].concat(memberData);
                memberData = inner.filterAttributes(memberData);

                //ListGrid
                if (isExistListGrid) {
                    var ids = [];
                    system.each(memberData, function (i, obj) { ids.push(obj.guid); });
                    return ids.join(',');
                }

                //The form of storage.
                if (isSystemStorage) {
                    return [this.input.data("data-map-value") || ""];
                }

                //Non-form storage.
                if (!isSystemStorage) {
                    var json = $.toJSON(memberData);
                    return json == "[]" ? "" : json;
                }
            }
        }

		/**
		 * Override the renderData method of the specified control.
		 * @private
		 * @override
		 * @method renderData
		 * @param {object} control  The edoc2MemberSelect control instance.
		 */
        inner.renderData = function (control) {
            var renderDataCache = control.renderData;
            control.renderData = function (data) {
                //Multiple departments or positions.
                var multiple = false;
                if (system.isObject(data)) data = [data];

                if (control.attachable) {
                    system.each(data, function (i, obj) {
                        if (obj.memberType != 0) return;           //Append member Name to users only.
                        if (obj.deptId || obj.positionId) return;   //Avoid duplicate confirmation.

                        //Attach department.
                        if (control.attachType == "department") {
                            multiple = inner.attachDepartment(obj) || multiple;
                        }

                        //Attach position.
                        if (control.attachType == "position") {
                            multiple = inner.attachPosition(obj) || multiple;
                        }
                    })
                }

                //Show confirm dialog or render data.
                if (multiple) {
                    inner.showConfirmDialog(control, data, function (data) {
                        if (control.getConfig("mode") == "false") {
                            control.input.find(".select2-chosen").text(data[0].text);
                        }

                        renderDataCache.call(control, data);
                    })
                }
                else {
                    system.each(data, function (i, obj) {
                        delete obj.attached;
                    })

                    if (control.getConfig("mode") == "false") {
                        control.input.find(".select2-chosen").text(data[0].text);
                    }

                    renderDataCache.call(control, data);
                }
            }
        }

		/**
		 * Extends the attachMember method for the specified control.
		 * @private
		 * @method attachMember
		 * @param {object} control  The edoc2MemberSelect control instance.
		 */
        inner.attachMember = function (control) {
            //The type of a member object,'department' or 'position',default 'position'.
            control.attachMember = function (type) {
                control.attachable = true;
                control.attachType = type;
            }

            //Initializes property values based on environment variables.
            control.attachable = env.memberSelect.attach;
            control.attachType = env.memberSelect.attachType;
        }

		/**
		 * Appends department information to the specified object.
		 * @private
		 * @method attachDepartment
		 * @param   {object} obj  The member data.
		 * @returns {boolean} True if the user belongs to multiple departments, otherwise, false.
		 */
        inner.attachDepartment = function (obj) {
            var multiple = false;
            var depts = [];

            xhr.sync.get("/user/departments/" + obj.id, null, function (res) {
                if (res.code == 200) {
                    depts = res.data;
                }
            })

            //Multiple positions.
            if (depts.length > 1) {
                if (env.memberSelect.attachMode == "custom") {
                    obj.multiple = true;
                    obj.members = depts;
                    multiple = true;
                }
                else {
                    var dept = depts.find((obj) => obj.isMain);
                    obj.deptId = dept.id;
                    obj.deptName = dept.name;
                    obj.text = obj.deptName + "/" + obj.text;
                }
            }

            //Only one position.
            if (depts.length == 1) {
                obj.deptId = depts[0].id;
                obj.deptName = depts[0].name;
                obj.text = obj.deptName + "/" + obj.text;
            }

            obj.attached = true;
            return multiple;
        }

		/**
		 * Appends position information to the specified object.
		 * @private
		 * @method attachPosition
		 * @param   {object} obj  The member data.
		 * @returns {boolean} True if the user belongs to multiple positions, otherwise, false.
		 */
        inner.attachPosition = function (obj) {
            var multiple = false;
            var positions = [];

            xhr.sync.get("/user/positions/" + obj.id, null, function (res) {
                if (res.code == 200) {
                    positions = res.data;
                }
            })

            //Multiple positions.
            if (positions.length > 1) {
                if (env.memberSelect.attachMode == "custom") {
                    obj.multiple = true;
                    obj.members = positions;
                    multiple = true;
                }
                else {
                    var position = positions.find((obj) => obj.isMain);
                    obj.positionId = position.id;
                    obj.positionName = position.name;
                    obj.text = obj.positionName + "/" + obj.text;
                }
            }

            //Only one position.
            if (positions.length == 1) {
                obj.positionId = positions[0].id;
                obj.positionName = positions[0].name;
                obj.text = obj.positionName + "/" + obj.text;
            }

            obj.attached = true;
            return multiple;
        }

		/**
		 * Returns a new object that does not contain the attributes.
		 * @private
		 * @method filterAttributes
		 * @param   {Array} data The original data.
		 * @returns {Array} A new object that does not contain the attributes.
		 */
        inner.filterAttributes = function (data) {
            var newData = [];
            system.each(data, function (i, member) {
                var obj = {};
                system.each(member, function (key, value) {
                    if (key == "attributes") return;
                    obj[key] = value;
                })
                newData.push(obj);
            })

            return newData;
        }

		/**
		 * Show the confirmation dialog.
		 * @private
		 * @method showConfirmDialog
		 * @param {object}   control    The memberSelect control.
		 * @param {Array}    data       The member data.
		 * @param {Function} callback   The confirmed callback function.
		 */
        inner.showConfirmDialog = function (control, data, callback) {
            var title = lang.Global_Department + "/"
                + lang.Global_Position
                + lang.Global_Confirm;
            var content = inner.renderHtml(data);

            utils.showDialog({
                type: "target",
                title: title,
                content: content,
                width: 350,
                height: 400,
                maximizable: false,
                closable: false,
                showSelf: true,
                buttons: [{
                    id: 'ok',
                    text: lang.Global_Confirm,
                    handler: function (dialog) {
                        var allSelected = inner.checkAllSelected(data, dialog.div);
                        if (!allSelected) return;

                        //Additional extended attribute.
                        inner.addExtendAttribute(control, data, dialog.div);

                        dialog.close();
                        callback(data);
                    }
                }, {
                    id: 'cancel',
                    text: lang.Global_Cancel,
                    handler: function (dialog) {
                        var isMultipleSelect = control.getProperty("mode").value == "true";

                        //Clears the value of the control when unconfirming.
                        control.setValue("");

                        //If the mode of the control is multiple select,
                        //only the newly added user is cleared.
                        if (isMultipleSelect) {
                            data = inner.clear(control, data);
                            control.setValue(data);
                        }

                        dialog.close();
                    }
                }]
            });
        }

		/**
		 * Generate HTML tag strings.
		 * @private
		 * @method renderHtml
		 * @param   {Array} data The member data.
		 * @returns {string} A string of html tags.
		 */
        inner.renderHtml = function (data) {
            var html = $("<div class='members'></div>");
            html.append(inner.getStyles());

            system.each(data, function (i, obj) {
                if (!obj.multiple) return;

                var member = $("<div class='member " + obj.id + "'></div>");
                member.append("<div class='title'>" + obj.text + "</div>");

                system.each(obj.members, function (i, mem) {
                    var item = $("<div class='item'></div>");
                    var radio = $("<input type='radio'/>")
                        .attr("name", obj.id)
                        .attr("id", obj.id + "_" + i)
                        .attr("data-id", mem.id)
                        .attr("data-name", mem.name)
                        .appendTo(item);

                    var label = $("<label></label>")
                        .attr("for", obj.id + "_" + i)
                        .text(mem.name)
                        .appendTo(item);

                    //Add a main department or position flag.
                    if (mem.isMain) {
                        label.html(mem.name + "<span style='color:red;'>（主）</span>");

                        //The main department or position is selected by default.
                        if (env.memberSelect.selectMain) {
                            radio.attr("checked", "checked");
                        }
                    }

                    member.append(item);
                })

                html.append(member);
            })

            return html[0].outerHTML;
        }

		/**
		 * Gets the dialog styles.
		 * @private
		 * @method getStyles
		 */
        inner.getStyles = function () {
            var style = $("<style></style>");
            style.append(".members{background:#eee;padding:1px 0;}");
            style.append(".member{background:#fff; margin:7px 5px; padding:10px 15px;border-radius:4px;}");
            style.append(".member .item,.member .title{height:30px;line-height:30px;}");
            style.append(".member .title{font-weight:bold;}");
            style.append(".member .item label{margin-left:10px;}");

            return style;
        }

		/**
		 * Check that all items are selected.
		 * @private
		 * @method checkAllSelected
		 * @param   {Array}     data    The member list.
		 * @param   {object}    el      Jquery html object.
		 * @returns {boolean} True ff all items are selected, otherwise, false.
		 */
        inner.checkAllSelected = function (data, el) {
            var flag = true;
            var tips = lang.Global_Tip;
            var message = lang.Global_Department + "/"
                + lang.Global_Position
                + lang.Global_NoHave
                + lang.Global_All
                + lang.Global_Confirm;

            for (var i in data) {
                var obj = data[i];
                if (!obj.multiple) continue;

                var selectItem = el.find(".member." + obj.id + " input:checked");
                if (selectItem.length == 0) {
                    flag = false;
                    $.messager.alert(tips, message);
                    break;
                }
            }

            return flag;
        }

		/**
		 * Additional extended attribute.
		 * @private
		 * @method addExtendAttribute
		 * @param {object}  control The memberSelect control.
		 * @param {Array}   data    The member list.
		 * @param {object}  el      The jquery element object.
		 */
        inner.addExtendAttribute = function (control, data, el) {
            if (!data) return;

            for (var i = 0; i < data.length; i++) {
                let obj = data[i];
                var item = el.find(".member." + obj.id + " input:checked");

                if (control.attachType == "department") {
                    if (obj.deptId) continue;
                    obj.deptId = item.data("id");
                    obj.deptName = item.data("name");
                    obj.text = obj.deptName + "/" + obj.text;
                }

                if (control.attachType == "position") {
                    if (obj.positionId) continue;
                    obj.positionId = item.data("id");
                    obj.positionName = item.data("name");
                    obj.text = obj.positionName + "/" + obj.text;
                }

                delete obj.attached;
                delete obj.multiple;
                delete obj.members;
            }
        }

		/**
		 * Clean up users without department or position confirmation.
		 * @param {object}  control The memberSelect control.
		 * @param {array}   data    The member list.
		 * @returns {array} The cleaned data.
		 */
        inner.clear = function (control, data) {
            var deletedData = [];

            system.each(data, function (i, obj) {
                if (obj.attached) deletedData.push(obj);
            })

            return data.filter(key => !deletedData.includes(key));
        }
    }

    var ext = new EDoc2SelectMemberExtension();
    ext.init();
    parser.onParseAfter = ext.init;
})