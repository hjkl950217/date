﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/11/25 16:11:02
*
***************************************************************************/

define(['gmp/eform/parser', 'gmp/system', 'gmp/eform/formData'], function (parser, system, formData) {
    var onParseAfter = function () {
        if (!edoc2Form.edoc2Selectbox) return;

        var controls = parser.controls._hash;
        system.each(controls, function (i, control) {
            if (!(control instanceof edoc2Form.edoc2Selectbox)) return;

            var controlObj = formData[control.controlId];
            if (!controlObj.show) return;
            if (controlObj.readonly) return;
            if (controlObj.value === "") return;

            var datasource = control.getData();
            var inexistent = !datasource.find(function (obj) { return obj.value == controlObj.value });
            if (inexistent) controlObj.value = "";
        })

        //Register again to resolve TAB asynchronous loading.
        system.wait(100).then(function () {
            parser.onParseAfter = onParseAfter;
        })
    }

    parser.onParseAfter = onParseAfter;
})