﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/16 16:24:10
*
***************************************************************************/

/**
 * The edoc2WorkFlowButton control extension module.
 * @module gmp/eform/exts/edoc2WorkFlowButtonExtension
 * @requires gmp/xhr
 * @requires gmp/eform/parser
 */
define(['gmp/xhr', 'gmp/eform/parser'], function (xhr, parser) {
	/**
	 * Extend the workflow button to open some internal methods.
	 * @private
	 * @method extendWorkFlowButton
	 */
	function extendWorkFlowButton() {
		if (!edoc2Form.edoc2WorkFlowButton) return;

		var url = location.origin + "/eform/scripts/controls/workflow/edoc2workflowbutton/edoc2.control.edoc2workflowbutton.js";

		xhr.sync.script(url).done(function (code) {
			code = code.replace(/function initiator\(/g, "this.initiator = function(")
				.replace(/initiator\(/g, "self.initiator(")

				.replace(/function submit\(/g, "this.submit = function(")
				.replace(/submit\(/g, "self.submit(")

				.replace(/function getService\(/g, "this.getService = function(")
				.replace(/getService\(/g, "self.getService(")

				.replace(/function cancel\(/g, "this.cancel = function(")
				.replace(/cancel\(/g, "self.cancel(")

				.replace(/function plusSign\(/g, "this.plusSign = function(")
				.replace(/plusSign\(/g, "self.plusSign(");

			eval(code);
		});
	}

	parser.onParseBefore = extendWorkFlowButton;
})