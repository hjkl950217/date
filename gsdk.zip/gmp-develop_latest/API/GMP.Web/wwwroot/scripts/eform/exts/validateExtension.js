﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/03/26 16:24:10
*
***************************************************************************/

define(['gmp/eform/parser'], function (parser) {
	parser.validate = function () {
		var flag = true;

		var controls = parser.controls._hash;
		for (var item in controls) {
			var control = controls[item];

			if (control.column.block.isShow == false) continue;
			if (control.column.isShow == false) continue;
			if (control.isShow == false) continue;
			if (control.getConfig('readonly') === "true") continue;

			//Remove space before and after.
			control.setValue(control.getValue().trim());
			flag = control.validate() && flag;
		}

		return flag;
	}
})