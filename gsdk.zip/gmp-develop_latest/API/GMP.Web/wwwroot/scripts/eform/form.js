﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/28 17:27:53
*
***************************************************************************/

define(['gmp/xhr', 'gmp/env', 'gmp/system', 'gmp/eform/parser', 'gmp/eform/lang'], function (xhr, env, system, parser, lang) {
	var Form = function () {
		var self = this;
		var inner = {};
		inner.serverUrl = location.origin + "/eform/default/SetData";

		/**
		 * Represents all the blocks in the current form.
		 * @property blocks
		 */
		self.blocks = parser.blocks._hash;
		/**
		 * Represents all the columns in the current form.
		 * @property columns
		 */
		self.columns = parser.columns._hash;
		/**
		 * Represents all the controls in the current form.
		 * @property controls
		 */
		self.controls = parser.controls._hash;

		/**
		 * Saves or updates the specified form data.
		 * @method save
		 * @param	{string} formId		The form id.
		 * @param	{object} formData	The form data.
		 * @param	{string} recordId	The id of the record.
		 * @returns	{object} Return a Promise instance.
		 */
		self.save = function (formId, formData, recordId) {
			var data = [];

			//Convert to array.
			formData.oldValues = formData.oldValues || "{}";
			system.each(formData, function (key, value) {
				data.push(key + "=" + $.URLencode(value));
			})

			//请求参数
			var params = {
				formId: edoc2Form.Cryptography.encryptData(formId),
				formVer: "",
				dataset: edoc2Form.Cryptography.encryptData(data.join("|")),
				recordId: edoc2Form.Cryptography.encryptData(recordId || $.genId())
			}

			//提交数据
			return xhr.post(inner.serverUrl, params);
		}

		/**
		 * Sets all controls on the current form to readonly.
		 * @method setFormReadonly
		 */
		self.setFormReadonly = function () {
			for (var key in self.blocks) {
				eform.setReadonly(self.blocks[key].id, true, 'block');
			}
		}

		/**
		 * Gets an instance of the specified control based on the class name.
		 * @method getControl
		 * @param   {string|object} className   Control id or Control class.
		 * @returns {object|Array} Return Control instance or collection of instances.
		 */
		self.getControl = function (className) {
			var result = [];
			if (!className) return result;

			//If className is the control id.
			if (typeof className == "string") {
				return self.controls[className];
			}

			//If className is the control class.
			for (var key in self.controls) {
				if (self.controls[key] instanceof className) {
					result.push(self.controls[key]);
				}
			}

			return result;
		}

		/**
		 * Gets the options of the specified control.
		 * @method getControlOptions
		 * @param {string} controlId    The control id.
		 */
		self.getControlOptions = function (controlId) {
			var control = self.getControl(controlId);
			var options = control.property.array;
			var obj = {};

			//Array to Object.
			for (var i = 0; i < options.length; i++) {
				obj[options[i].id] = options[i].value;
			}

			obj["constType"] = control.Const_Type;
			obj["isShow"] = control.isShow == undefined ? true : control.isShow;
			obj.name = lang[obj.name];

			return obj;
		}

		/**
		 * Gets the value of the specified control id.
		 * @method getValue
		 * @param   {string} controlId  The control id.
		 * @returns {any}   The control value.
		 */
		self.getValue = function (controlId) {
			var control = self.controls[controlId];
			if (!control) return "";

			return control.getValue();
		}
	}

	var form = new Form();
	return form;
})