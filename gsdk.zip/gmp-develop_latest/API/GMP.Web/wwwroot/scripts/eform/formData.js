﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/4 12:34:49
*
***************************************************************************/

/**
 *
 * @module gmp/eform/formData
 * @requires gmp/eform/parser
 * @requires gmp/eform/control
 */
define(['gmp/eform/parser', 'gmp/eform/control'], function (parser, Control) {
	var FormData = function () {
		var self = this;
		var inner = {};

		/**
		 * Gets the value of the specified control id.
		 * @method data
		 * @param   {string} controlId  The control id.
		 * @returns {any}   The control value.
		 */
		self.data = function (controlId) {
			return self[controlId].value;
		}

		/**
		 * Initialize form data.
		 * @private
		 * @method init
		 */
		inner.init = function () {
			//Blocks
			var blocks = parser.blocks._hash;
			for (var key in blocks) {
				if (self[key]) continue;
				self[key] = new Control(blocks[key], "block");
			}

			//Columns
			var columns = parser.columns._hash;
			for (var key in columns) {
				if (self[key]) continue;
				self[key] = new Control(columns[key], "column");
			}

			//Controls
			var controls = parser.controls._hash;
			for (var key in controls) {
				if (self[key]) continue;
				self[key] = new Control(controls[key], "control");
			}

			//Register again to resolve TAB asynchronous loading.
			setTimeout(function () {
				parser.onParseAfter = inner.init;
			}, 100);
		}

		parser.onParseAfter = inner.init;
	}

	var formData = new FormData();
	return formData;
})