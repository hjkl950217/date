﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/13 9:36:38
*
***************************************************************************/

/**
 * Language resources module.
 * @module gmp/eform/lang
 * @requires gmp/env
 */
define(['gmp/env'], function (env) {
	var Language = function () {
		var self = this;
		var base = self.constructor.prototype;
		var inner = {};
		inner.groupId = env.eform.rootGroupId;
		inner.sources = window.instancesFormSR[inner.groupId];

		for (var group in window.instancesFormSR) {
			var sources = window.instancesFormSR[group];
			for (var key in sources) {
				var reg = new RegExp(env.appid + "_", "i");
				if (reg.test(key)) {
					self[key] = sources[key];
				}
				else {
					base[key] = sources[key];
				}
			}
		}
	};

	var lang = new Language();
	return lang;
})