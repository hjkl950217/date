﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/21 13:56:34
*
***************************************************************************/

/**
 * The eform layout module.
 * @module gmp/eform/layout
 * @requires gmp/env
 * @requires gmp/system
 * @requires gmp/events
 * @requires gmp/eform/parser
 * @requires gmp/eform/lang
 */
define(['gmp/env', 'gmp/system', 'gmp/events', 'gmp/eform/parser', 'gmp/eform/lang'], function (env, system, events, parser, lang) {
    //Environment variable.
    env.layout = env.layout || {};
    env.layout.forms = env.layout.forms || {};

    var Layout = function () {
        var self = this;
        var inner = {};

        self.control = null;
        self.window = null;
        self.eform = null;
        self.forms = {};

        /**
         * Shows the menu with the specified formId.
         * @method show
         * @param {string} formId   The form id.
         */
        self.show = function (formId) {
            if (!self.forms[formId]) return;
            $(self.forms[formId].target).show();

            events.emit("layout.show", self.forms[formId]);
        }

        /**
         * Hides the menu with the specified formId.
         * @method hide
         * @param {string} formId   The form id.
         */
        self.hide = function (formId) {
            if (!self.forms[formId]) return;
            $(self.forms[formId].target).hide();

            events.emit("layout.hide", self.forms[formId]);
        }

        /**
         * Opens the specified form in the tabs.
         * @method open
         * @param {string}  formId      The form id.
         * @param {string}  name        The form name.
         * @param {string}  url         The custom url.
         * @param {boolean} closable    Whether to display the close button.
         * @param {string}  icon        Icon style name.
         * @param {boolean} redirect    Whether to allow redirection.
         */
        self.open = function (formId, name, url, closable, icon, redirect) {
            //If name is a Boolean value, then name indicates
            //whether redirection is allowed.
            redirect = system.isUndefined(redirect) ? true : redirect;
            if (system.isBoolean(name)) {
                redirect = name;
                name = undefined;
            }

            //If no cache exists, cache the form info.
            inner.cacheForm({ formId, name, url, closable, icon });
            var form = self.forms[formId];

            //If it is a system form, call the system method to open the form
            //and expand and select the left menu.
            if (form.type == "system") {
                var props = system.extend({}, form.props, { redirect: redirect });
                form.target.dataset.form = window.escape(JSON.stringify(props));

                self.control.builder.selectNavType(Number(form.firstIndex));
                self.control.builder.loadForm(form.formId, form.rowId, Number(form.firstIndex));
            }

            //If it is a custom form, open it directly in tabs.
            if (form.type == "custom") {
                //If it is not within the layout framework, it is opened by window.open().
                if (!self.control || (self.control && !self.control.tabs)) {
                    var url = form.url || $.format('/eform/index?formId={0}&t=' + env.timestamp, form.formId);
                    return window.open(url);
                }

                //Select and refresh if the form has been opened in tabs.
                var tab = self.control.tabs().tabs("getTab", form.name);
                if (tab) {
                    self.select(formId);
                    self.refresh(formId);
                    return;
                }

                //Open the custom form.
                inner.addTab(formId);
            }

            events.emit("layout.open", self.forms[formId]);
        }

        /**
         * Close the specified form (according to formid or Window).
         * @method close
         * @param {string}  formId  The form id.
         * @param {object}  win     To close the window object of the page.
         * @param {boolean} ack     To confirm before closing.
         */
        self.close = function (formId, win, ack) {
            win = win || window;

            var form = self.forms[formId];
            if (self.control) {
                var target = self.control.tabs().tabs('getTab', form.name);
                var iframe = target.find("iframe")[0];
                win = iframe.contentWindow || iframe.contentDocument;
            }

            //if it is not within the layout framework.
            if (!self.control) {
                inner.closeWin(win, ack);
            } else {
                inner.closeTab(win, ack);
            }

            events.emit("layout.close", self.forms[formId]);
        }

        /**
         * Select the specified form.
         * @method select
         * @param {string} formId   The form id.
         */
        self.select = function (formId) {
            if (!self.control) return;
            if (!self.forms[formId]) return;

            //The specified form is not open.
            var name = self.forms[formId].name;
            var target = self.control.tabs().tabs("getTab", name);
            if (!target) return;

            self.control.tabs().tabs("select", name);

            events.emit("layout.select", self.forms[formId]);
        }

        /**
         * Refresh the specified form.
         * @method refresh
         * @param {string} formId   The form id.
         */
        self.refresh = function (formId) {
            if (!self.control) return;
            if (!self.forms[formId]) return;

            //The specified form is not open.
            var name = self.forms[formId].name;
            var target = self.control.tabs().tabs('getTab', name);
            if (!target) return;

            var iframe = target.find("iframe")[0];
            var win = iframe.contentWindow || iframe.contentDocument;
            win.location.href = self.forms[formId].url || iframe.src;

            events.emit("layout.refresh", self.forms[formId]);
        }

        /**
         * Add content after navigation menu.
         * @method append
         * @param {string} formId   The form id.
         * @param {string} content  The content to add.
         */
        self.append = function (formId, content) {
            var text = $("[data-formid=" + formId + "]").find("span").data("text") || $("[data-formid=" + formId + "]").find("span").text();
            if (text) {
                $("[data-formid=" + formId + "]").find("span").html(text + content);
                $("[data-formid=" + formId + "]").find("span").data("text", text);
            }
            else {
                text = $("[data-rowid=" + formId + "]").data("text") || $("[data-rowid=" + formId + "]").text();
                $("[data-rowid=" + formId + "]").html(text + content);
                $("[data-rowid=" + formId + "]").data("text", text);
            }
        }

        /**
         * Open the file preview window.
         * @method preview
         * @param {number}     fileId      The file id.
         * @param {number}     fileVerId   The file version Id.
         * @param {string}     fileName    The file name.
         * @param {number}     incident    Process instance number.
         * @param {string}     gpc         Permission control identification.
         */
        self.preview = function (fileId, fileVerId, fileName, incident, gpc) {
            var url = "/preview.html?t=" + env.timestamp;
            if (fileId) url += "&fileid=" + fileId;
            if (fileVerId) url += "&fileverid=" + fileVerId;
            if (incident) url += "&incident=" + incident;
            if (gpc) url += "&gpc=" + gpc;

            self.open("docview", fileName, url);
        }

        /**
         * Initialize the layout.
         * @private
         * @method init
         */
        inner.init = function () {
            inner.inherit();

            //Initialize the layout.
            if (!self.control) {
                self.control = inner.getLayout();
                self.forms = inner.getForms();
                self.window = window;
                self.eform = eform;

                system.extend(self.forms, env.layout.forms);

                //#7029 标签页打开过多，右键关闭其他标签后，当前标签未显示在列表中
                var close = $.fn.tabs.methods.close;
                $.fn.tabs.methods.close = function (el, which) {
                    close.call(this, el, which);
                    el.find(".tabs-wrap").scrollLeft(0);
                }

                //Hide all secondary menu icons.
                $(".layout .second-nav .panel-icon").hide();
            }

            //If nested within another product, the header is hidden.
            if (!top.eform) inner.hideHeader();

            //Register tab closing and refresh events.
            //if (self.control && self.control.tabs()) {
            //    self.control.tabs().tabs({ onBeforeClose: inner.ontabClose });
            //    self.control.tabs().tabs({ onUpdate: inner.ontabClose });
            //}
        }

        /**
         * Inherit the layout property from the parent window.
         * @private
         * @method inhreit
         */
        inner.inherit = function () {
            if (!parent.layout) return;

            self.control = parent.layout.control;
            self.window = parent.layout.window;
            self.eform = parent.layout.eform;
            self.forms = parent.layout.forms;
        }

        /**
         * Gets the layout control.
         * @private
         * @method getLayout
         * @returns {object} Layout control object.
         */
        inner.getLayout = function () {
            if (!edoc2Form.edoc2Layout) return;

            //Disables opening the default form after refreshing.
            system.async().then(function () {
                window.onbeforeunload = system.noop;
            })

            var controls = parser.controls.array;
            return controls.find(function (obj) {
                return obj instanceof edoc2Form.edoc2Layout;
            })
        }

        /**
         * Hidden in the header of the layout page.
         * @private
         * @method hideHeader
         */
        inner.hideHeader = function () {
            $(".layout-panel-north").hide();
            $(".layout-panel-west,.layout-panel-center").css("top", 0);
        }

        /**
         * Gets all navigation menus.
         * @private
         * @method getForms
         * @returns {object} all navigation menus.
         */
        inner.getForms = function () {
            var forms = {};

            $(".nav-menu").each(function (index, element) {
                var formId = element.dataset.formid;
                var properties = element.dataset.form;

                forms[formId] = $.parseJSON(window.unescape(properties));
                forms[formId].props = $.parseJSON(window.unescape(properties));
                forms[formId].type = 'system';
                forms[formId].name = lang[forms[formId].navTypeName];
                forms[formId].target = element;
                forms[formId].closable = true;
            });

            return forms;
        }

        /**
         * Caching form data.
         * @private
         * @method cacheForm
         * @param {object} property The form properties.
         */
        inner.cacheForm = function (property) {
            self.forms[property.formId] = $.extend(self.forms[property.formId] || {
                formId: 0,
                name: 'custom',
                url: '',
                icon: "default.png",
                closable: true,
                type: 'custom'
            }, property)
        }

        /**
         * Open a new tab in layout.
         * @private
         * @method addTab
         * @param {string} formId   The form id.
         */
        inner.addTab = function (formId) {
            var form = self.forms[formId];
            if (!form) return;

            var iframe = '<iframe style="width:100%;height:100%;" name="ipreview" frameborder="0" src="{0}"></iframe>';
            var url = form.url || $.format('/eform/index?formId={0}&t=' + env.timestamp, form.formId);

            self.control.tabs().tabs("add", {
                id: form.formId,
                title: form.name,
                closable: form.closable,
                content: $.format(iframe, url),
                iconCls: form.icon,
                tools: [{
                    iconCls: "icon-mini-refresh",
                    handler: function () {
                        //Refresh the page.
                        var currTab = self.control.tabs().tabs("getSelected");
                        self.control.tabs().tabs('update', {
                            tab: currTab,
                            options: {
                                href: $(currTab.panel("options")).attr("href")
                            }
                        });
                    }
                }]
            })
        }

        /**
         * Close the window.
         * @private
         * @method closeWin
         * @param {window} win      To close the window object of the page.
         * @param {boolean} ack     To confirm before closing.
         */
        inner.closeWin = function (win, ack) {
            var close = function () {
                try {
                    win.opener = win;
                    var newWin = win.open("", "_self");
                    newWin.close();
                    top.close();//iframe
                } catch (e) { }
            }

            if (ack) {
                $.messager.alert(lang.Global_Tip, lang.Flow_ProcessSucess, null, function () {
                    close()
                })
            }
            else {
                close();
            }
        }

        /**
         * Close the tab.
         * @private
         * @method closeTab
         * @param {window}  win     To close the window object of the page.
         * @param {boolean} ack     To confirm before closing.
         */
        inner.closeTab = function (win, ack) {
            var formId;
            var regex = /formid=(\d+)/i;

            //Resolves the formId in the address bar of the window.
            if (win && regex.test(win.location.href)) {
                formId = regex.exec(win.location.href)[1];
            }

            //Confirm before closing.
            if (ack) {
                //Overwrite the window alert method to avoid two alert boxes popping up.
                var alert = win.$.messager.alert;
                win.$.messager.alert = function () { };

                alert(lang.Global_Tip, lang.Flow_ProcessSucess, null, function () {
                    self.control.tabs().tabs('close', self.forms[formId].name);
                })
            }
            else {
                self.control.tabs().tabs('close', self.forms[formId].name);
            }
        }

        /**
         * When the tab is closed, the tab form's close event is triggered.
         * @private
         * @event ontabClose
         * @param {string}  title    Tab title.
         * @param {int}     index    Tab index.
         */
        inner.ontabClose = function (title, index) {
            var closingTab = self.control.tabs().tabs('getTab', title);
            var selectedTab = self.control.tabs().tabs('getSelected');

            //Not the selected tab.
            if (closingTab != selectedTab) return;

            var win = closingTab.find("iframe")[0].contentWindow;
            win.onbeforeunload && win.onbeforeunload();
        }

        parser.onParseAfter = inner.init;
    }

    window.layout = new Layout();
    return layout;
})