﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/10 11:32:41
*
***************************************************************************/

requirejs.config({
    baseUrl: env.path.gmp + '/scripts'
});

require(['require.config'], function () {
    //Loading global dependencies.
    require(['css!../styles/eform.css']);
    require(['css!gmp/lib/font-awesome/css/font-awesome.css']);
    require(['gmp/eform/exts/edoc2WorkFlowButtonExtension']);
    require(['gmp/eform/exts/edoc2ListGridExtension']);
    require(['gmp/eform/exts/edoc2MemberSelectExtension']);
    require(['gmp/eform/exts/edoc2DropDownListEx']);
    //require(['gmp/eform/exts/edoc2SelectboxExtension']);

    require(['gmp/app', 'gmp/env', 'gmp/store', 'gmp/xhr', 'gmp/eform/parser', 'gmp/extends/jquery.resize'], function (app, env, store, xhr, parser, $) {
        env.user = env.user || store.get("user");

        require(['gmp/components/locker/locker']);
        require(['gmp/components/search/index']);

        var formId = env.eform.formId;
        var extjs = "app/eform/eform." + formId;

        //Enable debugging.
        function enableDebug() {
            if (env.isdebug) return;

            var type = arguments.length == 0 ? "app" : "gmp";
            var url = "&isdebug=1&debug=" + type;
            window.location.href = window.location.href + url;
        }

        //Converts all attribute names of the specified object to lowercase.
        function obj2low(obj) {
            var newObj = {};

            for (var key in obj) {
                var newKey = key.toLowerCase();
                newObj[newKey] = obj[key];
            }

            return newObj;
        }

        //Register pre-parse events.
        parser.onParseBefore = function () {
            eform.enableDebug = enableDebug;
        }

        /**
         * Monitor query block change events after form parsing.
         * Fix the problem that the control has no length
         * when the default block of eform is not displayed.
         */
        parser.onParseAfter = function () {
            $("#queryBlock").on("resize", function () {
                $(window).resize();
            })
        }

        /**
         * load custom form extension code.
         * @override
         * @event oninit
         */
        parser.oninit = function () {
            //Update environment variables.
            var options = window.instancesFormConfig[formId];
            env.eform.recordId = options.recordId;
            env.eform.isNew = options.isNewRecord;
            env.eform.lang = options.currentLanguage;
            env.eform.name = options.formData.FormName;
            env.eform.table = options.formData.TableName;
            env.eform.groupId = options.formData.GroupId;
            env.eform.rootGroupId = options.formData.RootGroupId;
            env.eform.dataSource = options.dataSource;

            //User information extension.
            if (!env.user) {
                env.user = obj2low(options.userInfo);
                var account = options.userInfo.Account;
                xhr.sync.get("/user?account=" + account).done(function (res) {
                    if (res.code == 200) {
                        env.user = res.data;
                    }
                })

                store.set("user", env.user);
            }
            
            //Load the form extension code.
            require([extjs], function () {
                parser._init();
            }, function (msg) {
                console.info(msg);
                parser._init();
            })
        }

        //Initialize the parser.
        parser.init();
    })
})