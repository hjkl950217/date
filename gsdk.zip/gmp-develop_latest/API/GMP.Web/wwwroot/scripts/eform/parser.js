﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/12 13:30:14
*
***************************************************************************/

/**
 * Form parser proxy module.
 * @module gmp/eform/parser
 * @requires gmp/env
 * @requires gmp/xhr
 */
define(['gmp/env', 'gmp/xhr', 'gmp/system'], function (env, xhr, system) {
    var FormParserProxy = function () {
        var self = this;
        var inner = {};
        var base = {};

        //Inherits the properties and methods of FormParser.
        window.FormParser.call(self, window.instancesFormParams);

        //Caches the original method definition so that it can be overwritten later.
        base.createControl = self.createControl;

        /**
         * Initializes the parser and loads the extension code.
         * @override
         * @method init
         * @returns {object} Current parser instance.
         */
        self.init = function () {
            self.runMode = self.instanceFormParm.runMode || 1;
            self.filterLogin();
            if (!self.checkBrowserSupport()) return self;

            var url = location.origin + "/eform/default/getextendcode";
            url += "?runmode=" + self.runMode;
            url += "&formid=" + env.eform.formId;
            url += "&formver=" + env.eform.formVer;
            if (env.eform.recordId) url += "&recordid=" + env.eform.recordId;
            if (env.isdebug) url += "&isdebug=1";
            xhr.script(url, null, function () { self.oninit(); });

            return self;
        }

        /**
         * Override the `setValue` method of the control after it is created, 
         * and trigger the `validate` method of the control after setting the value.
         * @override
         * @param {object} ctrObj The control property Configuration.
         * @param {boolean} isNewControl 
         */
        self.createControl = function (ctrObj, isNewControl) {
            var control = base.createControl.call(self, ctrObj, isNewControl);
            var setValue = control.setValue;
            control.setValue = function (value) {
                setValue.apply(control, arguments);
                value && control.validate();
            }

            var readonly = control.readonly;
            if (readonly) {
                control.readonly = function () {
                    readonly.apply(control, arguments);
                    control.validateUi && control.validateUi();
                }
            }

            return control;
        }

        /**
         * Gets an instance of the specified control based on the class name.
         * @override
         * @method getControl
         * @param   {string|object} className   Control id or Control class.
         * @returns {object|Array} Return Control instance or collection of instances.
         */
        self.getControl = function (className) {
            var result = [];
            if (!className) return result;

            //If className is the controlId.
            if (typeof className == "string") {
                return self.controls.get(className);
            }

            //If className is the control class.
            for (var key in self.controls._hash) {
                var control = self.controls._hash[key];
                if (control instanceof className) {
                    result.push(control);
                }
            }

            return result;
        }

        /**
         * Override the form validation method.
         * @override
         * @method validate
         * @returns {boolean} True if the validation passes, otherwise, false.
         */
        self.validate = function () {
            var flag = true;

            //Clear the edoc2Selectbox control of invalid values.
            $("body>div.combo-p>div.combo-panel:visible").panel('close');

            for (var item in self.controls._hash) {
                var control = self.controls._hash[item];

                if (control.column.block.isShow == false) continue;
                if (control.column.isShow == false) continue;
                if (control.isShow == false) continue;
                if (control.getConfig('readonly') === "true") continue;

                flag = control.validate() && flag;
            }

            return flag;
        }

        /**
         * The event that the parser initializes.
         * @event oninit
         */
        self.oninit = function () { self._init(); }

        //Binding event properties.
        Object.defineProperty(self, "onParseBefore", {
            set: function (callback) {
                if (self.isLoaded) return;
                window.customEformJsCallbackList.push(callback);
            }
        })
        Object.defineProperty(self, "onParseAfter", {
            set: function (callback) {
                //If the parsing is complete,
                //the current event is executed immediately.
                if (self.isLoaded) {
                    return callback && callback();
                }

                //Add to the list of  after parsing event.
                self.onParseEventList.push({
                    control: callback,
                    event: callback
                });
            }
        })
        Object.defineProperty(self, "onSaveBefore", {
            set: function (callback) {
                self.saveBefore = callback;
            }
        })
        Object.defineProperty(self, "onSaveAfter", {
            set: function (callback) {
                self.saveAfter = callback;
            }
        })

        //Mount to a global object.
        edoc2Form.formParser = self;
        window.instancesFormParser[env.eform.formId] = self;

        //Set a mark for the formContainer indicating that the current form is a query list.
        self.onParseAfter = function () {
            if (!self.isExistListGrid) return;
            document.getElementById("formContainer").classList.add("listgrid");
        }
    }

    FormParserProxy.prototype = new FormParseBase();
    FormParserProxy.prototype.constructor = FormParserProxy;

    var proxy = new FormParserProxy();
    return proxy;
})