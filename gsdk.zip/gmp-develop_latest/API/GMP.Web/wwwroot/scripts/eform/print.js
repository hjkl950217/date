﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: yuan.deng 2020/12/4 15:45:03
*
***************************************************************************/

define([
	"gmp/env",
	"gmp/eform/lang",
	"gmp/eform/utils",
	"gmp/xhr",
	'gmp/eform/exts/auditData'
], function (env, lang, utils, xhr, auditData) {
	//打印服务地址
	var url = "/pcs";
	var printTask = {};

	var print = function (settings) {
		//默认参数
		printTask = {};
		var metaData = auditData.getMetaData();
		var def = {
			PrinterId: "",              //打印机ID,指定打印机后预览界面无法更改
			FileName: "未知名称",       //文件名称
			PrintCopies: 0,             //打印份数,指定后预览界面无法修改
			PrintableCopies: function () { return 100; },       //可打印份数,可传入function
			PrintDirection: "0",        //打印方向
			Material: "",               //纸张大小
			Scope: "0",                 //打印范围,
			PageNumber: "",             //打印页码范围,指定后无法修改
			FileVerId: 0,               //文件版本ID
			Config: [],                 //多材质,多复印
			IsPreview: true,            //是否预览,不预览则直接打印
			Watermark: [],
			IsColor: false,
			IsDuplex: false,
			onAfterPrint: function (taskNumber, barCode) {
				console.info("打印成功，任务ID：" + taskNumber);
				console.info("打印成功，条码号：" + JSON.stringify(barCode));
			},
			error: function (msg) {
				$.messager.alert("提示", msg);
			},
			getPrintableCopies: function () {
				return printTask.PrintableCopies || 100;
			},
			auditInfo: function () {
				metaData.push({ Key: "FileVerId", Value: printTask.FileVerId, Category: "custom" });
				metaData.push({ Key: "IsColor", Value: printTask.IsColor, Category: "custom" });
				metaData.push({ Key: "IsDuplex", Value: printTask.IsDuplex, Category: "custom" });

				//验证信息
				return {
					action: "PrintFile",
					source: "文件打印",
					remarks: settings.FileName || "",   //摘要信息
					signers: [eform.userInfo.Account],	//签名账户，不传默认为当前用户
					changedData: [],					//更变确认数据，不传会使用默认方法获取更变数据
					metaData: metaData						//元数据
				};
			}
		};

		printTask = Object.assign({}, def, settings);

		//弹窗配置
		var config = {
			title: "文件打印",
			type: "iframe",
			content: "/gmp" + url + "/Preview/Index?Id=",
			width: "100%",
			height: "100%",
			maximizable: true,
			buttons: []
		}
		var taskId = new Date().getTime();
		printTask.TaskId = taskId;
		if (printTask.PrintableCopies instanceof Function) {
			printTask.getPrintableCopies = printTask.PrintableCopies;
			printTask.PrintableCopies = printTask.getPrintableCopies();
		}
		//top.require&&top.require(["gmp/audit/audit"])
		var gmpAudit;
		require(['gmp/audit/audit'], function (audit) {
			gmpAudit = audit;
		})

		//发起打印请求
		xhr.post(url + "/api/Print/StartPrintTask",
			JSON.stringify(printTask),
			function (res) {
				if ($.type(res) === "string") {
					res = JSON.parse(res);
				}
				if (!res.Success) {
					printTask.error(res.Message);
					return;
				}
				if (!printTask.IsPreview) {
					//不需要预览直接返回条码信息
					printTask.onAfterPrint(res.Result.taskNumber, res.Result.barCode);
					return;
				}

				//需要预览的情况
				var id = res.Result;
				config.content = config.content + id + "&dept=" + eform.userInfo.MainDepartmentId;
				var dialog = utils.showDialog(config, function () { delete top[taskId]; });
				console.info(dialog);
				top[taskId] = {
					//获取可打印份数
					getPrintableCopies: function () {
						return printTask.getPrintableCopies();
					},
					close: function () {
						//关闭弹窗
						dialog.close();
						delete top[taskId];
					},
					succeed: function (r) {
						//打印成功后回调
						if ($.type(r) === "string") {
							r = JSON.parse(r);
						}
						dialog.close();
						printTask.onAfterPrint(r.Result.taskNumber, r.Result.barCode);
						delete top[taskId];
					},
					audit: function (callback) {
						//调用审计信息
						var auditInfo = printTask.auditInfo && printTask.auditInfo();
						if (!auditInfo || !top.require) {
							callback && callback(true);
							return;
						}
						gmpAudit.action(auditInfo.action, auditInfo, false).fail(function () {
							console.info('审计取消');
							callback && callback(false);
						}).done(function (a) {
							callback && callback(true, a.save);
						});
					},
					PrintBefore:printTask.onBeforePrint
				};
			}, null, false);
	}

	/**
	* 绑定打印机和纸张
	* @param   {string}  printer     绑定打印机选择组件的ID
	* @param   {string}  material    绑定纸张选择组件的ID
	*/
	var bind = function (printer, material) {
		xhr.get("/pcs/api/Print/GetPrinters",
			{ dept: eform.userInfo.MainDepartmentId },
			function (res) {
				if ($.type(res) === "string") {
					res = JSON.parse(res);
				}
				if (!res.Success || res.Result.length == 0) {
					$.messager.alert("提示", "获取打印机失败或当前无可用打印机！");
					return;
				}
				console.log(res);
				var data = [];

				for (var i = 0; i < res.Result.length; i++) {
					data.push({
						value: res.Result[i]["Id"], text: res.Result[i]["PrinterAlias"] || res.Result[i]["PrinterName"],
						material: res.Result[i]["Material"].split(',')
					});
				}
				eform(printer).method("loadData", data);
				if (material) {
					//有纸张的情况下,选择打印机后重新加载可用纸张
					var printerChange = function (newValue, oldValue) {
						for (var j = 0; j < data.length; j++) {
							if (data[j]["value"] == newValue) {
								var materialList = [{ value: '0', text: '自动' }];
								for (var k = 0; k < data[j].material.length; k++) {
									materialList.push({ value: data[j].material[k], text: data[j].material[k] });
								}
								eform(material).method("loadData", materialList);
								if (oldValue !== -1) {
									eform(material).method("setValue", "0");
								}
							}
						}
					};
					eform(printer).method("onChange", printerChange);
					if (eform(printer).method("getValue")) {
						printerChange(eform(printer).method("getValue"), -1);
					}
				}
			});
	}

	return {
		print: print,
		bindPrinter: bind
	};
});