﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: C0620 2020/10/27 17:32:34
*
***************************************************************************/

define([], function () {
	env.proxy = env.proxy || {};
	env.proxy.enable = env.proxy.enable || true;

	var Proxy = function () {
		var self = this;
		var inner = {};
		var origin = location.origin;
		var app = env.path.app;

		if (edoc2Form.isDebug) {
			origin = env.path.origin;
		}

		self.url = app;

		self.enable = env.FormProxyEnable || true;
		var formValidateUrl = self.url + "/GMPFormProxyValidate";
		var formSaveUrl = self.url + "/GMPFormProxySave";
		inner.isSaving = false;
		$(function () {
			if (!env.proxy.enable) {
				return;
			}
			setTimeout(function () {
				//移除原有事件
				if (window.workFlowBtnObj) {
					window.workFlowBtnObj.control.find("a[action!='plusSign']").unbind('click');
					//添加自定义事件
					window.workFlowBtnObj.control.find("a[action!='plusSign']").click(actionClick);
				}
				eform.formEngine.save = save;
				window.edoc2Form.formParser.save = save;
			}, 1000);
		});

		function ajax(url, data, success, isAsync, errorCallback) {
			isAsync = isAsync === undefined ? true : isAsync;
			if (inner.isSaving) {
				return;
			}
			$.mask.show({
				parent: eform.formEngine.jqRootContainer,
				loadingText: eform.formEngine.Edoc2FormSR.Sys_Submitting
			});
			inner.isSaving = true;
			$.ajax({
				type: "Post",
				url: url,
				dataType: "json",
				async: isAsync,
				data: data,
				success: function (result) {
					if (result.result || result.isSuccess) {
						success && success(result);
					} else {
						errorCallback && errorCallback(result);
					}
				},
				error: function (xhr) {
					//ajax调用失败回调
					errorCallback && errorCallback({
						msg: xhr.responseText || '提交数据失败！'
					});
				},
				complete: function () {
					inner.isSaving = false;
					$.mask.hide();
				}
			});
		}
		//调用电子签名
		function sign(data, successCallback, errorCallback, isAsync) {
			var url = formValidateUrl + "?formId=" + eform.formId + "&recordId=" + eform.recordId;
			ajax(url, data, function () {
				$.messager.confirm("提示", "假装是一个电子签名", function (bool) {
					if (bool) {
						url = formSaveUrl + "?formId=" + eform.formId + "&recordId=" + eform.recordId;
						ajax(url, data, successCallback, isAsync, errorCallback);
					} else {
						errorCallback();
					}
				});
			}, isAsync, errorCallback);
		}

		/* 保存
	   * @ callback 保存成功的回调
	   * @ error 保存失败的回调
	   * @ recordId 记录id
	   * @ type: 提交类型, type=wf:流程表单,type=form:普通表单
	   * @ isSilent 静默保存不提示
	   * @ isAsync 异步同步
	   */
		function save(successCallback, errorCallback, recordId, useType, isSilent, isAsync) {
			var pParser = this;
			var cryptography = window.edoc2Form.Cryptography;
			var formId = pParser.formData.formId;
			var formVer = pParser.formData.formVer;
			if (pParser.saveBefore(formId, pParser.formData) === false) {
				errorCallback && errorCallback({ code: "0003", msg: "saveBefore return false" });
				return;
			}
			var dataset = pParser.getData("url");
			var postData = {
				formId: cryptography.encryptData(formId),
				formVer: cryptography.encryptData(formVer),
				dataset: cryptography.encryptData(dataset),
				recordId: cryptography.encryptData(recordId || pParser.instanceFormConfig.recordId),
				isNewRecord: eform.isNewRecord,
				DataSource: window.edoc2Form.Cryptography.encryptData(JSON.stringify(eform.getDataSource())),
				token: $.cookie("token")
			};

			function ajaxError(result) {
				if (result) {
					!isSilent &&
						$.messager.alert(Edoc2FormSR.Global_Tip, result.msg, 'warn', $.noop, true, true);
					result.code = "0001";
				}
				errorCallback && errorCallback(result);
				pParser.saveAfter(false, result);
			}
			sign(postData, function () {
				var afterEventsLength = pParser.onSaveAfterEventList.length;
				if (afterEventsLength > 0) {
					for (var i = 0; i < afterEventsLength; i++) {
						var oEvent = pParser.onSaveAfterEventList[i];
						oEvent.event.call(oEvent.control, result.id);
					}
				}
				// 执行全局保存后回调事件
				pParser.saveAfter(true, result.id);
				// 执行自定义回调事件
				if (successCallback) {
					successCallback(result.id, pParser.controls);
				}
				else {
					!isSilent && $.messager.alert(Edoc2FormSR.Global_Tip, window.Edoc2FormSR.Global_SaveOK, 'info');
				}
			}, ajaxError, isAsync);
		}

		//流程按钮点击事件
		function actionClick(item) {
			var action = $(this).attr("action");
			var isCustom = $(this).attr("isCustom");
			var self = window.workFlowBtnObj;
			if (self.formEngine.CurrentActivityConfig.cdirectBack && item.id == undefined && action == "returnStarter") {
				return;
			}

			if (!action) { action = "custom" }
			// 流程按钮全局提交前事件
			if (self.beforeSubmit(action) === false) {
				return;
			}
			var uiObj = self.getButtonByAction(action);
			//提交前事件
			if (!uiObj.beforeClick()) return false;
			var processId = $.getQueryString("processId", "", self.formEngine.queryParam),
				incidentId = $.getQueryString("incidentId", "", self.formEngine.queryParam),
				taskId = $.getQueryString("taskId", "", self.formEngine.queryParam),
				summary = "";
			if (incidentId == "")
				incidentId = $.getQueryString("id", "", self.formEngine.queryParam);
			// 审批意见
			if (self.textarea) {
				summary = $.removeHtmlTag(self.textarea.val());
				if (summary.length > 163) {
					$.messager.alert(self.formEngine.Edoc2FormSR.Global_Error, self.formEngine.Edoc2FormSR.Global_Error_SummaryLong);
					return;
				}
			}
			var fmId = $.getQueryString("formId", "", self.formEngine.queryParam);
			//获取流程引擎中流程设置的变量 在根据控件id填充值
			var data = { method: action, processId: processId, incidentId: incidentId, taskId: taskId, formId: fmId, summary: summary };
			data.allData = JSON.stringify(self.formEngine.getWfData());
			data.businessKey = self.formEngine.instanceFormConfig.recordId;
			if (self.formEngine.CurrentActivityConfig && self.formEngine.CurrentActivityConfig.subProcess) {
				var busVar = { name: "businessKey", value: id };
				self.formEngine.eform.wf.setVar(busVar);
				var list = self.formEngine.eform.wf.getVarList();
				var flowvars = JSON.stringify(list.getItemJsons());
				data.vars = flowvars;
			}

			var isClickd = false;
			if (isCustom != "true") {
				switch (action) {
					//发起
					case "initiate":
					case "approve":
					case "returnStarter":
					case "returnPreStep":
					case "cancel":
						isClickd = true;
						uiObj.beforeClick(function (isOk) {
							var bo = self.formEngine.validate();
							if (isOk && bo) {
								var list = self.formEngine.eform.wf.getVarList();
								var flowvars = JSON.stringify(list.getItemJsons());
								setParams(data, self, flowvars);
								approve(data, uiObj, action);
							}
						});
						break;
					case "print":
						isClickd = true;
						uiObj.beforeClick(function (isOk) {
							if (isOk) {
								print();
							}
						});
						break;
					case "custom":
						isClickd = true;
						self.onClick && self.onClick($(this).text(), $(this).prop("id"), action);
						break;
				}
			}
			if (isCustom == "true" && !isClickd) {
				self.onClick && self.onClick($(this).text(), $(this).prop("id"), action);
			}
		}

		// 流程操作时设置参数 tangbangguo 2018/5/30
		function setParams(data, self, flowvars) {
			if (data) {
				data.vars = flowvars;
				var IncidentRemark = self.getIncidentRemark().replaceAll('&nbsp;', '');
				IncidentRemark = IncidentRemark.replaceAll('<p>', '');
				IncidentRemark = IncidentRemark.replaceAll('</p>', '');
				data.incidentRemark = IncidentRemark;// 获取流程摘要
				data.remark = data.incidentRemark;
				data.signDataStr = self.getSignDataStr();
			}
		}
		function layoutReload() {
			try {
				window.opener.parent.layoutReload();
			} catch (e) { }
		}

		function afterSubmit(result, _action, recordId, procInstanceId) {
			var result = workFlowBtnObj.afterSubmit({
				result: result, // 是否发起成功
				action: _action, // 按钮类型
				recordId: recordId,   // 提交后表单记录编号
				procInstanceId: procInstanceId, // 流程实例编号
			});
			if (result === false) {
				return false;
			}
			return true;
		}
		//发起流程
		function approve(data, btnObj, action) {
			var errorCallback = function (result) {
				btnObj.afterClick(false);
				$.messager.alert(Edoc2FormSR.Global_Tip, result.msg, 'warn', $.noop, true, true);
				afterSubmit(false, action, null, null);
			}
			var self = workFlowBtnObj;
			data = { data: window.edoc2Form.Cryptography.encryptData($.toJSON(data)) }
			data.isNewRecord = eform.isNewRecord;
			data.IsWorkflow = true;
			data.DataSource = edoc2Form.Cryptography.encryptData(JSON.stringify(eform.getDataSource()));
			data.CurrentActivity = edoc2Form.Cryptography.encryptData(JSON.stringify(eform.wf.currentActivity));
			data.token = $.cookie("token");
			data.formVer = window.edoc2Form.Cryptography.encryptData(eform.formVer);
			data.businessKey = self.formEngine.instanceFormConfig.recordId;
			sign(data, function (result) {
				// 执行控件保存事件
				layoutReload();
				var recordId = result.context;
				//业务系统中存入流程编号和实例编号 如果页面存在这2个隐藏域就存进去
				var processId = $.getQueryString("processId", "", self.formEngine.queryParam);
				if (processId && recordId && action == 'initiate') {
					var process = self.formEngine.eform("Process", "", self.formEngine.queryParam);
					var incId = self.formEngine.eform("Incident", "", self.formEngine.queryParam);
					if (process && incId) {
						self.formEngine.changeFormToEdit(self.formEngine.instanceFormConfig.recordId);
						process.method("setValue", processId);
						incId.method("setValue", recordId);
					}
				}
				// 执行全局保存后回调事件
				if (afterSubmit(true, action, eform.recordId, recordId)) {
					var msg = self.formEngine.Edoc2FormSR.Flow_ProcessSucess;
					switch (action) {
						case 'initiate':
							msg = self.formEngine.Edoc2FormSR.Flow_StartSucess;
							break;
						case 'cancel':
							msg = self.formEngine.Edoc2FormSR.Flow_CxSucess;
							break;
						case 'returnPreStep':
						case 'returnStarter':
							msg = self.formEngine.Edoc2FormSR.Flow_ThSucess;
							break;
					}
					$.globalMessage(self.formEngine.Edoc2FormSR.Global_Tip, msg, "", function () {
						setTimeout(function () { window.close(); }, 500)
					});
				}
			}, errorCallback, true);
		}
	}
	//  window.gmp = window.gmp || {};
	// gmp.proxy = new Proxy();
})