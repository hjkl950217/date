﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: C0620 2020/10/27 17:32:34
*
***************************************************************************/
define(["gmp/env"
    , "gmp/eform/parser"
    , "gmp/eform/workflow"
    , "gmp/xhr"
    , "gmp/eform/lang"
    , "gmp/audit/audit"
    , 'gmp/eform/form'
    , 'gmp/eform/exts/auditData'
    , 'gmp/eform/layout'], function (env, parser, wf, xhr, lang, audit, form, auditdata, layout) {
        //Environment variable.
        env.proxy = env.proxy || {};
        env.proxy.enable = env.proxy.enable || true;

        var FormProxy = function () {
            var self = this;
            var inner = {};
            self.enable = env.proxy.enable;
            self.attach = {};
            inner.validateUrl = function () {
                return env.path.app + "/eform/proxy/validate/" + eform.formId;
            }
            inner.saveUrl = function () {
                return env.path.app + "/eform/proxy/save/" + eform.formId;
            }

            /**
             * Override the form save method.
             * @param {Function}    success     Save the successful callback function.
             * @param {Function}    error       Save the failed callback function.
             * @param {string}      recordId    The record id.
             * @param {string}      type        Submission types, `wf` is process form, `form` is normal form.
             * @param {boolean}     silent      True if the silent save form is used.
             * @param {boolean}     async       True if the form is saved asynchronously.
             * @override
             */
            self.save = function (success, error, recordId, type, silent, async) {
                //Save before event.
                if (parser.saveBefore(env.eform.formId, parser.formData) == false) {
                    error && error({ code: "0003", msg: "saveBefore return false." });
                    return;
                }
                var data = self.getData("form", recordId || env.eform.recordId);

                self.validate(data,
                    function (validateSuccess) {
                        if (validateSuccess) {
                            var successCallback = function (result) {
                                if ($.type(result) === "string") {
                                    result = JSON.parse(result);
                                }
                                if (!inner.xhrResult(result)) {
                                    inner.formAudit && inner.formAudit.save && inner.formAudit.save(false);
                                    return inner.onerror(result, error);
                                }
                                inner.formAudit && inner.formAudit.save && inner.formAudit.save();
                                //Execute the save callback event.
                                inner.onsaveAfter(result.id);
                                parser.saveAfter(true, result.id);
                                //Execute the custom callback event.
                                var wfData = type == "wf" ? parser.getData("wf") : null;
                                if (success) return success(result.id, parser.controls, wfData);

                                //Silent save does not show successful message.
                                !silent && $.messager.alert(lang.Global_Tip, lang.Global_SaveOK, 'info');
                            };
                            var res = xhr.post(inner.saveUrl(), data, successCallback, async);
                        } else {
                            error && error({ code: "0003", msg: "saveBefore return false." });
                        }
                    });
            }

            /**
             * Override
             * @param {string} action The button action name.
             * @override
             */
            self.beforeClick = function (action) {
                var btn = this.getButtonByAction(action);
                btn.beforeClick(function (isOk) {
                    if (isOk) {
                        self.submit(action, btn);
                    }
                });
            }

            /**
             *
             * @param {any} action
             * @param {any} btn
             */
            self.submit = function (action, btn) {
                var mid = $.mask.show({
                    parent: parser.jqRootContainer,
                    loadingText: lang.Sys_Submitting
                });
                var error = function (res) {
                    btn.afterClick(false);
                    wf.afterSubmit({
                        result: false,
                        action: action,
                        recordId: env.eform.recordId,
                        procInstanceId: null
                    });
                    inner.errorMessager(res)
                    //  $.messager.alert(Edoc2FormSR.Global_Error, Edoc2FormSR[res.msg] || res.msg, 'warn', $.noop, true, true);
                }
                var data = self.getData("wf", env.eform.recordId, action);

                xhr.post(inner.saveUrl(), data).done(function (res) {
                    if ($.type(res) === "string") {
                        res = JSON.parse(res);
                    }
                    if (!inner.xhrResult(res)) {
                        inner.formAudit && inner.formAudit.save && inner.formAudit.save(false);
                        error(res);
                        return;
                    }
                    var incident = res.context;
                    inner.layoutReload();
                    inner.updateProcessData(incident, action);
                    btn.afterClick(true);
                    inner.onsaveAfter(data.recordId);
                    if (eform.isNewRecord
                        && inner.formAudit
                        && inner.formAudit.data
                        && inner.formAudit.data.metaData) {
                        for (var i = 0; i < inner.formAudit.data.metaData.length; i++) {
                            if (inner.formAudit.data.metaData[i].key == 'Incident') {
                                inner.formAudit.data.metaData[i].value = incident;
                            }
                        }
                    }

                    inner.formAudit && inner.formAudit.save && inner.formAudit.save();
                    wf.afterSubmit({
                        result: true,
                        action: action,
                        recordId: env.eform.recordId,
                        procInstanceId: incident
                    });

                    inner.showSuccessMessage(action);
                    //  setTimeout(function () { window.close(); }, 500)
                }).catch(error).always(function () {
                    $.mask.hide({ maskHandlerId: mid });
                })
            }

            /**
             * Validate the form on before saving.
             * The form will not save if false is returned.
             * @param   {object}    data    The post data.
             * @param   {Function}  callback   callback
             * @returns {boolean} A value indicating whether the form should continue to be saved.
             * @override
             */
            self.validate = function (data, callback) {
                var actionCode = "";
                if (typeof data == "string") {
                    switch (data) {
                        case "initiate":
                            actionCode = "LaunchWorkFlow";
                            break;
                        case "approve":
                            if (eform.wf.currentActivity && eform.wf.currentActivity.activityNo == 'firstTask') {
                                actionCode = "LaunchWorkFlow";
                            } else {
                                actionCode = "AgreeWorkFlow";
                            }

                            break;
                        case "returnStarter":
                            actionCode = "ReturnToInitiatorWorkFlow";
                            break;
                        case "returnPreStep":
                            actionCode = "ReturnToLastWorkFlow";
                            break;
                        case "cancel":
                            actionCode = "TerminationWorkFlow";
                            break;
                        case "print":
                            actionCode = "FilePrint";
                            break;
                        case "plusSign":
                            actionCode = "CountersignWorkFlow";
                            break;
                        case "reject":
                            actionCode = "DisagreeWorkFlow";
                            break;
                    }
                    data = self.getData("wf", '', data);
                }

                xhr.post(inner.validateUrl(), data, function (result) {
                    if ($.type(result) === "string") {
                        result = JSON.parse(result);
                    }

                    if (!inner.xhrResult(result)) {
                        if (result.msg)
                            inner.errorMessager(result)
                        //  $.messager.alert(Edoc2FormSR.Global_Error, Edoc2FormSR[result.msg] || result.msg, 'warn', $.noop, true, true);
                        callback(false);
                        return;
                    }
                    //是否有审计信息
                    if (self.audit) {
                        var currentAudit = null;
                        if (self.audit instanceof Function) {
                            //审计信息为方法的调用方法
                            currentAudit = self.audit(result);
                        } else {
                            currentAudit = self.audit;
                        }

                        if (!currentAudit.action) {
                            //流程的默认识别
                            currentAudit.action = actionCode;
                        }
                        if (!currentAudit.signers) {
                            //默认当前登录人
                            currentAudit.signers = [eform.userInfo.Account];
                        }
                        if (currentAudit.changedData == null) {
                            currentAudit.changedData = auditdata.getChangedData();
                        }
                        if (currentAudit.metaData == null) {
                            currentAudit.metaData = auditdata.getMetaData();
                        }
                        audit.action(currentAudit.action, currentAudit, false).fail(function () {
                            console.info('审计取消');
                            callback(false);
                        }).done(function (auditBack, signers, data) {
                            callback(true, auditBack.save);
                            inner.formAudit = {
                                save: auditBack.save,
                                data: data,
                                signers: signers
                            }
                        });
                    } else {
                        callback(true);
                    }
                });
                return false;
            }
            //self.getChangedData = function () {
            //    var changedData = [];
            //    for (var key in form.controls) {
            //        if (!form.controls[key].isShow) {
            //            continue;
            //        }
            //        if (form.controls[key].column && !form.controls[key].column.isShow) {
            //            continue;
            //        }
            //        if (form.controls[key].column.block && !form.controls[key].column.block.isShow) {
            //            continue;
            //        }
            //        if (!form.controls[key].getLabelHtml) {
            //            continue;
            //        }
            //        var oldValue = eform.getDataSource(key);
            //        var newValue = form.controls[key].getValue();
            //        if (form.controls[key].Const_Type == "edoc2Date") {
            //            if (newValue.length <= 10){
            //                newValue += " 00:00:00";
            //            }
            //        }
            //        if (oldValue != newValue) {
            //            changedData.push({
            //                field: key,
            //                name: form.controls[key].getLabelHtml(),
            //                oldText: eform.getDataSource(key) || '',
            //                newText: form.controls[key].getValue()
            //            });
            //        }
            //    }
            //    return changedData;
            //}
            /**
             * Gets the post data that the form wants to save.
             * @param   {string} recordId The record id.
             * @returns {object} The post data.
             */
            self.getData = function (type, recordId, action) {
                var crypto = window.edoc2Form.Cryptography;

                //Regular forms data.
                var dataset = parser.getData("url");
                var data = {
                    formId: crypto.encryptData(env.eform.formId),
                    formVer: crypto.encryptData(env.eform.formVer),
                    dataset: crypto.encryptData(dataset),
                    recordId: crypto.encryptData(recordId || env.eform.recordId),
                    attach: JSON.stringify(self.attach)
                };

                //Process form data.
                if (type == "wf") {
                    $.extend(data, wf.getData(action));
                    data.isWorkflow = true;
                    data.currentActivity = crypto.encryptData(JSON.stringify(wf.currentActivity));
                }

                //Custom extension data.
                var dataSource = JSON.stringify(parser.dataSource);
                data.isNewRecord = env.eform.isNew;
                data.dataSource = crypto.encryptData(dataSource);
                data.token = env.token;
                data.lang = env.eform.lang;
                data.orgId = env.user.orgId;
                data.orgName = env.user.orgName;

                return data;
            }

            //Initiaize
            inner.init = function () {
                if (!env.proxy.enable) return;

                parser.save = self.save;

                //Re-register to resolve asynchronous loading of form tabs.
                if (!wf.hasWorkflow) {
                    setTimeout(function () {
                        parser.onParseAfter = inner.init
                    }, 0);
                    return;
                }

                wf.validate = self.validate;
                wf.beforeClick = self.beforeClick;
            }

            inner.xhrResult = function (res) {
                if ($.type(res) === "string") {
                    res = JSON.parse(res);
                }
                //  if (res.result || res.isSuccess) return true;
                //  $.messager.alert(Edoc2FormSR.Global_Error, res.msg, 'warn', $.noop, true, true);
                return res.result || res.isSuccess;
            }

            //Refresh the workflow list.
            inner.layoutReload = function () {
                try {
                    window.opener.parent.layoutReload();
                }
                catch (e) { }
            }

            /**
             * Update the `Process` and `Incident` fields in the form.
             * @param {any} incident
             */
            inner.updateProcessData = function (incident, action) {
                //if (action != 'initiate') return;
                //var processId = wf.processId;
                //incident = incident || wf.incident;

                //var processCtl = eform("Process");
                //var incidentCtl = eform("Incident");
                //if (processCtl && incidentCtl) {
                //    parser.changeFormToEdit(env.eform.recordId);

                //    processCtl.method("setValue", processId);
                //    incidentCtl.method("setValue", incident);
                //    parser.save(null, null, env.eform.recordId, "", true, false);

                //    self.formEngine.changeFormToCreate();
                //}
            }

            /**
             * Displays a successful message based on action.
             * @param {any} action
             */
            inner.showSuccessMessage = function (action) {
                var message = lang.Flow_ProcessSucess;

                // switch (action) {
                // case 'initiate':
                // message = lang.Flow_StartSucess;
                // break;
                // case 'cancel':
                // message = lang.Flow_CxSucess;
                // break;
                // case 'returnPreStep':
                // case 'returnStarter':
                // message = lang.Flow_ThSucess;
                // break;
                // }

                $.messager.alert(lang.Global_Tip, message, "success", function () {
                    layout.close(edoc2Form.formId, window, false);
                })
                // $('.message-alert-mask').remove();
            }

            /**
             * Execute the control to save the event.
             * @param {string} recordId The result record id.
             */
            inner.onsaveAfter = function (recordId) {
                var list = parser.onSaveAfterEventList;
                if (list.length == 0) return;

                for (var i = 0; i < list.length; i++) {
                    var obj = list[i];
                    obj.event.call(obj.control, eform.recordId);
                }
            }

            /**
             * The event that is triggered when the form fails to save.
             * @param {object}      result  The error message.
             * @param {Function}    error   Custom error callback.
             */
            inner.onerror = function (result, error) {
                // $.messager.alert(lang.Global_Tip, Edoc2FormSR[result.msg] || result.msg, 'warn', $.noop, true, true);
                inner.errorMessager(result)
                result.code = "0001";
                error && error(result);
            }
            inner.errorMessager = function (result) {
                var msg = Edoc2FormSR[result.msg] || result.msg;
                if (result.parameter && $.isArray(result.parameter) && result.parameter.length > 0) {
                    for (var i = 0; i < result.parameter.length; i++) {
                        result.parameter[i] = Edoc2FormSR[result.parameter[i]] || result.parameter[i];
                    }
                    $.messager.alert(lang.Global_Tip, $.format(msg, result.parameter), 'warn', $.noop, true, true);
                } else {
                    $.messager.alert(lang.Global_Tip, msg, 'warn', $.noop, true, true);
                }
            }

            //Register the parse after event.
            parser.onParseAfter = inner.init;
        }

        var proxy = new FormProxy();
        return proxy;
    })