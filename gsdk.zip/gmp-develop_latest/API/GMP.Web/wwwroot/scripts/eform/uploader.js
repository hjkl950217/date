﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/10 15:03:23
*
***************************************************************************/

/**
 * Provides encapsulation of upload control and simplifies file upload methods.
 * @module gmp/eform/uploader
 * @requires gmp/env
 * @requires gmp/eform/lang
 */
define(['gmp/env', 'gmp/eform/lang'], function (env, lang) {
	//Environment variable.
	env.uploader = env.uploader || {};
	env.uploader.width = env.uploader.width || 600;     //The width of the dialog.
	env.uploader.height = env.uploader.height || 550;   //The height of the dialog.

	var Uploader = function (utils) {
		var self = this;
		self.dialog = null;

		var inner = {};
		inner.url = "/component.html?token={0}&moduledatatype=proxy&moduledata={1}&singleuploadmode={2}";

		/**
		 * Creates a file upload or update window based on the specified configuration.
		 * @param {string}  type        Upload or update.
		 * @param {number}  folderId    The folder id in which the files are stored.
		 * @param {number}  fileId      The file id to update.
		 * @param {string}  fileName    The file name to update.
		 * @param {boolean} sign        True if it's a single file upload,otherwise,false.
		 */
		self.upload = function (type, folderId, fileId, fileName, sign) {
			var params = {
				"moduleId": "component/upload/index",
				"moduleName": "upload",
				"folderId": folderId,
				"message": "message",
				"datas": {
					"isEformEnv": true,
					"strategy": "majorUpgrade",
					"folder": {
						"id": folderId,
						"name": fileName || ""
					},
					"operateType": type || "upload",
					"updateFileId": fileId || ""
				}
			}

			var sign = type == "update" ? true : sign || false;
			var data = encodeURIComponent(JSON.stringify(params));
			var url = $.format(inner.url, env.token, data, sign);

			inner.bindEvent();

			self.dialog = utils.showDialog({
				title: lang.Global_Upload,
				content: url,
				width: env.uploader.width,
				height: env.uploader.height,
				showSelf: true
			});
		}

		/**
		 * Events that are triggered before uploading begins.
		 * @param   {Array}     files     A collection of files to be uploaded.
		 * @returns {boolean}   Returning false will stop the upload.
		 * @override
		 */
		self.onbeforeFileQueued = function (files) { return true; }

		/**
		 * Events that is triggered when an upload is skipped.
		 * @override
		 * */
		self.onuploadSkip = function () {
			setTimeout(function () {
				self.dialog.close()
			}, 500);
		}

		/**
		 * Events that is triggered when the upload is finish.
		 * @param {Array} postedFiles   A collection of files post to the server.
		 * @param {Array} successFiles  Collection of successfully uploaded files.
		 * @param {Array} failFiles     Failed file collection to upload.
		 * @param {Array} allFiles      A collection of files in the upload queue.
		 * @override
		 */
		self.onuploadFinish = function (postedFiles,/* successFiles, failFiles, allFiles */) { };

		//Bind event.
		inner.bindEvent = function () {
			window.activeUploaderHost = window.activeUploaderHost || {};

			window.activeUploaderHost.onBeforeFileQueued = function (files) {
				return self.onbeforeFileQueued(files);
			}

			window.activeUploaderHost.uploadSkip = function () {
				self.onuploadSkip();
			};

			window.activeUploaderHost.onUploadFinish = function (postedFiles, successFiles, failFiles, allFiles) {
				self.onuploadFinish(postedFiles, successFiles, failFiles, allFiles);
			};
		}
	}

	return Uploader;
})