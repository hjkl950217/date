﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/27 19:27:23
*
***************************************************************************/

/**
 * The eform tools module.
 * @module gmp/eform/utils
 * @requires gmp/env
 * @requires gmp/events
 * @requires gmp/eform/layout
 * @requires gmp/eform/lang
 * @requires gmp/eform/uploader
 */
define(['gmp/env', 'gmp/events', 'gmp/eform/layout', 'gmp/eform/lang', 'gmp/eform/uploader'], function (env, events, layout, lang, Uploader) {
	//Environment variable.
	env.dialog = env.dialog || {};
	env.dialog.width = env.dialog.width || 800;                 //The width of the dialog.
	env.dialog.height = env.dialog.height || 500;               //The height of the dialog.
	env.dialog.minimizable = env.dialog.minimizable || false;   //Display minimize button.
	env.dialog.maximizable = env.dialog.maximizable || true;    //Display maximize button.
	env.dialog.resizable = env.dialog.resizable || true;        //Change dialog size.
	env.dialog.closable = env.dialog.closable || true;          //Display close button.

	env.memberSelect = env.memberSelect || {};
	env.memberSelect.width = env.memberSelect.width || 800;                     //The width of the dialog.
	env.memberSelect.height = env.memberSelect.height || 500;                   //The height of the dialog.
	env.memberSelect.allowUser = env.memberSelect.multiple || true;             //True if users are allowed to be selected.
	env.memberSelect.allowPosition = env.memberSelect.allowPosition || false;   //True if positions are allowed to be selected.
	env.memberSelect.allowDept = env.memberSelect.allowDept || false;           //True if departments are allowed to be selected.
	env.memberSelect.allowGroup = env.memberSelect.allowGroup || false;         //True if user groups are allowed to be selected.
	env.memberSelect.multiple = env.memberSelect.multiple || true;              //True if multiple choices are allowed.
	env.memberSelect.deptRootId = env.memberSelect.deptRootId || 1;             //The root department id that is allowed to be selected.
	env.memberSelect.positionRootId = env.memberSelect.positionRootId || 1;     //The root position id that is allowed to be selected.
	env.memberSelect.userDeptRootId = env.memberSelect.userDeptRootId || 1;     //The user's root department id that is allowed to be selected.

	/**
	 * Provide basic helper methods for eform.
	 * @class Utility
	 */
	var Utility = function () {
		var self = this;
		var inner = {};
		inner.dialogs = []; //Dialog cache.

		/**
		 * Open a dialog box.
		 * @param   {object}    options     Dialog type, target or iframe, default iframe.
		 * @param   {Function}  callback    The callback function when the dialog is closed.
		 * @returns {object}    Return the dialog instance.
		 */
		self.showDialog = function (options, callback) {
			var identifier = new Date().getTime();
			options = $.extend({}, self.showDialog.defaults, options);

			//Basic config.
			var config = {
				title: options.title,
				width: options.width,
				height: options.height,
				minimizable: options.minimizable,
				maximizable: options.maximizable,
				resizable: options.resizable,
				closable: options.closable,
				modal: options.modal,
				buttons: [{
					text: lang.Global_Cancel,
					handler: function () {
						inner.dialogs[identifier].close();
						$("[class*=window]:hidden").remove();
						events.emit("dialog.close", inner.dialogs[identifier], window);
					}
				}]
			}

			//Adds custom buttons.
			if (options.buttons) {
				config.buttons = [];
				for (var index in options.buttons) {
					(function (index) {
						var button = options.buttons[index];
						config.buttons.push({
							id: button.id || '',
							text: button.text,
							handler: function () {
								button.handler && button.handler(inner.dialogs[identifier], window);
							}
						})
					})(index);
				}
			}

			//Dialog params.
			var params = {
				dialogType: options.type,
				showCloseBtn: false,
				target: options.content,
				onBeforeClose: function () {
					callback && callback(inner.dialogs[identifier], window);
					events.emit("dialog.close", inner.dialogs[identifier], window);
					delete inner.dialogs[identifier];
				}
			}

			//Create and return dialog instance.
			var dialog = options.showSelf ? new eform.Dialog(config, params)
				: new layout.eform.Dialog(config, params);
			inner.dialogs[identifier] = dialog;
			return dialog;
		}

		/**
		 * Open the file upload dialog.
		 * @method showUploadDialog
		 * @param   {number}  folderId    The folder id in which the files are stored.
		 * @param   {boolean} sign        True if it's a single file upload,otherwise,false.
		 * @returns {object} The uploader instance.
		 */
		self.showUploadDialog = function (folderId, sign) {
			var uploader = new Uploader(self);
			uploader.upload("upload", folderId, null, null, sign);
			return uploader;
		}

		/**
		 * Open the file update dialog.
		 * @method showUpdateDialog
		 * @param   {number}  folderId    The folder id in which the files are stored.
		 * @param   {number}  fileId      The file id to update.
		 * @param   {string}  fileName    The file name to update.
		 * @returns {object} The uploader instance.
		 */
		self.showUpdateDialog = function (folderId, fileId, fileName) {
			var uploader = new Uploader(self);
			uploader.upload("update", folderId, fileId, fileName, true);
			return uploader;
		}

		/**
		 * Open the member selection dialog.
		 * @method showMemberSelect
		 * @param {object}      options     Configuration options.
		 * @param {Function}    callback    The selected callback function.
		 */
		self.showMemberSelect = function (options, callback) {
			options = $.extend({}, self.showMemberSelect.defaults, options);

			var config = {
				"title": options.title,
				"width": options.width,
				"height": options.height,
				"multiple": options.multiple,
				"token": env.token,
				"param": {
					"IsChild": true,
					"IsLike": true,
					"AllowDept": options.allowDept,
					"AllowPosition": options.allowPosition,
					"AllowGroup": options.allowGroup,
					"AllowUser": options.allowUser
				},
				"showModal": "button",
				"defaultRootParams": {
					"deptRootId": options.deptRootId,
					"positionRootId": options.positionRootId,
					"userDeptRootId": options.userDeptRootId
				},
				onSelectCallbackData: function (data) {
					callback && callback(data);
					events.emit("member.select", data);
				}
			}

			//Initialize Edoc2MemberSelect.
			var button = $("<a></a>");
			button.Edoc2MemberSelect(config);

			//Show dialog.
			button.click();
		}

		//Dialog default options.
		self.showDialog.defaults = {
			title: "",
			type: "iframe",
			width: env.dialog.width,
			height: env.dialog.height,
			minimizable: env.dialog.minimizable,
			maximizable: env.dialog.maximizable,
			resizable: env.dialog.resizable,
			closable: env.dialog.closable,
			showSelf: false,
			modal: true
		}

		//MemberSelects default options.
		self.showMemberSelect.defaults = {
			title: lang.Control_SelectMember,
			width: env.memberSelect.width,
			height: env.memberSelect.height,
			allowUser: env.memberSelect.allowUser,
			allowPosition: env.memberSelect.allowPosition,
			allowDept: env.memberSelect.allowDept,
			allowGroup: env.memberSelect.allowGroup,
			multiple: env.memberSelect.multiple,
			deptRootId: env.user.orgIdentityId,
			positionRootId: env.user.orgPositionIdentityId,
			userDeptRootId: env.user.orgIdentityId,
		}

		/**
		 * Format the string as a hyperlink.
		 * @method fileNameFormatter
		 * @param    {number}    fileId         The file id.
		 * @param    {number}    fileVerId      The file version id.
		 * @param    {string}    fileName       The file name.
		 * @param    {number}    color          Color of text.
		 * @param    {boolean}   bold           Whether the text is bold, default is true.
		 * @param    {number}    incident       The process incident number.
		 * @param    {boolean}   isWindowOpen   use window.open
		 * @param    {string}    gpc            Permission control identification.
		 * @returns  {boolean}   A hyperlink string.
		 */
		self.fileNameFormatter = function (fileId, fileVerId, fileName, color, bold, incident, isWindowOpen, gpc) {
			if (fileName.lastIndexOf('.') > 0) {
				if (fileName.toLocaleLowerCase().endsWith(".docx")
					|| fileName.toLocaleLowerCase().endsWith(".doc")
					|| fileName.toLocaleLowerCase().endsWith(".xlsx")
					|| fileName.toLocaleLowerCase().endsWith(".xls")
					|| fileName.toLocaleLowerCase().endsWith(".pdf")
					|| fileName.toLocaleLowerCase().endsWith(".text")) {
					fileName = fileName.substring(0, fileName.lastIndexOf('.'));
				}
			}

			var element = $("<a></a>");
			element.text(fileName);
			element.attr("target", "view_window");
			if (isWindowOpen) {
				var url = "/preview.html?t=" + env.timestamp;
				if (fileId) url += "&fileid=" + fileId;
				if (fileVerId) url += "&fileverid=" + fileVerId;
				if (incident) url += "&incident=" + incident;
				if (gpc) url += "&gpc=" + gpc;

				element.attr("onclick", $.format("window.open('{0}');return false;", url));
			}
			else {
				var url = "layout.preview(";
				url += (fileId ? fileId : "");
				url += ",'" + (fileVerId ? fileVerId : "") + "'";
				url += ",'" + (fileName ? fileName : "") + "'";
				url += ",'" + (incident ? incident : "") + "'";
				url += ",'" + (gpc ? gpc : "") + "'";
				url += ");return false;";
				element.attr("onclick", url);
				//element.attr("onclick", $.format("layout.preview('{0}','{1}','{2}','{3}');return false;", fileId, fileVerId, fileName, incident));
			}
			element.css({ textDecoration: "none", color: color || "black", cursor: "pointer" });

			if (bold == undefined || bold == true) {
				element.css({ fontWeight: "bold" });
			}

			return element[0].outerHTML;
		}
	}

	return new Utility();
})