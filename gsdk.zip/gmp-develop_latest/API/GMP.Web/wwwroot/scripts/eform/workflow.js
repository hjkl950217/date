﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/22 16:52:11
*
***************************************************************************/

/**
 *
 * @module gmp/eform/workflow
 * @requires gmp/system
 * @requires gmp/env
 * @requires gmp/xhr
 * @requires gmp/events
 * @requires gmp/cookie
 * @requires gmp/eform/parser
 * @requires gmp/eform/lang
 */
define(['gmp/system', 'gmp/env', 'gmp/xhr', 'gmp/events', 'gmp/cookie', 'gmp/eform/parser', 'gmp/eform/lang'], function (system, env, xhr, events, cookie, parser, lang) {
    //Environment variable.
    env.workflow = env.workflow || {};
    env.workflow.confirm = env.workflow.confirm || true;

    var Workflow = function () {
        var self = this;
        var base = {};
        var inner = {};

        self.hasWorkflow = false;
        inner.control = null;
        inner.vars = {};
        inner.cache = { submitBefore: null, submitAfter: null };

		/**
		 * Get the latest version of the process id based on the process template key.
		 * @method getProcessId
		 * @param {string} processKey   The process template key.
		 * @returns {string} The process id.
		 */
        self.getProcessId = function (processKey) {
            var processId = "";
            var url = env.path.gmp + "/process/processId/" + processKey;

            xhr.sync.get(url).done(function (res) {
                if (res.code == 200) {
                    processId = res.data;
                }
            });

            return processId;
        }

		/**
		 * Gets the Url address for the specified process.
		 * @method getProcessUrl
		 * @param   {string} processKey   The process template key.
		 * @returns {string} The process url.
		 */
        self.getProcessUrl = function (processKey) {
            var processId = self.getProcessId(processKey);
            var jumpUrl = inner.getJumpUrl(processId);

            var regex = /window.open[\s\S]?\('(.*)?',/;
            var result = regex.exec(jumpUrl);

            return result[1] || "";
        }

		/**
		 * Open the process form.
		 * @method open
		 * @param {string} processKey  The process template key.
		 */
        self.open = function (processKey) {
            var processId = self.getProcessId(processKey);
            var jumpUrl = inner.getJumpUrl(processId);

            if (eform.pageType == "pc") {
                eval(jumpUrl);
            } else {
                var urls = /\('(\S+)'/.exec(jumpUrl);
                if ($.isArray(urls)) {
                    window.location.href = $.addRandomToUrl(urls[1]);
                }
            }

            events.emit("wf.open", self, processKey, processId, jumpUrl);
        }

		/**
		 * Shows the process button according to the specified options.
		 * @method showButtons
		 * @param {object} options  Button configuration options.
		 */
        self.showButtons = function (options) {
            options = system.extend(inner.options.defalut, options);

            //Hide all buttons.
            $("[controltype=edoc2WorkFlowButton] a[action]").hide();

            //Show the specified buttons
            for (var item in options) {
                if (options[item] == true) {
                    $("[controltype=edoc2WorkFlowButton] a[action=" + item + "]").show();
                }
            }
        }

		/**
		 * Represents process variables.
		 * @property vars
		 */
        Object.defineProperty(self,
            "vars",
            {
                get: function () {
                    inner.updateVarList();
                    setTimeout(inner.updateVarList, 0);
                    return inner.vars;
                }
            })

		/**
		 * Events that are triggered before the process is submited.
		 * @event onSubmitBefore
		 */
        Object.defineProperty(self,
            "onSubmitBefore",
            {
                set: function (callback) {
                    if (!self.hasWorkflow) {
                        inner.cache.submitBefore = callback;
                        return;
                    }

                    self.beforeSubmit = callback;
                }
            })

		/**
		 * Events that are triggered after the process is submited.
		 * @event onSubmitAfter
		 */
        Object.defineProperty(self,
            "onSubmitAfter",
            {
                set: function (callback) {
                    if (!self.hasWorkflow) {
                        inner.cache.submitAfter = callback;
                        return;
                    }

                    self.afterSubmit = callback;
                }
            })

		/**
		 * Workflow button click event.
		 * @event onclick
		 * @param {object} e The event object.
		 */
        base.onclick = function (e) {
            var action = $(this).attr("action") || "custom";
            events.emit("wf.click", self, action, e);

            if (parser.CurrentActivityConfig.cdirectBack && e.id == undefined && action == "returnStarter") {
                return;
            }

            if (!self.beforeSubmit(action)) return;

            //Limit of summary length.
            if (!self.summaryLengthLimit()) return;

            self.invoke(action);
        }

		/**
		 * Invokes the specified action.
		 * @method invoke
		 * @param {string} action   The button action name.
		 */
        base.invoke = function (action) {
            switch (action) {
                case "initiate":
                    self.initiate(action);
                    break;
                case "approve":
                case "reject":
                    self.approve(action);
                    break;
                case "returnStarter":
                    self.returnStarter(action);
                    break;
                case "returnPreStep":
                    self.returnPreStep(action);
                    break;
                case "cancel":
                    self.abort(action);
                    break;
                case "print":
                    self.print(action);
                    break;
                case "plusSign":
                    self.countersign(action);
                    break;
                case "custom":
                    var id = $(this).prop("id");
                    self.onClick && self.onClick($(this).text(), id, action);
                    break;
                default:
                    var id = $(this).prop("id");
                    self.onClick && self.onClick($(this).text(), id, action);
                    break;
            }

            events.emit("wf.invoke", self, action);
        }

		/**
		 * Process initiation action.
		 * @method initiate
		 * @param {string} action   The button action name.
		 */
        base.initiate = function (action) {
            if (!parser.validate()) return;
            var beforeClick = function (flag, save) {
                if (flag) {
                    self.beforeClick(action,
                        function (btn) {
                            self.confirm(lang.Flow_StartProcessTip), function () {
                                var data = self.getData(action);
                                self.initiator(data, btn, action);
                            }
                        });
                    events.emit("wf.initiate", self);
                }
            }
            if (!self.validate(action, beforeClick)) return;
            beforeClick(true);
        }
		/**
		 * Process approval action.
		 * @method approve
		 * @param {string} action   The button action name.
		 */
        base.approve = function (action) {
            if (!parser.validate()) return;

            var beforeClick = function (flag, save) {
                if (flag) {
                    self.beforeClick(action,
                        function (btn) {
                            self.confirm(lang.Flow_SubmitProcessTip,
                                function () {
                                    var data = self.getData(action);
                                    self.submit(data, btn, action);
                                });
                        });
                    events.emit("wf.approve", self);
                }
            }

            if (!self.validate(action, beforeClick)) return;
            beforeClick(true);
        }

		/**
		 * Return the process back to the originator.
		 * @method returnStarter
		 * @param {string} action   The button action name.
		 */
        base.returnStarter = function (action) {
            var beforeClick = function (flag, save) {
                if (flag) {
                    self.beforeClick(action,
                        function (btn) {
                            self.confirm(lang.FlowReturn_Tip,
                                function () {
                                    var data = self.getData(action);
                                    self.getService(data, btn, action);
                                });
                        });
                    events.emit("wf.back.start", self);
                }
            }
            if (!self.validate(action, beforeClick)) return;
            beforeClick(true);
        }

		/**
		 * Return the process back to the previous step.
		 * @method returnPreStep
		 * @param {string} action   The button action name.
		 */
        base.returnPreStep = function (action) {
            var beforeClick = function (flag, save) {
                if (flag) {
                    self.beforeClick(action,
                        function (btn) {
                            self.confirm(lang.FlowReturn_Tip,
                                function () {
                                    var data = self.getData(action);
                                    self.getService(data, btn, action);
                                });
                        });
                    events.emit("wf.back,prev", self);
                }
            }
            if (!self.validate(action, beforeClick)) return;
            beforeClick(true);
        }

		/**
		 * Abort the current process instance.
		 * @method abort
		 * @param {string} action   The button action name.
		 */
        base.abort = function (action) {
            var beforeClick = function (flag, save) {
                if (flag) {
                    self.beforeClick(action,
                        function (btn) {
                            self.confirm(lang.FlowReturn_Tip,
                                function () {
                                    var data = self.getData(action);
                                    self.cancel(data, btn, action);
                                });
                        });
                    events.emit("wf.abort", self);
                }
            }
            if (!self.validate(action, beforeClick)) return;
            beforeClick(true);
        }

		/**
		 * Prints the current process form.
		 * @method print
		 * @param {string} action   The button action name.
		 */
        base.print = function (action) {
            window.print();
            events.emit("wf.print", self);
        }

		/**
		 * Specify an external approver for the process.
		 * @method countersign
		 * @param {string} action   The button action name.
		 */
        base.countersign = function (action) {
            var btn = self.getButtonByAction(action);
            var data = self.getData(action);
            self.plusSign(data, btn, data.summary);
            events.emit("wf.sign", self);
        }

		/**
		 * Execute the button extension event.
		 * @method beforeClick
		 * @param {string}      action      The button action name.
		 * @param {Function}    callback    The callback function.
		 */
        base.beforeClick = function (action, callback) {
            var btn = self.getButtonByAction(action);
            btn.beforeClick(function (isOk) {
                if (isOk) {
                    callback && callback(btn);
                }
            });
        }

		/**
		 * Displays the confirmation dialog and the specified message.
		 * @method confirm
		 * @param {string}      message     The message to confirm.
		 * @param {Function}    callback    The confirmed callback function.
		 */
        base.confirm = function (message, callback) {
            if (!env.workflow.confirm) {
                return callback && callback();
            }

            $.messager.confirm(lang.Global_Tip,
                message,
                function (isOk) {
                    isOk && callback && callback();
                })

            events.emit("wf.confirm", self, message);
        }

		/**
		 * Limit the length of approval comments.
		 * @method summaryLengthLimit
		 * @returns {boolean} True if the limit length is not exceeded.
		 */
        base.summaryLengthLimit = function () {
            if (self.textarea) {
                var summary = $.removeHtmlTag(self.textarea.val());
                if (summary.length > 163) {
                    var errorSummaryLong = "审批意见,只限163个字符";
                    switch (eform.lang) {
                        case "ja":
                            errorSummaryLong = "承認意見は163文字に限ります";
                            break;
                        case "en":
                            errorSummaryLong = "Approval comments, 163 characters only";
                            break;
                    }
                    $.messager.alert(lang.Global_Error, errorSummaryLong);
                    return false;
                }
            }

            return true;
        }

		/**
		 * Gets the process post data based on the specified `action`.
		 * @method getData
		 * @param   {string} action The button action name.
		 * @returns {object} The workflow post data.
		 */
        base.getData = function (action) {
            var formId = system.querystring("formId");
            var processId = system.querystring("processId");
            var incidentId = system.querystring("incidentId");
            var taskId = system.querystring("taskId");
            var summary = $.removeHtmlTag(self.textarea.val());
            var vars = JSON.stringify(eform.wf.getVarList().getItemJsons());
            var remark = self.getIncidentRemark()
                .replaceAll('&nbsp;', '')
                .replaceAll('<p>', '')
                .replaceAll('</p>', '');

            if (incidentId == "") {
                incidentId = system.querystring("id");
            }

            var data = {
                method: action,
                processId: processId,
                incidentId: incidentId,
                taskId: taskId,
                vars: vars,
                formId: formId,
                summary: summary,
                allData: JSON.stringify(parser.getWfData()),
                businessKey: env.eform.recordId,
                remark: remark,
                incidentRemark: remark,
                signDataStr: self.getSignDataStr(),
                isBackReturn: false
            };

            return data;
        }

		/**
		 * Initialize workflow.
		 * @method init
		 * @private
		 */
        inner.init = function () {
            var controls = parser.getControl(edoc2Form.edoc2WorkFlowButton);

            //Re-register to resolve asynchronous loading of form tabs.
            if (controls.length == 0) {
                setTimeout(function () {
                    parser.onParseAfter = inner.init
                },
                    0);
                return;
            }

            self.actionType = eform.wf.actionType;
            self.taskTypeObj = eform.wf.taskType;
            self.processId = system.querystring("processId");
            self.processKey = self.processId.split(":")[0];
            self.incident = system.querystring("incidentId") || undefined;
            self.taskType = system.querystring("taskType");
            self.taskId = system.querystring("taskId") || undefined;
            self.taskState = system.querystring("taskState") || undefined;
            self.currentActivity = eform.wf.currentActivity;

            //Inherited workflow control.
            self.__proto__ = controls[0];
            system.extend(self.__proto__, base);

            setTimeout(t => {
                self.control.find("a").unbind('click');
                self.control.find("a").click(self.onclick);
            }, 500);


            //Binds the cached event.
            if (inner.cache.submitBefore) self.beforeSubmit = inner.cache.submitBefore;
            if (inner.cache.submitAfter) self.afterSubmit = inner.cache.submitAfter;

            self.hasWorkflow = true;

            window.workFlowBtnObj
                && window.workFlowBtnObj.textarea
                && window.workFlowBtnObj.textarea.attr('placeholder', '请输入审批意见,只限163个字符。');

            events.emit("wf.init", self);
        }

		/**
		 * Gets the process jump url.
		 * @method getJumpUrl
		 * @private
		 * @param   {string} processId   The process id.
		 * @returns {string} The process jump url.
		 */
        inner.getJumpUrl = function (processId) {
            var jumpUrl = "";
            var skin = window.theme || "";
            var token = cookie.get("token");
            var url = "/edoc2Flow-web/edoc2-form/jumpIndex?skin=" + skin + "&orgToken=" + token + "&t=" + env.times;

            var data = {
                state: undefined,
                taskType: "BeginTask",
                processId: processId,
                taskId: "",
                incidentId: "",
                businessKey: undefined
            };

            xhr.sync.get(location.origin + url, data).done(function (url) {
                jumpUrl = url;
            });

            jumpUrl = jumpUrl.replace("&skin=blue", "").replace(/&formver=\d+/, "");
            return jumpUrl;
        }

		/**
		 * Synchronize process variables with the process variables in eform.wf.
		 * @method updateVarList
		 * @private
		 */
        inner.updateVarList = function () {
            var list = eform.wf.getVarList()._hash;

            for (var key in inner.vars) {
                if (list[key]) continue;
                eform.wf.setVar({
                    name: key,
                    value: inner.vars[key]
                });
            }

            for (var key in list) {
                if (inner.vars[key]) continue;
                inner.vars[key] = list[key];
            }
        }

        //Button default options.
        inner.options = {};
        inner.options.defalut = {
            initiate: false,
            approve: false,
            reject: false,
            returnPreStep: false,
            returnStarter: false,
            plusSign: false,
            cancel: false,
            print: false
        }

        //Register the after parsing event.
        parser.onParseAfter = inner.init;
    }

    var workflow = new Workflow();
    return workflow;
})