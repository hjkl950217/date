﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/27 19:30:04
*
***************************************************************************/

var env = window.env || {};

env.appid = "gmp";  //Required.

//Debug environment variable.
env.debug = {};
env.debug.gmp = false;                      //True if debugging the gmp core.
env.debug.app = false;                      //True if debugging the application.
env.debug.origin = "http://localhost:5000"; //Local debug url, valid only under eform.enableDebug().

//Form environment variable.
env.eform = {};
env.eform.requiredMark = 'asterisk'; //asterisk, triangle
env.eform.requiredFixed = "prefix";  //prefix, suffix

//Layout environment variable.
env.layout = {};
env.layout.forms = { "123456789": { formId: "123456789", name: '测试表单' } }   //The forms that is not in the navigation menu.

//Common script environment variable.
env.script = {};
env.script.cache = true;            //True if script caching is enabled, false otherwise.
//env.script.cacheKey = "20200101";   //The static key used by the cache.
env.script.cacheKey = () => Math.floor(new Date().getTime() / 100000);  //The dynamic key used by the cache.
//env.script.cacheKey = () => new Date().getTime();  //The dynamic key used by the cache.
env.script.cacheKey = () => Math.floor(new Date().getTime() / 100000);
env.script.common = [];    //Common scripts.

//Path environment variable.
env.path = {};
env.path.origin = location.origin;
env.path.gmp = env.path.origin + "/gmp";        //GMP root path.
env.path.app = env.path.gmp + "/" + env.appid;  //GMP root path.
env.path.script = "/scripts";                   //Javascript script path.
env.path.eform = "/scripts/eform";               //The extension script path for eform.

//Data cache environment variable.
env.cache = {};
env.cache.enable = true;    //True if data caching is enabled, otherwise, false.

//Locker environment variable.
env.locker = {};
env.locker.enable = true;   //True if locker enabled, otherwise, false.
env.locker.freetime = 7;    //Idle time (in minutes) before the system is locked.
env.locker.polling = 30000; //The polling time for the locked state from the server.

//Logger environment variable.
env.logger = {};
env.logger.enable = true;   //True if logging is enabled, otherwise, false.
env.logger.level = 0;       //The minimum level of logging.
env.logger.format = "%c[/dt GMP_/a_/l] /m /e"; //The format of the log messages. Support /dt /d /t /l /m /g /e.
env.logger.colors = {
	debug: "background-color:sienna;color:white;",
	info: "background-color:aqua;color:royalblue;",
	warn: "background-color:yellow;color:red;",
	error: "background-color:red;color:yellow;"
}

//XHR environment variable.
env.xhr = {};
env.xhr.baseUrl = "/";  //The base url relative to the application level.
env.xhr.timeout = 0;        //Request timeout, default 0 is no timeout.

//Dialog environment variable.
env.dialog = {};
env.dialog.width = 800;         //The width of the dialog.
env.dialog.height = 500;        //The height of the dialog.
env.dialog.minimizable = false; //Display minimize button.
env.dialog.maximizable = true;  //Display maximize button.
env.dialog.resizable = true;    //Change dialog size.
env.dialog.closable = true;    //Display close button.

//Upload environment variable.
env.uploader = {};
env.uploader.width = 600;   //The width of the dialog.
env.uploader.height = 550;  //The height of the dialog.

//MemberSelect environment variable.
env.memberSelect = {};
env.memberSelect.width = 800;               //The width of the dialog.
env.memberSelect.height = 500;              //The height of the dialog.
env.memberSelect.allowUser = true;          //True if users are allowed to be selected.
env.memberSelect.allowPosition = false;     //True if positions are allowed to be selected.
env.memberSelect.allowDept = false;         //True if departments are allowed to be selected.
env.memberSelect.allowGroup = false;        //True if user groups are allowed to be selected.
env.memberSelect.multiple = true;           //True if multiple choices are allowed.
env.memberSelect.deptRootId = 1;            //The root department id that is allowed to be selected.
env.memberSelect.positionRootId = 1;        //The root position id that is allowed to be selected.
env.memberSelect.userDeptRootId = 1;        //The user's root department id that is allowed to be selected.
env.memberSelect.attach = true;             //True if you need to attach the member name.
env.memberSelect.attachType = "position";   //The type of member to attach.('dept' or 'position')
env.memberSelect.attachMode = "custom";     //How Identify multiple departments or positions.('auto' or 'custom')
env.memberSelect.selectMain = true;         //The main department or position is selected by default.