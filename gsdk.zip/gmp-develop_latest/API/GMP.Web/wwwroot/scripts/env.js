﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/27 19:30:04
*
***************************************************************************/

/**
 * Environment variable module.
 * @module gmp/env
 */
define(function () {
    var Environment = function () { };
    Environment.prototype = window.env;
    var env = new Environment();

    //Debug environment variable.
    env.debug = env.debug || {};
    env.debug.gmp = !!env.debug.gmp || /debug=gmp/.test(location.href);
    env.debug.app = !!env.debug.app || /debug=app/.test(location.href);
    env.debug.origin = env.debug.origin || location.origin;
    env.isdebug = /isdebug=1|debug=gmp|debug=app|localhost/.test(location.href);

    //Paths environment variable.
    env.path = env.path || {}
    env.path.origin = env.path.origin || location.origin;
    env.path.gmp = env.debug.gmp && env.debug.origin || env.path.gmp || env.path.origin + "/gmp";
    env.path.app = env.debug.app && env.debug.origin || env.path.app || env.path.gmp + "/" + (env.appid || "");
    env.path.script = env.path.script || "/scripts";
    env.path.eform = env.path.eform || "/scripts/eform";

    //Scripts environment variable.
    env.script = env.script || {};
    env.script.cache = env.script.cache == undefined || !!env.script.cache;
    env.script.cacheKey = env.script.cacheKey || (() => new Date().getTime());

    //Eform environment variable.
    env.eform = env.eform || {};
    env.iseform = /\/eform\//.test(location.href);
    if (env.iseform) {
        env.eform.formId = window.instancesFormParams.formId;
        env.eform.formVer = window.instancesFormParams.formVer;
        env.eform.recordId = window.instancesFormParams.recordId;
    }

    //Others environment variable.
    //if (/token=([^;]*)[;]?/.test(document.cookie)) {
    //    env.token = document.cookie.match(/token=([^;]*)[;]?/)[1];
    //}

    Object.defineProperty(env, "token", {
        get: function () {
            if (/token=([^;]*)[;]?/.test(document.cookie)) {
                return document.cookie.match(/token=([^;]*)[;]?/)[1];
            }

            return "";
        }
    })

    env.times = new Date().getTime();

    //Represents the operating system platform used to access the current system.
    env.platform = {
        mac: /Mac/i.test(navigator.platform),
        unix: /X11/i.test(navigator.platform),
        ipad: /iPad/i.test(navigator.platform),
        linux: /Linux/i.test(navigator.platform),
        iphone: /iPhone/i.test(navigator.platform),
        android: /Android/i.test(navigator.userAgent),
        windows: /Win32|Windows/i.test(navigator.platform),
        winphone: /(Windows Phone)/i.test(navigator.userAgent),
        mobile: /AppleWebKit.*Mobile.*/i.test(navigator.userAgent),
        ios: /\(i[^;]+;( U;)? CPU.+Mac OS X/.test(navigator.userAgent)
    }

    //Represents the browser environment used to access the current system.
    env.browser = {
        msie: /Trident/i.test(navigator.userAgent),
        msie6: /MSIE 6\.0/i.test(navigator.userAgent),
        msie7: /MSIE 7\.0/i.test(navigator.userAgent),
        msie8: /MSIE 8\.0/i.test(navigator.userAgent),
        msie9: /MSIE 9\.0/i.test(navigator.userAgent),
        msie10: /MSIE 10\.0/i.test(navigator.userAgent),
        msie11: /rv:11\.0/i.test(navigator.userAgent),
        edge: /Edge/i.test(navigator.userAgent),
        chrome: /Chrome/.test(navigator.userAgent),
        opera: /OPR|Opera/i.test(navigator.userAgent),
        firefox: /Firefox/i.test(navigator.userAgent),
        safari: /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent),
        presto: /Presto/i.test(navigator.userAgent),
        trident: /Trident/i.test(navigator.userAgent),
        webkit: /AppleWebKit/i.test(navigator.userAgent),
        gecko: /Gecko/i.test(navigator.userAgent) && /KHTML/i.test(navigator.userAgent),
    }

    return env;
})