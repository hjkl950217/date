﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/11/14 22:47:57
*
***************************************************************************/

/**
 * Event manager module that supports triggering events across pages and on specified pages.
 * @module gmp/events
 * @requires gmp/store
 */
define(['gmp/store'], function (store) {
	/**
	 * Represents an event subscription.
	 * @class Subscription
	 * @param {object}  owner    The Events instance.
	 * @param {string}  events   One or more events, separated by white space.
	 * @param {boolean} once     True if the event callback is executed only once.
	 */
	var Subscription = function (owner, events, once) {
		this.owner = owner;
		this.events = events;
		this.once = !!once;
	}

	/**
	 * Attaches a callback to the event subscription.
	 * @method then
	 * @param {function}    callback    The callback function to invoke when the event is triggered.
	 * @param {object}      context     An object to use as `this` when invoking the `callback`.
	 * @returns {Subscription} The subscription instance.
	 */
	Subscription.prototype.then = function (callback, context) {
		this.callback = callback || this.callback;
		this.context = context || this.context;
		if (!this.callback) return this;

		if (this.once) {
			this.owner.once(this.events, this.callback, this.context);
		}
		else {
			this.owner.on(this.events, this.callback, this.context);
		}

		return this;
	}

	/**
	 * Remove the subscription.
	 * @method off
	 * @returns {Subscription} The subscription instance.
	 */
	Subscription.prototype.off = function () {
		if (!this.callback) return this;
		this.owner.off(this.events, this.callback, this.context);
		return this;
	};

	/**
	 * Represents the event manager.
	 * @class Events
	 */
	var Events = function () {
		this.splitter = /\s+/;
		this.callbacks = {};
	};

	/**
	 * Creates a subscription or registers a callback for the specified event.
	 * @method on
	 * @param   {string}    events      One or more events, separated by white space.
	 * @param   {function}  callback    The callback function to invoke when the event is triggered.
	 * @param   {object}    context     An object to use as `this` when invoking the `callback`.
	 * @returns {Events|Subscription} A subscription is returned if no callback is supplied, otherwise the events object is returned.
	 */
	Events.prototype.on = function (events, callback, context) {
		if (!callback) return new Subscription(this, events);

		var event;
		events = events.split(this.splitter);
		while (event = events.shift()) {
			var list = this.callbacks[event] || (this.callbacks[event] = []);
			list.push({
				callback: callback,
				context: context
			});
		}

		return this;
	}

	/**
	 * Creates a subscription or registers a callback for the specified event.
	 * This events is executed only once.
	 * @method once
	 * @param   {string}    events      One or more events, separated by white space.
	 * @param   {function}  callback    The callback function to invoke when the event is triggered.
	 * @param   {object}    context     An object to use as `this` when invoking the `callback`.
	 * @returns {Events|Subscription} A subscription is returned if no callback is supplied, otherwise the events object is returned.
	 */
	Events.prototype.once = function (events, callback, context) {
		if (!callback) return new Subscription(this, events, true);

		var event, self = this;
		events = events.split(this.splitter);
		while (event = events.shift()) {
			var cb = (function (event) {
				return function once() {
					callback.apply(context || callback, arguments);
					self.off(event, cb, context);
				}
			})(event);

			this.on(event, cb, context);
		}
	}

	/**
	 * Removes the callbacks for the specified events.
	 * If `events` is not provided, all events and all callbacks will be removed.
	 * If `callback` is not provided, all callbacks for the specified events will be removed.
	 * @method off
	 * @param   {string}    events      One or more events, separated by white space.
	 * @param   {function}  callback    The callback function to remove.
	 * @param   {object}    context     The object that was used as `this`. Callbacks with this context will be removed.
	 * @returns {Events|Subscription} The events object is returned.
	 */
	Events.prototype.off = function (events, callback, context) {
		if (!this.callbacks) return this;

		//Remove all events and all callbacks.
		if (!(events || callback || context)) {
			this.callbacks = {};
			return this;
		}

		var event;
		events = events.split(this.splitter);
		while (event = events.shift()) {
			//Removes all callbacks for the specified event.
			if (!callback) {
				delete this.callbacks[event];
				continue;
			}

			//Removes the specified callback for the specified event.
			var calls = this.callbacks[event];
			for (var i = calls.length - 1; i >= 0; i--) {
				if (context && calls[i].callback === callback && calls[i].context == context) {
					calls.splice(i, 1)
				}

				if (!context && calls[i].callback === callback) {
					calls.splice(i, 1)
				}
			}
		}

		return this;
	}

	/**
	 * Triggers the specified event and the event registered on "all".
	 * The trigger will pass arguments to the callback function.
	 * @method emit
	 * @param {string} events One or more events, separated by white space.
	 */
	Events.prototype.emit = function (events) {
		if (!this.callbacks) return this;
		var callbacks = this.callbacks;
		var event, obj, calls = [];

		//Gets event arguments.
		var args = [];
		for (var i = 1; i < arguments.length; i++) {
			args.push(arguments[i]);
		}

		//Gets all callbacks for the specified events.
		events = events.split(this.splitter);
		while (event = events.shift()) {
			//Send cross-page events.
			if (event.indexOf(":") > 0) {
				this.across(event, args);
				continue;
			}

			if (!callbacks[event]) continue;

			//Copy callback lists to prevent modification.
			calls = calls.concat(callbacks[event].slice());
		}

		//Gets any `all` callbacks.
		if (callbacks.all) {
			calls = calls.concat(callbacks.all.slice());
		}

		//Execute event callbacks.
		while (obj = calls.shift()) {
			obj.callback.apply(obj.context || obj.callback, args);
		}

		return this;
	}

	/**
	 * Triggers the specified event on all or specified pages.
	 * @param {string} events One or more events, separated by white space.
	 */
	Events.prototype.across = function (events, args) {
		if (events.indexOf(":") == -1) return;

		var splitter = events.split(":");
		var qualifier = splitter[0];
		var event = splitter[1];
		var params = [event];

		//Events are triggered only in the current window.
		if (qualifier == "self") {
			this.emit.apply(this, params.concat(args));
		}

		//Events are triggered only in the parent window.
		else if (qualifier == "parent") {
			if (!window.parent.require) return;

			window.parent.require(["gmp/events"], function (ev) {
				ev.emit.apply(ev, params.concat(args));
			})
		}

		//Events are only triggered in the top window.
		else if (qualifier == "top") {
			if (!top.window.require) return;

			top.window.require(["gmp/events"], function (ev) {
				ev.emit.apply(ev, params.concat(args));
			})
		}

		//Triggers an event on all window.
		else if (qualifier == "all") {
			store.set("event", { event: events, data: args });
			store.remove("event");
		}

		/*
		 * If the qualifier contains the `.in` character,
		 * look for the window with the window.name
		 * compound qualifier on the entire parent link.
		 */
		else if (qualifier.indexOf(".in") > -1) {
			var prefix = qualifier.replace(".in", "");
			var parent = window;
			while (parent) {
				if (parent.window.name == prefix) {
					parent.window.require(["gmp/events"], function (ev) {
						ev.emit.apply(ev, params.concat(args));
					})
					break;
				}

				if (parent.window === top.window) {
					parent = null;
					break;
				}

				parent = parent.window.parent;
			}
		}

		//Events are only triggered where window.name equals the qualifier.
		else {
			store.set("event", { event: events, data: args });
			store.remove("event");
		}
	}

	/**
	 * Creates a function that calling the function will invoke
	 * the previously specified events on the events object.
	 * @method proxy
	 * @param   {string} events One or more events, separated by white space.
	 * @returns {function} Simplifies calling functions that specify events.
	 */
	Events.prototype.proxy = function (events) {
		var self = this;
		return function EventProxy() {
			var args = [events];
			for (var i = 0; i < arguments.length; i++) {
				args.push(arguments[i]);
			}

			self.emit.apply(self, args);
		};
	}

	/**
	 * Listen for localStorage onchange events to trigger cross-page events.
	 * @param {StorageEvent} e The event object when the storage area changes.
	 * @event
	 */
	store.onchange("event", function (e) {
		if (e.newValue == null) return;
		var data = JSON.parse(e.newValue);

		//Non-current page events or global events are skipped.
		var events = data.event.split(":");
		var qualifier = events[0];
		var event = events[1];
		if (qualifier !== "all" && qualifier !== window.name) return;

		//Gets the event arguments.
		var args = [event];
		args = args.concat(data.data);

		var ev = require('gmp/events');
		ev.emit.apply(ev, args);
	}, false);

	return new Events();
})