﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/18 10:49:39
*
***************************************************************************/

/**
 * JQuery resize event extension.
 * @module gmp/extends/jquery.resize
 * @requires jquery
 */
define(['jquery'], function ($) {
	var timer, elements = $([]), dataName = 'resize-special-event';
	$.resize = $.extend($.resize, { delay: 250, throttle: true });

	/**
	 * Initiates a listener that listens for changes
	 * in the height and width of the specified control,
	 * and fires a resize event when the width or height changes.
	 */
	function listener() {
		timer = setInterval(function () {
			elements.each(function () {
				var width = this.clientWidth;
				var height = this.clientHeight;
				var data = $.data(this, dataName);

				if (width !== data.w || height !== data.h) {
					data.w = width;
					data.h = height;
					$(this).trigger("resize", [width, height]);
				}
			});
		}, $.resize.delay);
	}

	//Registers the resize event in the jQuery event object.
	$.event.special["resize"] = {
		/**
		 * Configure the event data and start the event listener
		 * for the specified element.
		 * @method setup
		 */
		setup: function () {
			if (!$.resize.throttle && this.setTimeout) return false;

			var element = $(this);
			elements = elements.add(element);
			$.data(this, dataName, {
				w: this.clientWidth,
				h: this.clientHeight
			});

			if (elements.length) listener();
		},
		/**
		 * Removes resize event listening for the specified element.
		 * @method teardown
		 */
		teardown: function () {
			if (!$.resize.throttle && this.setTimeout) return false;

			var element = $(this);
			elements = elements.not(element);
			element.removeData(dataName);

			if (!elements.length) clearTimeout(timer);
		},
		/**
		 * Adds a resize event listening to the specified element.
		 * @param {object} handleObj The event handler object.
		 */
		add: function (handleObj) {
			if (!$.resize.throttle && this.setTimeout) return false;
			var callback;

			function handler(e, w, h) {
				var data = $.data(this, dataName);
				if (!data) return;

				data.w = w !== undefined ? w : this.clientWidth;
				data.h = h !== undefined ? h : this.clientHeight;
				callback.apply(this, arguments);
			}

			if ($.isFunction(handleObj)) {
				callback = handleObj;
				return handler;
			} else {
				callback = handleObj.handler;
				handleObj.handler = handler;
			}
		}
	};

	return $;
})