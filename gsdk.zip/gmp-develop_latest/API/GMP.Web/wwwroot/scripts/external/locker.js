﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/9/22 14:38:32
*
***************************************************************************/

!function (langs) {
	var Locker = function () {
		var self = this;
		var inner = {};

		self.enable = localStorage["locker.enable"] === 'true';
		self.freetime = localStorage["locker.freetime"] || 7;
		self.polling = localStorage["locker.polling"] || 30000;

		inner.user = {};
		inner.timer = null;
		inner.locked = false;
		inner.checking = false;
		inner.serverUrl = "/gmp/lock/";
		inner.token = document.cookie.match(/token=([^;]*)[;]?/) && document.cookie.match(/token=([^;]*)[;]?/)[1] || "";
		inner.locale = document.cookie.match(/lang=([^;]*)[;]?/) && document.cookie.match(/lang=([^;]*)[;]?/)[1] || "zh-cn";
		inner.account = document.cookie.match(/account=([^;]*)[;]?/) && document.cookie.match(/account=([^;]*)[;]?/)[1] || "";

		var lang = langs[inner.locale];
		inner.weeks = [lang.sunday, lang.monday, lang.tuesday, lang.wednesday, lang.thursday, lang.friday, lang.saturday];
		inner.html = "<div class=\"locker\" onselectstart=\"return false\"> "
			+ "    <div class=\"bg scale-down\"></div> "
			+ "    <div class=\"mask\"></div> "
			+ "    <div class=\"container\"> "
			+ "        <div class=\"avatar\"></div> "
			+ "        <div class=\"name\"></div> "
			+ "        <div class=\"unlock\"> "
			+ "            <div class=\"pwd\"> "
			+ "                <input autocomplete='off' type=\"password\" /> "
			+ "            </div> "
			+ "            <div class=\"btn-login\"></div> "
			+ "        </div> "
			+ "        <div class=\"loading\"> "
			+ "            <div><span></span></div> "
			+ "            <div><span></span></div> "
			+ "            <div><span></span></div> "
			+ "            <div><span></span></div> "
			+ "        </div> "
			+ "        <div class=\"message\"></div> "
			+ "    </div> "
			+ "    <div class=\"time\"></div> "
			+ "    <div class=\"date\"></div> "
			+ "</div> ";

		self.init = function () {
			if (!self.enable) return;
			$("head").append("<link rel=\"stylesheet\" href=\"/gmp/scripts/components/locker/locker.css\">");

			$.get("/gmp/user?account=" + inner.account).done(function (res) {
				if (res.code !== 200) return;
				inner.user = res.data;

				inner.registerMouseListener();
				inner.check();
				inner.polling();
			})
		}

		//Listen for mouse movement and reset the timer every 30 seconds.
		inner.registerMouseListener = function () {
			//Function of the throttle.
			var refresh = function () {
				var flag = false;
				return function () {
					if (flag) return;
					flag = !flag;

					setTimeout(function () { flag = !flag }, 30000);
					inner.refresh();
				}
			}

			//Listen mouse movement.
			$(window.document).mousemove(function () {
				refresh();
			})
		}

		//Check the lock status for the specified token.
		inner.check = function () {
			if (inner.checking) return;
			inner.checking = true;

			var url = inner.serverUrl + "check/" + self.freetime + "/" + inner.token;
			$.get(url).done(function (res) {
				if (res.code !== 200) return;

				if (res.data.state && !inner.locked) inner.lockScreen();
				if (!res.data.state && inner.locked) inner.unlockScreen();

				inner.emit(res.data.state ? "all:locker.lock" : "all:locker.unlock");
				inner.checking = false;
			}).always(function () {
				inner.checking = false;
			})
		}

		//Polling, synchronized across page state.
		inner.polling = function () {
			clearInterval(inner.timer);
			if (inner.locked) return;
			if (window !== top.window) return;

			inner.timer = setInterval(function () {
				inner.check();
			}, self.polling);
		}

		//Refreshes the time for the specified token.
		inner.refresh = function () {
			if (inner.locked) return;
			$.get(inner.serverUrl + "refresh/" + inner.token);
		}

		/**
		 * Unlocks the specified token.
		 * @param   {string} act  The user account.
		 * @param   {string} pwd  The user password.
		 */
		inner.unlock = function (act, pwd) {
			$.post(inner.serverUrl + "unlock/" + inner.token, { act, pwd }, function (res) {
				if (res.code == 200) {
					inner.locked = false;
					inner.unlockScreen();
					events.emit("all:locker.unlock");
				}

				if (res.code == 205) {
					inner.showMessage(lang.incorrectPasswordTips);
					inner.loading();
				}
			})
		}

		//Shows the lock screen interface.
		inner.lockScreen = function () {
			clearInterval(inner.timer);

			//Append locker html to the body.
			var el = $(inner.html);
			el.find(".pwd input").attr("placeholder", lang.unlockTips);
			$("body").append(el);

			//Display real-time time on the lock screen.
			inner.refreshTime(1000, false);
			inner.showAvatar();
			inner.showUserName();
			inner.bindEvents();

			inner.locked = true;
		}

		//Hides the lock screen interface.
		inner.unlockScreen = function () {
			$(".locker").addClass("fade-out");
			setTimeout(function () { $(".locker").remove() }, 500);

			inner.locked = false;
			inner.polling();
		}

		//Refresh the time on the lock screen.
		inner.refreshTime = function (sleep, tuning) {
			var timer = setInterval(function () {
				var now = new Date();
				var seconds = now.getSeconds();

				//After unlocking, stop the refresh time.
				if (!inner.locked) {
					clearInterval(timer);
				}

				//The timer is tuned to refresh every minute.
				if (!tuning && seconds == 0) {
					clearInterval(timer);
					inner.refreshTime(60000, true);
				}

				inner.showTime();
			}, sleep);
		}

		//Show the current time on the lock screen.
		inner.showTime = function () {
			var now = new Date();
			var month = now.getMonth() + 1;
			var week = now.getDay();
			var day = now.getDate();
			var hour = now.getHours();
			var minutes = now.getMinutes();
			var seconds = now.getSeconds();

			//Hours and minutes make up two.
			hour = ("00" + hour).substr(-2);
			minutes = ("00" + minutes).substr(-2);

			//Show current time.
			$(".locker .time").text(hour + " : " + minutes);
			$(".locker .date").text(month + "月" + day + "日，" + inner.weeks[week]);

			if (inner.locale != "zh-cn") {
				$(".locker .date").text(now.toDateString());
			}
		}

		//Show the current user name on the lock screen.
		inner.showUserName = function () {
			$(".locker .name").text(inner.user.name);
		}

		//Show the user avatar on the lock screen.
		inner.showAvatar = function () {
			var url = "/ImageType/GetUserAvatar?token=" + inner.token + "&userId=" + inner.user.identityId;
			$(".locker .avatar").css("background-image", "url(" + url + ")");
		}

		//Bind unlock event.
		inner.bindEvents = function () {
			$(".locker").on("click", inner.onclick);
			$(".locker .pwd input").on("keydown", inner.onkeydown);
			$(".locker .btn-login").on("click", inner.onunlock);

			//Illegal unlock.
			$(".locker").on("DOMNodeRemoved", function () {
				if (inner.locked && event.target.className == "locker") {
					alert(lang.illegalOperationTips);

					//Unable to rerender the DOM under IE.
					setTimeout(function () { inner.lockScreen(); }, 0);
				}
			});
		}

		//he unlock password window is displayed when clicking on the lock screen.
		inner.onclick = function () {
			$(".locker .bg").removeClass("scale-down").addClass("scale-up");
			$(".locker .mask,.locker .container").addClass("fade-in");
			$(".locker .time,.locker .date").addClass("fade-out");
			$(".locker .pwd input").focus();
		}

		/**
		 * Unlock it when the enter key is pressed,
		 * Ununlock when Esc key is pressed.
		 */
		inner.onkeydown = function () {
			//Enter the unlock.
			if (event.keyCode == 13) {
				inner.onunlock(event);
			}

			//Press the ECS button.
			if (event.keyCode == 27) {
				$(".locker .bg").removeClass("scale-up").addClass("scale-down");
				$(".locker .mask,.locker .container").removeClass("fade-in");
				$(".locker .time,.locker .date").removeClass("fade-out");

				$(".locker .pwd input:last").val("");
				$(".locker .pwd input").blur();

				inner.showMessage("");
			}
		}

		//Verify that user credentials are valid when unlocking.
		inner.onunlock = function () {
			inner.loading();

			var password = $(".locker .pwd input:last").val();
			if (password.trim() == "") {
				inner.showMessage(lang.noPasswordTips);
				inner.loading();
				return;
			}

			inner.unlock(inner.account, password);
		}

		//Show or hide the load animation.
		inner.loading = function () {
			if ($(".locker .unlock").is(":hidden")) {
				$(".locker .unlock").show();
				$(".locker .loading").hide();
			}
			else {
				this.showMessage(lang.welcome);
				$(".locker .unlock").hide();
				$(".locker .loading").show();
			}
		}

		/**
		 * Show the message on the lock screen.
		 * @param {string} message The message to display.
		 */
		inner.showMessage = function (message) {
			$(".locker .message").text(message);
		}

		/**
		 * Triggers the specified event and the event registered on "all".
		 * The trigger will pass arguments to the callback function.
		 * @param {string} events One or more events, separated by white space.
		 */
		inner.emit = function (events) {
			//Gets event arguments.
			var args = [];
			for (var i = 1; i < arguments.length; i++) {
				args.push(arguments[i]);
			}

			localStorage["event"] = JSON.stringify({ event: events, data: args })
			localStorage.removeItem("event");
		}

		/**
		 * Listen for localStorage onchange events to trigger cross-page events.
		 * @param {StorageEvent} e The event object when the storage area changes.
		 */
		window.addEventListener("storage", function (e) {
			if (e.key !== "event") return;
			if (e.newValue == null) return;
			var obj = JSON.parse(e.newValue);

			//Non-current page events or global events are skipped.
			var events = obj.event.split(":");
			var qualifier = events[0];
			var event = events[1];
			if (qualifier !== "all" && qualifier !== window.name) return;

			if (event == "locker.lock") inner.lockScreen();
			if (event == "locker.unlock") inner.unlockScreen();
		});
	}

	require(["require.config"], function () {
		require(['lib/jquery'], function () {
			new Locker().init();
		})
	});
}({
	"zh-cn": {
		welcome: '欢迎',
		monday: '星期一',
		tuesday: '星期二',
		wednesday: '星期三',
		thursday: '星期四',
		friday: '星期五',
		saturday: '星期六',
		sunday: '星期日',
		noPasswordTips: '请输入密码并重试',
		incorrectPasswordTips: '此密码不正确，请重新输入',
		illegalOperationTips: '当前操作是非法的，请输入密码进行解锁',
		unlockTips: '输入密码解锁...'
	},
	"zh-tw": {
		welcome: '歡迎',
		monday: '星期一',
		tuesday: '星期二',
		wednesday: '星期三',
		thursday: '星期四',
		friday: '星期五',
		saturday: '星期六',
		sunday: '星期日',
		noPasswordTips: '請輸入密碼並重試',
		incorrectPasswordTips: '此密碼不正確，請重新輸入',
		illegalOperationTips: '當前操作是非法的，請輸入密碼進行解鎖',
		unlockTips: '輸入密碼解鎖...'
	},
	"ja": {
		welcome: '歓迎',
		monday: '月曜日',
		tuesday: '火曜日',
		wednesday: '水曜日',
		thursday: '木曜日',
		friday: '金曜日',
		saturday: '土曜日',
		sunday: '日',
		noPasswordTips: 'パスワードを入力して再試行してください',
		incorrectPasswordTips: 'このパスワードは正しくありません。入力し直してください',
		illegalOperationTips: '現在の動作は不正です。パスワードを入力してロック解除してください',
		unlockTips: 'パスワードを入力して解除する...'
	},
	"en": {
		welcome: 'Welcome',
		monday: 'Mon.',
		tuesday: 'Tue.',
		wednesday: 'Wed.',
		thursday: 'Thu.',
		friday: 'Fri.',
		saturday: 'Sat.',
		sunday: 'Sun.',
		noPasswordTips: 'Please enter your password and try again.',
		incorrectPasswordTips: 'This password is not correct, please reenter it.',
		illegalOperationTips: 'This operation is illegal. Please enter your password to unlock it.',
		unlockTips: 'Enter password to unlock...'
	}
})