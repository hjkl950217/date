﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/23 18:54:12
*
***************************************************************************/

/**
 * Hash table module.
 * @module gmp/hashTable
 */
define(function () {
	var HashTable = function () {
		var self = this;
		self.hash = {};
		self.array = [];

		/**
		 * Gets the item count in the current hash table.
		 * @property count
		 */
		Object.defineProperty(self, "count", {
			get: function () {
				return self.array.length;
			}
		})
	}

	HashTable.prototype = {
		constructor: HashTable,
		/**
		 * Adds the specified key and value to the hash table.
		 * @method add
		 * @param {string} key The key to be added.
		 * @param {any} value The value of the key to add.
		 * @returns {boolean} True if added, otherwise, false.
		 */
		add: function (key, value) {
			if (!key) return false;
			if (this.contains(key)) return false;
			value = value == undefined ? null : value;

			this.array.push(value);
			this.hash[key] = value;
			return true;
		},
		/**
		 * Removes the item of the specified key from the hash table.
		 * @method remove
		 * @param {string} key The key to remove.
		 * @returns {boolean} True if removed, otherwise, false.
		 */
		remove: function (key) {
			var item = this.hash[key];
			var array = this.array.slice();
			if (item == undefined) return false;

			for (var i = 0; i < array.length; i++) {
				if (item === array[i]) {
					this.array.splice(i, 1);
					break;
				}
			}

			return delete this.hash[key];
		},
		/**
		 * Gets the value of the specified key.
		 * @method get
		 * @param {string} key The key to get the value.
		 * @returns {any} Specifies the value of the key.
		 */
		get: function (key) {
			return this.hash[key];
		},
		/**
		 * Returns a value indicating whether the specified key is included in the hash table.
		 * @method contains
		 * @param {string} key The key to retrieve.
		 * @returns {boolean} True if the specified key is included in the current hash table.
		 */
		contains: function (key) {
			return !!this.hash[key];
		},
		/**
		 * Clears the current hash table.
		 * @method clear
		 */
		clear: function () {
			this.hash = {};
			this.array = [];
		}
	}

	return HashTable;
})