﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/2 10:02:02
*
***************************************************************************/

define(['gmp/system', 'gmp/env', 'gmp/store', 'gmp/events', 'layui/layer', 'knockout', 'i18n!./lang', 'jquery'], function (system, env, store, events, layer, ko, lang, $) {
    var company = store.get("company") || env.user.companies[0];
    var element;

    var obj = {
        isShow: !!company,
        company: ko.observable(company),
        companies: ko.observableArray(env.user.companies),
        changeCompany: function (model) {
            store.set("company", model);
            events.emit("all:company.change", model);
        },
        attached: function (view) {
            element = view;
        }
    }

    /**
     * Update the company after the company changed.
     * @event company.change
     */
    events.on("company.change").then(function (company) {
        if (company == obj.company()) return;

        obj.company(company);
        layer.msg(lang.changed);
        $(element).find(".layui-nav-child").removeClass("layui-show");

        //Refresh the window.
        if (window === top) {
            system.wait(1000).done(function () {
                top.location.reload();
            });
        }
    })

    return obj;
})