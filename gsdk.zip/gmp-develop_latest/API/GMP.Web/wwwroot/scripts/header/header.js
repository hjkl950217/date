﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/10 14:56:22
*
***************************************************************************/

define(['gmp/env', 'gmp/xhr', 'knockout', 'plugins/router', 'layui/element', 'css!./header'], function (env, xhr, ko, router, _, _) {
    var header = function () {
        var self = this;
        var inner = {};

        self.element = null;
        self.router = router;
        self.height = ko.observable("50px");
        self.showNav = ko.observable(true);
        self.showUserBar = ko.observable(true);
        self.navLogo = ko.observable("images/logo_white_110x30.png");

        //Load the configuration and get it from the cache if there is one.
        inner.loadSettings = function () {
            if (env.settings) return;

            xhr.sync.get("/config/settings").done(function (settings) {
                if (!settings) return;
                env.settings = settings;
            })
        }

        self.activate = function (params) {
            inner.loadSettings();

            for (var key in params) {
                if (!self[key]) return;

                if (ko.isObservable(self[key])) {
                    self[key](params[key]);
                }
                else {
                    self[key] = params[key];
                }
            }

            if (location.href.endsWith("#404")) {
                location.href = location.origin;
            }

            if (!env.settings.navLogo) return;
            self.navLogo("/" + env.settings.navLogo);
        }

        self.attached = function (view, parent, context) {
            self.element = view;
            layui.element.render();
        }
    }

    return header;
})