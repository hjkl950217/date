﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/1 10:44:08
*
***************************************************************************/

/**
 * System multilingual module.
 * @module language
 * @requires knockout
 */
define(['gmp/system', 'gmp/events', 'gmp/cookie', 'gmp/hashTable', 'knockout', 'i18n!./lang', 'jquery'], function (system, events, cookie, hashtable, ko, lang, $) {
	var langs = new hashtable();
	langs.add("zh-cn", { lang: 'zh-cn', text: "简体中文", icon: "icon-cn" });
	//langs.add("zh-tw", { lang: "zh-tw", text: "繁體中文", icon: "icon-hk" });
	langs.add("en", { lang: "en", text: "English", icon: "icon-en" });
	langs.add("ja", { lang: "ja", text: "日本語", icon: "icon-ja" });

	var model = {
		element: null,
		current: ko.observable(),
		/**
		 * All languages supported by the system.
		 * @property languages
		 */
		languages: langs.array,
		/**
		 * Gets the current system language
		 * @method get
		 * @returns {string} The current language.
		 */
		get: function () {
			return model.current().lang;
		},
		/**
		 * Sets the current system language.
		 * @method set
		 * @param {string} language The language to set.
		 */
		set: function (language) {
			var current = langs.get(language);
			this.current(current);
		},
		/**
		 * The event that is triggered when the system language changes.
		 * @event onchange
		 * @param {string} lang The changed language.
		 */
		onchange: function (lang) {
			events.emit("all:language.change", lang);
		},
		/**
		 * Hook function, sets the current language when the module is activated.
		 * @method activate
		 */
		activate: function () {
			var lang = ((/lang=([^&]*)/.exec(location.search) && RegExp.$1)
				|| cookie.get("lang")
				|| navigator.language
				|| (navigator.languages && navigator.languages[0])
			).toLowerCase();

			model.set(lang);
		},
		/**
		 * Hook function, view of module.
		 * @param {HTMLElement} view view of module.
		 */
		attached: function (view) {
			model.element = view;
		}
	}

	/**
	 * Update the language after the current language changed.
	 * @event language.change
	 */
	events.on("language.change").then(function (language) {
		if (language == model.current()) return;

		model.set(language);
		cookie.set("lang", language, { path: "/" });
		layer.msg(lang.changed);
		$(model.element).find(".layui-nav-child").removeClass("layui-show");

		//Refresh the window.
		if (window === top) {
			system.wait(1000).done(function () {
				top.location.reload();
			});
		}
	})

	return model;
})