﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/25 9:17:41
*
***************************************************************************/

define(['gmp/app', 'gmp/edoc2', 'gmp/events', 'layui/layer', 'knockout', 'jquery', 'i18n!./lang'], function (app, edoc2, events, layer, ko, $, lang) {
    var about = {
        lang: lang,
        dialog: null,
        version: app.version,
        build: app.build,
        license: ko.observable({}),
        expiredTime: ko.pureComputed(function () {
            var expired = about.license().ExpiredTime;
            if (!expired) return "";

            var date = expired.replace(/\/Date\((\d+)\+\d+\)\//gi, "$1");;
            return new Date(parseFloat(date)).toLocaleDateString();
        }),
        close: function () {
            layer.close(this.dialog);
        },
        attached: function (view, parent, context) {
            this.dialog = layer.open({
                type: 1,
                title: false,
                content: $(view),
                closeBtn: 0,
                shadeClose: true,
                area: ['600px', '400px'],
                end: function () {
                    events.emit("component.show", {})
                }
            })
        }
    }

    edoc2.webcore("SystemManager", "GetLicenseInfo").done(function (res) {
        about.license(res.License);
    })

    return about;
})