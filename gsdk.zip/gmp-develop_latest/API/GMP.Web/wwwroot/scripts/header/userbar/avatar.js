﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/10/29 9:40:55
*
***************************************************************************/

define([
    'gmp/system'
    , 'gmp/xhr'
    , 'gmp/events'
    , 'layui/layer'
    , 'knockout'
    , 'jquery'
    , 'jquery.form'
    , 'jcrop'
    , 'i18n!./lang'
], function (system, xhr, events, layer, ko, $, jform, _, lang) {
    var vm = {
        lang: lang,
        dialog: null,
        jcrop: null,
        promise: null,
        avatarUrl: ko.observable(""),
        imgX: 0,
        imgY: 0,
        imgWidth: 0,
        imgHeight: 0,
        setSelect: [0, 0, 140, 140],
        init: function () {
            var e = new Image;
            e.onload = function () {
                $("#defaultImg").Jcrop({
                    allowSelect: true,
                    allowMove: true,
                    allowResize: true,
                    bgOpacity: .3,
                    aspectRatio: 1,
                    minSize: [30, 30],
                    maxSize: [1e3, 1e3],
                    onChange: vm.cutting,
                    onSelect: vm.cutting
                }, function () {
                    vm.jcrop = this;
                    vm.avatarUrl() && this.setSelect(vm.setSelect);
                })
            }

            e.src = this.avatarUrl()
        },
        cutting: function (e) {
            vm.imgX = e.x;
            vm.imgY = e.y;
            vm.imgHeight = e.h;
            vm.imgWidth = e.w;
        },
        onchange: function (self, e) {
            if (!e.target.files) return;
            if (!e.target.files.length) return;
            if (!e.target.files[0].size) return;

            var image = e.target.files[0];
            var imgName = image.name;
            var imgSize = image.size / 1024;

            if (!this.validate(imgName)) return layer.msg(lang.imgFormatErrorTips);
            if (imgSize > 1024) return layer.msg(lang.imgSizeOverflowTips);

            var uploader = this.upload($(e.target), function (e) {
                if (!e) return;
                e = JSON.parse(e);
                if (!e.path) return layer.msg(lang.imgUploadFailTips);


                vm.avatarUrl(e.path);
                $("#defaultImg").attr("src", e.path);
                $(".avatar-uploader").remove();

                if (vm.jcrop) {
                    vm.jcrop.setImage(e.path, function () {
                        this.setSelect(vm.setSelect);
                    })
                } else {
                    vm.init();
                }
            })

            uploader.submit();
        },
        validate: function (imgName) {
            var suffix = imgName.substring(imgName.lastIndexOf("."));
            return ".jpg,.bmp,.png,.jpeg".indexOf(suffix) > -1;
        },
        save: function () {
            if (this.imgWidth === 0 && this.imgHeight === 0) {
                return layer.msg(lang.selectCuttingAreaTips);
            }

            var data = {
                mainImgPath: this.avatarUrl(),
                imgY: this.imgY,
                imgX: this.imgX,
                imgWidth: this.imgWidth,
                imgHeight: this.imgHeight,
                resetChoose: false
            };

            xhr.post(location.origin + "/ImageType/ImgCut", data).done(function (res) {
                if (!res.ok) layer.msg(lang.saveFailed);
                layer.msg(lang.imgSaveSuccessTips);
                layer.close(vm.dialog);

                events.emit("all:user.updateAvatar");
            })
        },
        upload: function (target, callback) {
            var clone = target.clone(true);
            var parent = target.parent();
            var sibling = target.next();

            var form = $('<form class="avatar-uploader" action="/ImageType/HeadUpload" enctype="multipart/form-data" method="post"></form>');
            form.append(target);
            $(".avatar-uploader").remove();
            $("body").append(form);

            sibling.length ? sibling.before(clone) : parent.append(clone);

            return form.submit(function () {
                form.ajaxSubmit({
                    success: callback,
                    error: system.noop
                })

                return false;
            })
        },
        activate: function () {
            vm.promise = system.defer();

            xhr.get(location.origin + "/ImageType/GetSourceFaceImage?m=" + Math.random()).done(function (res) {
                res.exist ? vm.avatarUrl(res.path + "?m=" + Math.random()) : vm.avatarUrl("");
                vm.promise.resolve();
            })
        },
        attached: function (view, parent, context) {
            this.dialog = layer.open({
                type: 1,
                title: lang.avatarSetting,
                content: $(view),
                closeBtn: 1,
                shadeClose: false,
                area: ['450px', '550px'],
                btn: [lang.confirm, lang.cancel],
                btn1: function (index) { vm.save() },
                btn2: function (index) { layer.close(index) },
                end: function () { events.emit("component.show", {}) }
            })
        },
        compositionComplete: function (e, t) {
            if (this.jcrop) {
                $(".file").val("");
                this.jcrop.destroy();
                this.avatarUrl("");
                this.jcrop = null;
            }

            this.promise.done(function () {
                vm.init();
            })
        },
        detached: function () {
            this.jcrop && this.jcrop.destroy();
            this.jcrop = null;

            system.async().then(function () {
                events.emit("component.show", { model: 'header/userbar/userInfo' });
            })
        }
    }

    return vm;
})