﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/5 14:52:11
*
***************************************************************************/

define(function () {
    return {
        info: "Information",
        chpwd: "Change Password",
        about: "About",
        logout: "Logout",

        copyrightWarning: "Warning: This computer program is protected by copyright law and international conventions, and unauthorized reproduction or distribution of part or all of this program will result in severe civil and criminal penalties, with known violators subject to the full extent of the law.",
        customer: "Customer：",
        version: "Version：",
        buildNo: "Build No.：",
        serialNo: "Serial No.：",
        maxUsers: "Max Users：",
        expiredTime: "Expiration Date：",

        incompleteInformationTips: "Please complete the information.",
        originalPasswordErrorTips: "User original password not macthed.",
        passwordsDifferTips: "The two entered passwords are inconsistent.",
        cannotDefaultPasswordTips: "The new password cannot be the default password.",
        passwordLengthInvalidTips: "The password length is invalid.",
        passwordInvalidTips: "The password is invalid.",
        cannotUseOldPasswordsTips: "Cannot Use Old Passwords.",
        changePasswordSuccessTips: "Password changed successfully.",
        changePassword: "Change Password",
        confirm: "Confirm",
        cancel: "Cancel",
        currentPassword: "Current Password",
        newPassword: "New Password",
        confirmPassword: "Confirm Password",

        account: "Account",
        userName: "User Name",
        gender: "Gender",
        men: "Men",
        women: "Women",
        position: "Position",
        department: "Department",
        company: "Company",
        email: "Email",
        telephone: "Telephone",
        mobile: "Mobile",
        userNameNotEmptyTips: "The user name are required.",
        userInfoUpdateSuccessTips: "The user information is updated successfully.",
        userInfoUpdateFailTips: "The user information is update failed.",

        avatarSetting: "Avatar Setting",
        selectAvatar: "Select avatar picture",
        reselectAvatar: "Reselect",
        imgLimit: "Supports JPG | JPEG | PNG | BMP image,less than 1M.",
        imgFormatErrorTips: "Image format error.",
        imgSizeOverflowTips: "The image size cannot be larger than 1M.",
        imgUploadFailTips: "Image uploading failed.",
        selectCuttingAreaTips: "Select the clipping area.",
        imgSaveSuccessTips: "User picture saved Successfully.",
        imgSaveFailedTips: "User picture fails to be saved.",

    }
})