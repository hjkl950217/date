﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/6/25 17:09:05
*
***************************************************************************/

define(function () {
    return {
        info: "基本資料",
        chpwd: "パスワード",
        about: "について",
        logout: "抹消する",

        copyrightWarning: "警告:本コンピュータプログラムは著作権法と国際規約によって保護されており、ライセンスを受けずに本プログラムの一部または全部を複製または流布した場合、厳しい民事・刑事上の処罰を受け、既知の違反者に対しては法律の範囲内で全面的な制裁を科す。",
        customer: "顧客名:",
        version: "制品バージョン:",
        buildNo: "バージョン番号:",
        serialNo: "シリアルナンバー:",
        maxUsers: "ユーザー数:",
        expiredTime: "ライセンス期間:",

        incompleteInformationTips: "完全に情報を作成して",
        originalPasswordErrorTips: "原始密码不正确",
        passwordsDifferTips: "2回入力したパスワードが一致しない",
        cannotDefaultPasswordTips: "新パスワードはシステムのパスワードを黙認でき",
        passwordLengthInvalidTips: "パスワード丈に合致しない要求は",
        passwordInvalidTips: "パスワードが要件を満たしていない",
        cannotUseOldPasswordsTips: "新パスワードはパスワードを使った古いない",
        changePasswordSuccessTips: "パスワードの変更に成功",
        changePassword: "パスワードを変更する",
        confirm: "確認する",
        cancel: "キャンセル",
        currentPassword: "現在のパスワード",
        newPassword: "新しいパスワード",
        confirmPassword: "パスワードを確認する",

        account: "ユーザ名",
        userName: "名前",
        gender: "性别",
        men: "男",
        women: "女",
        position: "ポジション",
        department: "部門",
        company: "会社",
        email: "メール",
        telephone: "電話",
        mobile: "携帯電話",
        userNameNotEmptyTips: "名前を空欄にしてはいけない",
        userInfoUpdateSuccessTips: "ユーザー情報の更新に成功",
        userInfoUpdateFailTips: "ユーザー情報の更新に失敗",

        avatarSetting: "アイコンを設定し",
        selectAvatar: "アイコン画像を選択する",
        reselectAvatar: "選択し直す",
        imgLimit: "だけ支持jpg | jpeg | png | bmp、写真ファイルでファイルを1M以下",
        imgFormatErrorTips: "画像フォーマットエラー",
        imgSizeOverflowTips: "画像サイズは1M以上にならない",
        imgUploadFailTips: "画像アップロードに失敗",
        selectCuttingAreaTips: "クロッピング領域を選択してください",
        imgSaveSuccessTips: "アイコン保存成功",
        imgSaveFailedTips: "アイコン保存失敗",
    }
})