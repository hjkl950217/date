﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/1/5 14:52:11
*
***************************************************************************/

define(function () {
    return {
        info: "基本资料",
        chpwd: "更改密码",
        about: "关于",
        logout: "注销",

        copyrightWarning: "警告：本计算机程序受著作权法和国际公约的保护，未经授权擅自复制或散布本程序的部分或全部，将承受严厉的民事和刑事处罚，对已知的违法者将给予法律范围内的全面制裁。",
        customer: "客户名称：",
        version: "产品版本：",
        buildNo: "版本号：",
        serialNo: "序列号：",
        maxUsers: "用户数：",
        expiredTime: "授权期限：",

        incompleteInformationTips: "请将信息填写完整",
        originalPasswordErrorTips: "原始密码不正确",
        passwordsDifferTips: "两次输入的密码不一致",
        cannotDefaultPasswordTips: "新密码不能是系统默认密码",
        passwordLengthInvalidTips: "密码长度不符合要求",
        passwordInvalidTips: "密码不符合要求",
        cannotUseOldPasswordsTips: "新密码不能是使用过的旧密码",
        changePasswordSuccessTips: "密码修改成功",
        changePassword: "修改密码",
        confirm: "确认",
        cancel: "取消",
        currentPassword: "当前密码",
        newPassword: "新密码",
        confirmPassword: "确认密码",

        account: "用户名",
        userName: "姓名",
        gender: "性别",
        men: "男",
        women: "女",
        position: "职位",
        department: "部门",
        company: "公司",
        email: "邮箱",
        telephone: "电话",
        mobile: "手机",
        userNameNotEmptyTips: "姓名不能为空",
        userInfoUpdateSuccessTips: "个人信息更新成功",
        userInfoUpdateFailTips: "个人信息更新失败",

        avatarSetting: "设置头像",
        selectAvatar: "选择头像图片",
        reselectAvatar: "重新选择",
        imgLimit: "仅支持 jpg | jpeg | png | bmp 图片文件，且文件小于1M",
        imgFormatErrorTips: "图片格式错误",
        imgSizeOverflowTips: "图片大小不能大于1M",
        imgUploadFailTips: "图片上传失败",
        selectCuttingAreaTips: "请选择裁剪区域",
        imgSaveSuccessTips: "头像保存成功",
        imgSaveFailedTips: "头像保存失败",
    }
})