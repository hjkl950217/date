﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/6/25 17:08:24
*
***************************************************************************/

define(function () {
    return {
        info: "基本資料",
        chpwd: "更改密碼",
        about: "關於",
        logout: "注銷",

        copyrightWarning: "警告：本電腦程式受著作權法和國際公約的保護,未經授權擅自複製或散佈本程式的部分或全部,將承受嚴厲的民事和刑事處罰,對已知的違法者將給予法律範圍內的全面制裁。",
        customer: "客戶名稱：",
        version: "產品版本：",
        buildNo: "版本號：",
        serialNo: "序號：",
        maxUsers: "用戶數：",
        expiredTime: "授權期限：",

        incompleteInformationTips: "請將資訊填寫完整",
        originalPasswordErrorTips: "原始密碼不正確",
        passwordsDifferTips: "兩次輸入的密碼不一致",
        cannotDefaultPasswordTips: "新密碼不能是系統默認密碼",
        passwordLengthInvalidTips: "密碼長度不符合要求",
        passwordInvalidTips: "密碼不符合要求",
        cannotUseOldPasswordsTips: "新密碼不能是使用過的舊密碼",
        changePasswordSuccessTips: "密碼修改成功",
        changePassword: "修改密碼",
        confirm: "確認",
        cancel: "取消",
        currentPassword: "當前密碼",
        newPassword: "新密碼",
        confirmPassword: "確認密碼",

        account: "用戶名",
        userName: "姓名",
        gender: "性別",
        men: "男",
        women: "女",
        position: "職位",
        department: "部門",
        company: "公司",
        email: "郵箱",
        telephone: "電話",
        mobile: "手機",
        userNameNotEmptyTips: "姓名不能爲空",
        userInfoUpdateSuccessTips: "個人信息更新成功",
        userInfoUpdateFailTips: "個人信息更新失敗",

        avatarSetting: "設置頭像",
        selectAvatar: "選擇頭像圖片",
        reselectAvatar: "重新選擇",
        imgLimit: "僅支持 jpg | jpeg | png | bmp 圖片文件，且文件大小1M",
        imgFormatErrorTips: "圖片格式錯誤",
        imgSizeOverflowTips: "圖片大小不能大於1M",
        imgUploadFailTips: "圖片上傳失敗",
        selectCuttingAreaTips: "請選擇裁剪區域",
        imgSaveSuccessTips: "頭像保存成功",
        imgSaveFailedTips: "頭像保存失敗",
    }
})