﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/25 15:28:40
*
***************************************************************************/

define(['gmp/xhr', 'gmp/events', 'layui/layer', 'knockout', 'jquery', 'i18n!./lang'], function (xhr, events, layer, ko, $, lang) {
    return {
        lang: lang,
        dialog: null,
        currentPassword: ko.observable(""),
        newPassword: ko.observable(""),
        confirmPassword: ko.observable(""),
        close: function () {
            layer.close(this.dialog);
        },
        validate: function () {
            if (this.currentPassword() == ""
                || this.newPassword() == ""
                || this.confirmPassword() == "") {
                layer.msg(lang.incompleteInformationTips);
                return false;
            }

            if (this.newPassword() !== this.confirmPassword()) {
                layer.msg(lang.passwordsDifferTips);
                return false;
            }

            return true;
        },
        onsubmit: function (index) {
            if (!this.validate()) return;

            xhr.post(location.origin + "/WebCore", {
                module: "OrgnizationManager",
                fun: "ChangeCurrentUserPassword",
                oldPassword: this.currentPassword(),
                newPassword: this.newPassword(),
            }).done(function (res) {
                var returnUrl = window.location.pathname + window.location.hash;
                returnUrl = window.encodeURIComponent(returnUrl);

                if (res.url) {
                    window.top.location.href = res.url + "?returnUrl=" + returnUrl;
                    return;
                }

                if (res.result == 0) {
                    layer.msg(lang.changePasswordSuccessTips, null, function () {
                        top.location.reload();
                    });
                }
                else if (res.result == 209) layer.msg(lang.originalPasswordErrorTips);
                else if (res.result == 222) layer.msg(lang.cannotDefaultPasswordTips);
                else if (res.result == 226) layer.msg(lang.passwordLengthInvalidTips);
                else if (res.result == 227) layer.msg(lang.passwordInvalidTips);
                else if (res.result == 229) layer.msg(lang.cannotUseOldPasswordsTips);
                else layer.msg(res.result);
            })
        },
        attached: function (view, parent, context) {
            var self = this;
            this.dialog = layer.open({
                type: 1,
                title: lang.changePassword,
                content: $(view),
                closeBtn: 1,
                //shadeClose: true,
                area: ['400px', '280px'],
                btn: [lang.confirm, lang.cancel],
                btn1: function (index) { self.onsubmit(index) },
                btn2: function (index) { layer.close(index); },
                end: function () { events.emit("component.show", {}) }
            })
        }
    }
})