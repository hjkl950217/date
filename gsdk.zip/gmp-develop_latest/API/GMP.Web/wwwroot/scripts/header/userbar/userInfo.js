﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/25 13:27:16
*
***************************************************************************/

define([
	'gmp/system'
	, 'gmp/env'
	, 'gmp/xhr'
	, 'gmp/events'
	, 'gmp/store'
	, 'gmp/edoc2'
	, 'layui/layer'
	, 'knockout'
	, 'jquery'
	, 'i18n!./lang'
], function (system, env, xhr, events, store, edoc2, layer, ko, $, lang) {
	var vm = {
		lang: lang,
		dialog: null,
		editing: ko.observable(false),
		user: env.user,
		avatarUrl: ko.observable('/ImageType/GetUserAvatar?userId=' + env.user.identityId),
		userName: ko.observable(env.user.name),
		email: ko.observable(env.user.email),
		telephone: ko.observable(env.user.telephone),
		mobile: ko.observable(env.user.mobile),
		gender: ko.pureComputed(function () {
			return env.user.gender == 1 ? lang.men : lang.women;
		}),
		comdept: ko.pureComputed(function () {
			return env.user.orgName + " · " + env.user.deptName;
		}),
		close: function () {
			layer.close(this.dialog);
		},
		check: function () {
			edoc2.checkLogin();
			this.editing(true);
		},
		update: function () {
			var self = this;
			edoc2.checkLogin();

			if (this.userName().trim() == "") {
				layer.msg(lang.userNameNotEmptyTips);
				return;
			}

			edoc2.webcore("WebClient", "SaveUserInfo", {
				ModifyPerDetails_txtRealname: this.userName(),
				ModifyPerDetails_chkGenderMale: 1,
				ModifyPerDetails_txtEmail: this.email(),
				ModifyPerDetails_txtTelephone: this.telephone(),
				ModifyPerDetails_txtMobile: this.mobile()
			}).done(function (res) {
				if (res.result != 0) {
					layer.msg(lang.userInfoUpdateFailTips);
					return;
				}

				self.updateUserCache();
				layer.msg(lang.userInfoUpdateSuccessTips);
				self.editing(false);
			})
		},
		cancel: function () {
			this.userName(env.user.name);
			this.email(env.user.email);
			this.telephone(env.user.telephone);
			this.mobile(env.user.mobile);

			this.editing(false);
		},
		updateUserCache: function () {
			var promise = xhr.get("/user?account=" + env.user.account);
			promise.done(function (res) {
				if (res.code == 200) {
					var user = env.user = res.data;
					var company = store.get("company");

					user.orgId = company.id;
					user.orgIdentityId = company.identityId;
					user.orgCode = company.code;
					user.orgName = company.name;
					user.orgPositionId = company.positionId;
					user.orgPositionIdentityId = company.positionIdentityId;
					user.orgPath = company.path;
					user.orgParentId = company.parentId;
					user.orgParentidentityId = company.parentIdentityId;

					store.remove("user");
					store.set("user", user);
					events.emit("all:user.update", user);
				}
			})
		},
		setAvatar: function () {
			events.emit("component.show", { model: 'header/userbar/avatar' })
		},
		attached: function (view, parent, context) {
			this.dialog = layer.open({
				type: 1,
				title: false,
				content: $(view),
				closeBtn: 0,
				shadeClose: true,
				area: ['700px', '400px'],
				end: function () {
					events.emit("component.show", {})
				}
			})

			events.on("user.updateAvatar").then(function () {
				vm.avatarUrl("/ImageType/GetUserAvatar?userId=" + env.user.identityId + "&r=" + system.random());
			})
		},
		detached: function () {
			layer.close(vm.dialog);
		}
	}

	return vm;
})