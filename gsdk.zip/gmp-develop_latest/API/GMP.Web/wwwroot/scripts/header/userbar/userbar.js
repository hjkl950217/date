﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/2 10:02:14
*
***************************************************************************/

define(['gmp/system', 'gmp/env', 'gmp/xhr', 'gmp/events', 'knockout', 'i18n!./lang'], function (system, env, xhr, events, ko, lang) {
    return {
        user: ko.observable(env.user),
        avatarUrl: ko.observable('/ImageType/GetUserAvatar?userId=' + env.user.identityId),
        commands: [
            { command: 'showUserInfo', class: "fa fa-user", text: lang.info },
            { command: 'changePassword', class: "fa fa-lock", text: lang.chpwd },
            { command: 'showAbout', class: "fa fa-info-circle", text: lang.about },
            { command: 'logout', class: "fa fa-power-off", text: lang.logout }
        ],
        showUserInfo: function () {
            events.emit("component.show", {
                model: 'header/userbar/userInfo'
            })
        },
        changePassword: function () {
            events.emit("component.show", {
                model: 'header/userbar/password'
            })
        },
        showAbout: function () {
            events.emit("component.show", {
                model: 'header/userbar/about'
            })
        },
        logout: function () {
            xhr.post(location.origin + "/WebCore", {
                module: "OrgnizationManager",
                fun: "UserLogout"
            }).done(function (res) {
                if (!res) return;

                var returnUrl = window.location.pathname + window.location.hash;
                returnUrl = window.encodeURIComponent(returnUrl);

                if (res.url) window.top.location.href = res.url + "?returnUrl=" + returnUrl;
                else if (res.loginurl) window.top.location.href = res.loginurl + "?returnUrl=" + returnUrl;
                else window.top.location.href = "/api/auth/login";
            })
        },
        attached: function () {
            var self = this;

            events.on("user.update").then(function (user) {
                self.user(user);
            })

            events.on("user.updateAvatar").then(function () {
                self.avatarUrl("/ImageType/GetUserAvatar?userId=" + env.user.identityId + "&r=" + system.random());
            })
        }
    }
})