﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/26 10:21:17
*
***************************************************************************/

require(['require.config'], function () {
    require(['css!gmproot/styles/gmp.css']);
    require(['css!./lib/font-awesome/css/font-awesome.min.css']);

    require(['durandal/app', 'durandal/system', 'knockout', 'gmp/utils/security', 'layui/core', 'jquery'], function (app, system, ko, _, _, $) {
        system.debug(true);
        window.jQuery = window.$ = $;

        app.title = 'GMP Management System';
        app.start().then(function () {
            ko.applyBindings();
        });
    })
})