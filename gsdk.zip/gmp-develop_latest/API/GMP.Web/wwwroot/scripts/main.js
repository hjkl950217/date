﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/9 16:41:02
*
***************************************************************************/

if (!/\/gmp\//.test(top.location.href) && !/localhost/.test(top.location.href)) {
	top.location.href = "/gmp/index.html";
}

require(['require.config'], function () {
	require(['css!./lib/bootstrap/css/bootstrap.css']);
	require(['css!./lib/font-awesome/css/font-awesome.min.css']);
	require(['css!gmproot/styles/gmp.css']);
	require(['css!gmproot/styles/icons.css']);

	require(['durandal/app', 'durandal/system', 'gmp/app'], function (app, system) {
		system.debug(true);
		app.title = 'DMS文档管理系统';

		app.configurePlugins({
			router: true
		});

		//Start the application
		app.start().then(function () {
			app.setRoot('shell', 'entrance');
		});
	})
})