﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/9 10:12:13
*
***************************************************************************/

/**
 * Requirejs configuration module.
 * @module require.config
 * @requires gmp/env
*/

define(['env'], function (env) {
    var config = {
        paths: {
            'gmproot': env.path.gmp,
            'approot': env.path.app,
            'gmp': env.path.gmp + '/scripts',
            'app': env.path.app + "/scripts",
            'require.config': env.path.gmp + '/scripts/require.config',
            'css': env.path.gmp + '/scripts/lib/require/css',
            'i18n': env.path.gmp + '/scripts/lib/require/i18n',
            'text': env.path.gmp + '/scripts/lib/require/text',
            'durandal': env.path.gmp + '/scripts/lib/durandal',
            'plugins': env.path.gmp + '/scripts/lib/durandal/plugins',
            'knockout': env.path.gmp + '/scripts/lib/knockout/knockout',
            'bootstrap': env.path.gmp + '/scripts/lib/bootstrap/bootstrap',
            'transitions': env.path.gmp + '/scripts/lib/durandal/transitions',
            'jquery': env.path.gmp + '/scripts/lib/jquery/jquery',
            'jquery.form': env.path.gmp + '/scripts/lib/jquery/jquery.form',
            'layui': env.path.gmp + '/scripts/lib/layui',
            'html2canvas': env.path.gmp + '/scripts/lib/html2canvas.min',
            'jcrop': env.path.gmp + '/scripts/lib/jcrop/jquery.Jcrop'
        },
        shim: {
            'bootstrap': {
                deps: ['jquery'],
                exports: 'jQuery'
            },
            jcrop: {
                deps: ['jquery', 'css!./lib/jcrop/jquery.Jcrop'],
                exports: 'jQuery'
            },
            'layui/layer': {
                deps: ['layui/core'],
                exports: 'layer'
            },
            'gmp/env': {
                deps: ['env'],
                exports: 'env'
            }
        },
        urlArgs: function (id, url) {
            var args = "";

            if (env.script && env.script.cache) {
                if (typeof env.script.cacheKey == "function") {
                    args = "t=" + env.script.cacheKey();
                }
                else {
                    args = "?t=" + env.script.cacheKey;
                }
            }

            return (url.indexOf('?') === -1 ? '?' : '&') + args;
        }
    }

    requirejs.config(config);
    return config;
})