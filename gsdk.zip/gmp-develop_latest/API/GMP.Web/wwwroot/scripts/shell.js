﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/18 16:12:01
*
***************************************************************************/

define(['knockout'
    , 'plugins/router'
    , 'gmp/xhr'
    , 'gmp/events'
    , 'gmp/utils/navitem'
    , 'gmp/env'
    , 'gmp/store'
    , 'gmp/system'
    , 'gmp/edoc2'
    , 'gmp/cookie'
    , 'gmp/utils/security'
    , 'layui/core'
    , 'jquery'
], function (ko, router, xhr, events, NavItem, env, store, system, edoc2, cookie, _, _, $) {
    window.jQuery = window.$ = $;
    env.user = env.user || store.get("user");
    if (!env.user && cookie.get("account")) {
        var account = cookie.get("account");
        xhr.sync.get("/user?account=" + account).done(function (res) {
            if (res.code == 200) {
                env.user = res.data;
            }
        })

        store.set("user", env.user);
    }

    require(['gmp/components/locker/locker']);
    require(['gmp/components/search/index']);

    //Redirect to the first route if no route is specified.
    router.guardRoute = function (instance, instruction) {
        if (instruction && instruction.fragment === '') return router.routes[0].hash;
        return true;
    };

    var shell = {
        router: router,
        /**
         * Represents a dynamic component.
         */
        component: ko.observable(),
        /**
         * Indicates whether the current user has system administration menu permissions.
         */
        hasSystemMenuPerm: ko.observable(false),
        /**
         * Get the main navigation menu from ECM.
         * @returns {promise} The jQuery Promise object.
         */
        loadNavigation: function () {
            var self = this, promise;

            //Load system main navigation.
            promise = edoc2.webcore("SystemManager", "GetMainNavigatesForUI");
            promise.done(function (res) {
                if (!res) return;

                //No login, redirect to login page.
                if (res.errorCode == "ErrorCode4") {
                    top.location.href = res.url + "?returnUrl=" + res.defaultUrl;
                }

                //Load the routes.
                self.addNavigation(res.list);
            })

            return promise;
        },
        /**
         * Adds the specified navigation menu to the route list.
         * @param {object[]} navs Navigation menus.
         */
        addNavigation: function (navs) {
            var self = this;
            if (!navs || !navs.length) return;

            var lang = system.lang();
            var langMap = { "zh-cn": "ZhCn", "zh-tw": "ZhTw", en: "En", ja: "Jp" }

            //Remove navigation with hash `#doc`.
            var index = navs.findIndex(function (obj) { return obj.Hash == "#doc" });
            if (index > -1) navs.splice(index, 1);

            system.each(navs, function (index, obj) {
                var nav, token, setting = JSON.parse(obj.Setting);

                //hide the system menu when without system permissions.
                if (obj.Hash == "#system" && !self.hasSystemMenuPerm()) return;

                if (obj.Setting.indexOf("token") > -1) {
                    token = "?token=" + env.token;
                    if (setting.url.indexOf("?") > -1) {
                        setting.url = setting.url + "&token=" + env.token;
                    } else {
                        setting.url = setting.url + "?token=" + env.token;
                    }
                }

                //Internal routing.
                if (obj.Type == 1) {
                    nav = new NavItem({
                        nav: true,
                        route: obj.Route,
                        moduleId: obj.ModuleId,
                        title: obj[langMap[lang]],
                        hash: obj.Hash,
                        target: "_" + setting.target
                    });
                }

                //Exterior routing
                if (obj.Type == 2) {
                    var hash = "#third/" + index + (token || '');
                    if (setting.target == "blank") hash = setting.url;

                    nav = new NavItem({
                        nav: true,
                        route: "third/(:index)",
                        moduleId: "components/thirdsystem/index",
                        title: obj[langMap[lang]],
                        hash: hash,
                        target: "_" + setting.target,
                        url: setting.url
                    });
                }

                nav.isActive(obj.Active);
                router.map(nav);
            })
        },
        /**
         * Adds the search address to the route list.
         */
        addSearchRoute: function () {
            var route = new NavItem({
                nav: false,
                route: "search*details",
                moduleId: "components/search/details",
                title: '搜索',
                hash: "#search",
                target: "_self"
            });

            router.map(route);
        },
        activate: function () {
            var self = this, promise;

            promise = edoc2.webcore("OrgnizationManager", "GetTopFunctionsIncludeCustom")
                .done(function (res) { self.hasSystemMenuPerm(res.result); })
                .fail(function () { self.hasSystemMenuPerm(false); });

            promise.always(function () {
                self.loadNavigation().done(function () {
                    self.addSearchRoute();
                    router.buildNavigationModel();

                    /*
                     * If there is no `location.hash` or `location.hash` is not in the route list, 
                     * jump to the default navigation menu or the first navigation menu.
                     */
                    var navs = router.navigationModel();
                    if (!location.hash || !navs.find(v => v.hash == location.hash)) {
                        var active = navs.find(function (nav) {
                            return nav.actived();
                        })

                        active = active || navs[0];
                        location.href = location.href.replace(location.hash, "") + (active.hash || active.Hash);
                    }

                    router.mapUnknownRoutes('components/error/404', '404');
                    router.activate();
                })
            })

            return router;
        },
        attached: function () {
            events.on("component.show").then(function (component) {
                this.component(null);
                this.component(component);
            }, this);

            events.on("searching").then(function (key) {
                router.navigate("#search?q=" + window.encodeURI(key));
            })
        }
    }

    return shell;
})