﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/23 19:30:29
*
***************************************************************************/

/**
 * Local storage module.
 * @module gmp/store
 */
define(function () {
    var Store = function () {
        var self = this;
        var inner = {};
        var store = self.data = localStorage;
        self.events = {};

        /**
         * Gets the value of the specified key.
         * @method get
         * @param {string} key The key to get the value.
         * @returns {any} Specifies the value of the key.
         */
        self.get = function (key) {
            var value = store[key];
            if (value === "") return "";
            if (value === undefined) return undefined;
            if (value === "undefined") return undefined;

            return JSON.parse(store[key]);
        }

        /**
         * Sets the specified key and value to the store.
         * @param {string} key The key to be added.
         * @param {any} value The value of the key to add.
         */
        self.set = function (key, value) {
            var oldValue = store[key];
            store[key] = value === "" ? "" : JSON.stringify(value);
            inner.dispatch(key, store[key], oldValue);
        }

        /**
         * Removes the item of the specified key from the store.
         * @param {string} key The key to remove.
         * @returns {boolean} True if removed, otherwise, false.
         */
        self.remove = function (key) {
            inner.dispatch(key, null, store[key]);
            return delete store[key];
        }

        /**
         * Clear all local storage.
         * @method clear
         */
        self.clear = store.clear;

        /**
         * Listens for the specified key and executes the specified callback function
         * when the value of the specified key changes.
         * @event onchange
         * @param {string} key Listen for the key to change the value.
         * @param {function} callback The callback function when the value of the specified key is changed.
         */
        self.onchange = function (key, callback) {
            var calls = self.events[key] || (self.events[key] = []);
            calls.push(callback);
        }

        /**
         * Triggers a storage event and provides the values before and after the storage change.
         * @method dispatch
         * @param {string} key Key in storage.
         * @param {any} newValue The new value.
         * @param {any} oldValue The old value.
         */
        inner.dispatch = function (key, newValue, oldValue) {
            var storageEvent = new Event("storage");
            storageEvent.key = key;
            storageEvent.newValue = newValue;
            storageEvent.oldValue = oldValue;
            window.dispatchEvent(storageEvent);
        }

        /**
         * Adds local storage change events.
         * @event storage
         * @param {StorageEvent} e Store the event object when the change occurs.
         */
        window.addEventListener("storage", function (e) {
            var callbacks = self.events[e.key];
            if (!callbacks) return;

            var calls = [].concat(callbacks);
            while (fn = calls.shift()) {
                fn.call(fn, e);
            }
        });
    }

    return new Store();
})