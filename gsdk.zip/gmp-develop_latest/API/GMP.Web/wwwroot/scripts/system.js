﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/12 10:35:49
*
***************************************************************************/

/**
 * Provides the most commonly used functionality for other modules.
 * @module gmp/system
 * @requires gmp/env
 * @requires jquery
 */
define(['gmp/env', 'gmp/cookie', 'jquery'], function (env, cookie, $) {
	var system = {};
	var types = "Object String Array Function Number Boolean Date RegExp Arguments Null Undefined".split(" ");

	/**
	 * An empty function that does not perform any operations.
	 * @method noop
	 */
	system.noop = function () { };

	/**
	 * Creates a namespace based on the specified path.
	 * @method namespace
	 * @param {string} path The path to the namespace.
	 * @returns {object} The object specified by the namespace.
	 */
	system.namespace = function (path) {
		var parent = window;
		var parts = path.split('.');

		if (parts[0] === "window") {
			parts = parts.slice(1);
		}

		for (var i = 0; i < parts.length; i++) {
			var key = parts[i];
			parent[key] = parent[key] || {};
			parent = parent[key];
		}

		return parent;
	}

	/**
	 * Returns a string representing the type of the unevaluated operand.
	 * @method typeof
	 * @param {any} obj An object or primitive value.
	 * @returns {string} The type of the object.
	 */
	system.typeof = function (obj) {
		return Object.prototype.toString.call(obj).match(/\[object (\w+)\]/)[1].toLowerCase();
	}

	/**
	 * Iterates over the specified object using the specified iterator,
	 * terminating the iteration immediately if the iterator returns false.
	 * @method each
	 * @param {number|object|Array} obj The object to be traversed.
	 * @param {function} iterator An iterator function.
	 * @param {object} context The execution context of the `iterator`.
	 */
	system.each = function (obj, iterator, context) {
		//Number.
		if (this.typeof(obj) === 'number') {
			for (var i = 0; i < obj; i++) {
				iterator(i, i)
			}
			return;
		}

		//Array.
		if (this.typeof(obj) === 'array') {
			for (var i = 0; i < obj.length; i++) {
				if (iterator.call(context, i, obj[i], obj) === false) break;
			}
			return;
		}

		//Object.
		for (var key in obj) {
			if (iterator.call(context, key, obj[key], obj) === false) break;
		}
	}

	/**
	 * Extends the first object with the properties of the following objects.
	 * @method extend
	 * @returns {object} The extended object.
	 */
	system.extend = function () {
		var obj, clone, target = arguments[0] || {};

		for (var i = 1; i < arguments.length; i++) {
			if (!(obj = arguments[i])) return;

			for (var key in obj) {
				var src = target[key];
				var item = obj[key];
				if (target[key] === item) continue;
				if (item === undefined) continue;

				if (this.isArray(item) || this.isObject(item)) {
					if (this.isArray(item)) {
						clone = src && this.isArray(src) ? src : [];
					}
					else {
						clone = src && this.isObject(src) ? src : {};
					}

					target[key] = this.extend(clone, item);
					continue;
				}

				target[key] = item;
			}
		}

		return target;
	}

	/**
	 * Copies the specified object and returns.
	 * @param {any} obj The object to copy.
	 * @returns {any} A new object.
	 */
	system.clone = function (obj) {
		if (this.isArray(obj)) {
			return this.extend([], obj);
		}

		if (this.isObject(obj)) {
			return this.extend({}, obj);
		}

		return obj;
	}

	/**
	 * Replace the placeholder in the string with the real value.
	 * @method format
	 * @param {string} source The string to format.
	 * @returns {string} The formatted string.
	 */
	system.format = function (source) {
		if (arguments.length <= 1) return source;

		var params = Array.prototype.slice.call(arguments).slice(1);
		this.each(params, function (i, n) {
			source = source.replace(new RegExp("\\{" + i + "\\}", "g"), n);
		});

		return source;
	}

	/**
	 * Gets the specifies value of name or query string object.
	 * @method querystring
	 * @param {string} name The name of the query string.
	 * @returns {string|object} Specifies the value of name or query string object.
	 */
	system.querystring = function (name, defaultValue) {
		var key = name ? ("?" + name) : "*?";
		var search = location.href.slice(1);
		var reg = new RegExp("([^\\?&]" + key + ")=([^&]*)", "ig");
		var obj = {};

		do {
			result = reg.exec(search)
			if (!result) continue;
			obj[RegExp.$1] = RegExp.$2;
		} while (result)

		return name ? (obj[name] || defaultValue || "") : obj;
	}

	/**
	 * Determines whether the specified object is of the specified type.
	 * @method isObject
	 * @method isString
	 * @method isArray
	 * @method isFunction
	 * @method isNumber
	 * @method isBoolean
	 * @method isDate
	 * @method isRegExp
	 * @method isArguments
	 * @method isNull
	 * @method isUndefined
	 * @param {any} obj The object to check.
	 * @returns {boolean} True if matches the type,otherwise, false .
	 */
	system.each(types, function (index, type) {
		system["is" + type] = function (obj) {
			return system.typeof(obj) === type.toLowerCase();
		}
	})

	/**
	 * Determines if the specified object is a promise.
	 * @method isPromise
	 * @param {object} object The object to check.
	 * @return {boolean} True if matches the type, false otherwise.
	 */
	system.isPromise = function (obj) {
		return obj && system.isFunction(obj.then);
	};

	/**
	 * Determines if the specified object is an html element.
	 * @method isElement
	 * @param {object} object The object to check.
	 * @return {boolean} True if matches the type, false otherwise.
	 */
	system.isElement = function (obj) {
		return obj && obj.nodeType === 1;
	};

	/**
	 * Use to combine multiple elements into a single string, separated by a specified delimiter.
	 * @method join
	 * @param {string} separator Specifies the delimiter to use. If omitted, the comma is used as the delimiter.
	 * @param {string|Array} args Multiple arguments that need to be connected.
	 * @returns {string} A string concatenated by the specified delimiter.
	 */
	system.join = function (/* optional */ separator) {
		var params = Array.prototype.slice.call(arguments).slice(1);
		if (params.length == 0 && this.isArray(params[0])) {
			params = params[0];
		}

		return params.join(separator);
	}

	/**
	 * Gets the current language of the system.
	 * @method lang
	 * @returns {string} The current language.
	 */
	system.lang = function () {
		var lang = ((/lang=([^&]*)/.exec(location.search) && RegExp.$1)
			|| cookie.get("lang")
			|| navigator.language
			|| (navigator.languages && navigator.languages[0])
		).toLowerCase();

		return lang;
	}

	/**
	 * Methods that can be used for asynchronous execution
	 * are encapsulated by Deferred objects.
	 * @method defer
	 * @method wait
	 * @method async
	 */
	system.extend(system, {
		/**
		 * Creates a deferred object which can be used to create a promise.
		 * Optionally pass a function action to perform which will
		 * be passed an object used in resolving the promise.
		 * @method defer
		 * @param {function} [action] The action to defer.
		 * @return {Deferred} The deferred object.
		 */
		defer: function (action) {
			var defer = $.Deferred(action);
			var done = defer.done, fail = defer.fail, then = defer.then;

			this.extend(defer, {
				then: function () { then(arguments); return defer; },
				done: function () { done(arguments); return defer; },
				fail: function () { fail(arguments); return defer; },
				timeout: function (callback) {
					return defer.fail(function (state) {
						if (state == "timeout") {
							callback && callback(state);
						}
					})
				}
			})

			this.extend(defer, { pipe: defer.then, catch: defer.fail })
			return defer;
		},
		/**
		 * Uses a setTimeout to wait the specified milliseconds.
		 * @method wait
		 * @param {number} milliseconds The number of milliseconds to wait.
		 * @returns {Promise} A pomise object.
		 */
		wait: function (milliseconds) {
			return this.defer(function (promise) {
				setTimeout(promise.resolve, milliseconds);
			}).promise();
		},
		/**
		 * Execute something after the current tick of the event loop.
		 * An implementation that simulates asynchronous execution.
		 * @method async
		 * @returns {Promise} A pomise object.
		 */
		async: function () { return this.wait(0); }
	})

	/**
	 * Gets all the owned keys or all the owned values of the specified object.
	 * @method keys
	 * @method values
	 * @returns {Array} A collection of all keys or values.
	 */
	system.extend(system, {
		/**
		 * Gets all the owned keys of the specified object.
		 * @method keys
		 * @param {object} obj A object.
		 * @returns {Array} A collection of all keys or values.
		 */
		keys: function (obj) {
			var keys = [];
			for (var key in obj) {
				if (obj.hasOwnProperty(key)) keys.push(key);
			}
			return keys;
		},
		/**
		 * Gets all the owned values of the specified object.
		 * @method values
		 * @param {object} obj A object.
		 * @returns {Array} A collection of all keys or values.
		 */
		values: function (obj) {
			var values = [];
			for (var key in obj) {
				if (obj.hasOwnProperty(key)) values.push(obj[key]);
			}
			return values;
		}
	})

	/**
	 * Debounce and Throttle are both techniques used to control
	 * that a specified callback function executes only once at a given time.
	 * @method throttle
	 * @method debounce
	 */
	system.extend(system, {
		/**
		 * Make a function cannot be called continuously within a very short time interval,
		 * when the specified time interval has passed after the last function execution,
		 * the next call of the function can be made.
		 * @method throttle
		 * @param {int}         delay       Delay the time of the trigger, in milliseconds.
		 * @param {function}    callback    The callback method to be triggered.
		 * @param {object}      context     The context in which the callback function executes.
		 * @returns {function} The throttle function.
		 */
		throttle: function (delay, callback, context) {
			var flag = false;
			return function () {
				if (flag) return;
				flag = !flag;

				setTimeout(function () { flag = !flag }, delay);
				callback.apply(context || callback, arguments);
			}
		},
		/**
		 * Allows a function to wait a while before executing.
		 * If the function is called again within the specified time,
		 * the previous function is cancelled and the timer is reset.
		 * @method debounce
		 * @param {int}         delay       Delay the time of the trigger, in milliseconds.
		 * @param {function}    callback    The callback method to be triggered.
		 * @param {object}      context     The context in which the callback function executes.
		 * @returns {function} The debounce function.
		 */
		debounce: function (delay, callback, context) {
			var timer = null;
			return function () {
				clearTimeout(timer);
				var args = arguments;

				timer = setTimeout(function () {
					callback.apply(context || callback, args);
				}, delay);
			}
		}
	})

	/**
	 * Gets the current date time from the remote server.
	 * @method currentDate
	 * @method currentTime
	 * @method currentDateTime
	 * @method now
	 */
	system.extend(system, {
		/**
		 * Gets the current date from the server.
		 * @method currentDate
		 * @returns {string} String value for the current date.
		 */
		currentDate: function () {
			var currentDateTime = this.currentDateTime();
			return currentDateTime.substring(0, currentDateTime.indexOf(' '));
		},
		/**
		 * Gets the current time from the server.
		 * @method currentTime
		 * @returns {string} String value for the current time.
		 */
		currentTime: function () {
			var currentDateTime = this.currentDateTime();
			return currentDateTime.substring(currentDateTime.indexOf(' ') + 1, currentDateTime.length);
		},
		/**
		 * Gets the current datetime from the server.
		 * @method currentDateTime
		 * @returns {string} String value for the current date and time.
		 */
		currentDateTime: function () {
			var now = this.now();
			var date = now.toLocaleDateString().replace(/\//g, '-');
			var time = now.toTimeString().substring(0, 8);

			return date + " " + time;
		},
		/**
		 * Gets the current datetime from the server.
		 * @method now
		 * @returns {Date} The current date and time.
		 */
		now: function () {
			var result = "";

			$.ajax({
				url: env.path.gmp + '/system/datetime/now',
				async: false
			}).done(function (res) {
				result = new Date(res);
			})

			return result;
		}
	});

	/**
	 * Represents the current platform and browser environment.
	 * @property platform
	 * @property browser
	 */
	system.extend(system, {
		platform: env.platform,
		browser: env.browser
	})

	/**
	 * Get a randomly generated ID.
	 * @method guid
	 * @method random
	 */
	system.extend(system, {
		/**
		 * Creates a simple UUID.
		 * @method guid
		 * @returns {string} The guid.
		 */
		guid: function () {
			var format = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
			var times = new Date().getTime();

			return format.replace(/[xy]/g, function (char) {
				var random = (times + Math.random() * 16) % 16 | 0;
				times = Math.floor(times / 16);
				var value = char == 'x' ? random : (random & 0x7 | 0x8);
				return value.toString(16);
			});
		},
		/**
		 * Generate a random number between 0 and 65535.
		 * @method random
		 * @returns {number} A random number between 0 and 65535.
		 */
		random: function () {
			return Math.random() * 0x10000 | 0;
		}
	})

	/**
	 * Show or hide the load animation.
	 * @method loading
	 * @method loaded
	 */
	system.extend(system, {
		/**
		 * Displays the loading layer in the document.body or specified container.
		 * If the timeout is specified, the loading layer will wait for the specified time to be removed.
		 * @param {string|object} container The container to display the loading layer.
		 * @param {number} timeout Timeout time (in milliseconds).
		 * @returns {number} The loader id.
		 */
		loading: function (/* optional */ container,/* optional */  timeout) {
			container = container || 'body';
			container = this.isString(container) ? $(container) : container;
			var id = this.random();

			var loader = $("<div class='gui-loading active'></div>").attr("id", id);
			container.append(loader);

			if (timeout) {
				this.wait(timeout).then(function () {
					system.loaded(id);
				})
			}

			return id;
		},
		/**
		 * Removes all or specified loading layer from the document.
		 * @param {number} id The loader id to remove.
		 */
		loaded: function (/* optional */ id) {
			if (id) {
				$("#" + id).remove();
			}
			else {
				$(".gui-loading[id]").remove();
			}
		}
	})

	return system;
})