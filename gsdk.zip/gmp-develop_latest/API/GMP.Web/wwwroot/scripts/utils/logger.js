﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/21 16:38:32
*
***************************************************************************/

/**
 * Logger module.
 * @module gmp/logger
 * @requires gmp/env
 * @requires gmp/xhr
 */
define(['gmp/env', 'gmp/xhr'], function (env, xhr) {
	//Environment variable.
	env.logger = env.logger || {};
	env.logger.enable = env.logger.enable || true;                  //True if logging is enabled, otherwise, false.
	env.logger.level = env.logger.level || 0;                       //The minimum level of logging.
	env.logger.format = env.logger.format || "%c[/dt GMP_/a_/l] /m /e";//The format of the log messages. Support /dt /d /t /l /m /g /e.
	env.logger.colors = env.logger.colors || {
		debug: "background-color:sienna;color:white;",
		info: "background-color:aqua;color:royalblue;",
		warn: "background-color:yellow;color:red;",
		error: "background-color:red;color:yellow;"
	}

	/**
	 * Provides console output of log messages and push from the server.
	 * @class Logger
	 */
	var Logger = function () {
		var self = this;
		self.enable = env.logger.enable;
		self.group = "";
		self.level = env.logger.level;

		var inner = {};
		inner.levels = {
			debug: { value: 1, name: "DEBUG" },
			info: { value: 2, name: "INFO" },
			warn: { value: 3, name: "WARN" },
			error: { value: 4, name: "ERROR" }
		}
		inner.format = env.logger.format;
		inner.serverUrl = env.path.gmp + "/log/push";

		/**
		 * Writes a debug log message.
		 * @method debug
		 * @param {string} message  The log message.
		 * @param {string} group    The message group name.
		 */
		self.debug = function (message, group) {
			inner.write(inner.levels.debug, message, group);
		}

		/**
		 * Writes a informational log message.
		 * @method info
		 * @param {string} message  The log message.
		 * @param {string} group    The message group name.
		 */
		self.info = function (message, group) {
			inner.write(inner.levels.info, message, group);
		}

		/**
		 * Writes a warning log message.
		 * @method warn
		 * @param {string} message  The log message.
		 * @param {string} group    The message group name.
		 */
		self.warn = function (message, group) {
			inner.write(inner.levels.warn, message, group);
		}

		/**
		 * Writes a error log message.
		 * @method error
		 * @param {string} message  The log message.
		 * @param {object} ex       The exception to log.
		 * @param {string} group    The message group name.
		 */
		self.error = function (message, ex, group) {
			inner.write(inner.levels.error, message, ex, group);
		}

		/**
		 * Writes the log message.
		 * @private
		 * @method write
		 * @param {int}     level       The level of the logger.
		 * @param {string}  message     The log message.
		 * @param {object}  ex          The exception to log.
		 * @param {string}  group       The message group name.
		 */
		inner.write = function (level, message, ex, group) {
			if (!self.enable) return;
			if (level < self.level) return;
			group = group || self.group;

			//Output to the browser console.
			var consoler = console[level.name.toLowerCase()];
			var color = env.logger.colors[level.name.toLowerCase()];
			var msg = inner.formatMessage(level, message, group, ex);

			consoler.call(console, msg, color);

			//Push to remote server.
			inner.push(level, message, group, ex);
		}

		/**
		 * Format log message.
		 * @private
		 * @method formatMessage
		 * @param {int}     level       The level of the logger.
		 * @param {string}  message     The log message.
		 * @param {string}  group       The message group name.
		 * @param {object}  ex          The exception to log.
		 */
		inner.formatMessage = function (level, message, group, ex) {
			var msg = inner.format;
			var now = new Date();

			msg = msg.replace("/a", env.appid.toUpperCase());
			msg = msg.replace("/dt", now.format("yyyy-MM-dd hh:mm:ss"));
			msg = msg.replace("/d", now.format("yyyy-MM-dd"));
			msg = msg.replace("/t", now.format("hh:mm:ss"));
			msg = msg.replace("/l", level.name);
			msg = msg.replace("/m", message);
			msg = msg.replace("/g", group);
			msg = msg.replace("/e", ex || "");

			return msg;
		}

		/**
		 * Push to remote server.
		 * @private
		 * @method push
		 * @param {int}     level       The level of the logger.
		 * @param {string}  message     The log message.
		 * @param {string}  group       The message group name.
		 * @param {object}  ex          The exception to log.
		 */
		inner.push = function (level, message, group, ex) {
			xhr.post(inner.serverUrl, null, function () {
			})
		}
	}

	return new Logger();
})