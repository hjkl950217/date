﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/29 10:02:55
*
***************************************************************************/

define(['gmp/system', 'knockout', 'plugins/router'], function (system, ko, router) {
	var NavItem = function (options) {
		var self = this;

		self.route = "";
		self.moduleId = "";
		self.title = "";
		self.nav = false;
		self.hash = "";
		self.target = "_self";
		self.url = "";
		self.actived = ko.observable(false);

		self.isActive = ko.pureComputed({
			read: function () {
				var activated = router.activeInstruction();
				if (!activated) return false;

				var fragment = "#" + activated.fragment;
				var hash = self.hash;
				if (hash.indexOf("?") > -1) {
					hash = hash.substr(0, hash.indexOf("?"));
				}

				return fragment === hash;
			},
			write: function (value) {
				self.actived(value);
			}
		})

		system.extend(self, options);
	}

	return NavItem;
})