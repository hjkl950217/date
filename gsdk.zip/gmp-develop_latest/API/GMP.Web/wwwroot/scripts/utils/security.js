﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/12/18 10:25:13
*
***************************************************************************/

/**
 * Security control module, delete all bind information in document in non-debug mode.
 * @module gmp/security
 * @requires gmp/env
 * @requires durandal/system
 * @requires durandal/binder
 * @requires jquery
 */
define(['gmp/env', 'durandal/system', 'durandal/binder', 'jquery'], function (env, system, binder, $) {
	/**
	 * Callback for require.js loader.After the specified module is loaded,
	 * the script element is removed from the document.head.
	 * @method onResourceLoad
	 * @param {object}  context     The require context.
	 * @param {object}  map         The module name map.
	 * @param {Array}   depArray    The module dependencies.
	 */
	requirejs.onResourceLoad = function (context, map, depArray) {
		//Sets the module id for the specified object.
		system.setModuleId(context.defined[map.id], map.id);

		//Removes the current model's script element.
		if (env.isdebug) return;
		if (/.css$/.test(map.id)) return;

		var moduleId = map.id.replace(/^.*!/, "");
		$("[data-requiremodule='" + moduleId + "']").remove();
	};

	/**
	 * Called after every model binding operation,
	 * the module's `data-bind` and `data-view` attributes are removed from the document,
	 * and if the module is a virtual node, it is removed.
	 * @method bindingComplete
	 * @param {object} model The view model that has just been bound.
	 * @param {DOMElement} view The view that has just been bound.
	 * @param {object} instruction The object that carries the binding instructions.
	 */
	binder.bindingComplete = function (model, view, instruction) {
		if (env.isdebug) return;

		//Removes the current model's script element.
		var moduleId = model.__moduleId__;
		$("[data-requiremodule='" + moduleId + "']").remove();

		//Remove the data-bind and data-view attributes.
		$("[data-bind]").removeAttr("data-bind");
		$("[data-view]").removeAttr("data-view");

		//Remove virtual comment nodes.
		if (view.previousSibling.nodeType == 8) {
			setTimeout(function () {
				view.previousSibling.remove();
				view.nextSibling.remove();
			}, 0);
		}
	}

	//Removes the loaded model's script elements from document.head.
	if (env.isdebug) return;
	$("[data-main]").remove();
	$("[data-requiremodule]").remove();
})