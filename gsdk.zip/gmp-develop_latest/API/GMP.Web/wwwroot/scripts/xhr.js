﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/27 13:51:27
*
***************************************************************************/

/**
 * XMLHttpRequest service request module.
 * @module gmp/xhr
 * @requires gmp/env
 * @requires gmp/events
 * @requires gmp/system
 * @requires jquery
 */
define(['gmp/env', 'gmp/events', 'gmp/system', 'jquery'], function (env, events, system, $) {
	//Environment variable.
	env.xhr = env.xhr || {};
	env.xhr.baseUrl = env.xhr.baseUrl || "";    //The base url relative to the application level.
	env.xhr.timeout = env.xhr.timeout || 0;     //Request timeout, default 0 is no timeout.
	env.xhr.headers = env.xhr.headers || {      //Customize the request header.
		Appid: env.appid,
		Token: env.token
	};

	/**
	 * Provide service request encapsulation based on jQuery.ajax,
	 * support synchronous request and asynchronous request simple invocation way.
	 * @class XHR
	 */
	var XHR = function () {
		var self = this;
		self.sync = {};
		self.timeout = env.xhr.timeout;
		self.headers = env.xhr.headers;

		var inner = {};
		inner.methods = "get post delete put patch script json".split(" ");
		inner.methedType = { script: "get", json: "get" };
		inner.dataType = { script: "script", json: "json" };
		inner.contentType = {
			form: "application/x-www-form-urlencoded; charset=UTF-8",
			json: "application/json; charset=UTF-8"
		}

		/**
		 * Creates and returns an absolute request address.
		 * @private
		 * @method createUrl
		 * @param {string} url The request url.
		 * @returns {string} The url of an absolute path.
		 */
		inner.createUrl = function (url) {
			var requestUrl = "";

			//Absolute url address.
			if (url.startsWith("http")) {
				requestUrl = url;
			}

			//Relative absolute url address.
			else if (url.startsWith("/")) {
				requestUrl = env.path.gmp + url;
			}

			//Relative url address.
			else if (!url.startsWith("/")) {
				requestUrl = system.join("/", env.path.app, env.xhr.baseUrl, url);
			}

			return requestUrl.replace(/([^:])\/\//ig, "$1/");
		}

		//Create implementations for all supported request methods.
		system.each(inner.methods, function (index, method) {
			/**
			 * Sends an asynchronous request of the specified type to the server.
			 * @method get
			 * @method post
			 * @method delete
			 * @method put
			 * @method patch
			 * @method script
			 * @method json
			 * @param   {string}          url   The url at which the request was sent.
			 * @param   {string|object}   data  Data sent to the server, supported objects or JSON strings.
			 * @param   {function}        done  Callback function on successful request.
			 * @param   {function}        fail  Callback function on failed request.
			 * @param   {boolean}         async True If it's an asynchronous request, otherwise, false.
			 * @returns {Promise} Returns a Pomise object.
			 */
			self[method] = function (url, data, done, fail, async) {
				async = async == false ? false : true;
				var promise = system.defer();

				var request = {};
				request.type = inner.methedType[method] || method;
				request.contentType = inner.contentType.form;
				request.url = inner.createUrl(url);
				request.data = data;
				request.dataType = inner.dataType[method];
				request.async = async;
				request.timeout = self.timeout;
				request.headers = self.headers;
				request.success = function (res) {
					//Json to object.
					if (system.isString(res) && /^\{.*?\}$|^\[.*?\]$/.test(res)) {
						res = JSON.parse(res);
					}

					promise.resolve(res);
					events.emit("xhr.done", res);
				}
				request.error = function (response) {
					if (response.statusText == "timeout") {
						promise.reject("timeout", response);
					}
					else {
						promise.reject(response);
					}

					events.emit("xhr.error", response);
				}

				//Asynchronous load scripts force them to be loaded across domains using script tags
				//and set a 2 - second timeout to trigger an Ajax error event.
				if (method == "script") {
					request.timeout = async ? 2000 : 0;
					request.crossDomain = async;
				}

				//If the data is of type String, think of it as jSON-formatted data,
				//and send the data using the JSON format.
				if (typeof data == "string") {
					request.contentType = inner.contentType.json;
				}

				//Bind done and fail callback.
				done && promise.done(done);
				fail && promise.fail(fail);

				//Sending ajax requests.
				$.ajax(request);

				return promise;
			}

			/**
			 * Sends a synchronous request of the specified type to the server.
			 * @method sync.get
			 * @method sync.post
			 * @method sync.delete
			 * @method sync.put
			 * @method sync.patch
			 * @method sync.script
			 * @method sync.json
			 * @param   {string}          url   The url at which the request was sent.
			 * @param   {string|object}   data  Data sent to the server, supported objects or JSON strings.
			 * @param   {function}        done  Callback function on successful request.
			 * @param   {function}        fail  Callback function on failed request.
			 * @returns {Promise} Returns a Pomise object.
			 */
			self.sync[method] = function (url, data, done, fail) {
				return self[method](url, data, done, fail, false);
			}
		})

		//Returns a new XHR instance.
		self.new = function () { return new XHR(); }
	}

	return new XHR();
})