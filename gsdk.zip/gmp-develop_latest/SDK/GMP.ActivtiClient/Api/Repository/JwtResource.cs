﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using GMP.ActivtiClient.Engine;
using GMP.ActivtiClient.Model.Repository;
using GMP.Configuration;
using Newtonsoft.Json;

namespace GMP.ActivtiClient.Api.Repository
{
	public class JwtResource : BaseResource
	{
		public static string jwtKey = AppSettings.Items["WF_AppId"];
		public static string jwtPwd = AppSettings.Items["WF_Pwd"];

		public JwtToken GetJwtToken(string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetJwtVerification");
			if (string.IsNullOrEmpty(userName) && string.IsNullOrEmpty(passWord))
			{
				userName = string.IsNullOrEmpty(jwtKey) ? "edoc2" : jwtKey;
				passWord = string.IsNullOrEmpty(jwtPwd) ? "edoc2" : jwtPwd;
			}
			this.RequestExecution.DefaultBaseUrlValue(resource);
			HttpResponseMessage response = null;
			string resourceUrl = resource["Value"];
			resourceUrl += "?appId=" + userName + "&password=" + passWord;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);
				response = client.GetAsync(resourceUrl).Result;
				if (response.IsSuccessStatusCode)
				{
					// Parse the response body. Blocking!
					// 解析响应体。阻塞！
					string result = response.Content.ReadAsStringAsync().Result;
					return JsonConvert.DeserializeObject<JwtToken>(result);
				}
				return null;
			}
		}
	}
}