﻿using System.Collections.Generic;
using System.IO;
using GMP.ActivtiClient.Engine;
using GMP.ActivtiClient.Model.Repository;
using GMP.ActivtiClient.Model.ReuqestParams;

namespace GMP.ActivtiClient.Api.Repository
{
	public class ModelsResource : BaseResource
	{
		public dynamic GetModels(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModels");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<ProcessManageResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetModelById(string modelId, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModelById");
			if (!string.IsNullOrEmpty(modelId))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", modelId);
			}
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<GMP.ActivtiClient.Model.Repository.Model>(resource, userName, passWord, null);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, null);
			}
		}

		public string AddModel(GMP.ActivtiClient.Model.Repository.ProcessManage requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("AddModel");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			if (requestParams != null)
			{
				dic.Add("name", requestParams.Name);
				dic.Add("key", requestParams.Key);
				dic.Add("descript", requestParams.Descript);
				dic.Add("category", requestParams.Category);
				dic.Add("potentialStarterId", requestParams.PotentialStarterId);
				dic.Add("potentialType", requestParams.PotentialType);
				dic.Add("initiator", requestParams.Initiator);
				dic.Add("formKey", requestParams.FormKey);
				dic.Add("extProp", requestParams.ExtProp);
				dic.Add("processDefinitionXml", requestParams.ProcessDefinitionXml.ToString());
				dic.Add("creator", requestParams.Creator);
			}
			return this.RequestExecution.PostForm(resource, userName, passWord, dic);
		}

		public string UpdateModel(GMP.ActivtiClient.Model.Repository.ProcessManage requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateModel");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			if (requestParams != null)
			{
				dic.Add("id", requestParams.Id);
				dic.Add("name", requestParams.Name);
				dic.Add("key", requestParams.Key);
				dic.Add("descript", requestParams.Descript);
				dic.Add("category", requestParams.Category);
				dic.Add("potentialStarterId", requestParams.PotentialStarterId);
				dic.Add("potentialType", requestParams.PotentialType);
				dic.Add("formKey", requestParams.FormKey);
			}
			return this.RequestExecution.PostForm(resource, userName, passWord, dic);
		}

		public string DeleteModel(GMP.ActivtiClient.Model.Repository.Model requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteModel");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.DeleteExecute(resource, userName, passWord);
		}

		public string UploadModelBpmnSource(GMP.ActivtiClient.Model.Repository.Model requestParams, Stream stream, string fileName, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UploadModelBpmnSource");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.UploadFileStringExecute(resource, userName, passWord, stream, fileName);
		}

		public Stream GetModelBpmnSource(GMP.ActivtiClient.Model.Repository.Model requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModelBpmnSource");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.GetStreamExecute(resource, userName, passWord, null);
		}

		public Stream GetModelExtraSource(GMP.ActivtiClient.Model.Repository.Model requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModelExtraSource");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.GetStreamExecute(resource, userName, passWord, null);
		}

		public Stream UploadModelExtraSource(GMP.ActivtiClient.Model.Repository.Model requestParams, Stream stream, string fileName, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UploadModelExtraSource");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.UploadFileStreamExecute(resource, userName, passWord, stream, fileName);
		}

		public string UploadModelBpmnSourceExt(GMP.ActivtiClient.Model.Repository.Model requestParams, Stream stream, string fileName, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UploadModelBpmnSourceExt");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.UploadFileStringExecute(resource, userName, passWord, stream, fileName, "POST");
		}

		public string GetModelBpmnSourceExt(GMP.ActivtiClient.Model.Repository.Model requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModelBpmnSourceExt");
			if (requestParams != null && !string.IsNullOrEmpty(requestParams.Id))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", requestParams.Id);
				requestParams.Id = null;
			}
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		public string DeployByModel(Dictionary<string, string> requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeployByModel");
			return this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
		}

		public string DeleteCascade(string modelId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteCascade");
			if (!string.IsNullOrEmpty(modelId))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{id}", modelId);
			}
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		public string GetProcessXml(string modelId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessXml");
			if (!string.IsNullOrEmpty(modelId))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{modelId}", modelId);
			}
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		public string ImportModel(Stream stream, string fileName, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("ImportModel");
			return this.RequestExecution.UploadFileStringExecute(resource, userName, passWord, stream, fileName, "POST");
		}

		public string SaveNewModelSource(NewModelRequestParams requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("SaveNewModelSource");
			Dictionary<string, string> param = new Dictionary<string, string>();
			param.Add("extPropJson", requestParams.ExtPropJson);
			param.Add("processDefinitionXml", requestParams.ProcessDefinitionXml);
			param.Add("modelKey", requestParams.ModelKey);
			return this.RequestExecution.PostForm(resource, userName, passWord, param);
		}

		public string UpdateNewModelSource(NewModelRequestParams requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateNewModelSource");
			Dictionary<string, string> param = new Dictionary<string, string>();
			param.Add("extPropJson", requestParams.ExtPropJson);
			param.Add("processDefinitionXml", requestParams.ProcessDefinitionXml);
			param.Add("modelKey", requestParams.ModelKey);
			return this.RequestExecution.PostForm(resource, userName, passWord, param);
		}

		public string GetBpmDesignInfo(string modelKey, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetBpmDesignInfo");
			Dictionary<string, string> param = new Dictionary<string, string>();
			param.Add("id", modelKey);
			return this.RequestExecution.GetExecute(resource, userName, passWord, param);
		}

		public BpmProcessBeanResponse GetBpmProcessBean(string modelKey, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetBpmProcessBean");
			Dictionary<string, string> param = new Dictionary<string, string>();
			param.Add("modelKey", modelKey);
			return this.RequestExecution.GetExecute<BpmProcessBeanResponse>(resource, userName, passWord, param);
		}

		public string UpdateBpmnDesign(GMP.ActivtiClient.Model.Repository.ProcessManage requestParams, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateBpmnDesign");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			if (requestParams != null)
			{
				dic.Add("id", requestParams.Id);
				dic.Add("processDefinitionXml", requestParams.ProcessDefinitionXml.ToString());
				dic.Add("extPropJson", requestParams.ExtProp);
			}
			return this.RequestExecution.PostForm(resource, userName, passWord, dic);
		}

		public ProcessDesignResult GetProcessDesignStatus(string processId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessDesignStatus");
			Dictionary<string, string> param = new Dictionary<string, string>();
			param.Add("processId", processId);
			return this.RequestExecution.GetExecute<ProcessDesignResult>(resource, userName, passWord, param);
		}
	}
}