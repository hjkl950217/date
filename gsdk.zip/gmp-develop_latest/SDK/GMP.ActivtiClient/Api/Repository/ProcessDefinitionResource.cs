﻿using System;
using System.Collections.Generic;
using GMP.ActivtiClient.Engine;
using GMP.ActivtiClient.Model.ProcessTimeout;
using GMP.ActivtiClient.Model.Repository;

namespace GMP.ActivtiClient.Api.Repository
{
	public class ProcessDefinitionResource : BaseResource
	{
		public dynamic GetProcessDefinition(Dictionary<string, string> requestParams, ResponseType type,
											string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessDefinition");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<ProcessDefinitionResponse>(resource, userName, passWord,
																				   requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public string SetProcessDefinitionState(string processDefinitionId, bool isSupper, string userName = "",
												string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("SetProcessDefinitionState");
			if (!string.IsNullOrEmpty(processDefinitionId))
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{processDefinitionId}", processDefinitionId);
			}
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			if (isSupper == true)
			{
				requestParams.Add("state", "suspend");
			}
			else
			{
				requestParams.Add("state", "activate");
			}
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		public string GetStartFormKey(string processDefinitionId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetStartFormKey");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			if (!string.IsNullOrEmpty(processDefinitionId))
			{
				//  if (resource != null)

				// resource["Value"] = resource["Value"].Replace("{processDefinitionId}", processDefinitionId);
				requestParams.Add("processDefinitionId", processDefinitionId);
			}
			return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
		}

		public string GetStartFormKeyInCludeFormVersion(string processDefinitionId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetStartFormKeyInCludeFormVersion");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			if (!string.IsNullOrEmpty(processDefinitionId))
			{
				//  if (resource != null)

				// resource["Value"] = resource["Value"].Replace("{processDefinitionId}", processDefinitionId);
				requestParams.Add("processDefinitionId", processDefinitionId);
			}
			return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
		}

		/// <summary>
		/// 查询流程实例日志接口
		/// 不传分页参数就查所有的
		/// </summary>
		/// <param name="processInstanceId"></param>
		/// <param name="indexPage"></param>
		/// <param name="pageSize"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetProcessLogInfo(string processInstanceId, string indexPage, string pageSize, string userName = "", string passWord = "")
		{
			try
			{
				Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessLogInfo");
				Dictionary<string, string> dic = new Dictionary<string, string>();
				dic["processInstanceId"] = processInstanceId;
				dic["currentPage"] = indexPage;
				dic["pageSize"] = pageSize;
				return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
			}
			catch (Exception e)
			{
				return "";
			}
		}

		/// <summary>
		/// 查询流程实例日志接口 (New)
		/// 不传分页参数就查所有的
		/// </summary>
		/// <param name="processInstanceId"></param>
		/// <param name="indexPage"></param>
		/// <param name="pageSize"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetProcessLogs(string processInstanceId, string indexPage, string pageSize, string userName = "", string passWord = "")
		{
			try
			{
				Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessLogs");
				Dictionary<string, string> dic = new Dictionary<string, string>();
				dic["processInstanceId"] = processInstanceId;
				dic["currentPage"] = indexPage;
				dic["pageSize"] = pageSize;
				return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
			}
			catch (Exception e)
			{
				return "";
			}
		}

		/// <summary>
		/// 查询流程实例日志接口 (New)
		/// 不传分页参数就查所有的
		/// </summary>
		/// <param name="processInstanceId"></param>
		/// <param name="indexPage"></param>
		/// <param name="pageSize"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetProcessNewLogs(string processInstanceId, string userName = "", string passWord = "")
		{
			try
			{
				Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessLogs");
				Dictionary<string, string> dic = new Dictionary<string, string>();
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{processInstanceId}", processInstanceId);
				dic["processInstanceId"] = processInstanceId;
				return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
			}
			catch (Exception e)
			{
				return "";
			}
		}

		public string UpdateProcessGroup(string processDefinitionKey, string category, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateProcessGroup");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			dic["processDefinitionId"] = processDefinitionKey;
			dic["category"] = category;
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		/// <summary>
		/// 根据流程key获取当前发布最新的版本
		/// </summary>
		/// <param name="processKey"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetLastVersionProcessDefinitionByKey(string processKey, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetLastVersionProcessDefinitionByKey");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			dic["processKey"] = processKey;
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		/// 根据流程key获取当前发布最新的版本
		/// </summary>
		/// <param name="processKey"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetVarisByProcKey(string processKey, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetVarisByProcKey");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			dic["key"] = processKey;
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		/// <summary>
		/// 获取最新版本的流程列表
		/// </summary>
		/// <param name="pageIndex">页索引</param>
		/// <param name="rows">记录数</param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string GetLastVersionProcessDefinitions(string pageIndex, string rows, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetLastVersionProcessDefinitions");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			dic["page"] = pageIndex;
			dic["rows"] = rows;
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		public string GetListSignatureChecked(string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetListSignatureChecked");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		public string SaveOrUpdateSignData(string signStr, string userName = "",
											   string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("SaveOrUpdateSignData");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("signStr", signStr);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		public string SaveSignature(string rowsStr, string userName = "",
											   string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("SaveSignature");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("rowsStr", rowsStr);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		public string DeleteSignature(string jsonStr, string userName = "",
											 string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteSignature");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("jsonStr", jsonStr);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		public string GetListSignature(string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetListSignature");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			return this.RequestExecution.GetExecute(resource, userName, passWord, dic);
		}

		public string DeleteSignData(string idsStr, string userName = "",
										  string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteSignData");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("idsStr", idsStr);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		/// <summary>
		/// 获取流程超时数据
		/// </summary>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		public List<ProcessTimeoutRequestParams> GetProcessOverTimeList(string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessOverTimeList");
			Dictionary<string, string> dic = new Dictionary<string, string>();
			return this.RequestExecution.GetExecute<List<ProcessTimeoutRequestParams>>(resource, userName, passWord, dic);
		}

		/// <summary>
		/// 删除流程超时数据
		/// </summary>
		/// <param name="processId"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		public void DeleteProcessOverTimeByProcessId(string processId, string userName = "",
										  string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteProcessOverTimeByProcessId");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("processId", processId);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
		}

		/// <summary>
		/// 修改邮件发送次数
		/// </summary>
		/// <param name="processId"></param>
		/// <param name="countNum"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		public void UpdateProcessOvertimeCount(string processId, string countNum, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateProcessOvertimeCount");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("processId", processId);
			requestParams.Add("countNum", countNum);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
		}

		/// <summary>
		/// 修改超时提醒天数
		/// </summary>
		/// <param name="processId"></param>
		/// <param name="countNum"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		public string UpdateProcessOverTimeDay(string processId, string newDay, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateProcessOverTimeDay");
			Dictionary<string, string> requestParams = new Dictionary<string, string>();
			requestParams.Add("processId", processId);
			requestParams.Add("newDay", newDay);
			string json = this.RequestExecution.PostForm(resource, userName, passWord, requestParams);
			return json;
		}

		public string GetHighlighted(string processInstanceId, string userName = "", string passWord = "")
		{
			string result;
			try
			{
				Dictionary<string, string> requestMappingByMethodName = RequestMappingBuilder.GetRequestMappingByMethodName("GetHighlighted");
				Dictionary<string, string> requestParams = new Dictionary<string, string>();
				if (requestMappingByMethodName != null)
				{
					requestMappingByMethodName["Value"] = requestMappingByMethodName["Value"].Replace("{processInstanceId}", processInstanceId);
				}
				result = base.RequestExecution.GetExecute(requestMappingByMethodName, userName, passWord, requestParams);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}

		public string Diagram_layout_Id(string processDefinitionId, string userName = "", string passWord = "")
		{
			string result;
			try
			{
				Dictionary<string, string> requestMappingByMethodName = RequestMappingBuilder.GetRequestMappingByMethodName("Diagram_layout_Id");
				Dictionary<string, string> requestParams = new Dictionary<string, string>();
				if (requestMappingByMethodName != null)
				{
					requestMappingByMethodName["Value"] = requestMappingByMethodName["Value"].Replace("{processDefinitionId}", processDefinitionId);
				}
				result = base.RequestExecution.GetExecute(requestMappingByMethodName, userName, passWord, requestParams);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}

		public string Diagram_layout_Key(string processDefinitionKey, string userName = "", string passWord = "")
		{
			string result;
			try
			{
				Dictionary<string, string> requestMappingByMethodName = RequestMappingBuilder.GetRequestMappingByMethodName("Diagram_layout_Key");
				Dictionary<string, string> requestParams = new Dictionary<string, string>();
				if (requestMappingByMethodName != null)
				{
					requestMappingByMethodName["Value"] = requestMappingByMethodName["Value"].Replace("{processDefinitionKey}", processDefinitionKey);
				}
				result = base.RequestExecution.GetExecute(requestMappingByMethodName, userName, passWord, requestParams);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}

		public string GetActivityInfos(string processInstanceId, string userName = "", string passWord = "")
		{
			string result;
			try
			{
				Dictionary<string, string> requestMappingByMethodName = RequestMappingBuilder.GetRequestMappingByMethodName("GetActivityInfos");
				Dictionary<string, string> requestParams = new Dictionary<string, string>();
				if (requestMappingByMethodName != null)
				{
					requestMappingByMethodName["Value"] = requestMappingByMethodName["Value"].Replace("{processInstanceId}", processInstanceId);
				}
				result = base.RequestExecution.GetExecute(requestMappingByMethodName, userName, passWord, requestParams);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}
	}
}