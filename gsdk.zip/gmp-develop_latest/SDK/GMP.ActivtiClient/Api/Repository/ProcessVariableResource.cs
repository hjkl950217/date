﻿using System.Collections.Generic;
using GMP.ActivtiClient.Engine;
using GMP.ActivtiClient.Model.Repository;

namespace GMP.ActivtiClient.Api.Repository
{
	public class ProcessVariableResource : BaseResource
	{
		public dynamic GetModelVariables(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetModelVariables");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<ModelVariableResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetVars(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetVars");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<List<ModelVariable>>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public string AddModelVariable(Dictionary<string, string> requestBpmModelVariable, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("AddModelVariable");
			return this.RequestExecution.PostForm(resource, userName, passWord, requestBpmModelVariable);
		}

		public string UpdateModelVariable(Dictionary<string, string> requestBpmModelVariable, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("UpdateModelVariable");
			return this.RequestExecution.PostForm(resource, userName, passWord, requestBpmModelVariable);
		}

		public string DeleteModelVariable(Dictionary<string, string> requestBpmModelVariable, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteModelVariable");
			return this.RequestExecution.PostExecute(resource, userName, passWord, requestBpmModelVariable);
		}

		public string SaveOrUpadteVars(Dictionary<string, string> requestBpmModelVariable, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("SaveOrUpadteVars");
			return this.RequestExecution.PostForm(resource, userName, passWord, requestBpmModelVariable);
		}
	}
}