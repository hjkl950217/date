﻿using System.Collections.Generic;
using GMP.ActivtiClient.Engine;

namespace GMP.ActivtiClient.Api.Runtime
{
	public class ProcessInstanceResource : BaseResource
	{
		public string GetProcessInstance(string processInstanceId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetProcessInstance");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{processInstanceId}", processInstanceId);
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		/// <summary>
		/// 删除实例
		/// </summary>
		/// <param name="processInstanceId">实例号</param>
		/// <param name="forced">是否强制删除</param>
		/// <param name="deleteReason">删除原因</param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string DeleteProcessInstance(string processInstanceId, bool forced, string deleteReason, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DeleteProcessInstance");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{processInstanceId}", processInstanceId);
			if (resource != null)
			{
				Dictionary<string, string> formData = new Dictionary<string, string>();
				formData.Add("forced", forced.ToString());
				formData.Add("deleteReason", deleteReason.ToString());
				return this.RequestExecution.GetExecute(resource, userName, passWord, formData);
			}
			return "";
		}

		/// <summary>
		/// 删除实例 验证当前审批用户是否为userId 如果不是不能删除
		/// </summary>
		/// <param name="processInstanceId">实例号</param>
		/// <param name="forced">是否强制删除</param>
		/// <param name="deleteReason">删除原因</param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string DeleteProcessInstance(string processInstanceId, string userId, bool forced, string deleteReason, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("AbortProcessInstance");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{processInstanceId}", processInstanceId);
			if (resource != null)
			{
				Dictionary<string, string> formData = new Dictionary<string, string>();
				formData.Add("forced", forced.ToString());
				formData.Add("userId", userId);
				formData.Add("deleteReason", deleteReason);
				return this.RequestExecution.GetExecute(resource, userName, passWord, formData);
			}
			return "";
		}

		/// <summary>
		/// 终止实例
		/// </summary>
		/// <param name="processInstanceId">实例号</param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string Suspension(string processInstanceId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("Suspension");
			if (resource != null)
			{
				Dictionary<string, string> formData = new Dictionary<string, string>();
				formData.Add("id", processInstanceId);
				return this.RequestExecution.PostExecute(resource, userName, passWord, formData);
			}
			return "";
		}

		/// <summary>
		/// 终止实例
		/// </summary>
		/// <param name="processInstanceId">实例号</param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public string Suspension(string processInstanceId, bool isCancel, string taskId, string summary, string remark, string signDataStr, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("Suspension");
			if (resource != null)
			{
				Dictionary<string, string> formData = new Dictionary<string, string>();
				formData.Add("id", processInstanceId);
				formData.Add("taskId", taskId);
				formData.Add("summary", summary);
				formData.Add("remark", remark);
				formData.Add("signDataStr", signDataStr);

				return this.RequestExecution.PostExecute(resource, userName, passWord, formData);
			}
			return "";
		}

		public string BatchStopProcessInstance(string incidentIds, string taskIds, string summary, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("BatchStopProcessInstance");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["incidentIds"] = incidentIds;
			formParams["taskIds"] = taskIds;
			formParams["summary"] = summary;
			return this.RequestExecution.PostExecute(resource, userName, passWord, formParams);
		}
	}
}