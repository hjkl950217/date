﻿using System;
using System.Collections.Generic;
using GMP.ActivtiClient.Engine;
using GMP.ActivtiClient.Model.Repository;
using GMP.ActivtiClient.Model.Runtime;
using GMP.ActivtiClient.Model.Runtime.Count;
using GMP.ActivtiClient.Model.Task;

namespace GMP.ActivtiClient.Api.Runtime
{
	public class TaskResource : BaseResource
	{
		public dynamic GetInboxList(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetInboxList");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<CustomTaskResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetTaskCount(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetTaskCount");
			if (requestParams != null)
			{
				if (resource != null)
					resource["Value"] = resource["Value"].Replace("{type}", requestParams["type"]).Replace("{groupType}", requestParams["groupType"]);
				if (requestParams.ContainsKey("type"))
					requestParams.Remove("type");
				if (requestParams.ContainsKey("groupType"))
					requestParams.Remove("groupType");
			}
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<TaskCountResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetApplyList(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			try
			{
				Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetApplyList");
				if (ResponseType.Entity == type)
				{
					return this.RequestExecution.GetExecute<ApplyModelResponse>(resource, userName, passWord, requestParams);
				}
				else
				{
					return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
				}
			}
			catch (Exception e)
			{
				return null;
			}
		}

		public dynamic GetCompleteList(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetCompleteList");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<CompleteTaskResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetInitList(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetInitList");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<InitTaskResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public dynamic GetArchiveList(Dictionary<string, string> requestParams, ResponseType type, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetArchiveList");
			if (ResponseType.Entity == type)
			{
				return this.RequestExecution.GetExecute<ArchiveTaskResponse>(resource, userName, passWord, requestParams);
			}
			else
			{
				return this.RequestExecution.GetExecute(resource, userName, passWord, requestParams);
			}
		}

		public string StartProcessInstance(StartProcessRequest requestParams, List<VariablesRequest> vars, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("StartProcessInstance");
			string requsetParamsStr = Newtonsoft.Json.JsonConvert.SerializeObject(requestParams);
			string varsStr = Newtonsoft.Json.JsonConvert.SerializeObject(vars);
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["requsetParams"] = requsetParamsStr;
			formParams["variablesParams"] = varsStr;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string CompleteTask(string taskId, string comment, List<VariablesRequest> vars, string remark, string signDataStr, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("CompleteTask");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{taskId}", taskId);
			string requsetParamsStr = comment;
			string varsStr = Newtonsoft.Json.JsonConvert.SerializeObject(vars);
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["comment"] = requsetParamsStr;
			formParams["variablesParams"] = varsStr;
			formParams["incidentRemark"] = remark;
			formParams["signDataStr"] = signDataStr;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string RejectPrevActivity(string rejectOrgin, string taskId, string remark, string signDataStr, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("RejectPrevActivity");
			string requsetParamsStr = rejectOrgin;
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["rejectOrgin"] = requsetParamsStr;
			formParams["taskId"] = taskId;
			formParams["incidentRemark"] = remark;
			formParams["signDataStr"] = signDataStr;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string RejectStarterActivity(string rejectOrgin, string taskId, bool isBackReturn, string remark, string signDataStr, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("RejectStarterActivity");
			string requsetParamsStr = rejectOrgin;
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["rejectOrgin"] = requsetParamsStr;
			formParams["taskId"] = taskId;
			formParams["isBackReturn"] = isBackReturn.ToString();
			formParams["incidentRemark"] = remark;
			formParams["signDataStr"] = signDataStr;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string GetTask(string taskId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetTask");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{type}", taskId);
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		public string PlusSign(string taskId, string plusSignType, bool isSequential, string commonet, string assignees, string remark, string signDataStr, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("PlusSign");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{taskId}", taskId).Replace("{plusSignType}", plusSignType);
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams.Add("commonet", commonet);
			formParams.Add("isSequential", isSequential.ToString());
			formParams.Add("assigenLists", assignees);
			formParams.Add("incidentRemark", remark);
			formParams.Add("signDataStr", signDataStr);
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string GetActivityInfo(string taskId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetActivityInfo");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{taskId}", taskId);
			return this.RequestExecution.GetExecute(resource, userName, passWord, null);
		}

		public string Revocation(string taskId, List<VariablesRequest> vars, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("Revocation");
			if (resource != null)
				resource["Value"] = resource["Value"].Replace("{taskId}", taskId);
			string varsStr = Newtonsoft.Json.JsonConvert.SerializeObject(vars);
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["variablesParams"] = varsStr;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string DelegateAllTask(string userId, string delegateUserId, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DelegateAllTask");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["userId"] = userId;
			formParams["delegateUserId"] = delegateUserId;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string DelegateTasks(string taskIds, string delegateUserId, bool isSingleMandate = false, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("DelegateTasks");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["taskIds"] = taskIds;
			formParams["delegateUserId"] = delegateUserId;
			formParams["isSingleMandate"] = isSingleMandate.ToString();
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string CancelDelegates(string delegateIds, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("CancelDelegates");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["delegateIds"] = delegateIds;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string CancelDelegateByAssignee(string assignee, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("CancelDelegateByAssignee");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["assignee"] = assignee;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		public string ClaimTask(string userId, string taskIds, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("ClaimTask");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["userId"] = userId;
			formParams["taskIds"] = taskIds;
			return this.RequestExecution.GetExecute(resource, userName, passWord, formParams);
		}

		public string GgetMyCandidateTasks(string pageIndex, string pageSize, string candidateUser, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("GetMyCandidateTasks");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["page"] = pageIndex;
			formParams["rows"] = pageSize;
			formParams["candidateUser"] = candidateUser;
			return this.RequestExecution.PostForm(resource, userName, passWord, formParams);
		}

		/// <summary>
		/// 检测用户任务是否超时
		/// </summary>
		/// <param name="requestParams"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public List<TaskOverTimeResponse> CheckTaskOverTime(string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("CheckTaskOverTime");
			return this.RequestExecution.GetExecute<List<TaskOverTimeResponse>>(resource, userName, passWord, new Dictionary<string, string>());
		}

		/// <summary>
		/// 对超时任务处理
		/// </summary>
		/// <param name="requestParams"></param>
		/// <param name="userName"></param>
		/// <param name="passWord"></param>
		/// <returns></returns>
		public bool TaskOverTimeHandler(string proceInsId, string taskInsId, string userName = "", string passWord = "")
		{
			try
			{
				Dictionary<string, string> requestParams = new Dictionary<string, string>();
				requestParams.Add("proceInsId", proceInsId);
				requestParams.Add("taskInsId", taskInsId);
				Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("TaskOverTimeHandler");
				this.RequestExecution.GetExecute<List<TaskOverTimeResponse>>(resource, userName, passWord, requestParams);
				return true;
			}
			catch
			{
				return false;
			}
		}

		public string BatchRejectPrevActivity(string taskIds, string rejectOrgin, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("BatchRejectPrevActivity");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["taskIds"] = taskIds;
			formParams["rejectOrgin"] = rejectOrgin;
			return this.RequestExecution.PostExecute(resource, userName, passWord, formParams);
		}

		public string BatchCompleteTask(string taskIds, string comment, List<VariablesRequest> vars, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("BatchCompleteTask");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["taskIds"] = taskIds;
			if (vars != null && vars.Count > 0)
			{
				string varsStr = Newtonsoft.Json.JsonConvert.SerializeObject(vars);
				formParams["variablesParams"] = varsStr;
			}
			formParams["comment"] = comment;

			return this.RequestExecution.PostExecute(resource, userName, passWord, formParams);
		}

		public string BatchRejectStarterActivity(string taskIds, string rejectOrgin, string userName = "", string passWord = "")
		{
			Dictionary<string, string> resource = RequestMappingBuilder.GetRequestMappingByMethodName("BatchRejectStarterActivity");
			Dictionary<string, string> formParams = new Dictionary<string, string>();
			formParams["taskIds"] = taskIds;
			formParams["rejectOrgin"] = rejectOrgin;
			return this.RequestExecution.PostExecute(resource, userName, passWord, formParams);
		}
	}
}