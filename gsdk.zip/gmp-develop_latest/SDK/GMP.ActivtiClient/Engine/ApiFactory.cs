﻿namespace GMP.ActivtiClient.Engine
{
	public class ApiFactory
	{
		private static string _host = "";

		public static void SetApiUrl(string url)
		{
			_host = url;
		}

		public static string GetApiUrl()
		{
			return _host;
		}
	}
}