﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using GMP.Configuration;

namespace GMP.ActivtiClient.Engine
{
	public class BaseResource
	{
		private string ActivtiBaseUrl { set; get; }
		protected string UserName { set; get; }
		protected string PassWord { set; get; }

		public BaseResource()
		{
			if (string.IsNullOrEmpty(this.ActivtiBaseUrl))
			{
				this.ActivtiBaseUrl = AppSettings.Items["ActivtiBaseUrl"];
				this.UserName = AppSettings.Items["Activti.UserName"];
				this.PassWord = AppSettings.Items["Activti.PassWord"];
			}
		}

		private Execution _requestExecution;

		protected Execution RequestExecution
		{
			get { return this._requestExecution ?? (this._requestExecution = new Execution(this.ActivtiBaseUrl, this.UserName, this.PassWord)); }
		}

		public Dictionary<string, string> GetCurrentMethodMapping()
		{
			string mapping = "";
			StackFrame frame = new StackFrame(1);       //偏移一个函数位,也即是获取当前函数的前一个调用函数
			MethodBase method = frame.GetMethod();
			Dictionary<string, string> dic = new Dictionary<string, string>();
			object[] mappingAttr = method.GetCustomAttributes(typeof(RequestMappingAttribute), false);
			if (mappingAttr != null && mappingAttr.Length > 0)
			{
				RequestMappingAttribute attribute =
				(GMP.ActivtiClient.Engine.RequestMappingAttribute)(mappingAttr[0]);
				dic.Add("BaseUrl", attribute.BaseUrl);
				dic.Add("Value", attribute.Value);
			}
			else
			{
				Console.WriteLine("请在当前方法上加上Mapping信息！");
			}
			return dic;
		}
	}
}