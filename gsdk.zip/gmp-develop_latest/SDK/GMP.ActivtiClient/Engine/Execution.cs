﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using GMP.Configuration;

namespace GMP.ActivtiClient.Engine
{
	public class Execution
	{
		private readonly string _baseUrl;
		private readonly string _userName;
		private readonly string _passWord;

		public Execution(string baseUrl, string userName, string passWord)
		{
			this._baseUrl = baseUrl;
			this._userName = userName;
			this._passWord = passWord;
		}

		public string GetExecute(Dictionary<string, string> resource, string userName, string passWord, Dictionary<string, string> requestParams)
		{
			string json = "{}";
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			json = RequestUtils.GetReturnJson(resource, heads, requestParams);
			return json;
		}

		public void DefaultBaseUrlValue(Dictionary<string, string> resource)
		{
			if (resource.ContainsKey("BaseUrl") && string.IsNullOrEmpty(resource["BaseUrl"]))
			{
				resource["BaseUrl"] = LoadBalance.Instance.Register("apm_url", this._baseUrl);
			}
			else
			{
				string apiUrl = ApiFactory.GetApiUrl();
				if (string.IsNullOrEmpty(apiUrl))
				{
					apiUrl = AppSettings.Items[resource["BaseUrl"]];
				}
				string url = apiUrl;
				resource["BaseUrl"] = LoadBalance.Instance.Register("apm_ext", url);
			}
		}

		public Stream GetStreamExecute(Dictionary<string, string> resource, string userName, string passWord, Dictionary<string, string> requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			Stream stream = RequestUtils.GetReturnStream(resource, heads, requestParams);
			return stream;
		}

		public void SetUserNameAndPassWord(ref string userName, ref string passWord)
		{
			if (string.IsNullOrEmpty(userName) && string.IsNullOrEmpty(passWord))
			{
				userName = this._userName;
				passWord = this._passWord;
			}
		}

		public T GetExecute<T>(Dictionary<string, string> resource, string userName, string passWord, Dictionary<string, string> requestParams)
		{
			T obj = default(T);
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			obj = RequestUtils.GetReturnObject<T>(resource, heads, requestParams);
			return obj;
		}

		public string PostExecute(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.PostReturnJson(resource, heads, requestParams);
			return json;
		}

		public string Post<T>(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.PostReturnJson<T>(resource, heads, requestParams);
			return json;
		}

		public T PostExecute<T>(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			T obj = RequestUtils.PostReturnObject<T>(resource, heads, requestParams);
			return obj;
		}

		public string PutExecute(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.PutReturnJson(resource, heads, requestParams);
			return json;
		}

		public string PutModelExecute<T>(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.PutReturnJson<T>(resource, heads, requestParams);
			return json;
		}

		public T PutExecute<T>(Dictionary<string, string> resource, string userName, string passWord, dynamic requestParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			T obj = RequestUtils.PutReturnObject<T>(resource, heads, requestParams);
			return obj;
		}

		public string PostForm(Dictionary<string, string> resource, string userName, string passWord, Dictionary<string, string> formParams)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.PostFormJson(resource, heads, formParams);
			return json;
		}

		public string DeleteExecute(Dictionary<string, string> resource, string userName, string passWord)
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = RequestUtils.DeleteReturnJson(resource, heads);
			return json;
		}

		public string UploadFileStringExecute(Dictionary<string, string> resource, string userName, string passWord, Stream stream, string fileName, string method = "PUT")
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);
			string json = "";
			if (method.Equals("PUT"))
			{
				json = RequestUtils.UploadFileReturnJson(resource, heads, stream, fileName);
			}
			else
			{
				json = RequestUtils.UploadFileReturnJson(resource, heads, stream, fileName, "POST");
			}
			return json;
		}

		public Stream UploadFileStreamExecute(Dictionary<string, string> resource, string userName, string passWord, Stream stream, string fileName, string method = "PUT")
		{
			this.SetUserNameAndPassWord(ref userName, ref passWord);
			Dictionary<string, string> heads = new Dictionary<string, string>();
			string userNamePassword = userName + ":" + passWord;
			heads.Add("Authorization", "Basic " +
											   Convert.ToBase64String(new ASCIIEncoding().GetBytes(userNamePassword)));
			this.DefaultBaseUrlValue(resource);

			Stream streamResult = RequestUtils.UploadFileReturnStream(resource, heads, stream, fileName, method);
			return streamResult;
		}
	}
}