﻿namespace GMP.ActivtiClient.Engine
{
	public enum FormatType
	{
		Default = 0,
		Json = 1,
		Xml = 2
	}
}