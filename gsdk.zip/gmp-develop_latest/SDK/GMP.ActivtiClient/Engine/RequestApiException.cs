﻿using System;

namespace GMP.ActivtiClient.Engine
{
	public class RequestApiException : Exception
	{
		public RequestApiException(string message)
			: base(message)
		{
		}

		public RequestApiException(string message, Exception innerException)
			: base(message, innerException)
		{
		}
	}
}