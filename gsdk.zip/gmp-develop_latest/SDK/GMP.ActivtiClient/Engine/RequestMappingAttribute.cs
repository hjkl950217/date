﻿using System;

namespace GMP.ActivtiClient.Engine
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
	public class RequestMappingAttribute : Attribute
	{
		public string Value { set; get; }
		public string BaseUrl { set; get; }
	}
}