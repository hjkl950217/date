﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace GMP.ActivtiClient.Engine
{
	public class RequestMappingBuilder
	{
		public static Dictionary<string, string> GetRequestMappingByMethodName(string name)
		{
			Dictionary<string, string> requestMapping = RequestMappingCache.GetMethodByKey(name);
			Dictionary<string, string> dic = new Dictionary<string, string>();
			if (requestMapping == null)
			{
				Dictionary<string, string> dictionary = new Dictionary<string, string>();
				Stream tempStream =
				  System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("GMP.ActivtiClient.Config.RequestMethodConfig.xml");
				System.Xml.Linq.XDocument xDoc = System.Xml.Linq.XDocument.Load(tempStream);
				System.Xml.Linq.XElement scanners = xDoc.Descendants("Method").Where(node => node.Attribute("key").Value == name).FirstOrDefault();
				if (scanners != null)
				{
					System.Xml.Linq.XAttribute typeAttr = scanners.Attribute("type");
					if (typeAttr != null)
					{
						string type = typeAttr.Value;
						dictionary.Add("type", type);
					}
					System.Xml.Linq.XAttribute baseUrlAttr = scanners.Attribute("BaseUrl");
					if (baseUrlAttr != null)
					{
						string baseUrl = baseUrlAttr.Value;
						dictionary.Add("BaseUrl", baseUrl);
					}
					System.Xml.Linq.XAttribute valueAttr = scanners.Attribute("Value");
					if (valueAttr != null)
					{
						string value = valueAttr.Value;
						dictionary.Add("Value", value);
					}
					RequestMappingCache.AddMethod(name, dictionary);
					foreach (KeyValuePair<string, string> map in dictionary)
					{
						dic.Add(map.Key, map.Value);
					}
				}
			}
			else
			{
				foreach (KeyValuePair<string, string> map in requestMapping)
				{
					dic.Add(map.Key, map.Value);
				}
			}
			return dic;
		}
	}
}