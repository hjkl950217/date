﻿using System.Collections.Generic;

namespace GMP.ActivtiClient.Engine
{
	public class RequestMappingCache
	{
		/// <summary>
		/// 定义静态字典存储信息(缓存)
		/// </summary>
		public static Dictionary<string, Dictionary<string, string>> _cache = new Dictionary<string, Dictionary<string, string>>();

		//添加缓存
		public static void AddMethod(string key, Dictionary<string, string> u)
		{
			if (!_cache.ContainsKey(key))
				_cache.Add(key, u);
			//_cache[getuserKey(u)] = u;
		}

		//删除指定缓存
		public static void DeleteMethod(string key)
		{
			if (_cache.ContainsKey(key))
				_cache.Remove(key);
		}

		//获取指定缓存
		public static Dictionary<string, string> GetMethodByKey(string key)
		{
			if (_cache.ContainsKey(key))
				return _cache[key];
			else
			{
				return null;
			}
		}

		//获取所有缓存
		public static Dictionary<string, Dictionary<string, string>> GetAllMethod()
		{
			return _cache;
		}

		//删除所有缓存
		public static void RemoveAll()
		{
			_cache.Clear();
		}
	}
}