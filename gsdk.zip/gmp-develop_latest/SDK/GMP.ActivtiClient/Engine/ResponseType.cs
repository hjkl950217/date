﻿namespace GMP.ActivtiClient.Engine
{
	public enum ResponseType
	{
		Default = 0,
		Entity = 1,
		Json = 2
	}
}