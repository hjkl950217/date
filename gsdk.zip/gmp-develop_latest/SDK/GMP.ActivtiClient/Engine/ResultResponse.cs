﻿namespace GMP.ActivtiClient.Engine
{
	public class ResultResponse
	{
		/// <summary>
		/// 是否成功
		/// </summary>
		public bool IsSuccess { set; get; }

		/// <summary>
		/// 返回的结果
		/// </summary>
		public dynamic Result { set; get; }

		/// <summary>
		/// 备注信息
		/// </summary>
		public string Remark { set; get; }

		/// <summary>
		/// 错误信息
		/// </summary>
		public string Error { set; get; }
	}
}