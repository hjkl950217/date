﻿namespace GMP.ActivtiClient.Model.ProcessTimeout
{
	public class ProcessTimeoutRequestParams
	{
		public string ProcessId { get; set; }

		public string OverTime { get; set; }

		public string Initiator { get; set; }

		public string InitiatorTime { get; set; }

		public int CountNum { get; set; }

		public string UserGroupName { get; set; }

		public string UserGroupGuid { get; set; }

		public int UserGroupId { get; set; }

		public int UserGroupType { get; set; }

		public string EmailTemplate { get; set; }

		public string DesignName { get; set; }

		public string InitatorName { get; set; }

		public string Countdown { get; set; }
	}
}