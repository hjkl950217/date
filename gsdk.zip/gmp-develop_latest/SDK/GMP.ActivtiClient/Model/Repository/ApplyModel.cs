﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ApplyModel
	{
		[JsonProperty("tenantId")]
		public string TenantId { get; set; }

		[JsonProperty("id")]
		public string Id { get; set; }

		[JsonProperty("category")]
		public string Category { get; set; }

		[JsonProperty("diagramResourceName")]
		public string DiagramResourceName { get; set; }

		[JsonProperty("description")]
		public object Description { get; set; }

		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("deploymentId")]
		public string DeploymentId { get; set; }

		[JsonProperty("key")]
		public string Key { get; set; }

		[JsonProperty("version")]
		public int Version { get; set; }

		[JsonProperty("formKey")]
		public string FormKey { set; get; }
	}
}