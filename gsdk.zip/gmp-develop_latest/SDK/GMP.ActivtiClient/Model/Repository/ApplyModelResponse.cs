﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ApplyModelResponse : PageInfoResponse
	{
		[JsonProperty("rows")]
		public ApplyModel[] Rows { get; set; }
	}
}