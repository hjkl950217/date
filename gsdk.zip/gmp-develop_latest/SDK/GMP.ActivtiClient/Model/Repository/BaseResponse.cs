﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class BaseResponse
	{
		[JsonProperty("total")]
		public int Total { get; set; }

		[JsonProperty("start")]
		public int Start { get; set; }

		[JsonProperty("sort")]
		public string Sort { get; set; }

		[JsonProperty("order")]
		public string Order { get; set; }

		[JsonProperty("size")]
		public int Size { get; set; }
	}
}