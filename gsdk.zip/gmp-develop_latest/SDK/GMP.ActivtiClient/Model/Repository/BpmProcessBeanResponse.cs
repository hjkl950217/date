﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class BpmProcessBeanResponse
	{
		[JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
		public int Id { get; set; }

		[JsonProperty("extPropJson", NullValueHandling = NullValueHandling.Ignore)]
		public string ExtPropJson { get; set; }

		[JsonProperty("modelKey", NullValueHandling = NullValueHandling.Ignore)]
		public string ModelKey { get; set; }

		[JsonProperty("actProcdefXml", NullValueHandling = NullValueHandling.Ignore)]
		public byte[] ActProcdefXml { get; set; }

		[JsonProperty("processDefinitionXml", NullValueHandling = NullValueHandling.Ignore)]
		public string ProcessDefinitionXml { get; set; }
	}
}