﻿using System;
using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class JwtToken
	{
		[JsonProperty("token")]
		public string Token { set; get; }

		[JsonProperty("timeOut")]
		public DateTime TimeOut { set; get; }

		[JsonProperty("isSuccess")]
		public bool IsSuccess { set; get; }
	}
}