﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class Model
	{
		[JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
		public string Name { get; set; }

		[JsonProperty("key", NullValueHandling = NullValueHandling.Ignore)]
		public object Key { get; set; }

		[JsonProperty("category", NullValueHandling = NullValueHandling.Ignore)]
		public object Category { get; set; }

		[JsonProperty("version", NullValueHandling = NullValueHandling.Ignore)]
		public int Version { get; set; }

		[JsonProperty("metaInfo", NullValueHandling = NullValueHandling.Ignore)]
		public string MetaInfo { get; set; }

		[JsonProperty("deploymentId", NullValueHandling = NullValueHandling.Ignore)]
		public object DeploymentId { get; set; }

		[JsonProperty("tenantId", NullValueHandling = NullValueHandling.Ignore)]
		public string TenantId { get; set; }

		[JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
		public string Id { get; set; }

		[JsonProperty("url", NullValueHandling = NullValueHandling.Ignore)]
		public string Url { get; set; }

		[JsonProperty("createTime", NullValueHandling = NullValueHandling.Ignore)]
		public object CreateTime { get; set; }

		[JsonProperty("lastUpdateTime", NullValueHandling = NullValueHandling.Ignore)]
		public object LastUpdateTime { get; set; }

		[JsonProperty("deploymentUrl", NullValueHandling = NullValueHandling.Ignore)]
		public object DeploymentUrl { get; set; }
	}
}