﻿namespace GMP.ActivtiClient.Model.Repository
{
	public class ModelMeta
	{
		public string Descript { set; get; }
		public string PotentialStarterId { set; get; }
		public int PotentialStarterType { set; get; }
		public string Initiator { set; get; }
		public string FormKey { set; get; }
	}
}