﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ModelResponse : BaseResponse
	{
		[JsonProperty("data")]
		public Model[] Data { get; set; }
	}
}