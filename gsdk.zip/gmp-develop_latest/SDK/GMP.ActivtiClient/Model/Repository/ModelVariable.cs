﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ModelVariable
	{
		[JsonProperty("id")]
		public string VarId { get; set; }

		[JsonProperty("ralationId")]
		public string RalationId { get; set; }

		[JsonProperty("ralationName")]
		public string RalationName { get; set; }

		[JsonProperty("processManage")]
		public ProcessManage ProcessManage { get; set; }

		[JsonProperty("varName")]
		public string VarName { get; set; }

		[JsonProperty("type")]
		public int Type { get; set; }

		[JsonProperty("remark")]
		public string Remark { get; set; }

		[JsonProperty("createTime")]
		public object CreateTime { get; set; }
	}
}