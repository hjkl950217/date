﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ModelVariableResponse : PageInfoResponse
	{
		[JsonProperty("rows")]
		public ModelVariable[] Rows { get; set; }
	}
}