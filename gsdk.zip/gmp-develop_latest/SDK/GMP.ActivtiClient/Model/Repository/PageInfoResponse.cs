﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class PageInfoResponse
	{
		[JsonProperty("total")]
		public int Total { get; set; }

		[JsonProperty("pageSize")]
		public int PageSize { get; set; }

		[JsonProperty("currPage")]
		public int CurrPage { get; set; }
	}
}