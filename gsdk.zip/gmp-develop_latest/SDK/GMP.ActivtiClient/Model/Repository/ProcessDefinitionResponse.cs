﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ProcessDefinitionResponse : PageInfoResponse
	{
		[JsonProperty("rows")]
		public ProcessDefinition[] Data { get; set; }
	}
}