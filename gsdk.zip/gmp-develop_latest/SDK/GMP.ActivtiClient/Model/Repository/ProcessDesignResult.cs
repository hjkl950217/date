﻿namespace GMP.ActivtiClient.Model.Repository
{
	public class ProcessDesignResult
	{
		public bool isSuccess { get; set; }
		public string code { get; set; }
		public string context { get; set; }

		public object data { get; set; }
	}
}