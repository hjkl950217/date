﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ProcessManage
	{
		[JsonProperty("id")]
		public string Id { get; set; }

		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("key")]
		public string Key { get; set; }

		[JsonProperty("descript")]
		public string Descript { get; set; }

		[JsonProperty("category")]
		public string Category { get; set; }

		[JsonProperty("potentialStarterId")]
		public string PotentialStarterId { get; set; }

		[JsonProperty("potentialType")]
		public string PotentialType { get; set; }

		[JsonProperty("initiator")]
		public string Initiator { get; set; }

		[JsonProperty("formKey")]
		public string FormKey { get; set; }

		[JsonProperty("extProp")]
		public string ExtProp { get; set; }

		[JsonProperty("processDefinitionXml")]
		public object ProcessDefinitionXml { get; set; }

		[JsonProperty("createTime")]
		public long CreateTime { get; set; }

		[JsonProperty("lastUpdateTime")]
		public long LastUpdateTime { get; set; }

		[JsonProperty("rev")]
		public int Rev { get; set; }

		[JsonProperty("bpmnVars")]
		public object[] BpmnVars { get; set; }

		[JsonProperty("creator")]
		public string Creator { get; set; }

		[JsonProperty("token")]
		public string Token { get; set; }
	}
}