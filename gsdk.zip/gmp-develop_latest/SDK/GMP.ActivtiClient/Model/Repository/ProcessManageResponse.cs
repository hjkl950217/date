﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class ProcessManageResponse : PageInfoResponse
	{
		[JsonProperty("rows")]
		public ProcessManage[] Rows { get; set; }
	}
}