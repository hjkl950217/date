﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Repository
{
	public class RequestBpmModelVariable
	{
		[JsonProperty("id")]
		public int id { set; get; }

		[JsonProperty("ralationId")]
		public string ralationId { set; get; }

		[JsonProperty("ralationName")]
		public string ralationName { set; get; }

		[JsonProperty("modelId")]
		public int modelId { set; get; }

		[JsonProperty("name")]
		public string name { set; get; }

		[JsonProperty("varType")]
		public int varType { set; get; }

		[JsonProperty("remark")]
		public string remark { set; get; }
	}
}