﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.ReuqestParams
{
	public class DefinitionStateRequestParams
	{
		[JsonProperty("action")]
		public string Action { set; get; }

		[JsonProperty("includeProcessInstances")]
		public string IncludeProcessInstances { set; get; }

		[JsonProperty("date", NullValueHandling = NullValueHandling.Ignore)]
		public string Date { set; get; }
	}
}