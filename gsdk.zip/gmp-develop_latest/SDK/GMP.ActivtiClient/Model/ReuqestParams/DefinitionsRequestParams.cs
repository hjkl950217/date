﻿namespace GMP.ActivtiClient.Model.ReuqestParams
{
	public class DefinitionsRequestParams
	{
	}
}