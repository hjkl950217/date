﻿namespace GMP.ActivtiClient.Model.ReuqestParams
{
	public class DeployRequestParams
	{
		public string starterType { set; get; }

		public string processKey { set; get; }

		public string processType { set; get; }

		public string starterCode { set; get; }
	}
}