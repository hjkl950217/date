﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.ReuqestParams
{
	public class NewModelRequestParams
	{
		[JsonProperty("extPropJson")]
		public string ExtPropJson { set; get; }

		[JsonProperty("modelKey")]
		public string ModelKey { set; get; }

		[JsonProperty("processDefinitionXml")]
		public string ProcessDefinitionXml { set; get; }
	}
}