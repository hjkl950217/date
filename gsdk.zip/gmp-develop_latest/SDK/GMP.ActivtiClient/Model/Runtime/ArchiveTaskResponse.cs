﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class ArchiveTaskResponse
	{
		[JsonProperty("total")]
		public int Total { get; set; }

		[JsonProperty("rows")]
		public ArchiveTask[] Rows { get; set; }
	}
}