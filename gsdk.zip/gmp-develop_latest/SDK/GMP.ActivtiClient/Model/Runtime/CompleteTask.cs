﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class CompleteTask
	{
		[JsonProperty("id")]
		public string Id { get; set; }

		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("assignee")]
		public string Assignee { get; set; }

		[JsonProperty("taskDefinitionKey")]
		public string TaskDefinitionKey { get; set; }

		[JsonProperty("category")]
		public object Category { get; set; }

		[JsonProperty("createTime")]
		public object CreateTime { get; set; }

		[JsonProperty("description")]
		public string Description { get; set; }

		[JsonProperty("dueDate")]
		public object DueDate { get; set; }

		[JsonProperty("executionId")]
		public string ExecutionId { get; set; }

		[JsonProperty("owner")]
		public object Owner { get; set; }

		[JsonProperty("priority")]
		public int Priority { get; set; }

		[JsonProperty("processInstanceId")]
		public string ProcessInstanceId { get; set; }

		[JsonProperty("processDefinitionId")]
		public string ProcessDefinitionId { get; set; }

		[JsonProperty("processDefinitionName")]
		public string ProcessDefinitionName { get; set; }

		[JsonProperty("processDefinitionKey")]
		public string ProcessDefinitionKey { get; set; }

		[JsonProperty("comments")]
		public string Comments { get; set; }

		[JsonProperty("formKey")]
		public object FormKey { get; set; }

		[JsonProperty("tenantId")]
		public string TenantId { get; set; }

		[JsonProperty("parentTaskId")]
		public object ParentTaskId { get; set; }

		[JsonProperty("delegationState")]
		public object DelegationState { get; set; }

		[JsonProperty("isTurnBack")]
		public bool IsTurnBack { get; set; }

		[JsonProperty("starter")]
		public string Starter { get; set; }
	}
}