﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class CompleteTaskResponse
	{
		[JsonProperty("total")]
		public int Total { get; set; }

		[JsonProperty("rows")]
		public CompleteTask[] Rows { get; set; }
	}
}