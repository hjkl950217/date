﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime.Count
{
	public class Context
	{
		[JsonProperty("key")]
		public string Key { get; set; }

		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("count")]
		public int Count { get; set; }
	}
}