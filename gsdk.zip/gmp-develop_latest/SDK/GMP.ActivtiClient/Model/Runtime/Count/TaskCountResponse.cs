﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime.Count
{
	public class TaskCountResponse
	{
		[JsonProperty("inbox")]
		public Context[] Inbox { get; set; }

		[JsonProperty("apply")]
		public Context[] Apply { get; set; }

		[JsonProperty("complete")]
		public Context[] Complete { get; set; }

		[JsonProperty("init")]
		public Context[] Init { get; set; }

		[JsonProperty("archive")]
		public Context[] Archive { get; set; }
	}
}