﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class InitTask
	{
		[JsonProperty("id")]
		public string Id { get; set; }

		[JsonProperty("processInstanceId")]
		public string ProcessInstanceId { get; set; }

		[JsonProperty("processDefinitionId")]
		public string ProcessDefinitionId { get; set; }

		[JsonProperty("processDefinitionName")]
		public string ProcessDefinitionName { get; set; }

		[JsonProperty("startTime")]
		public object StartTime { get; set; }

		[JsonProperty("endTime")]
		public long? EndTime { get; set; }

		[JsonProperty("durationInMillis")]
		public int? DurationInMillis { get; set; }

		[JsonProperty("deleteReason")]
		public object DeleteReason { get; set; }

		[JsonProperty("endActivityId")]
		public string EndActivityId { get; set; }

		[JsonProperty("businessKey")]
		public string BusinessKey { get; set; }

		[JsonProperty("startUserId")]
		public string StartUserId { get; set; }

		[JsonProperty("startActivityId")]
		public string StartActivityId { get; set; }

		[JsonProperty("superProcessInstanceId")]
		public object SuperProcessInstanceId { get; set; }

		[JsonProperty("tenantId")]
		public string TenantId { get; set; }

		[JsonProperty("name")]
		public object Name { get; set; }

		[JsonProperty("queryVariables")]
		public object QueryVariables { get; set; }
	}
}