﻿using GMP.ActivtiClient.Model.Repository;
using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class InitTaskResponse : PageInfoResponse
	{
		[JsonProperty("rows")]
		public InitTask[] Rows { get; set; }
	}
}