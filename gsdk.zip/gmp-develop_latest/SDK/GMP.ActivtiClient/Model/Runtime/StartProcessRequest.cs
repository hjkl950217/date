﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class StartProcessRequest
	{
		[JsonProperty("processDefinitionId")]
		public string ProcessDefinitionId { set; get; }

		[JsonProperty("starter")]
		public string Starter { set; get; }

		[JsonProperty("summary")]
		public string Summary { set; get; }

		[JsonProperty("signDataStr")]
		public string SignDataStr { set; get; }

		[JsonProperty("businessKey")]
		public string BusinessKey { set; get; }

		public StartProcessRequest()
		{
		}

		public StartProcessRequest(string processDefinitionId, string starter, string summary, string signDataStr)
		{
			this.ProcessDefinitionId = processDefinitionId;
			this.Starter = starter;
			this.Summary = summary;
			this.SignDataStr = signDataStr;
		}
	}
}