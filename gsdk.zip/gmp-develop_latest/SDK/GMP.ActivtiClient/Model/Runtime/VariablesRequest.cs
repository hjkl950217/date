﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Runtime
{
	public class VariablesRequest
	{
		[JsonProperty("name")]
		public string Name { set; get; }

		[JsonProperty("value")]
		public string Value { set; get; }
	}
}