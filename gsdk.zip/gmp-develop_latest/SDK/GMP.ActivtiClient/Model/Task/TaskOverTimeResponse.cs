﻿using Newtonsoft.Json;

namespace GMP.ActivtiClient.Model.Task
{
	public class TaskOverTimeResponse
	{
		/// <summary>
		/// 主键Id
		/// </summary>
		[JsonProperty("id")]
		public int Id { get; set; }

		/// <summary>
		/// 流程实例Id
		/// </summary>
		[JsonProperty("proceInsId")]
		public string ProceInsId { get; set; }

		/// <summary>
		/// 任务Id
		/// </summary>
		[JsonProperty("taskInsId")]
		public string TaskInsId { get; set; }

		/// <summary>
		/// 任务结束日期
		/// </summary>
		[JsonProperty("overtime")]
		public string Overtime { get; set; }

		/// <summary>
		/// 待办人
		/// </summary>
		[JsonProperty("assignee")]
		public string Assignee { get; set; }
	}
}