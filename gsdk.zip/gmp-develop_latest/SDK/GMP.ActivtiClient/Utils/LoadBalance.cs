﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace GMP.ActivtiClient
{
	/// <summary>
	/// 负载均衡类
	/// </summary>
	public class LoadBalance
	{
		private LoadBalance()
		{
		}

		private static LoadBalance instance = new LoadBalance();

		/// <summary>
		/// 负载均衡实例对象
		/// </summary>
		public static LoadBalance Instance
		{
			get
			{
				if (instance == null)
				{
					instance = new LoadBalance();
				}
				return instance;
			}
		}

		/// <summary>
		/// TCP请求方式的全部IP列表
		/// </summary>
		public Dictionary<string, Dictionary<string, int>> OriginalTcpIPDictionary = new Dictionary<string, Dictionary<string, int>>();

		/// <summary>
		/// TCP可正常连接的IP列表
		/// </summary>
		public Dictionary<string, Dictionary<string, int>> TcpIPRunDictionary = new Dictionary<string, Dictionary<string, int>>();

		/// <summary>
		/// Tcp方式新增的一组IP列表的Id
		/// </summary>
		private string TcpAddedId = "";

		/// <summary>
		/// Http请求方式的全部Url列表
		/// </summary>
		private readonly Dictionary<string, Dictionary<string, string>> OriginalHttpUrlDictionary = new Dictionary<string, Dictionary<string, string>>();

		/// <summary>
		/// Http可正常连接的Url列表
		/// </summary>
		private readonly Dictionary<string, Dictionary<string, string>> HttpUrlRunDictionary = new Dictionary<string, Dictionary<string, string>>();

		/// <summary>
		/// Http方式新增的一组Url列表的Id
		/// </summary>
		private string HttpAddedId = "";

		/// <summary>
		/// 生成随机数时用到的对象
		/// </summary>
		private readonly Random RandomObj = new Random();

		#region TCP方式相关

		/// <summary>
		/// 注册一组IP，随机返回一个可以正常使用TCP请求的IP
		/// </summary>
		/// <param name="id">一组IP的标识id</param>
		/// <param name="ips">IP地址，多个以分隔符分隔</param>
		/// <param name="port">端口号</param>
		/// <param name="splitChar">分隔符，默认为逗号</param>
		/// <returns></returns>
		public string Register(string id, string ips, int port, char splitChar = ',')
		{
			string strResult = "";
			try
			{
				if (string.IsNullOrEmpty(id) == true || string.IsNullOrEmpty(ips) == true || port < 0)
				{
					return "";
				}
				bool bIsFirstCall = (this.OriginalTcpIPDictionary.Count < 1);   //定义是否为第一次调用GetNormalTcpIp()的变量
				this.AddTcpDictionaryByArray(id, ips.Split(splitChar), port);
				if (bIsFirstCall == true)
				{
					this.ListenerTcpConnection();
				}

				//获取一个可用的IP，最多延迟5秒无可用IP时，则返回空
				for (int i = 0 ; i < 100 ; i++)
				{
					Thread.Sleep(50);
					strResult = this.GetOneNormalIp(id);
					if (string.IsNullOrEmpty(strResult) == false)
					{
						break;
					}
				}
			}
			catch (Exception ex)
			{
				Log.WriteError(ex.Message + "\r\n" + ex.StackTrace);
			}

			return strResult;
		}

		/// <summary>
		/// 将IP数组添加到TCP请求方式的IP列表集合中
		/// </summary>
		/// <param name="id">要添加IP的标识id</param>
		/// <param name="ipArray">IP数组</param>
		/// <param name="port">端口号</param>
		private void AddTcpDictionaryByArray(string id, string[] ipArray, int port)
		{
			if (ipArray == null || ipArray.Length < 1)
			{
				return;
			}

			if (this.OriginalTcpIPDictionary.Count < 1 || this.OriginalTcpIPDictionary[id] == null)
			{
				this.OriginalTcpIPDictionary[id] = new Dictionary<string, int>();
			}

			bool bIsAdded = false;
			string strTemp = "";
			foreach (string strIp in ipArray)
			{
				strTemp = strIp.ToLower();
				if (this.OriginalTcpIPDictionary[id].ContainsKey(strTemp) == false)
				{
					this.OriginalTcpIPDictionary[id][strTemp] = port;
					bIsAdded = true;
				}
			}
			if (bIsAdded == true)
			{
				this.TcpAddedId = id;
			}
		}

		/// <summary>
		/// 验证参数中的Tcp连接是否连接成功
		/// </summary>
		/// <param name="ip">要验证的IP</param>
		/// <param name="port">要验证的端口号</param>
		/// <returns></returns>
		private bool ValidateTcpIsConnection(string ip, int port)
		{
			try
			{
				TcpClient client = new TcpClient(ip, port);
				if ((client.Client.Poll(20, SelectMode.SelectRead)) && (client.Client.Available == 0))
				{
					return false;
				}
				client.Close();
				client = null;
			}
			catch
			{
				return false;
			}
			return true;
		}

		/// <summary>
		/// 遍历所有Tcp请求方式的IP
		/// </summary>
		private void LoopTcpIps()
		{
			bool isFirstLoop = false;   //如果有新增IP组要跳转时，则从第一组开始遍历
										//遍历TCP连接方式所有IP组的列表
			for (int i = 0 ; i < this.OriginalTcpIPDictionary.Count ; i++)
			{
				string strId = this.OriginalTcpIPDictionary.Keys.ToList()[i];   //拿到当前IP组的Id
																				//跳转到新增的IP组开始
				if (string.IsNullOrEmpty(this.TcpAddedId) == false && this.TcpAddedId != strId)
				{
					if (isFirstLoop == false)
					{
						i = 0;
						isFirstLoop = true;
					}
					continue;
				}
				Dictionary<string, int> ipDictionary = this.OriginalTcpIPDictionary[strId];
				if (ipDictionary == null || ipDictionary.Count < 1)
				{
					continue;
				}
				//遍历TCP连接方式当前IP组中所有IP列表
				for (int j = 0 ; j < ipDictionary.Count ; j++)
				{
					//跳转到新增的IP组开始
					if (string.IsNullOrEmpty(this.TcpAddedId) == false && this.TcpAddedId != strId)
					{
						if (isFirstLoop == false)
						{
							i = 0;
							isFirstLoop = true;
						}
						break;
					}
					string strIp = ipDictionary.Keys.ToList()[j];
					//验证当前IP、端口是否可以连接
					bool bIsConn = this.ValidateTcpIsConnection(strIp, ipDictionary[strIp]);
					//若可以正常连接，则添加到可连接列表中
					if (bIsConn == true)
					{
						if (this.TcpIPRunDictionary.ContainsKey(strId) == false)
						{
							this.TcpIPRunDictionary[strId] = new Dictionary<string, int>();
						}

						if (this.TcpIPRunDictionary[strId].ContainsKey(strIp) == false)
						{
							this.TcpIPRunDictionary[strId][strIp] = ipDictionary[strIp];
						}
					}
					//若不可以正常连接，则从可连接列表中删除
					else
					{
						Log.WriteError(string.Format("<{0}\t{1}:{2}>Tcp请求失败", strId, strIp, ipDictionary[strIp]));
						if (this.TcpIPRunDictionary.ContainsKey(strId) == true)
						{
							Dictionary<string, int> ipRunDictionary = this.TcpIPRunDictionary[strId];
							if (ipRunDictionary == null || ipRunDictionary.Count < 1)
							{
								continue;
							}
							if (ipRunDictionary.ContainsKey(strIp) == true)
							{
								ipRunDictionary.Remove(strIp);
							}
						}
					}
				}
			}
			if (string.IsNullOrEmpty(this.TcpAddedId) == false)
			{
				this.TcpAddedId = "";
			}
		}

		/// <summary>
		/// 监听Tcp方式连接的方法
		/// </summary>
		private void ListenerTcpConnection()
		{
			//开启线程监听Tcp连接
			Thread thListener = new Thread(new ThreadStart(() =>
			{
				while (true)
				{
					if (this.OriginalTcpIPDictionary == null || this.OriginalTcpIPDictionary.Count < 1)
					{
						Thread.Sleep(20);
						continue;
					}
					try
					{
						this.LoopTcpIps();
					}
					catch (Exception ex)
					{
						Log.WriteError(ex.Message + "\r\n" + ex.StackTrace);
					}
					Thread.Sleep(5000);
				}
			}));
			thListener.Start();
		}

		/// <summary>
		/// 获取指定服务器上一个可正常连接的TCP方式的IP
		/// </summary>
		/// <param name="id">要获取IP所属的标识id</param>
		/// <returns></returns>
		private string GetOneNormalIp(string id)
		{
			string result = "";
			if (this.TcpIPRunDictionary == null || this.TcpIPRunDictionary.Count < 1)
			{
				return result;
			}
			Dictionary<string, int> ipDictionary = this.TcpIPRunDictionary[id];
			if (ipDictionary == null || ipDictionary.Count < 1)
			{
				return result;
			}
			List<string> ipList = ipDictionary.Keys.ToList();
			int index = this.RandomObj.Next(ipList.Count);
			result = ipList[index];

			return result;
		}

		#endregion TCP方式相关

		#region Http方式相关

		/// <summary>
		/// 注册一组Url，随机返回一个可以正常使用Http请求的Url
		/// </summary>
		/// <param name="id">一组Url的标识id</param>
		/// <param name="urls">请求的Url，多个以分隔符分隔</param>
		/// <param name="splitChar">分隔符，默认为逗号</param>
		/// <returns></returns>
		public string Register(string id, string urls, char splitChar = ',')
		{
			string strResult = "";
			try
			{
				if (string.IsNullOrEmpty(id) == true || string.IsNullOrEmpty(urls) == true)
				{
					return "";
				}
				bool bIsFirstCall = (this.OriginalHttpUrlDictionary.Count < 1);   //定义是否为第一次调用Register()的变量
				this.AddHttpDictionaryByArray(id, urls.Split(splitChar));
				if (bIsFirstCall == true)
				{
					this.ListenerHttpConnection();
				}

				//获取一个可用的Url，最多延迟20秒无可用Url时，则返回空
				for (int i = 0 ; i < 400 ; i++)
				{
					Thread.Sleep(50);
					strResult = this.GetOneNormalUrl(id);
					if (string.IsNullOrEmpty(strResult) == false)
					{
						break;
					}
				}
			}
			catch (Exception ex)
			{
				Log.WriteError(ex.Message + "\r\n" + ex.StackTrace);
			}

			return strResult;
		}

		/// <summary>
		/// 将Url数组添加到Http请求方式的Url列表集合中
		/// </summary>
		/// <param name="strServerName">要添加Url的标识id</param>
		/// <param name="urlArray">Url数组</param>
		private void AddHttpDictionaryByArray(string id, string[] urlArray)
		{
			if (urlArray == null || urlArray.Length < 1)
			{
				return;
			}

			if (this.OriginalHttpUrlDictionary.Count < 1 || this.OriginalHttpUrlDictionary[id] == null)
			{
				this.OriginalHttpUrlDictionary[id] = new Dictionary<string, string>();
			}

			bool bIsAdded = false;
			string strTemp = "";
			foreach (string strUrl in urlArray)
			{
				strTemp = strUrl.ToLower();
				if (this.OriginalHttpUrlDictionary[id].ContainsKey(strTemp) == false)
				{
					this.OriginalHttpUrlDictionary[id][strTemp] = strUrl;
					bIsAdded = true;
				}
			}
			if (bIsAdded == true)
			{
				this.HttpAddedId = id;
			}
		}

		/// <summary>
		/// 验证参数中的Http请求是否成功
		/// </summary>
		/// <param name="url">要验证的Url</param>
		/// <returns></returns>
		private bool ValidateHttpIsConnection(string url)
		{
			if (string.IsNullOrEmpty(url) == true)
			{
				return false;
			}
			string strTempUrl = url.ToLower();
			if (!strTempUrl.StartsWith("http://") && !strTempUrl.StartsWith("https://"))
			{
				url = "http://" + url;
			}
			HttpWebRequest myRequest = null;
			try
			{
				myRequest = (HttpWebRequest)WebRequest.Create(url);
				myRequest.Method = "HEAD";
				myRequest.Timeout = 10000;  //超时时间10秒
				HttpWebResponse res = (HttpWebResponse)myRequest.GetResponse();
				return (res.StatusCode == HttpStatusCode.OK);
			}
			catch
			{
				return false;
			}
			finally
			{
				if (myRequest != null)
				{
					myRequest.Abort();
					myRequest = null;
				}
			}
		}

		/// <summary>
		/// 遍历所有Http请求方式的Url
		/// </summary>
		private void LoopHttpUrls()
		{
			bool isFirstLoop = false;   //如果有新增Url组要跳转时，则从第一组开始遍历
										//遍历Http连接方式所有Url组的列表
			for (int i = 0 ; i < this.OriginalHttpUrlDictionary.Count ; i++)
			{
				string strId = this.OriginalHttpUrlDictionary.Keys.ToList()[i]; //拿到当前Url组的Id
																				//跳转到新增的Url组开始
				if (string.IsNullOrEmpty(this.HttpAddedId) == false && this.HttpAddedId != strId)
				{
					if (isFirstLoop == false)
					{
						i = 0;
						isFirstLoop = true;
					}
					continue;
				}
				Dictionary<string, string> urlDictionary = this.OriginalHttpUrlDictionary[strId];
				if (urlDictionary == null || urlDictionary.Count < 1)
				{
					continue;
				}
				//遍历Http连接方式当前Url组中的所有Url列表
				for (int j = 0 ; j < urlDictionary.Count ; j++)
				{
					//跳转到新增的Url组开始
					if (string.IsNullOrEmpty(this.HttpAddedId) == false && this.HttpAddedId != strId)
					{
						if (isFirstLoop == false)
						{
							i = 0;
							isFirstLoop = true;
						}
						break;
					}
					string strUrl = urlDictionary.Keys.ToList()[j];
					//验证当前Url是否可以正常访问
					bool bIsConn = this.ValidateHttpIsConnection(urlDictionary[strUrl]);
					//若可以正常访问，则添加到可访问列表中
					if (bIsConn == true)
					{
						if (this.HttpUrlRunDictionary.ContainsKey(strId) == false)
						{
							this.HttpUrlRunDictionary[strId] = new Dictionary<string, string>();
						}

						if (this.HttpUrlRunDictionary[strId].ContainsKey(strUrl) == false)
						{
							this.HttpUrlRunDictionary[strId][strUrl] = urlDictionary[strUrl];
						}
					}
					//若不可以正常访问，则从可访问列表中删除
					else
					{
						Log.WriteError(string.Format("<{0}\t{1}>Url请求失败", strId, strUrl));
						if (this.HttpUrlRunDictionary.ContainsKey(strId) == true)
						{
							Dictionary<string, string> urlRunDictionary = this.HttpUrlRunDictionary[strId];
							if (urlRunDictionary == null || urlRunDictionary.Count < 1)
							{
								continue;
							}
							if (urlRunDictionary.ContainsKey(strUrl) == true)
							{
								urlRunDictionary.Remove(strUrl);
							}
						}
					}
				}
			}
			if (string.IsNullOrEmpty(this.HttpAddedId) == false)
			{
				this.HttpAddedId = "";
			}
		}

		/// <summary>
		/// 监听Http方式连接的方法
		/// </summary>
		private void ListenerHttpConnection()
		{
			//开启线程监听Http请求
			Thread thListener = new Thread(new ThreadStart(() =>
			{
				while (true)
				{
					if (this.OriginalHttpUrlDictionary == null || this.OriginalHttpUrlDictionary.Count < 1)
					{
						Thread.Sleep(20);
						continue;
					}
					try
					{
						this.LoopHttpUrls();
					}
					catch (Exception ex)
					{
						Log.WriteError(ex.Message + "\r\n" + ex.StackTrace);
					}
					Thread.Sleep(5000);
				}
			}));
			thListener.Start();
		}

		/// <summary>
		/// 获取指定服务器上一个可正常连接的HTTP方式的Url
		/// </summary>
		/// <param name="id">要获取Url所属的标识id</param>
		/// <returns></returns>
		private string GetOneNormalUrl(string id)
		{
			string strResult = "";
			if (this.HttpUrlRunDictionary == null || this.HttpUrlRunDictionary.Count < 1)
			{
				return strResult;
			}
			Dictionary<string, string> urlDictionary = this.HttpUrlRunDictionary[id];
			if (urlDictionary == null || urlDictionary.Count < 1)
			{
				return strResult;
			}
			List<string> urlList = urlDictionary.Values.ToList();
			int nIndex = this.RandomObj.Next(urlList.Count);
			strResult = urlList[nIndex];

			return strResult;
		}

		#endregion Http方式相关
	}
}