﻿using System;

namespace GMP.ActivtiClient
{
	public class Log
	{
		public static void WriteError(string message)
		{
			string path = AppDomain.CurrentDomain.BaseDirectory;
			path = System.IO.Path.GetDirectoryName(path) + System.IO.Path.PathSeparator + " ErrorLogs";
			//try
			//{
			if (!System.IO.Directory.Exists(path))
			{
				System.IO.Directory.CreateDirectory(path);
			}
			string fileName = System.IO.Path.Combine(path, DateTime.Now.ToString("yyyy-MM-dd") + ".log");
			System.IO.StreamWriter sw = new System.IO.StreamWriter(fileName, true);
			sw.WriteLine(DateTime.Now.ToString("HH:mm:ss:fff") + " -------------------");
			sw.WriteLine(message);
			sw.WriteLine();
			sw.Close();
			//}
			//catch
			//{
			//}
		}
	}
}