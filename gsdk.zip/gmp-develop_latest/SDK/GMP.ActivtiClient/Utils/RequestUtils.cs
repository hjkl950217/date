﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using GMP.ActivtiClient.Api.Repository;
using GMP.ActivtiClient.Model.Repository;
using Newtonsoft.Json;

namespace GMP.ActivtiClient
{
	public class RequestUtils
	{
		public static JwtToken jwtToken = null;

		public static JwtToken LoadNewJwtToken()
		{
			JwtResource jwtResource = new JwtResource();
			if (jwtToken == null)
			{
				JwtToken newToken = jwtResource.GetJwtToken();
				if (newToken.IsSuccess)
				{
					jwtToken = newToken;
				}
			}
			else
			{
				if (DateTime.Now > jwtToken.TimeOut)
				{
					JwtToken newToken = jwtResource.GetJwtToken();
					if (newToken.IsSuccess)
					{
						jwtToken = newToken;
					}
					else
					{
						jwtToken = null;
					}
				}
			}
			return jwtToken;
		}

		public static string GetParamsUrl(Dictionary<string, string> requestParams)
		{
			string url = "";
			JwtToken jwtToken = LoadNewJwtToken();
			if (requestParams != null && requestParams.Count > 0)
			{
				url += "?";
				int i = 0;
				foreach (string key in requestParams.Keys)
				{
					url += key + "=" + requestParams[key].Trim();
					i++;
					if (i < requestParams.Count)
						url += "&";
				}

				if (jwtToken != null)
				{
					string spt = "";
					if (i > 0)
					{
						spt = "&";
					}
					url += (spt + "token=" + jwtToken.Token);
				}
			}
			else
			{
				url = "?token=" + jwtToken.Token;
			}
			return url;
		}

		public static string GetParamsJson(Dictionary<string, string> requestParams)
		{
			string json = "{";
			if (requestParams != null)
			{
				int i = 0;

				foreach (string key in requestParams.Keys)
				{
					i++;
					json += "\"" + key + "\":\"" + requestParams[key] + "\"";
					if (i < requestParams.Keys.Count)
					{
						json += ",";
					}
				}
				JwtToken jwtToken = LoadNewJwtToken();
				if (jwtToken != null)
				{
					string spt = "";
					if (i > 0)
					{
						spt = ",";
					}
					json += (spt + "\"token\":" + "\"" + jwtToken.Token + "\"");
				}
			}
			json += "}";
			return json;
		}

		private static HttpResponseMessage Get(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> requesParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			resourceUrl += GetParamsUrl(requesParams);
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);

				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				response = client.GetAsync(resourceUrl).Result;
			}
			return response;
		}

		private static HttpResponseMessage Post(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			string requestJson = "{}";
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			if (requesParams != null && requesParams is IDictionary)
				resourceUrl += GetParamsUrl(requesParams);
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);

				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				if (requesParams is IDictionary)
				{
					dynamic request = JsonConvert.SerializeObject(requesParams);
					HttpContent httpContent = new StringContent(request, Encoding.UTF8, "application/json");
					response = client.PostAsync(resourceUrl, httpContent).Result;
				}
				else
				{
					HttpContent httpContent = new StringContent(JsonConvert.SerializeObject(requesParams), Encoding.UTF8, "application/json");
					response = client.PostAsync(resourceUrl, httpContent).Result;
				}
			}
			return response;
		}

		private static HttpResponseMessage Post<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			string requestJson = "{}";
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);
				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				if (requesParams is string)
				{
					StringContent content = new StringContent(requesParams, Encoding.UTF8);
					response = client.PostAsync(resourceUrl, content).Result;
				}
				else
				{
					StringContent content = new StringContent(JsonConvert.SerializeObject(requesParams), Encoding.UTF8, "application/json");

					response = client.PostAsync(resourceUrl, content).Result;
				}
			}
			return response;
		}

		private static HttpResponseMessage Put(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			if (requesParams != null && requesParams is IDictionary)
				resourceUrl += GetParamsUrl(requesParams);
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);
				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				if (requesParams is string)
				{
					StringContent content = new StringContent(requesParams, Encoding.UTF8);
					response = client.PostAsync(resourceUrl, content).Result;
				}
				else
				{
					StringContent content = new StringContent(JsonConvert.SerializeObject(requesParams), Encoding.UTF8, "application/json"); ;
					response = client.PostAsync(resourceUrl, content).Result;
				}
			}
			return response;
		}

		private static HttpResponseMessage PostForm(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> formParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);
				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				string text2 = "";
				if (formParams != null)
				{
					foreach (string current in formParams.Keys)
					{
						string text3 = text2;
						text2 = string.Concat(new string[]
					 {
						text3,
						"&",
						current,
						"=",
						System.Web.HttpUtility.UrlEncode(formParams[current])
					 });
					}
					JwtToken jwtToken = LoadNewJwtToken();
					if (text2.Length > 0)
					{
						text2 = text2.Substring(1);
						if (jwtToken != null)
						{
							text2 += "&token=" + jwtToken.Token;
						}
					}
					else
					{
						if (jwtToken != null)
						{
							text2 += "token=" + jwtToken.Token;
						}
					}
				}
				// Use the JSON formatter to create the content of the request body.
				// 使用JSON格式化器创建请求体内容。
				StringContent stringContent = new StringContent(text2, Encoding.UTF8, "application/x-www-form-urlencoded");
				response = client.PostAsync(resourceUrl, stringContent).Result;
			}
			return response;
		}

		private static HttpResponseMessage Put<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			string resourceUrl = resource["Value"];
			if (string.IsNullOrEmpty(resourceUrl))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			if (requesParams != null && requesParams is IDictionary)
				resourceUrl += GetParamsUrl(requesParams);
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);
				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				if (requesParams is string)
				{
					StringContent content = new StringContent(requesParams, Encoding.UTF8);
					response = client.PostAsync(resourceUrl, content).Result;
				}
				else
				{
					StringContent content = new StringContent(JsonConvert.SerializeObject(requesParams), Encoding.UTF8, "application/json"); ;
					response = client.PostAsync(resourceUrl, content).Result;
				}
			}
			return response;
		}

		private static HttpResponseMessage Delete(Dictionary<string, string> resource, Dictionary<string, string> head)
		{
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			if (string.IsNullOrEmpty(resource["Value"]))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);

				if (head != null)
				{
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				response = client.DeleteAsync(resource["BaseUrl"]).Result;
			}
			return response;
		}

		private static HttpResponseMessage UploadFile(Dictionary<string, string> resource, Dictionary<string, string> head, Stream stream, string fileName)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			if (string.IsNullOrEmpty(resource["Value"]))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);

				if (head != null)
				{
					//client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/multipart/form-data"));
					foreach (string key in head.Keys)
					{
						client.DefaultRequestHeaders.Add(key,
												head[key]);
					}
				}
				// Create a stream content for the file
				StreamContent content = new StreamContent(stream);
				// Create Multipart form data content, add our submitter data and our stream content
				MultipartFormDataContent formData = new MultipartFormDataContent();
				formData.Add(content, "filename", fileName);
				JwtToken jwtToken = LoadNewJwtToken();
				if (jwtToken != null)
				{
					formData.Add(content, "token", jwtToken.Token);
				}
				// Post the MIME multipart form data upload with the file
				response = client.PutAsync(resource["Value"], formData).Result;
			}
			return response;
		}

		private static HttpResponseMessage UploadPostFile(Dictionary<string, string> resource, Dictionary<string, string> head, Stream stream, string fileName)
		{
			if (resource == null)
				return null;
			if (string.IsNullOrEmpty(resource["BaseUrl"]))
				Console.WriteLine("baseUrl not is null!");
			if (string.IsNullOrEmpty(resource["Value"]))
				Console.WriteLine("resource not is null!");
			HttpResponseMessage response = null;
			using (HttpClient client = new HttpClient())
			{
				client.BaseAddress = new Uri(resource["BaseUrl"]);

				if (head != null)
				{
				}
				// Create a stream content for the file
				StreamContent content = new StreamContent(stream);
				content.Headers.Add("Content-Type", "application/octet-stream");
				// Create Multipart form data content, add our submitter data and our stream content
				MultipartFormDataContent formData = new MultipartFormDataContent();
				formData.Add(content, "file", fileName);
				JwtToken jwtToken = LoadNewJwtToken();
				if (jwtToken != null)
				{
					formData.Add(new StringContent(jwtToken.Token, Encoding.UTF8, "application/x-www-form-urlencoded"), "token");
				}
				// Post the MIME multipart form data upload with the file
				response = client.PostAsync(resource["Value"], formData).Result;
			}
			return response;
		}

		public static string UploadFileReturnJson(Dictionary<string, string> resource, Dictionary<string, string> head, Stream stream, string fileName, string method = "PUT")
		{
			string json = "";
			HttpResponseMessage response = null;
			if (method.Equals("PUT"))
			{
				response = UploadFile(resource, head, stream, fileName);
			}
			else
			{
				response = UploadPostFile(resource, head, stream, fileName);
			}
			if (response != null && response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				json = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				//throw new RequestApiException(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return json;
		}

		public static Stream UploadFileReturnStream(Dictionary<string, string> resource, Dictionary<string, string> head, Stream stream, string fileName, string method = "PUT")
		{
			Stream streamResult;
			HttpResponseMessage response = null;
			if (method.Equals("PUT"))
			{
				response = UploadFile(resource, head, stream, fileName);
			}
			else
			{
				response = UploadPostFile(resource, head, stream, fileName);
			}
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				streamResult = response.Content.ReadAsStreamAsync().Result;
			}
			else
			{
				streamResult = null;
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return streamResult;
		}

		public static string GetReturnJson(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> requesParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = Get(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static Stream GetReturnStream(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> requesParams)
		{
			Stream streamResult = null;
			HttpResponseMessage response = Get(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				streamResult = response.Content.ReadAsStreamAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return streamResult;
		}

		public static T GetReturnObject<T>(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> requesParams)
		{
			T resultObj = default(T);
			HttpResponseMessage response = Get(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				string result = response.Content.ReadAsStringAsync().Result;
				resultObj = JsonConvert.DeserializeObject<T>(result);
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return resultObj;
		}

		public static string PostReturnJson(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = Post(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static string PostReturnJson<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = Post<T>(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static T PostReturnObject<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			T jsonObj = default(T);
			HttpResponseMessage response = Post(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				string result = response.Content.ReadAsStringAsync().Result;
				jsonObj = JsonConvert.DeserializeObject<T>(result);
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonObj;
		}

		public static string PutReturnJson(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = Put(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static string PostFormJson(Dictionary<string, string> resource, Dictionary<string, string> head, Dictionary<string, string> formParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = PostForm(resource, head, formParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static string PutReturnJson<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			string jsonResult = "";
			HttpResponseMessage response = Put<T>(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				jsonResult = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonResult;
		}

		public static T PutReturnObject<T>(Dictionary<string, string> resource, Dictionary<string, string> head, dynamic requesParams)
		{
			T jsonObj = default(T);
			HttpResponseMessage response = Put(resource, head, requesParams);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				string result = response.Content.ReadAsStringAsync().Result;
				jsonObj = JsonConvert.DeserializeObject<T>(result);
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return jsonObj;
		}

		public static string DeleteReturnJson(Dictionary<string, string> resource, Dictionary<string, string> head)
		{
			string json = "";
			HttpResponseMessage response = Delete(resource, head);
			if (response.IsSuccessStatusCode)
			{
				// Parse the response body. Blocking!
				// 解析响应体。阻塞！
				json = response.Content.ReadAsStringAsync().Result;
			}
			else
			{
				Console.WriteLine(string.Format("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase));
			}
			return json;
		}
	}
}