﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 14:11:06
*
***************************************************************************/

using System;

namespace GMP.ApiClient.Attributes
{
	/// <summary>
	/// Specifies the mode of HTTP request.
	/// </summary>
	[AttributeUsage(AttributeTargets.Method)]
	public class HttpMethodAttribute : Attribute
	{
		/// <summary>
		/// Gets or sets the http request method.
		/// </summary>
		public HttpMethod Method { get; set; }

		/// <summary>
		/// Initialize a new instance of the <see cref="HttpMethodAttribute"/> class.
		/// </summary>
		public HttpMethodAttribute(HttpMethod method)
		{
			this.Method = method;
		}
	}
}