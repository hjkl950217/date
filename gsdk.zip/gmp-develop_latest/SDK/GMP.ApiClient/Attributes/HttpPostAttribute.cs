﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 14:11:20
*
***************************************************************************/

using System;

namespace GMP.ApiClient.Attributes
{
	/// <summary>
	/// Represents a POST request based on the Http protocol.This class cannot be inherited.
	/// </summary>
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class HttpPostAttribute : HttpMethodAttribute
	{
		/// <summary>
		/// Initialize a new instance of the <see cref="HttpPostAttribute"/> class.
		/// </summary>
		public HttpPostAttribute() : base(HttpMethod.Post) { }
	}
}