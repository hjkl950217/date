﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 14:11:42
*
***************************************************************************/

using System;

namespace GMP.ApiClient.Attributes
{
	/// <summary>
	/// Provides routing rules for Http requests. This class cannot be inherited.
	/// </summary>
	[AttributeUsage(AttributeTargets.Interface | AttributeTargets.Method)]
	public sealed class RouteAttribute : Attribute
	{
		//Path routing      [HttpRoute("docs")] [HttpRoute("/docs")]
		//Parameter routing [HttpRoute("docs/{docid}")] [HttpRoute("docs/{docid}/update")]
		//Optional routing  [HttpRoute("docs/{docid?}")]
		//Default routing   [HttpRoute("docs/{lang=en}")]

		/// <summary>
		/// Gets the pattern of the route.
		/// </summary>
		public string Pattern { get; }

		/// <summary>
		/// Initializea a new instance of the <see cref="RouteAttribute"/> class.
		/// </summary>
		/// <param name="pattern">The pattern of route.</param>
		public RouteAttribute(string pattern)
		{
			if (string.IsNullOrEmpty(pattern))
			{
				throw new ArgumentNullException("The pattern parameter cannot be null or empty.");
			}

			this.Pattern = pattern.TrimEnd('/');
		}
	}
}