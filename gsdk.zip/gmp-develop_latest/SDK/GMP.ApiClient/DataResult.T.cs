﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 11:41:48
*
***************************************************************************/

using Newtonsoft.Json;

namespace GMP
{
    /// <summary>
    /// Represents the data result of a specified type <typeparamref name="T"/>.
    /// </summary>
    /// <typeparam name="T">A specified data type.</typeparam>
    public class DataResult<T> : DataResult, IDataResult<T>
    {
        /// <summary>
        /// Gets the return data.
        /// </summary>
        public T Data { get; protected set; }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        public DataResult() : this(ErrorCodes.OK_200, string.Empty, default) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        public DataResult(int code) : this(code, string.Empty, default) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="data">Return result data.</param>
        public DataResult(T data) : this(ErrorCodes.OK_200, string.Empty, data) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="message">Result message.</param>
        public DataResult(string message) : this(ErrorCodes.OK_200, message, default) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        /// <param name="message">Result message.</param>
        /// <param name="data">Result data.</param>
        /// <param name="requestPath">request Path</param>
        /// <param name="stackTrace">stack Trace</param>
        [JsonConstructor]
        public DataResult(
            int code = ErrorCodes.OK_200,
            string message = "",
            T data = default,
            string requestPath = "",
            string stackTrace = "") : base(code, message, requestPath, stackTrace)
        {
            this.Data = data;
        }

        /// <summary>
        /// Convert <typeparamref name="T"/> to <see cref="DataResult{T}"/>.
        /// </summary>
        ///
        /// <param name="data">Data of a specified type <typeparamref name="T"/>.</param>
        public static implicit operator DataResult<T>(T data) => new DataResult<T>(data);

        /// <summary>
        /// Convert <see cref="DataResult{T}"/> to <typeparamref name="T"/>.
        /// </summary>
        /// <param name="data">Represents the data result of a specified type <typeparamref name="T"/>.</param>
        public static implicit operator T(DataResult<T> data) => data.Data;
    }
}