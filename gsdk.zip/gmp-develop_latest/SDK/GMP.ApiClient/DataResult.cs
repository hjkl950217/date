﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 11:41:48
*
***************************************************************************/

using Newtonsoft.Json;

namespace GMP
{
    /// <summary>
    /// 返回的结果类型
    /// </summary>
    public class DataResult : IDataResult
    {
        public static string EmptyMessage = string.Empty;

        /// <summary>
        /// Gets the error code.
        /// </summary>
        public int Code { get; protected set; }

        /// <summary>
        /// Gets the error message.
        /// </summary>
        public string Message { get; protected set; }

        /// <summary>
        /// 请求路径
        /// </summary>
        [JsonIgnore]
        public string RequestPath { get; protected set; }

        /// <summary>
        /// 调用堆栈
        /// </summary>
        [JsonIgnore]
        public string StackTrace { get; protected set; }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        public DataResult() : this(ErrorCodes.OK_200, string.Empty) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        public DataResult(int code) : this(code, string.Empty) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="message">Result message.</param>
        public DataResult(string message) : this(ErrorCodes.OK_200, message) { }

        /// <summary>
        /// Initializes a new instance.
        /// </summary>
        /// <param name="code">Error code.</param>
        /// <param name="message">Result message.</param>
        /// <param name="requestPath">request Path</param>
        /// <param name="stackTrace">stack Trace</param>
        [JsonConstructor]
        public DataResult(
            int code = ErrorCodes.OK_200,
            string message = "",
            string requestPath = "",
            string stackTrace = "")
        {
            this.Code = code;
            this.Message = message;
            this.RequestPath = requestPath;
            this.StackTrace = stackTrace;
        }
    }
}