﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 10:47:02
*
***************************************************************************/

using System.ComponentModel;

namespace GMP
{
    /// <summary>
    /// Represents a system error code.
    /// </summary>
    public static partial class ErrorCodes
    {
        /// <summary>
        /// Unknown error.
        /// </summary>
        public const int UNKNOWN = -1;

        /// <summary>
        /// Success.
        /// </summary>
        public const int OK_200 = 200;

        /// <summary>
        /// Request error.
        /// </summary>
        public const int ERROR_REQUEST_400 = 400;

        /// <summary>
        /// Unauthorized.
        /// </summary>
        public const int UNAUTHORIZED_401 = 401;

        /// <summary>
        /// Access forbidden.
        /// </summary>
        public const int FORBIDDEN_403 = 403;

        /// <summary>
        /// Not found.
        /// </summary>
        public const int NOT_FOUND_404 = 404;

        /// <summary>
        /// 缺少令牌
        /// </summary>
        public const int NO_TOKEN_405 = 405;

        /// <summary>
        /// Token is expired or invalid
        /// </summary>
        public const int INVALID_TOKEN_406 = 406;

        /// <summary>
        /// Request Timeout.
        /// </summary>
        public const int TIMEOUT_408 = 408;

        /// <summary>
        /// Failed to meet one or more prerequisites.
        /// </summary>
        public const int PERCONDITION_FAILED_412 = 412;

        /// <summary>
        /// Type mismatch.
        /// </summary>
        public const int TYPE_MISMATCH_415 = 415;

        /// <summary>
        /// Out of range.
        /// </summary>
        public const int OVERFLOW_416 = 416;

        /// <summary>
        /// Not up to expectations.
        /// </summary>
        public const int EXPECTATION_FAILED_417 = 417;

        /// <summary>
        /// File not found.
        /// </summary>
        [Description("File not found")]
        public const int FILE_NOT_FOUND_430 = 430;

        /// <summary>
        /// File version not found.
        /// </summary>
        public const int FILE_VER_NOT_FOUND_431 = 431;

        /// <summary>
        /// File annotate not found.
        /// </summary>
        public const int FILE_ANNOTATE_NOT_FOUND_432 = 432;

        /// <summary>
        /// User not found.
        /// </summary>
        public const int USER_NOT_FOUND_450 = 450;

        /// <summary>
        /// Process instance not found.
        /// </summary>
        public const int WF_INCIDENT_NOT_FOUND_480 = 480;

        /// <summary>
        /// Internal server error.
        /// </summary>
        public const int INNER_ERROR_500 = 500;

        /// <summary>
        /// Service unavailable.
        /// </summary>
        public const int SERVER_UNAVAILABLE_503 = 503;
    }
}