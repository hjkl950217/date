﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:57:13
*
***************************************************************************/
#if (NETFRAMEWORK == false)

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;

namespace GMP.ApiClient
{
    /// <summary>
    /// Provides proxy request methods for all services.This class cannot be inherited.
    /// </summary>
    public sealed class HttpClientRequestProxy : ServiceRequestProxy
    {
        protected HttpResponseMessage httpResponseMessage;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpClientRequestProxy"/> class.
        /// </summary>
        /// <param name="baseUrl">The request address based on the HTTP/HTTPS protocol.</param>
        public HttpClientRequestProxy(string baseUrl) : base(baseUrl) { }

        protected override T InternalRequest<T>(IAppService service, MethodInfo method, params object[] parameters)
        {
            using HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Connection.Add("keep-alive");

            //Custom value type parameter headers
            foreach (KeyValuePair<string, string> item in this.ParameterResolver.ValueTypeParams)
            {
                client.DefaultRequestHeaders.Add(item.Key, item.Value);
            }

            // execute http call
            HttpResponseMessage response = this.HttpMethod switch
            {
                HttpMethod.Get => client.GetAsync(this.RequestUrl).Result,
                HttpMethod.Delete => client.GetAsync(this.RequestUrl).Result,
                HttpMethod.Post => client.PostAsync(this.RequestUrl, getContent()).Result,
                HttpMethod.Put => client.PutAsync(this.RequestUrl, getContent()).Result,
                _ => throw new NotSupportedException()
            };
            this.httpResponseMessage = response;

            // convert to generic
            return this.ConvertResponseResult<T>(response);

            HttpContent getContent()
            {
                string postData = this.ParameterResolver.GetPostContent();
                HttpContent content = new StringContent(postData, Encoding.UTF8, "application/json");

                //If has ValueType parameters, append them to the URL query parameters.
                if (this.ParameterResolver.HasValueTypes)
                {
                    this.RequestUrl += $"?{this.ParameterResolver.GetUrlContent()}";
                }

                //If no ReferenceType parameters, the request is sent as key/value pair.
                if (!this.ParameterResolver.HasReferenceTypes)
                {
                    postData = this.ParameterResolver.GetUrlContent();
                    content = new StringContent(postData, Encoding.UTF8, "application/x-www-form-urlencoded");
                }

                return content;
            }
        }

        /// <summary>
        /// Converts the result returned by the request to the specified object and returns it.
        /// </summary>
        /// <param name="response">The result returned by the request.</param>
        /// <returns>A object of specified type.</returns>
        private T ConvertResponseResult<T>(HttpResponseMessage response)
        {
            if (response != null && response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                return base.ConvertValueType<T>(result);
            }

            return default(T);
        }

        protected override void CheckOnResponsed()
        {
            if (this.httpResponseMessage == null)
            {
                throw new Exception("response is null");
            }

            if (this.httpResponseMessage.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception($"request failure!,Method:{this.httpResponseMessage.RequestMessage.Method}, ResponseUri:{this.httpResponseMessage.RequestMessage.RequestUri},StatusCode:{this.httpResponseMessage.StatusCode}");
            }
        }
    }
}

#endif