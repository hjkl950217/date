﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 14:52:49
*
***************************************************************************/

namespace GMP.ApiClient
{
	/// <summary>
	/// Define standard Http request protocol methods.
	/// </summary>
	public enum HttpMethod
	{
		/// <summary>
		/// Represents an HTTP GET protocol method.
		/// </summary>
		Get,

		/// <summary>
		/// Represents an HTTP POST protocol method.
		/// </summary>
		Post,

		/// <summary>
		/// Represents an HTTP PUT protocol method.
		/// </summary>
		Put,

		/// <summary>
		/// Represents an HTTP DELETE protocol method.
		/// </summary>
		Delete
	}
}