﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 16:39:06
*
***************************************************************************/

using System;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace GMP.ApiClient
{
    /// <summary>
    /// Provides a service request method in <see cref="HttpWebRequest"/>.
    /// </summary>
    public class HttpWebRequestProxy : ServiceRequestProxy
    {
        protected HttpWebResponse httpWebResponse;

        /// <summary>
        /// Initialize a new instance of the <see cref="HttpWebRequestProxy"/> class.
        /// </summary>
        /// <param name="baseUrl">The request address based on the HTTP/HTTPS protocol.</param>
        public HttpWebRequestProxy(string baseUrl) : base(baseUrl) { }

        protected override T InternalRequest<T>(IAppService service, MethodInfo method, params object[] parameters)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(this.RequestUrl);
            request.Method = this.HttpMethodName;
            request.ContentType = "application/json";

            //Custom ValueType parameter headers
            foreach (System.Collections.Generic.KeyValuePair<string, string> item in this.ParameterResolver.ValueTypeParams)
            {
                request.Headers.Add(item.Key, item.Value);
            }

            if (this.HttpMethod == HttpMethod.Post || this.HttpMethod == HttpMethod.Put)
            {
                string postData = this.ParameterResolver.GetPostContent();

                //If no ReferenceType parameters, the request is sent as key/value pair.
                if (!this.ParameterResolver.HasReferenceTypes)
                {
                    postData = this.ParameterResolver.GetUrlContent();
                    request.ContentType = "application/x-www-form-urlencoded";
                }

                byte[] buffer = Encoding.UTF8.GetBytes(postData);
                request.ContentLength = buffer.Length;
                request.GetRequestStream().Write(buffer, 0, buffer.Length);
            }

            //A certificate verification callback is provided under an Https request.
            if (this.RequestUrl.StartsWith("HTTPS", StringComparison.OrdinalIgnoreCase))
            {
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(ServerCertificateValidation);
            }

            //Gets the service return result.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            this.httpWebResponse = response;
            using StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            string result = reader.ReadToEnd();
            return base.ConvertValueType<T>(result);
        }

        /// <summary>
        /// Returns a value indicating that the server certificate is valid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="certificate"></param>
        /// <param name="chain"></param>
        /// <param name="errors"></param>
        /// <returns>Always return true.</returns>
        private static bool ServerCertificateValidation(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
        {
            return true;
        }

        protected override void CheckOnResponsed()
        {
            if (this.httpWebResponse == null)
            {
                throw new Exception("response is null");
            }

            if (this.httpWebResponse.StatusCode != HttpStatusCode.OK)
            {
                throw new Exception($"request failure!, ResponseUri:{this.httpWebResponse.ResponseUri},StatusCode:{this.httpWebResponse.StatusCode}");
            }
        }
    }
}