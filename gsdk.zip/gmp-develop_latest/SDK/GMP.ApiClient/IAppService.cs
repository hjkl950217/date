﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:58:51
*
***************************************************************************/

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides interface constraints for app services.
	/// </summary>
	public interface IAppService
	{
	}
}