﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/16 10:20:21
*
***************************************************************************/

namespace GMP
{
    /// <summary>
    /// Represents a return value of a specified type.
    /// </summary>
    /// <typeparam name="T">A specified return type.</typeparam>
    public interface IDataResult<T> : IDataResult
    {
        /// <summary>
        /// Gets the return data.
        /// </summary>
        T Data { get; }
    }
}