﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 14:06:24
*
***************************************************************************/

using System.Reflection;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides encapsulation of service requests and resolution of returned results.
	/// </summary>
	public interface IServiceRequestProxy
	{
		/// <summary>
		/// Send a request to the specified Uri.
		/// </summary>
		/// <param name="service">Requested service.</param>
		/// <param name="method">Requested method.</param>
		/// <param name="parameters">A collection of request parameters.</param>
		/// <returns>The result returned by the request.</returns>
		T Request<T>(IAppService service, MethodInfo method, params object[] parameters);
	}
}