﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 15:32:57
*
***************************************************************************/

using System;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides functionality to serialize objects or value types to JSON
	/// and to deserialize JSON into objects or value types.
	/// </summary>
	public static class JsonConvert
	{
		/// <summary>
		/// Converts the specified type value to a JSON string.
		/// </summary>
		/// <typeparam name="T">The type of the value to serialize.</typeparam>
		/// <param name="value">The value to convert.</param>
		/// <returns>A JSON string representation of the value.</returns>
		public static string Serialize<T>(T value)
		{
			return Newtonsoft.Json.JsonConvert.SerializeObject(value);
		}

		/// <summary>
		/// Parses the text representing a JSON value into an instance of a specified type.
		/// </summary>
		/// <param name="value">The JSON text to parse.</param>
		/// <param name="type">The type of the object to convert to and return.</param>
		/// <returns>A returnType representation of the JSON value.</returns>
		public static object Deserialize(string value, Type type)
		{
			return Newtonsoft.Json.JsonConvert.DeserializeObject(value, type);
		}

		/// <summary>
		/// Parses the text representing a JSON value into an instance of a specified type.
		/// </summary>
		/// <typeparam name="T">The target type of the JSON value.</typeparam>
		/// <param name="value">The JSON text to parse.</param>
		/// <returns>A <typeparamref name="T"/> representation of the JSON value.</returns>
		public static object Deserialize<T>(string value)
		{
			return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(value);
		}
	}
}