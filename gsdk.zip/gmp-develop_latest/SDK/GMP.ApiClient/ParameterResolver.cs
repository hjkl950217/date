﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:58:23
*
***************************************************************************/

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides methods of parameter resolve for services.
	/// This class cannot be inherited.
	/// </summary>
	public sealed class ParameterResolver
	{
		/// <summary>
		/// Gets a collection of request parameters.
		/// </summary>
		private readonly Dictionary<string, object> referenceTypeParams = new Dictionary<string, object>();

		private readonly Dictionary<string, string> valueTypeParams = new Dictionary<string, string>();

		/// <summary>
		/// Gets or sets a value indicating whether the parameter contains a ValueType parameter.
		/// </summary>
		public bool HasValueTypes { get; set; }

		/// <summary>
		/// Gets or sets a value indicating whether the parameter contains ReferenceType parameter.
		/// </summary>
		public bool HasReferenceTypes { get; set; }

		/// <summary>
		/// Gets all of the ValueType parameters.
		/// </summary>
		public Dictionary<string, string> ValueTypeParams => this.valueTypeParams;

		/// <summary>
		/// Gets all of the ReferenceType parameters.
		/// </summary>
		public Dictionary<string, object> ReferenceTypeParams => this.referenceTypeParams;

		/// <summary>
		/// Initializes a new instance of the <see cref="ParameterResolver"/> class.
		/// </summary>
		/// <param name="method">The <see cref="MethodInfo"/> for a method of the service.</param>
		/// <param name="params">A collection of request parameters.</param>
		public ParameterResolver(MethodInfo method, object[] @params)
		{
			ParameterInfo[] parameterInfos = method.GetParameters();
			if (parameterInfos.Length == 0) return;

			//Adds the parameter name and value to the collection.
			for (int i = 0 ; i < parameterInfos.Length ; i++)
			{
				object value = @params[i];
				if (value == null) continue;
				if (value.GetType().IsValueType || value is string)
				{
					this.valueTypeParams.Add(parameterInfos[i].Name, value.ToString());
					this.HasValueTypes = true;
				}
				else
				{
					this.HasReferenceTypes = true;
					this.referenceTypeParams.Add(parameterInfos[i].Name, value);
				}
			}
		}

		/// <summary>
		/// Gets the content of the request in Get mode.
		/// </summary>
		/// <returns>The content of the request in Get mode.</returns>
		public string GetUrlContent()
		{
			string search = "";

			foreach (KeyValuePair<string, string> item in this.ValueTypeParams)
			{
				if (item.Value == null) continue;
				search += $"{item.Key}={item.Value}&";
			}

			foreach (KeyValuePair<string, object> item in this.ReferenceTypeParams)
			{
				Dictionary<string, object> dic = this.ConvertToDictionary(item.Key, item.Value);
				foreach (KeyValuePair<string, object> obj in dic)
				{
					search += $"{obj.Key}={obj.Value}&";
				}
			}

			return search;
		}

		/// <summary>
		/// Gets the content of the request in Post mode.
		/// </summary>
		/// <returns>The content of the request in Post mode.</returns>
		public string GetPostContent()
		{
			if (this.ReferenceTypeParams.Count == 1)
			{
				object value = this.ReferenceTypeParams.First().Value;
				return JsonConvert.Serialize(value);
			}

			return JsonConvert.Serialize(this.ReferenceTypeParams);
		}

		/// <summary>
		/// Gets the content of the request in Put mode.
		/// </summary>
		/// <returns>The content of the request in Put mode.</returns>
		public string GetPutContent()
		{
			return this.GetPostContent();
		}

		/// <summary>
		/// Gets the content of the request in Delete mode.
		/// </summary>
		/// <returns>The content of the request in Delete mode.</returns>
		public string GetDeleteContent()
		{
			return this.GetUrlContent();
		}

		/// <summary>
		/// Converts an object of the specified <typeparamref name="T"/> to a <see cref="Dictionary{TKey, TValue}"/>.
		/// </summary>
		/// <typeparam name="T">Any type that can be converted to a dictionary.</typeparam>
		/// <param name="name">The parameter name.</param>
		/// <param name="obj">The object to be converted to a dictionary.</param>
		/// <returns>A dictionary.</returns>
		private Dictionary<string, object> ConvertToDictionary<T>(string name, T obj) where T : class
		{
			Dictionary<string, object> dic = new Dictionary<string, object>();

			if (obj is IDictionary)
			{
				dic = this.ConvertToDictionary(name, obj as IDictionary);
			}
			else if (obj is IList)
			{
				dic = this.ConvertToDictionary(name, obj as IList);
			}
			else
			{
				PropertyInfo[] propertis = obj.GetType().GetProperties();
				foreach (PropertyInfo property in propertis)
				{
					object value = property.GetValue(obj, null);
					if (value == null) continue;

					dic.Add(property.Name, value);
				}
			}

			return dic;
		}

		/// <summary>
		/// Converts an object of the specified <see cref="IDictionary"/> data to a <see cref="Dictionary{TKey, TValue}"/>.
		/// </summary>
		/// <param name="name">The parameter name.</param>
		/// <param name="data">The object to be converted to a dictionary.</param>
		/// <returns>A dictionary.</returns>
		private Dictionary<string, object> ConvertToDictionary(string name, IDictionary data)
		{
			Dictionary<string, object> dic = new Dictionary<string, object>();

			IDictionaryEnumerator enumerator = data.GetEnumerator();
			while (enumerator.MoveNext())
			{
				DictionaryEntry current = (DictionaryEntry)enumerator.Current;
				dic.Add(current.Key.ToString(), current.Value);
			}

			return dic;
		}

		/// <summary>
		/// Converts an object of the specified <see cref="IList"/> data to a <see cref="Dictionary{TKey, TValue}"/>.
		/// </summary>
		/// <param name="name">The parameter name.</param>
		/// <param name="data">The object to be converted to a dictionary.</param>
		/// <returns>A dictionary.</returns>
		private Dictionary<string, object> ConvertToDictionary(string name, IList data)
		{
			Dictionary<string, object> dic = new Dictionary<string, object>();

			for (int i = 0 ; i < data.Count ; i++)
			{
				dic.Add($"{name}[{i}]", data[i]);
			}

			return dic;
		}
	}
}