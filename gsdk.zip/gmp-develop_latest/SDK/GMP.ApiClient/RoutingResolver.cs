﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:58:07
*
***************************************************************************/

using System;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using GMP.ApiClient.Attributes;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides methods of routing resolve for services.
	/// This class cannot be inherited.
	/// </summary>
	internal sealed class RoutingResolver
	{
		private readonly Uri baseUrl;
		private string requestUrl = "";
		private string serviceRoutePattern;
		private string methodRoutePattern;
		private readonly string[] formalParameters;
		private object[] actualParameters;

		/// <summary>
		/// Initializes a new instance of the <see cref="RoutingResolver"/> class.
		/// </summary>
		/// <param name="baseUrl">The base url of the service.</param>
		/// <param name="service">A service object.</param>
		/// <param name="method">The <see cref="MethodInfo"/> for a method of the service.</param>
		public RoutingResolver(string baseUrl, IAppService service, MethodInfo method)
		{
			this.baseUrl = new Uri(baseUrl);
			this.formalParameters = method.GetParameters().Select(v => v.Name).ToArray();

			this.SetServiceRoutePattern(service);
			this.SetMethodRoutePattern(method);
		}

		/// <summary>
		/// Returns a url for the service.
		/// </summary>
		/// <returns>A url for the service.</returns>
		public string GetRequestUrl(object[] parameters)
		{
			this.actualParameters = parameters;

			this.ParseServicePattern();
			this.ParseMethodPattern();
			this.ParseParameters();

			return this.requestUrl;
		}

		/// <summary>
		/// Sets the route for the service.
		/// </summary>
		/// <param name="service">A service object.</param>
		private void SetServiceRoutePattern(IAppService service)
		{
			ServiceDescriptor descriptor = new ServiceDescriptor(service.GetType());
			object typeAttribute = descriptor.ServiceType.GetCustomAttributes(typeof(RouteAttribute), false).FirstOrDefault();
			if (typeAttribute != null)
			{
				this.serviceRoutePattern = ((RouteAttribute)typeAttribute).Pattern.Replace("[controller]", descriptor.ServiceName);
			}
			else
			{
				this.serviceRoutePattern = descriptor.ServiceName;
			}
		}

		/// <summary>
		/// Sets the route for the service method.
		/// </summary>
		/// <param name="method">The <see cref="MethodInfo"/> for a method of the service.</param>
		private void SetMethodRoutePattern(MethodInfo method)
		{
			object methodAttribute = method.GetCustomAttributes(typeof(RouteAttribute), false).FirstOrDefault();
			if (methodAttribute != null)
			{
				this.methodRoutePattern = ((RouteAttribute)methodAttribute).Pattern.Replace("[action]", method.Name);
			}
			else
			{
				this.methodRoutePattern = method.Name;
			}
		}

		/// <summary>
		/// Resolve the service routing rules.
		/// </summary>
		private void ParseServicePattern()
		{
			/*
            * If the routing rule starts with a slash (/), it ignores the path in baseUrl.
            * e.g.：baseUrl=http://127.0.0.1/api/
            *       serviceRoute=/docs
            * then：requestUrl=http://127.0.0.1/docs
            *
            * If the routing rule starts without a slash (/), it preserves the path portion of the baseUrl.
            * e.g.：baseUrl=http://127.0.0.1/api/
            *       serviceRoute=docs
            * then：requestUrl=http://127.0.0.1/api/docs
            *
            */

			if (this.serviceRoutePattern.StartsWith("/"))
			{
				this.requestUrl = string.Format("{0}://{1}{2}", this.baseUrl.Scheme, this.baseUrl.Authority, this.serviceRoutePattern);
			}
			else
			{
				this.requestUrl = string.Format("{0}/{1}", this.baseUrl.OriginalString, this.serviceRoutePattern);
			}
		}

		/// <summary>
		/// Resolve method routing rules.
		/// </summary>
		private void ParseMethodPattern()
		{
			/*
             * If the routing rule starts with a slash (/), it ignores the path in the serviceRoutePattern.
             * e.g.：baseUrl=http://127.0.0.1/api/
             *       serviceRoute=docs
             *       methodRoute=/{key}/delete
             * then：requestUrl=http://127.0.0.1/api/{key}/delete
             *
             * If the routing rule starts without a slash (/), it preserves the path in the serviceRoutePattern.
             * e.g.：baseUrl=http://127.0.0.1/api/
             *       serviceRoute=docs
             *       methodRoute={key}/delete
             * then：requestUrl=http://127.0.0.1/api/docs/{key}/delete
             *
             */

			if (this.methodRoutePattern.StartsWith("/"))
			{
				this.requestUrl = this.baseUrl.OriginalString + this.methodRoutePattern;
			}
			else
			{
				this.requestUrl = string.Format("{0}/{1}", this.requestUrl, this.methodRoutePattern);
			}
		}

		/// <summary>
		/// Resolve parameter variable.
		/// </summary>
		private void ParseParameters()
		{
			/*
             * Parameters：          {docid}    It is output as a string, when this parameter is not provided or null.
             * Optional parameters： {docid?}   This parameter is ignored, when this parameter is not provided or null.
             * Default value：       {lang=en}  Used the default value, when this parameter is not provided or null.
             */

			for (int i = 0 ; i < this.formalParameters.Length ; i++)
			{
				string param = "{" + this.formalParameters[i] + "}";                     //Parameters
				string optionalParam = "{" + this.formalParameters[i] + "?}";            //Optional parameters
				string defaultValueParam = "{" + this.formalParameters[i] + "=(.*?)}";   //Default value

				//Make parameter variable substitutions.
				string paramValue = this.actualParameters[i] == null ? "" : this.actualParameters[i].ToString();
				if (!string.IsNullOrEmpty(paramValue))
				{
					this.requestUrl = this.requestUrl.Replace(param, paramValue);
					this.requestUrl = this.requestUrl.Replace(optionalParam, paramValue);
					this.requestUrl = Regex.Replace(this.requestUrl, defaultValueParam, paramValue);
				}

				//Parameter value is empty or null.
				if (string.IsNullOrEmpty(paramValue))
				{
					this.requestUrl = this.requestUrl.Replace(optionalParam + "/", paramValue);
					this.requestUrl = Regex.Replace(this.requestUrl, defaultValueParam, "$1");
				}
			}

			//Clear optional parameters and set default values for parameters with default values.
			this.requestUrl = Regex.Replace(this.requestUrl, "{.*?\\?}/{0,1}", "");
			this.requestUrl = Regex.Replace(this.requestUrl, "{[^/{]+=([^/}]+)}", "$1");
		}
	}
}