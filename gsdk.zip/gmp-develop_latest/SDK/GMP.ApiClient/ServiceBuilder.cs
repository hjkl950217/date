﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:57:54
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using GMP.ApiClient.Attributes;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides methods of service builds for services.
	/// This class cannot be inherited.
	/// </summary>
	internal sealed class ServiceBuilder
	{
		/// <summary>
		/// Service descriptor.
		/// </summary>
		private readonly ServiceDescriptor serviceResolver = null;

		/// <summary>
		/// A collection of parameter types for constructors.
		/// </summary>
		private readonly Type[] ctorParamsTypes = { typeof(IServiceRequestProxy), typeof(MethodInfo[]) };

		/// <summary>
		/// A collection of fields representing a service.
		/// </summary>
		private readonly Dictionary<string, FieldBuilder> serviceFields = new Dictionary<string, FieldBuilder>();

		/// <summary>
		/// The proxy request method for the service
		/// </summary>
		private readonly MethodInfo proxyMethod = typeof(IServiceRequestProxy).GetMethod(nameof(IServiceRequestProxy.Request));

		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceBuilder"/> class.
		/// </summary>
		/// <param name="type">The type of service.</param>
		public ServiceBuilder(Type type)
		{
			this.ServiceType = type;
			this.serviceResolver = new ServiceDescriptor(this.ServiceType);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceBuilder"/> class.
		/// </summary>
		/// <param name="type">The type of service.</param>
		/// <param name="resolver">A <see cref="ServiceDescriptor"/> object.</param>
		public ServiceBuilder(Type type, ServiceDescriptor resolver)
		{
			this.ServiceType = type;
			this.serviceResolver = resolver;
		}

		/// <summary>
		/// Gets or sets the type of service.
		/// </summary>
		public Type ServiceType { get; set; }

		private AssemblyBuilder AssemblyBuilder { get; set; }
		private ModuleBuilder ModuleBuilder { get; set; }
		private TypeBuilder TypeBuilder { get; set; }
		private MethodBuilder MethodBuilder { get; set; }

		/// <summary>
		/// Build an instance of the service.
		/// </summary>
		/// <returns>An instance of the service.</returns>
		public ConstructorInfo Build()
		{
			this.serviceResolver.Check();

			this.BuildAssembly($"{this.serviceResolver.ServiceName}AppService")
				.BuildModule($"{this.serviceResolver.ServiceName}AppService.dll")
				.BuildType(this.serviceResolver.TypeName)
				.DefineInterface(this.ServiceType)
				.DefineField("serviceProxy", typeof(IServiceRequestProxy), FieldAttributes.Private)
				.DefineField("methods", typeof(MethodInfo[]), FieldAttributes.Private)
				//.DefineField("debug", typeof(bool), FieldAttributes.Private)
				.BuildMethod(this.serviceResolver.Methods)
				.BuildConstructor(this.ctorParamsTypes);

			return this.GetConstructor(this.ctorParamsTypes);
		}

		/// <summary>
		/// Build a dynamic assembly with the specified name.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder BuildAssembly(string assemblyName)
		{
			if (string.IsNullOrEmpty(assemblyName)) throw new ArgumentNullException(nameof(assemblyName));

			AssemblyName name = new AssemblyName(assemblyName);
#if NET40
            this.AssemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(name, AssemblyBuilderAccess.Run);
#elif NET45
            this.AssemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(name, AssemblyBuilderAccess.RunAndSave);
#else
			this.AssemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(name, AssemblyBuilderAccess.Run);
#endif

			return this;
		}

		/// <summary>
		/// Build a module with the specified name.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder BuildModule(string moduleName)
		{
			if (string.IsNullOrEmpty(moduleName)) throw new ArgumentNullException(nameof(moduleName));
			if (this.AssemblyBuilder == null) throw new NullReferenceException(nameof(this.AssemblyBuilder));

			this.ModuleBuilder = this.AssemblyBuilder.DefineDynamicModule(moduleName);

			return this;
		}

		/// <summary>
		/// Build a service type with the specified name.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder BuildType(string typeName)
		{
			if (string.IsNullOrEmpty(typeName)) throw new ArgumentNullException(nameof(typeName));
			if (this.ModuleBuilder == null) throw new NullReferenceException(nameof(this.ModuleBuilder));

			this.TypeBuilder = this.ModuleBuilder.DefineType(typeName, TypeAttributes.Class | TypeAttributes.Public);

			//Set Attribute
			object typeAttribute = this.ServiceType.GetCustomAttributes(typeof(RouteAttribute), false).FirstOrDefault();
			if (typeAttribute != null)
			{
				ConstructorInfo ctor = ((RouteAttribute)typeAttribute).GetType().GetConstructor(new Type[] { typeof(string) });
				CustomAttributeBuilder customAttrBuilder = new CustomAttributeBuilder(ctor, new object[] { ((RouteAttribute)typeAttribute).Pattern });
				this.TypeBuilder.SetCustomAttribute(customAttrBuilder);
			}

			return this;
		}

		/// <summary>
		/// Add an interface to the service.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder DefineInterface(Type interfaceType)
		{
			if (interfaceType == null) throw new ArgumentNullException(nameof(interfaceType));
			if (this.TypeBuilder == null) throw new NullReferenceException(nameof(this.TypeBuilder));

			if (!interfaceType.IsInterface)
			{
				throw new NotSupportedException("The parameter interfaceType must be the interfaceType.");
			}

			this.TypeBuilder.AddInterfaceImplementation(interfaceType);

			return this;
		}

		/// <summary>
		/// Build the field to the service.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder DefineField(string name, Type type, FieldAttributes attributes)
		{
			if (string.IsNullOrEmpty(name)) throw new ArgumentNullException(nameof(name));
			if (type == null) throw new ArgumentNullException(nameof(type));
			if (this.TypeBuilder == null) throw new NullReferenceException(nameof(this.TypeBuilder));

			FieldBuilder fieldBuilder = this.TypeBuilder.DefineField(name, type, attributes);
			this.serviceFields.Add(name, fieldBuilder);

			return this;
		}

		/// <summary>
		/// Build the methods to the service.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder BuildMethod(MethodInfo[] methods)
		{
			if (methods.Length == 0) return this;
			if (this.TypeBuilder == null) throw new NullReferenceException(nameof(this.TypeBuilder));

			for (int i = 0 ; i < methods.Length ; i++)
			{
				MethodInfo method = methods[i];
				ParameterInfo[] parameters = method.GetParameters();
				Type[] paramTypes = parameters.Select(v => v.ParameterType).ToArray();
				MethodAttributes attributes = MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final | MethodAttributes.NewSlot | MethodAttributes.HideBySig;
				MethodBuilder methodBuilder = this.TypeBuilder.DefineMethod(method.Name, attributes, CallingConventions.Standard, method.ReturnType, paramTypes);

				ILGenerator il = methodBuilder.GetILGenerator();

				//Property: Debug
				if (method.Name == "get_Debug")
				{
					il.Emit(OpCodes.Ldarg_0);
					il.Emit(OpCodes.Ldfld, this.serviceFields["debug"]);
					il.Emit(OpCodes.Ret);

					continue;
				}

				if (method.Name == "set_Debug")
				{
					il.Emit(OpCodes.Ldarg_0);
					il.Emit(OpCodes.Ldarg_1);
					il.Emit(OpCodes.Stfld, this.serviceFields["debug"]);
					il.Emit(OpCodes.Ret);

					continue;
				}

				//Local variable
				LocalBuilder methodInfo = il.DeclareLocal(typeof(MethodInfo));
				LocalBuilder paramArray = il.DeclareLocal(typeof(object[]));
				LocalBuilder result = il.DeclareLocal(typeof(object));

				//MethodInfo method = this.methods[i]
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldfld, this.serviceFields["methods"]);
				il.Emit(OpCodes.Ldc_I4, i);
				il.Emit(OpCodes.Ldelem_Ref);
				il.Emit(OpCodes.Stloc, methodInfo);

				//object[] paramArray = new object[parameters.Length];
				il.Emit(OpCodes.Ldc_I4, parameters.Length);
				il.Emit(OpCodes.Newarr, typeof(object));
				il.Emit(OpCodes.Stloc, paramArray);

				//Parameters
				for (int j = 0 ; j < parameters.Length ; j++)
				{
					il.Emit(OpCodes.Ldloc, paramArray);
					il.Emit(OpCodes.Ldc_I4, j);

					il.Emit(OpCodes.Ldarg, j + 1);

					//If the parameter type is value type or generic, boxed.
					Type paramType = paramTypes[j];
					if (paramType.IsValueType || paramType.IsGenericParameter)
					{
						il.Emit(OpCodes.Box, paramType);
					}

					il.Emit(OpCodes.Stelem_Ref);
				}

				//this.serviceProxy.Request(this, methodInfo, paramArray)
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldfld, this.serviceFields["serviceProxy"]);
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldloc, methodInfo);
				il.Emit(OpCodes.Ldloc, paramArray);
				il.Emit(OpCodes.Callvirt, this.proxyMethod.MakeGenericMethod(method.ReturnType));

				//return result
				il.Emit(OpCodes.Stloc, result);
				il.Emit(OpCodes.Ldloc, result);
				if (method.ReturnType == typeof(void))
				{
					il.Emit(OpCodes.Pop);
				}
				il.Emit(OpCodes.Ret);
			}

			return this;
		}

		/// <summary>
		/// Build the constructor to the service.
		/// </summary>
		/// <returns>The current <see cref="ServiceBuilder"/> instance.</returns>
		public ServiceBuilder BuildConstructor(Type[] ctorParamsTypes)
		{
			if (this.TypeBuilder == null) throw new NullReferenceException(nameof(this.TypeBuilder));

			if (ctorParamsTypes == null)
			{
				this.TypeBuilder.DefineDefaultConstructor(MethodAttributes.Public);
			}
			else
			{
				ConstructorBuilder ctorBuilder = this.TypeBuilder.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, ctorParamsTypes);
				ILGenerator il = ctorBuilder.GetILGenerator();

				//private IAppServiceProxy serviceProxy = null;
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldnull);
				il.Emit(OpCodes.Stfld, this.serviceFields["serviceProxy"]);

				//private MethodInfo[] methods = null;
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldnull);
				il.Emit(OpCodes.Stfld, this.serviceFields["methods"]);

				//Object.ctor()
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Call, typeof(object).GetConstructor(new Type[] { }));

				//this.serviceProxy = Parameter 1
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldarg_1);
				il.Emit(OpCodes.Stfld, this.serviceFields["serviceProxy"]);

				//this.methods = Parameter 2
				il.Emit(OpCodes.Ldarg_0);
				il.Emit(OpCodes.Ldarg_2);
				il.Emit(OpCodes.Stfld, this.serviceFields["methods"]);
				il.Emit(OpCodes.Ret);
			}

			return this;
		}

		/// <summary>
		/// Gets a public instance constructor whose parameters match the types in the specified array.
		/// </summary>
		/// <param name="types">
		/// An array of <see cref="Type"/> objects representing the number, order, and type
		/// of the  parameters for the desired constructor,
		/// or an empty array of <see cref="Type"/> objects
		/// </param>
		/// <returns>A public instance constructor.</returns>
		public ConstructorInfo GetConstructor(Type[] types)
		{
			if (this.TypeBuilder == null) throw new NullReferenceException(nameof(this.TypeBuilder));
#if NET40
            Type type = this.TypeBuilder.CreateType();
#else
			Type type = this.TypeBuilder.CreateTypeInfo();
#endif

#if NETFRAMEWORK
            this.AssemblyBuilder.Save($"{this.serviceResolver.ServiceName}AppService.dll");
#endif
			return type.GetConstructor(types);
		}
	}
}