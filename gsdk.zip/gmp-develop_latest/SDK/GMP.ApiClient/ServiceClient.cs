﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:55:53
*
***************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Reflection;

namespace GMP.ApiClient
{
	/// <summary>
	/// A service client tool that provides instantiation of a service.
	/// This class cannot be inherited.
	/// </summary>
	public sealed class ServiceClient
	{
		/// <summary>
		/// Caching the constructor for the service.
		/// </summary>
		private static readonly ConcurrentDictionary<Type, ConstructorInfo> services = new ConcurrentDictionary<Type, ConstructorInfo>();

		/// <summary>
		/// Gets or sets the request address based on the HTTP/HTTPS protocol.
		/// </summary>
		public static string BaseUrl { get; set; } = "";// AppSettings.Properties["BaseUrl"];

		/// <summary>
		/// Gets or sets the request proxy of the service.
		/// </summary>
		public static IServiceRequestProxy ServiceProxy { get; set; }

		/// <summary>
		/// Returns a service instance of type <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">An interface inherited from <see cref="IAppService"/>.</typeparam>
		/// <returns></returns>
		public static TService GetService<TService>() where TService : class, IAppService
		{
			return GetService<TService>(BaseUrl, null);
		}

		/// <summary>
		/// Returns a service instance of type <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">An interface inherited from <see cref="IAppService"/>.</typeparam>
		/// <param name="baseUrl">A request address based on the HTTP/HTTPS protocol.</param>
		/// <returns></returns>
		public static TService GetService<TService>(string baseUrl) where TService : class, IAppService
		{
			return GetService<TService>(baseUrl, null);
		}

		/// <summary>
		/// Returns a service instance of type <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">An interface inherited from <see cref="IAppService"/>.</typeparam>
		/// <param name="serviceProxy">The service request proxy.</param>
		/// <returns></returns>
		public static TService GetService<TService>(IServiceRequestProxy serviceProxy) where TService : class, IAppService
		{
			return GetService<TService>(BaseUrl, serviceProxy);
		}

		/// <summary>
		/// Returns a service instance of type <typeparamref name="TService"/>.
		/// </summary>
		/// <typeparam name="TService">An interface inherited from <see cref="IAppService"/>.</typeparam>
		/// <param name="baseUrl">A request address based on the HTTP/HTTPS protocol.</param>
		/// <param name="serviceProxy">The service request proxy.</param>
		/// <returns></returns>
		public static TService GetService<TService>(string baseUrl, IServiceRequestProxy serviceProxy) where TService : class, IAppService
		{
			if (string.IsNullOrEmpty(baseUrl))
			{
				throw new ArgumentNullException(nameof(baseUrl));
			}

			Type service = typeof(TService);
			ServiceDescriptor resolver = new ServiceDescriptor(service);
#if NETFRAMEWORK
            var proxy = serviceProxy ?? ServiceClient.ServiceProxy ?? new HttpWebRequestProxy(baseUrl);
#else
			IServiceRequestProxy proxy = serviceProxy ?? ServiceClient.ServiceProxy ?? new HttpClientRequestProxy(baseUrl);
#endif

			ConstructorInfo ctor = services.GetOrAdd(service, type => new ServiceBuilder(service, resolver).Build());
			return ctor.Invoke(new object[] { proxy, resolver.Methods }) as TService;
		}
	}
}