﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 13:57:38
*
***************************************************************************/

using System;
using System.Linq;
using System.Reflection;

namespace GMP.ApiClient
{
	/// <summary>
	/// Provides a description of the service.This class cannot be inherited.
	/// </summary>
	internal sealed class ServiceDescriptor
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceDescriptor"/> class.
		/// </summary>
		/// <param name="type">The type of the service.</param>
		public ServiceDescriptor(Type type)
		{
			this.ServiceType = type;
			this.ServiceName = type.Name.Substring(1).Replace("AppService", "");
		}

		/// <summary>
		/// Gets a type of the service.
		/// </summary>
		public Type ServiceType { get; private set; }

		/// <summary>
		/// Gets a name of the service.
		/// </summary>
		public string ServiceName { get; private set; }

		/// <summary>
		/// Gets a value indicating whether is a interface type.
		/// </summary>
		public bool IsInterface
		{
			get { return this.ServiceType.IsInterface; }
		}

		/// <summary>
		/// Gets a value indicating whether the current object has public access.
		/// </summary>
		public bool IsPublic
		{
			get
			{
				return this.ServiceType.Attributes.HasFlag(TypeAttributes.Public)
					|| this.ServiceType.Attributes.HasFlag(TypeAttributes.NestedPublic);
			}
		}

		/// <summary>
		/// Gets a name of the assembly.
		/// </summary>
		public string AssemblyName
		{
			get { return this.ServiceType.Assembly.GetName().Name; }
		}

		/// <summary>
		/// Gets a name of module.
		/// </summary>
		public string ModuleName
		{
			get { return this.ServiceType.Module.Name; }
		}

		/// <summary>
		/// Gets a name of the type.
		/// </summary>
		public string TypeName
		{
			get { return $"{this.ServiceName}AppService.{this.ServiceType.Name}"; }
		}

		/// <summary>
		/// Gets all methods of the service, including inherited ones.
		/// </summary>
		public MethodInfo[] Methods
		{
			get { return this.GetMethods(this.ServiceType); }
		}

		/// <summary>
		/// Returns all methods of the specified service, including inherited ones.
		/// </summary>
		/// <param name="type">A type that represents the service.</param>
		/// <returns>An array of the <see cref="MethodInfo"/>.</returns>
		private MethodInfo[] GetMethods(Type type)
		{
			System.Collections.Generic.List<MethodInfo> methods = type.GetMethods().ToList();

			foreach (Type parentType in type.GetInterfaces())
			{
				MethodInfo[] parentMethods = this.GetMethods(parentType);
				if (parentMethods != null)
				{
					foreach (MethodInfo method in parentMethods)
					{
						if (!methods.Contains(method))
						{
							methods.Add(method);
						}
					}
				}
			}

			return methods.ToArray();
		}

		/// <summary>
		/// Gets a value indicating whether inherited the specified type.
		/// </summary>
		/// <param name="type">A type or interface.</param>
		/// <returns>True if inhertied from specified type, otherwise, false.</returns>
		public bool IsInheritFrom(Type type)
		{
			return type.IsAssignableFrom(this.ServiceType);
		}

		/// <summary>
		/// Gets a value indicating whether the service satisfies the specified condition.
		/// </summary>
		/// <returns></returns>
		public bool Check()
		{
			if (!this.IsInterface)
			{
				throw new NotSupportedException($"{this.ServiceType.Name}The service must be an interface type.");
			}

			if (!this.IsPublic)
			{
				throw new NotSupportedException($"{this.ServiceType.Name}The service must have Public access.");
			}

			if (!this.IsInheritFrom(typeof(IAppService)))
			{
				throw new NotSupportedException($"{this.ServiceType.Name}The service must inherit to the IAppService interface.");
			}

			return true;
		}
	}
}