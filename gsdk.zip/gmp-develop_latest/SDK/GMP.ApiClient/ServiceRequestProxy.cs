﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 16:50:52
*
***************************************************************************/

using System;
using System.Reflection;
using GMP.ApiClient.Attributes;

namespace GMP.ApiClient
{
    /// <summary>
    /// Provides an abstract base class for the http request proxy.
    /// The class cannot be instantiated.
    /// </summary>
    public abstract class ServiceRequestProxy : IServiceRequestProxy
    {
        /// <summary>
        /// Gets or sets the request address based on the HTTP/HTTPS protocol.
        /// </summary>
        public string BaseUrl { get; set; }

        /// <summary>
        /// Gets or sets the service request url.
        /// </summary>
        public string RequestUrl { get; set; }

        /// <summary>
        /// Gets or sets the http request method. default <see cref="HttpMethod.Get"/>.
        /// </summary>
        public HttpMethod HttpMethod { get; set; }

        /// <summary>
        /// Gets or sets the http method name. defalut GET.
        /// </summary>
        public string HttpMethodName { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="ApiClient.ParameterResolver"/>.
        /// </summary>
        public ParameterResolver ParameterResolver { get; set; }

        /// <summary>
        /// Initialize a new instance of the <see cref="ServiceRequestProxy"/> class.
        /// </summary>
        /// <param name="baseUrl">The request address based on the HTTP/HTTPS protocol.</param>
        public ServiceRequestProxy(string baseUrl)
        {
            if (string.IsNullOrEmpty(baseUrl)) throw new ArgumentNullException(nameof(baseUrl));

            this.BaseUrl = baseUrl.TrimEnd('/'); ;
            this.HttpMethod = HttpMethod.Get;
            this.HttpMethodName = "GET";
        }

        public T Request<T>(IAppService service, MethodInfo method, params object[] parameters)
        {
            //[1] init
            this.InitRequestParameter(service, method, parameters);

            //[2] execute http call
            T result = this.InternalRequest<T>(service, method, parameters);

            //[3] check http repose
            this.CheckOnResponsed();
            return result;
        }

        /// <summary>
        /// Details of implementing different proxies by subclasses
        /// </summary>
        /// <param name="service">Requested service.</param>
        /// <param name="method">Requested method.</param>
        /// <param name="parameters">A collection of request parameters.</param>
        /// <returns>The virtual methods return null by default.</returns>
        protected abstract T InternalRequest<T>(IAppService service, MethodInfo method, params object[] parameters);

        /// <summary>
        /// Check response after call http
        /// </summary>
        protected abstract void CheckOnResponsed();

        /// <summary>
        /// Init Request Parameter
        /// </summary>
        /// <param name="service">Requested service.</param>
        /// <param name="method">Requested method.</param>
        /// <param name="parameters">A collection of request parameters.</param>
        /// <returns>The virtual methods return null by default.</returns>
        protected virtual void InitRequestParameter(IAppService service, MethodInfo method, params object[] parameters)
        {
            //Get request protocol.
            object[] attrs = method.GetCustomAttributes(typeof(HttpMethodAttribute), false);
            if (attrs.Length > 0)
            {
                this.HttpMethod = (attrs[0] as HttpMethodAttribute).Method;
            }

            //Specify request protocol method.
            this.HttpMethodName = this.HttpMethod switch
            {
                HttpMethod.Get => "GET",
                HttpMethod.Post => "POST",
                HttpMethod.Put => "PUT",
                HttpMethod.Delete => "Delete",
                _ => throw new NotSupportedException()
            };

            //Resolve parameters and routes.
            this.ParameterResolver = new ParameterResolver(method, parameters);
            RoutingResolver router = new RoutingResolver(this.BaseUrl, service, method);
            this.RequestUrl = router.GetRequestUrl(parameters);
            this.RequestUrl += "?" + this.ParameterResolver.GetUrlContent();
        }

        /// <summary>
        /// Converts the specified value to the specified type {<typeparamref name="T"/>}.
        /// </summary>
        /// <typeparam name="T">The type to be converted and returned.</typeparam>
        /// <param name="value">The value to convert.</param>
        /// <returns>The converted value.</returns>
        protected T ConvertValueType<T>(string value)
        {
            object result = null;
            Type returnType = typeof(T);

            if (!returnType.IsValueType && returnType != typeof(string))
            {
                result = JsonConvert.Deserialize<T>(value);
            }
            else if (returnType.IsEnum)
            {
                result = Enum.ToObject(returnType, Convert.ToInt32(value));
            }
            else if (returnType == typeof(char))
            {
                result = Convert.ChangeType(value.Replace("\"", ""), returnType);
            }
            else
            {
                result = Convert.ChangeType(value, returnType);
            }

            return (T)result;
        }
    }
}