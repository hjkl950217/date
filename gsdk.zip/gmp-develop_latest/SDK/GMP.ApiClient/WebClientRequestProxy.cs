﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/24 16:39:26
*
***************************************************************************/

using System;
using System.Collections.Specialized;
using System.Net;
using System.Reflection;
using System.Text;

namespace GMP.ApiClient
{
    /// <summary>
    /// Provides a service request method in <see cref="WebClient"/>.
    /// </summary>
    public class WebClientRequestProxy : ServiceRequestProxy
    {
        protected Exception exception;

        /// <summary>
        /// Initialize a new instance of the <see cref="WebClientRequestProxy"/> class.
        /// </summary>
        /// <param name="baseUrl">The request address based on the HTTP/HTTPS protocol.</param>
        public WebClientRequestProxy(string baseUrl) : base(baseUrl) { }

        protected override T InternalRequest<T>(IAppService service, MethodInfo method, params object[] parameters)
        {
            string result = string.Empty;

            WebClient client = new WebClient();
            client.Headers.Add("Content-Type", "application/json");
            client.Encoding = Encoding.UTF8;

            //Custom ValueType parameter headers
            foreach (System.Collections.Generic.KeyValuePair<string, string> item in this.ParameterResolver.ValueTypeParams)
            {
                client.Headers.Add(item.Key, item.Value);
            }

            #region execute

            try
            {
                if (this.HttpMethod == HttpMethod.Get) result = client.DownloadString(this.RequestUrl);
                if (this.HttpMethod == HttpMethod.Delete) result = client.UploadString(this.RequestUrl, this.HttpMethodName, "");

                if (this.HttpMethod == HttpMethod.Post || this.HttpMethod == HttpMethod.Put)
                {
                    string postData = this.ParameterResolver.GetPostContent();
                    if (!this.ParameterResolver.HasReferenceTypes)
                    {
                        NameValueCollection dic = new NameValueCollection();
                        foreach (System.Collections.Generic.KeyValuePair<string, string> item in this.ParameterResolver.ValueTypeParams)
                        {
                            dic.Add(item.Key, item.Value);
                        }

                        client.Headers[HttpRequestHeader.ContentType] = "application/x-www-form-urlencoded";
                        byte[] response = client.UploadValues(this.RequestUrl, this.HttpMethodName, dic);
                        result = Encoding.UTF8.GetString(response);
                    }
                    else
                    {
                        byte[] bytes = Encoding.UTF8.GetBytes(postData);
                        byte[] response = client.UploadData(this.RequestUrl, this.HttpMethodName, bytes);
                        result = Encoding.UTF8.GetString(response);
                    }
                }
            }
            catch (System.Exception e)
            {
                this.exception = e;
                throw;
            }

            #endregion execute

            return base.ConvertValueType<T>(result);
        }

        protected override void CheckOnResponsed()
        {
            if (this.exception == null) { return; }

            throw new Exception($"request failure!,method:{this.HttpMethod},request uri:{this.RequestUrl},error type:{this.exception.GetType().Name},error msg:{this.exception.Message}");
        }
    }
}