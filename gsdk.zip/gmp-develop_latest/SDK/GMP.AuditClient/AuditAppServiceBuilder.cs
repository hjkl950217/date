﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 15:02:18
*
***************************************************************************/

using System;
using GMP.ApiClient;
using GMP.Configuration;

namespace GMP.AuditClient
{
	/// <summary>
	/// AuditAppService builder
	/// </summary>
	public static class AuditAppServiceBuilder
	{
		/// <summary>
		/// check baseUrl for AuditClientApp with exception when baseUrl is null or empty
		/// </summary>
		/// <param name="urlKey"></param>
		public static void CheckBaseUrlWithException(string urlKey = AuditClientConst.UrlKey)
		{
			string baseUrl = AppSettings.GetValue(urlKey);
			if (baseUrl.IsNullOrEmpty())
			{
				throw new ArgumentNullException("The configuration item AUDIT_SERVICE_URL could not be found");
			}
		}

		/// <summary>
		/// get base url for  AuditClientApp
		/// </summary>
		/// <param name="urlKey"></param>
		/// <returns></returns>
		public static string GetAuditAppBaseUrl(string urlKey = AuditClientConst.UrlKey)
		{
			return AppSettings.GetValue(urlKey);
		}

		/// <summary>
		/// build AuditAppService
		/// </summary>
		/// <param name="urlKey"></param>
		/// <returns></returns>
		public static IAuditAppService BuildAuditAppService(string urlKey = AuditClientConst.UrlKey)
		{
			return ServiceClient.GetService<IAuditAppService>(GetAuditAppBaseUrl(urlKey));
		}
	}
}