﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 14:51:01
*
***************************************************************************/

namespace GMP.AuditClient
{
	/// <summary>
	/// AuditClient 常量
	/// </summary>
	public static class AuditClientConst
	{
		/// <summary>
		/// 获取基础URL配置的key
		/// </summary>
		public const string UrlKey = "audit.service.url";
	}
}