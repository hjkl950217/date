﻿using GMP.AuditClient;
using System;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// AuditClient配置
    /// </summary>
    public static class AuditClientExtension
    {
        /// <summary>
        /// 注册AuditClient服务<para></para>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="appId">常量参考 <see cref="GMP.GmpConst.AppId"/> </param>
        /// <param name="urlKey"></param>
        /// <returns></returns>
        public static IServiceCollection AddGmpAuditClient(
            this IServiceCollection services,
            string appId,
            string urlKey = AuditClientConst.UrlKey)
        {
            if (appId.IsNullOrEmpty())
            {
                throw new ArgumentNullException(nameof(appId));
            }
            AuditProviderExtensions.AppId = appId;

            AuditAppServiceBuilder.CheckBaseUrlWithException(urlKey);

            services.AddSingleton<IAuditAppService>(di =>
            {
                return AuditAppServiceBuilder.BuildAuditAppService();
            });

            services.AddSingleton<IAuditProvider, AuditProvider>();

            return services;
        }
    }
}