﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:04:33
*
***************************************************************************/

using System;

namespace GMP.AuditClient
{
    /// <summary>
    /// <see cref="AuditDataRequest"/> extensions
    /// </summary>
    public static class AuditDataExtensions
    {
        /// <summary>
        /// 检查对象以及必填属性是否为空
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static bool CheckArg(this AuditDataRequest data)
        {
            if (data.IsNullOrEmpty()
                || data.AppId.IsNullOrEmpty()
                || data.Source.IsNullOrEmpty()
                || data.UserName.IsNullOrEmpty()
                || data.UserAccount.IsNullOrEmpty()
                || data.ActionCode.IsNullOrEmpty()) return false;

            return true;
        }

        /// <summary>
        /// 检查对象以及必填属性是否为空,有空时抛出<see cref="ArgumentNullException	"/>
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static void CheckArgWithException(this AuditDataRequest data)
        {
            data.CheckNullWithException(nameof(data));
            data.AppId.CheckNullWithException(nameof(data.AppId));
            data.Source.CheckNullWithException(nameof(data.Source));
            data.UserName.CheckNullWithException(nameof(data.UserName));
            data.UserAccount.CheckNullWithException(nameof(data.UserAccount));
            data.ActionCode.CheckNullWithException(nameof(data.ActionCode));
        }
    }
}