﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:04:33
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GMP.AuditClient
{
    /// <summary>
    /// Represents data related to a system activity.
    /// </summary>
    public class AuditDataRequest
    {
        /// <summary>
        /// [Must]Gets or sets the application id.
        /// </summary>
        [Required]
        public string AppId { get; set; }

        /// <summary>
        /// Gets or sets the time of the event.
        /// </summary>
        public DateTime? OpTime { get; set; }

        /// <summary>
        /// [Must]Gets or sets the event source.
        /// </summary>
        [Required]
        public string Source { get; set; }

        /// <summary>
        /// [Must]Gets or sets the action code.
        /// </summary>
        [Required]
        public string ActionCode { get; set; }

        /// <summary>
        /// [Must]Gets or sets the event user.
        /// </summary>
        [Required]
        public string UserName { get; set; }

        /// <summary>
        /// [Must]Gets or sets the event user account.
        /// </summary>
        [Required]
        public string UserAccount { get; set; }

        /// <summary>
        /// [Must]Gets or sets the orgId
        /// </summary>
        [Required]
        public string OrgId { get; set; }

        /// <summary>
        /// [Must]Gets or sets the org name
        /// </summary>
        [Required]
        public string OrgName { get; set; }

        /// <summary>
        /// Gets or sets the event result.
        /// </summary>
        public bool Result { get; set; }

        /// <summary>
        /// Gets or sets the audit remarks.
        /// </summary>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets a collection of change data.
        /// </summary>
        public List<ChangeData> ChangeData { get; } = new List<ChangeData>();

        /// <summary>
        /// Gets a collection of metadata.
        /// </summary>
        public List<MetaData> MetaData { get; } = new List<MetaData>();
    }
}