﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:05:16
*
***************************************************************************/

using System;
using System.Threading.Tasks;
using GMP.ApiClient;

namespace GMP.AuditClient
{
    /// <summary>
    /// Provides methods for inserting audit events.
    /// </summary>
    public static class AuditManager
    {
        /// <summary>
        /// Add an audit event and return the result of execution.
        /// </summary>
        /// <param name="data">The audit data.</param>
        /// <param name="auditService">Custom audit service implementation.</param>
        public static Task<DataResult<bool>> AddEventAsync(AuditDataRequest data, IAuditAppService auditService = null)
        {
            data.CheckArgWithException();
            data.OpTime ??= DateTime.Now;

            return Task.Run(() =>
            {
                IAuditAppService service = auditService ?? ServiceClient.GetService<IAuditAppService>();
                return service.SaveAuditEvent(data);
            });
        }

        /// <summary>
        /// Add an audit event and return the result of execution.
        /// </summary>
        /// <param name="data">The audit data.</param>
        public static Task<DataResult<bool>> AddEventAsync(AuditDataRequest data)
        {
            IAuditAppService service = AuditAppServiceBuilder.BuildAuditAppService(AuditClientConst.UrlKey);
            return AuditManager.AddEventAsync(data, service);
        }
    }
}