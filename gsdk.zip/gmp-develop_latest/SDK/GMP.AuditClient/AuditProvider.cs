﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/2 16:09:11
*
***************************************************************************/

using System.Threading.Tasks;

namespace GMP.AuditClient
{
    /// <summary>
    /// Provides methods for inserting audit events.
    /// </summary>
    public class AuditProvider : IAuditProvider
    {
        private readonly IAuditAppService auditAppService;

        /// <summary>
        /// 初始化一个<see cref="AuditProvider"/>实例
        /// </summary>
        /// <param name="auditAppService"></param>
        public AuditProvider(IAuditAppService auditAppService)
        {
            this.auditAppService = auditAppService;
        }

        /// <summary>
        /// Add an audit event.
        /// </summary>
        /// <param name="data">The audit data.</param>
        /// <returns></returns>
        public Task<DataResult<bool>> AddEventAsync(AuditDataRequest data)
        {
            return AuditManager.AddEventAsync(data, this.auditAppService);
        }
    }
}