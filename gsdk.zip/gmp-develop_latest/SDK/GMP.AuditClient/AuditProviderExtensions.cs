﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/23 星期五 10:16:35
*
***************************************************************************/

using System;
using System.Collections.Generic;

namespace GMP.AuditClient
{
    public static class AuditProviderExtensions
    {
        // public static Func<HttpClient> createAuditHttpClient;

        public static string AppId = string.Empty;

        /// <summary>
        /// 保存系统审计事件(记录失败时会尝试记录时一条失败的审计信息)
        /// </summary>
        /// <param name="auditProvider"></param>
        /// <param name="actionCode"></param>
        /// <param name="source"></param>
        /// <param name="remarks"></param>
        /// <param name="changeDataList"></param>
        /// <param name="metaDataList"></param>
        /// <param name="result">事件的结果</param>
        /// <param name="orgId"></param>
        /// <param name="orgName"></param>
        /// <returns></returns>
        public static DataResult<bool> AddEvent(
            this IAuditProvider auditProvider,
            string actionCode,
            string source = "",
            string remarks = "",
            IEnumerable<ChangeData> changeDataList = null,
            IEnumerable<MetaData> metaDataList = null,
            bool result = true,
            string orgId = "",
            string orgName = "")
        {
            auditProvider.CheckNullWithException(nameof(auditProvider));
            actionCode.CheckNullWithException(nameof(actionCode));

            AuditDataRequest auditData = new AuditDataRequest()
            {
                AppId = AuditProviderExtensions.AppId,
                Source = source,
                ActionCode = actionCode,
                OpTime = DateTime.Now,
                UserName = "system",
                UserAccount = "system",
                Remarks = remarks,
                Result = result,
                OrgId = orgId,
                OrgName = orgName
            };

            if (changeDataList.IsNotNullOrEmpty())
            {
                auditData.ChangeData.AddRange(changeDataList);
            }
            if (metaDataList.IsNotNullOrEmpty())
            {
                auditData.MetaData.AddRange(metaDataList);
            }

            try
            {
                //记录审计
                return auditProvider.AddEventAsync(auditData)
                   .ConfigureAwait(false)
                   .GetAwaiter()
                   .GetResult();
            }
            catch (Exception e)
            {
                string errMsg = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}]  审计时发生异常:[{e.GetType().Name}] {e.Message} ";
                Console.WriteLine(errMsg);
                //  Logger.Debug();

                //记录审计时发生失败
                auditData.Result = false;
                auditProvider.AddEventAsync(auditData)
                    .ConfigureAwait(false)
                    .GetAwaiter()
                    .GetResult();

                throw;
            }
        }

        //public static async Task<DataResult<bool>> SendEventAsync(AuditData auditData)
        //{
        //    HttpClient httpClient = AuditProviderExtensions.createAuditHttpClient();

        //    //请求
        //    string path = "/gmp/audit/eventbyservice";
        //    Logger.Info($"准备请求'{path}',数据:{auditData.ToJsonExt()}");
        //    HttpResponseMessage responseMsg = await httpClient
        //        .PostAsync(path, new StringContent(auditData.ToJsonExt()));

        //    //处理响应
        //    string headerList = (responseMsg.Headers as IEnumerable<KeyValuePair<string, IEnumerable<string>>>).ToJsonExt();
        //    string responseJsonStr = await responseMsg.Content.ReadAsStringAsync();
        //    Logger.Info($"请求API({responseMsg.RequestMessage.RequestUri})完成[{ responseMsg.StatusCode}],Header:{headerList},收到结果:{responseJsonStr}");

        //    return responseJsonStr.ToObjectExt<DataResult<bool>>();
        //}
    }
}