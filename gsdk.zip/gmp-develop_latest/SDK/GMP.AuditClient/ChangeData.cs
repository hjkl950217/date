﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:03:51
*
***************************************************************************/

namespace GMP.AuditClient
{
	/// <summary>
	/// Represents audit related change data.
	/// </summary>
	public class ChangeData
	{
		/// <summary>
		/// Gets or sets the changed field.
		/// </summary>
		public string Field { get; set; }

		/// <summary>
		/// Gets or sets the field name.
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the old value.
		/// </summary>
		public string OldValue { get; set; }

		/// <summary>
		/// Gets or sets the old text.
		/// </summary>
		public string OldText { get; set; }

		/// <summary>
		/// Gets or sets the new value.
		/// </summary>
		public string NewValue { get; set; }

		/// <summary>
		/// Gets or sets the new text.
		/// </summary>
		public string NewText { get; set; }
	}
}