﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:15:23
*
***************************************************************************/

using GMP.ApiClient;
using GMP.ApiClient.Attributes;

namespace GMP.AuditClient
{
    /// <summary>
    /// Provides methods to add audit events.
    /// </summary>
    [Route("audit")]
    public interface IAuditAppService : IAppService
    {
        /// <summary>
        /// Adds the specified audit event and records its audit data.
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("eventbyservice")]
        DataResult<bool> SaveAuditEvent(AuditDataRequest data);
    }
}