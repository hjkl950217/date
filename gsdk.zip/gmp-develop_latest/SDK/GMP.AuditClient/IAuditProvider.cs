﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/2 16:08:53
*
***************************************************************************/

using System.Threading.Tasks;

namespace GMP.AuditClient
{
    /// <summary>
    /// Provides methods to add audit events.
    /// </summary>
    public interface IAuditProvider
    {
        /// <summary>
        /// Adds the specified audit event and records its audit data.
        /// </summary>
        /// <param name="data">The audit data.</param>
        /// <returns></returns>
        Task<DataResult<bool>> AddEventAsync(AuditDataRequest data);
    }
}