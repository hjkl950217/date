﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:15:23
*
***************************************************************************/

using System;
using System.Collections.Generic;

namespace GMP.AuditClient
{
    public static class IAuditProviderExtensions
    {
        public static List<ChangeData> GetChangeDataList<T>(
            this IAuditProvider auditProvider,
            T oldObj,
            T newObj)
            where T : class
        {
            auditProvider.CheckNullWithException(nameof(auditProvider));
            oldObj.CheckNullWithException(nameof(oldObj));
            newObj.CheckNullWithException(nameof(newObj));

            Dictionary<string, string> oldDic = oldObj.ToDictionary();
            Dictionary<string, string> newDic = newObj.ToDictionary();

            //找出差异
            foreach (KeyValuePair<string, string> item in oldDic)
            {
                if (newDic.GetOrDefault(item.Key) == item.Value)
                {
                    newDic.Remove(item.Key);
                }
            }

            //转换成changeData集合
            List<ChangeData> result = new List<ChangeData>();
            foreach (KeyValuePair<string, string> item in newDic)
            {
                ChangeData changeData = new ChangeData()
                {
                    Field = item.Key,
                    Name = item.Key,
                    OldValue = oldDic[item.Key],
                    NewValue = item.Value,
                    OldText = string.Empty,
                    NewText = string.Empty
                };
                result.Add(changeData);
            }
            return result;
        }

        /// <summary>
        /// Adds the specified audit event and records its audit data.
        /// </summary>
        /// <param name="auditProvider"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public static DataResult<bool> AddEvent(
            this IAuditProvider auditProvider,
            AuditDataRequest data)
        {
            auditProvider.CheckNullWithException(nameof(auditProvider));
            data.CheckNullWithException(nameof(data));

            return auditProvider.AddEventAsync(data)
                .ConfigureAwait(false)
                .GetAwaiter()
                .GetResult();
        }
    }
}