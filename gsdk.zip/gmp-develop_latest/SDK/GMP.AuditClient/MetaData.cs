﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2021/4/1 17:03:09
*
***************************************************************************/

namespace GMP.AuditClient
{
	/// <summary>
	/// Represents audit related metadata.
	/// </summary>
	public class MetaData
	{
		/// <summary>
		/// The key of the metadata.
		/// </summary>
		public string Key { get; set; }

		/// <summary>
		/// The value of metadata.
		/// </summary>
		public string Value { get; set; }

		/// <summary>
		/// The category of metadata, default to Custom.
		/// </summary>
		public string Category { get; set; } = "Custom";

		/// <summary>
		/// Initializes a new instance of the <see cref="MetaData"/>.
		/// </summary>
		public MetaData() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="MetaData"/>
		/// with the specified <paramref name="key"/> and <paramref name="value"/>.
		/// </summary>
		/// <param name="key"></param>
		/// <param name="value"></param>
		public MetaData(string key, string value)
		{
			this.Key = key;
			this.Value = value;
		}
	}
}