﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using AutoMapper;
using GMP.AutoMapper;

namespace Microsoft.Extensions.DependencyInjection
{
	/// <summary>
	/// AutoMapper配置
	/// </summary>
	public static class AutoMapperExtension
	{
		/// <summary>
		/// 注册AutoMapper服务<para></para>
		/// <see cref="Profile"/>类请保证有一个无参数的构造方法
		/// </summary>
		/// <param name="services"></param>
		/// <param name="assemblies">要注册automapper的程序集</param>
		/// <param name="configure">映射配置委托</param>
		/// <returns></returns>
		public static IServiceCollection AddGmpAutoMapper(
			this IServiceCollection services,
			IEnumerable<Assembly> assemblies,
			Action<IMapperConfigurationExpression> configure)
		{
			if (assemblies == null || !assemblies.Any())
			{
				return services;
			}

			(IMapper mapper, IConfigurationProvider config) mapResult = AutoMapperHelper.CrateMapper(assemblies, configure);

			IMapper mapper = mapResult.mapper;
			services.AddSingleton(mapper);
			services.AddSingleton(mapResult.config);

			return services;
		}

		/// <summary>
		/// 注册AutoMapper服务
		/// </summary>
		/// <param name="services"></param>
		/// <param name="assemblies">要注册automapper的程序集</param>
		/// <returns></returns>
		public static IServiceCollection AddGmpAutoMapper(
			this IServiceCollection services,
			params Assembly[] assemblies)
		{
			return AutoMapperExtension.AddGmpAutoMapper(services, assemblies, t => { });
		}
	}
}