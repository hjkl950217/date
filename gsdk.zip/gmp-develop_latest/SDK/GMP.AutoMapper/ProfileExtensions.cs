﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-25 星期二 11:22:11
*
***************************************************************************/

using System;

using GMP.Db.Abstractions.Entity;

namespace AutoMapper
{
    public static class AutoMapperExtensions
    {
        #region Ignore

        /// <summary>
        /// 忽略<see cref="IDbAuditEntity{Tid}"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> IgnoreDbAuditEntity<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TDestination : IDbAuditEntity
        {
            mapping.ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.CreateTime, opt => opt.Ignore())
                .ForMember(dest => dest.ModifiedTime, opt => opt.Ignore())
                .ForMember(dest => dest.CreateId, opt => opt.Ignore())
                .ForMember(dest => dest.UpdateId, opt => opt.Ignore())
                .ForMember(dest => dest.Validity, opt => opt.Ignore());

            return mapping;
        }

        /// <summary>
        /// 忽略<see cref="IFlowEntity"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> IgnoreFlowEntity<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TDestination : IFlowEntity
        {
            mapping.ForMember(dest => dest.FlowStatus, opt => opt.Ignore())
                .ForMember(dest => dest.Process, opt => opt.Ignore())
                .ForMember(dest => dest.Incident, opt => opt.Ignore());

            return mapping;
        }

        #endregion Ignore

        #region Map

        /// <summary>
        /// 映射<see cref="IDbAuditEntity"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> MapDbAuditEntity<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TSource : IDbAuditEntity
            where TDestination : IDbAuditEntity
        {
            mapping.ForMember(dest => dest.Id, opt => opt.MapFrom(t => t.Id))
                .ForMember(dest => dest.CreateTime, opt => opt.MapFrom((a, b, c, ctx) =>
                {
                    return b?.CreateTime ?? DateTime.Now;
                }))
                .ForMember(dest => dest.ModifiedTime, opt => opt.MapFrom(t => DateTime.Now))
                .ForMember(dest => dest.CreateId, opt => opt.MapFrom(t => t.CreateId))
                .ForMember(dest => dest.UpdateId, opt => opt.MapFrom(t => t.UpdateId))
                .ForMember(dest => dest.Validity, opt => opt.MapFrom(t => t.Validity))
                .ForMember(dest => dest.CompanyId, opt => opt.MapFrom(t => t.CompanyId));

            return mapping;
        }

        /// <summary>
        /// 映射<see cref="IFlowEntity"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> MapFlowEntity<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TSource : IFlowEntity
            where TDestination : IFlowEntity
        {
            mapping.ForMember(dest => dest.FlowStatus, opt => opt.MapFrom(t => t.FlowStatus))
                .ForMember(dest => dest.Process, opt => opt.MapFrom(t => t.Process))
                .ForMember(dest => dest.Incident, opt => opt.MapFrom(t => t.Incident));

            return mapping;
        }

        /// <summary>
        /// 映射<see cref="IValidity"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> MapValidity<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TSource : IValidity
            where TDestination : IValidity
        {
            mapping.ForMember(dest => dest.Validity, opt => opt.MapFrom(t => t.Validity));

            return mapping;
        }

        /// <summary>
        /// 映射<see cref="ICompany"/>所属的字段
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDestination"></typeparam>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDestination> MapCompany<TSource, TDestination>(this IMappingExpression<TSource, TDestination> mapping)
            where TSource : ICompany
            where TDestination : ICompany
        {
            mapping.ForMember(dest => dest.CompanyId, opt => opt.MapFrom(t => t.CompanyId));

            return mapping;
        }

        #endregion Map
    }
}