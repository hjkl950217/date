﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/26 12:26:34
*
***************************************************************************/

namespace GMP.Configuration
{
	/// <summary>
	///
	/// </summary>
	public static class AppSettings
	{
		private static readonly IConfiguration config;

		/// <summary>
		/// Represents configuration items.
		/// </summary>
		public static IConfiguration Items => config;

		/// <summary>
		/// Static constructor.
		/// </summary>
		static AppSettings()
		{
			config = new ConfigurationBuilder()
				.AddXmlFile("app.config", true)
				.AddJsonFile("appsettings.json", true)
				.AddEnvironmentVariables()
				.Build();
		}

		/// <summary>
		/// Gets a configuration value with the specified key.
		/// </summary>
		/// <param name="key">The configuration key.</param>
		/// <returns>The configuration value.</returns>
		public static string GetValue(string key) => config[key];

		/// <summary>
		/// Gets a configuration sub-section with the specified key.
		/// </summary>
		/// <param name="key">The key of the configuration section.</param>
		/// <returns>The <see cref="IConfigurationSection"/>.</returns>
		public static IConfigurationSection GetSection(string key) => config.GetSection(key);
	}
}