﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:18:51
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using GMP.Cryptos.Symmetric;

namespace GMP.Configuration
{
    /// <summary>
    /// Used to build key/value based configuration settings for use in an application.
    /// </summary>
    public static class ConfigurationDecrypt
    {
        public const string _DES_KEY = "4d4b582b8bfb1";
        const string Key = "f306917227f343efacbcdb140c6dfbc4";
        public static void Decrypt(IDictionary<string, string> keyValues)
        {
            foreach (var key in keyValues.Keys.ToList())
            {
                keyValues[key] = Decrypt(keyValues[key]);
            }
        }
        public static string Decrypt(string val)
        {
            if (val?.IndexOf(_DES_KEY) != 0) 
                return val;
            var des = new DES(Key);
            return des.Decrypt(val.Remove(0, _DES_KEY.Length));
        }

        public static string Encrypt(string val)
        {
            var des = new DES(Key);
            return _DES_KEY + des.Encrypt(val);
        }
    }
}