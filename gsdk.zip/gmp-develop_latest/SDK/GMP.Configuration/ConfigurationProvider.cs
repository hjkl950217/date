﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:17:14
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Configuration
{
	/// <summary>
	/// Base helper class for implementing an <see cref="IConfigurationProvider"/>
	/// </summary>
	public abstract class ConfigurationProvider : IConfigurationProvider
	{
		/// <summary>
		/// Initialize a new instance of the <see cref="IConfigurationProvider"/> class.
		/// </summary>
		protected ConfigurationProvider()
		{
			this.Data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		}

		/// <summary>
		/// The configuration key value pairs for this provider.
		/// </summary>
		protected IDictionary<string, string> Data { get; set; }

		/// <summary>
		/// Attempts to find a value with the given key, returns true if one is found, false otherwise.
		/// </summary>
		/// <param name="key">The key to lookup.</param>
		/// <param name="value">The value found at key if one is found.</param>
		/// <returns>True if key has a value, false otherwise.</returns>
		public virtual bool TryGet(string key, out string value) => this.Data.TryGetValue(key, out value);

		/// <summary>
		/// Sets a value for a given key.
		/// </summary>
		/// <param name="key">The configuration key to set.</param>
		/// <param name="value">The value to set.</param>
		public virtual void Set(string key, string value) => this.Data[key] = value;

		/// <summary>
		/// Loads (or reloads) the data for this provider.
		/// </summary>
		public virtual void Load() { }

		/// <summary>
		/// Returns the list of keys that this provider has.
		/// </summary>
		/// <param name="earlierKeys">The earlier keys that other providers contain.</param>
		/// <param name="parentPath">The path for the parent IConfiguration.</param>
		/// <returns>The list of keys for this provider.</returns>
		public virtual IEnumerable<string> GetChildKeys(IEnumerable<string> earlierKeys, string parentPath)
		{
			string prefix = parentPath == null ? string.Empty : parentPath + ConfigurationPath.KeyDelimiter;

			return this.Data
				.Where(kv => kv.Key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
				.Select(kv => Segment(kv.Key, prefix.Length))
				.Concat(earlierKeys)
				.OrderBy(k => k, ConfigurationKeyComparer.Instance);
		}

		/// <summary>
		/// Shard the key according to <see cref="ConfigurationPath.KeyDelimiter"/>.
		/// </summary>
		/// <param name="key">The configuration key.</param>
		/// <param name="prefixLength">The prefix length.</param>
		/// <returns>Key after sharding.</returns>
		private static string Segment(string key, int prefixLength)
		{
			int index = key.IndexOf(ConfigurationPath.KeyDelimiter, prefixLength, StringComparison.OrdinalIgnoreCase);
			return index < 0 ? key.Substring(prefixLength) : key.Substring(prefixLength, index - prefixLength);
		}

		/// <summary>
		/// Generates a string representing this provider name and relevant details.
		/// </summary>
		/// <returns> The configuration name. </returns>
		public override string ToString() => $"{this.GetType().Name}";
	}
}