﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/11 22:49:57
*
***************************************************************************/

using System;
using System.Collections.Generic;

namespace GMP.Configuration
{
	/// <summary>
	/// Represents a section of application configuration values.
	/// </summary>
	public class ConfigurationSection : IConfigurationSection
	{
		private readonly ConfigurationRoot root;
		private string key;

		/// <summary>
		/// Initializes a new instance.
		/// </summary>
		/// <param name="root">The configuration root.</param>
		/// <param name="path">The path to this section.</param>
		public ConfigurationSection(ConfigurationRoot root, string path)
		{
			if (root == null) throw new ArgumentNullException(nameof(root));
			if (path == null) throw new ArgumentNullException(nameof(path));

			this.root = root;
			this.Path = path;
		}

		/// <summary>
		/// Gets the full path to this section from the <see cref="IConfiguration"/>.
		/// </summary>
		public string Path { get; }

		/// <summary>
		/// Gets the key this section occupies in its parent.
		/// </summary>
		public string Key
		{
			get
			{
				if (this.key == null)
				{
					//Key is calculated lazily as last portion of Path
					this.key = ConfigurationPath.GetSectionKey(this.Path);
				}

				return this.key;
			}
		}

		/// <summary>
		/// Gets or sets the section value.
		/// </summary>
		public string Value
		{
			get => this.root[this.Path];
			set => this.root[this.Path] = value;
		}

		/// <summary>
		/// Gets or sets the value corresponding to a configuration key.
		/// </summary>
		/// <param name="key">The configuration key.</param>
		/// <returns>The configuration value.</returns>
		public string this[string key]
		{
			get => this.root[ConfigurationPath.Combine(this.Path, key)];
			set => this.root[ConfigurationPath.Combine(this.Path, key)] = value;
		}

		/// <summary>
		/// Gets a configuration sub-section with the specified key.
		/// </summary>
		/// <param name="key">The key of the configuration section.</param>
		/// <returns>The <see cref="IConfigurationSection"/>.</returns>
		/// <remarks>
		///     This method will never return <c>null</c>. If no matching sub-section is found with the specified key,
		///     an empty <see cref="IConfigurationSection"/> will be returned.
		/// </remarks>
		public IConfigurationSection GetSection(string key) => this.root.GetSection(ConfigurationPath.Combine(this.Path, key));

		/// <summary>
		/// Gets the immediate descendant configuration sub-sections.
		/// </summary>
		/// <returns>The configuration sub-sections.</returns>
		public IEnumerable<IConfigurationSection> GetChildren() => this.root.GetChildren(this.Path);
	}
}