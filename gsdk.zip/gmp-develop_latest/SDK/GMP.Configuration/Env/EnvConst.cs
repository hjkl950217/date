﻿namespace GMP.Configuration.Env
{
    public static class EnvConst
    {
        /// <summary>
        /// web项目启动时的URL配置
        /// </summary>
        public const string ASPNETCORE_URLS = "ASPNETCORE_URLS";

        /// <summary>
        /// 程序所有的环境
        /// </summary>
        public const string ASPNETCORE_ENVIRONMENT = "ASPNETCORE_ENVIRONMENT";
    }
}