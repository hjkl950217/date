﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace GMP.Configuration.Env
{
    /// <summary>
    /// 环境帮助类
    /// </summary>
    public static class EnvHelper
    {
        public readonly static EnvInfo EnvInfo;

        static EnvHelper()
        {
            EnvInfo = GetEnvInfo();
        }

        /// <summary>
        /// 获取环境变量
        /// </summary>
        /// <param name="envName"></param>
        /// <returns></returns>
        public static string GetEnvValue(string envName)
        {
            return Environment.GetEnvironmentVariable(envName) ?? string.Empty;
        }

        /// <summary>
        /// 获取所有环境变量
        /// </summary>
        /// <returns></returns>
        public static IReadOnlyDictionary<string, string> GetAllEnvValue()
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            foreach (DictionaryEntry item in Environment.GetEnvironmentVariables())
            {
                result.Add(item.Key.ToString(), item.Value.ToString());
            }

            return result;
        }

        /// <summary>
        /// 获取环境信息对象
        /// </summary>
        /// <returns></returns>
        public static EnvInfo GetEnvInfo()
        {
            if (EnvHelper.EnvInfo != null) return EnvHelper.EnvInfo;

            EnvInfo envInfo = new EnvInfo();
            envInfo.AllEnv = GetAllEnvValue();

            //确定运行环境
            bool parseResult = Enum.TryParse(GetEnvValue(EnvConst.ASPNETCORE_ENVIRONMENT).Trim(), out AppEnvType envType);
            envInfo.AppEnvType = parseResult ? envType : AppEnvType.Development;

            //其它字段

            //确定web项目相关
            envInfo.WebEnvInfo.UrlConfig = GetEnvValue(EnvConst.ASPNETCORE_URLS);

            return envInfo;
        }
    }
}