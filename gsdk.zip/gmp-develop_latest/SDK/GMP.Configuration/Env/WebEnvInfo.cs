﻿namespace GMP.Configuration.Env
{
    /// <summary>
    /// web项目相关的环境变量
    /// </summary>
    public class WebEnvInfo
    {
        /// <summary>
        /// web项目启动时的URL配置
        /// </summary>
        public string UrlConfig { get; set; }
    }
}