﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:09:53
*
***************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace GMP.Configuration.EnvironmentVariable
{
	/// <summary>
	/// An environment variable based <see cref="ConfigurationProvider"/>.
	/// </summary>
	public class EnvironmentVariablesConfigurationProvider : ConfigurationProvider
	{
		/// <summary>
		/// The source settings for this provider.
		/// </summary>
		public EnvironmentVariablesConfigurationSource Source { get; }

		/// <summary>
		/// Initializes a new instance with the specified source.
		/// </summary>
		/// <param name="source">The source settings.</param>
		public EnvironmentVariablesConfigurationProvider(EnvironmentVariablesConfigurationSource source)
		{
			this.Source = source ?? throw new ArgumentNullException(nameof(source));
		}

		/// <summary>
		/// Loads the environment variables.
		/// </summary>
		public override void Load() => this.Load(Environment.GetEnvironmentVariables());

		/// <summary>
		/// Loads the environment variables.
		/// </summary>
		/// <param name="envVariables"></param>
		internal void Load(IDictionary envVariables)
		{
			Dictionary<string, string> data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

			IEnumerable<DictionaryEntry> filteredEnvVariables = envVariables
				.Cast<DictionaryEntry>()
				.Where(entry => ((string)entry.Key).StartsWith(this.Source.Prefix, StringComparison.OrdinalIgnoreCase));

			foreach (DictionaryEntry envVariable in filteredEnvVariables)
			{
				string key = ((string)envVariable.Key).Substring(this.Source.Prefix.Length).ToLower();

				//If need to convert the delimiter.
				if (this.Source.ConvertDelimiter)
				{
					key = key.Replace(this.Source.Delimiter, ConfigurationPath.KeyDelimiter);
				}

				data[key] = (string)envVariable.Value;
			}

			this.Data = data;
            ConfigurationDecrypt.Decrypt(Data);
		}
	}
}