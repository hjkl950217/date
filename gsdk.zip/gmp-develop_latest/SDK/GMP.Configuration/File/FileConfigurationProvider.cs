﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:21:25
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;

namespace GMP.Configuration.File
{
	/// <summary>
	/// Base class for file based <see cref="ConfigurationProvider"/>.
	/// </summary>
	public abstract class FileConfigurationProvider : ConfigurationProvider, IDisposable
	{
		/// <summary>
		/// Initializes a new instance with the specified source.
		/// </summary>
		/// <param name="source">The source settings.</param>
		public FileConfigurationProvider(FileConfigurationSource source)
		{
			this.Source = source ?? throw new ArgumentNullException(nameof(source));
		}

		/// <summary>
		/// The source settings for this provider.
		/// </summary>
		public FileConfigurationSource Source { get; }

		/// <summary>
		/// Generates a string representing this provider name and relevant details.
		/// </summary>
		/// <returns> The configuration name. </returns>
		public override string ToString()
			=> $"{this.GetType().Name} for '{this.Source.Path}' ({(this.Source.Optional ? "Optional" : "Required")})";

		/// <summary>
		/// Loads the provider's data.
		/// </summary>
		/// <param name="reload">Whether to reload.</param>
		private void Load(bool reload)
		{
			try
			{
				//Configuration file are not optional.
				if (!System.IO.File.Exists(this.Source.Path))
				{
					if (this.Source.Optional) return;
					throw new FileNotFoundException($"The configuration file '{this.Source.Path}' was not found and is not optional.");
				}

				//Always create new Data on reload to drop old keys.
				if (reload)
				{
					this.Data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    ConfigurationDecrypt.Decrypt(Data);
                }

				using (Stream stream = new FileStream(
						this.Source.Path,
						FileMode.Open,
						FileAccess.Read,
						FileShare.ReadWrite,
						bufferSize: 1,
						FileOptions.SequentialScan))
				{
					this.Load(stream);
				}
			}
			catch (Exception e)
			{
				this.HandleException(e);
			}
		}

		/// <summary>
		/// Loads the contents of the file at <see cref="Path"/>.
		/// </summary>
		/// <exception cref="FileNotFoundException">If Optional is <c>false</c> on the source and a
		/// file does not exist at specified Path.</exception>
		public override void Load() => this.Load(reload: false);

		/// <summary>
		/// Loads this provider's data from a stream.
		/// </summary>
		/// <param name="stream">The stream to read.</param>
		public abstract void Load(Stream stream);

		/// <summary>
		/// Custom exception handling.
		/// </summary>
		/// <param name="e">The <see cref="Exception"/> object when an exception occurs.</param>
		private void HandleException(Exception e)
		{
			if (this.Source.OnLoadException != null)
			{
				this.Source.OnLoadException.Invoke(e);
			}

			throw e;
		}

		/// <summary>
		/// Dispose the provider.
		/// </summary>
		public void Dispose()
		{
		}
	}
}