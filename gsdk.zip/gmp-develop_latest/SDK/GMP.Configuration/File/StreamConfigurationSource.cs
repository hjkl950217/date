﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:35:19
*
***************************************************************************/

using System.IO;

namespace GMP.Configuration.File
{
	/// <summary>
	/// Stream based <see cref="IConfigurationSource" />.
	/// </summary>
	public abstract class StreamConfigurationSource : IConfigurationSource
	{
		/// <summary>
		/// The stream containing the configuration data.
		/// </summary>
		public Stream Stream { get; set; }

		/// <summary>
		/// Builds the <see cref="StreamConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>An <see cref="IConfigurationProvider"/></returns>
		public abstract IConfigurationProvider Build(IConfigurationBuilder builder);
	}
}