﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:30:02
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace GMP.Configuration.Json
{
	/// <summary>
	/// Provides parsing of JSON configuration files.
	/// </summary>
	internal class JsonConfigurationFileParser
	{
		private readonly IDictionary<string, string> data;

		/// <summary>
		/// External instantiation is not allowed.
		/// </summary>
		private JsonConfigurationFileParser()
		{
			this.data = new SortedDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Parsing the JSON object from a stream.
		/// </summary>
		/// <param name="input">A stream of JSON objects.</param>
		/// <returns>Key/value pairs for json objects.</returns>
		public static IDictionary<string, string> Parse(Stream input)
			=> new JsonConfigurationFileParser().ParseStream(input);

		/// <summary>
		/// Parsing json stream.
		/// </summary>
		/// <param name="input">A stream of JSON objects.</param>
		/// <returns>Key/value pairs for json objects.</returns>
		private IDictionary<string, string> ParseStream(Stream input)
		{
			StreamReader reader = new StreamReader(input);
			string json = reader.ReadToEnd();
			this.ParseJson(json);

			return this.data;
		}

		/// <summary>
		/// Parsing a JSON string.
		/// </summary>
		/// <param name="json">A json string.</param>
		private void ParseJson(string json)
		{
			string temp = string.Empty;
			Stack<string> keys = new Stack<string>();
			bool isStringValue = false;
			bool isEndObject = false;

			//Removes the carriage return newline character and excess characters from the JSON object.
			json = json.Replace("\r\n", "");
			json = Regex.Replace(json, ".*?({.*}).*?", "$1");

			for (int i = 0 ; i < json.Length ; i++)
			{
				if (json[i] != '"' && isStringValue) { temp += json[i]; continue; }
				if (json[i] == '{') { isEndObject = false; continue; }
				if (json[i] == '}')
				{
					//The previous value is an object. e.g.:}}
					if (string.IsNullOrEmpty(temp)) { keys.Pop(); continue; }

					this.data.Add(string.Join(ConfigurationPath.KeyDelimiter, keys.Reverse()).ToLower(), temp);

					keys.Pop();
					if (!string.IsNullOrEmpty(temp) && keys.Count > 0) keys.Pop();

					temp = string.Empty;
					isEndObject = true;
					continue;
				}
				if (json[i] == '"') { isStringValue = !isStringValue; continue; }
				if (json[i] == ' ') continue;
				if (json[i] == ':') { keys.Push(temp); temp = string.Empty; continue; }
				if (json[i] == ',')
				{
					//Represents a comma immediately after an object. e.g.: },
					if (string.IsNullOrEmpty(temp)) continue;

					this.data.Add(string.Join(ConfigurationPath.KeyDelimiter, keys.Reverse()).ToLower(), temp);

					keys.Pop();
					temp = string.Empty;
					continue;
				}

				isEndObject = false;
				temp += json[i];
			}
		}
	}
}