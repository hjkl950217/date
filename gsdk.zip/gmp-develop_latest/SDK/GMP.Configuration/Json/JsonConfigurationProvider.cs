﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:19:39
*
***************************************************************************/

using System;
using System.IO;
using GMP.Configuration.File;

namespace GMP.Configuration.Json
{
	/// <summary>
	/// A JSON file based <see cref="FileConfigurationProvider"/>.
	/// </summary>
	public class JsonConfigurationProvider : FileConfigurationProvider
	{
		/// <summary>
		/// Initializes a new instance with the specified source.
		/// </summary>
		/// <param name="source">The source settings.</param>
		public JsonConfigurationProvider(JsonConfigurationSource source) : base(source)
		{ }

		/// <summary>
		/// Loads the JSON data from a stream.
		/// </summary>
		/// <param name="stream">The stream to read.</param>
		public override void Load(Stream stream)
		{
			try
			{
				this.Data = JsonConfigurationFileParser.Parse(stream);
                ConfigurationDecrypt.Decrypt(Data);
			}
			catch (Exception e)
			{
				throw new FormatException("Could not parse the JSON file.", e);
			}
		}
	}
}