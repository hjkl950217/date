﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:28:36
*
***************************************************************************/

using GMP.Configuration.File;

namespace GMP.Configuration.Json
{
	/// <summary>
	/// Represents a JSON file as an <see cref="IConfigurationSource"/>.
	/// </summary>
	public class JsonConfigurationSource : FileConfigurationSource
	{
		/// <summary>
		/// Builds the <see cref="JsonConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>A <see cref="JsonConfigurationProvider"/></returns>
		public override IConfigurationProvider Build(IConfigurationBuilder builder)
			=> new JsonConfigurationProvider(this);
	}
}