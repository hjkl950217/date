﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 1:25:21
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace GMP.Configuration.Xml
{
	/// <summary>
	/// Provides parsing of XML configuration files.
	/// </summary>
	internal class XmlConfigurationFileParser
	{
		private readonly XmlDocument doc = new XmlDocument();
		private readonly IDictionary<string, string> data;

		/// <summary>
		/// External instantiation is not allowed.
		/// </summary>
		private XmlConfigurationFileParser()
		{
			this.data = new SortedDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Parsing the XML object from a stream.
		/// </summary>
		/// <param name="input">A stream of XML objects.</param>
		/// <returns>Key/value pairs for XML objects.</returns>
		public static IDictionary<string, string> Parse(Stream input)
			=> new XmlConfigurationFileParser().ParseStream(input);

		/// <summary>
		/// Parsing XML stream.
		/// </summary>
		/// <param name="input">A stream of XML objects.</param>
		/// <returns>Key/value pairs for XML objects.</returns>
		private IDictionary<string, string> ParseStream(Stream input)
		{
			this.doc.Load(input);
			this.ParseXmlDocument(this.doc.DocumentElement);

			return this.data;
		}

		/// <summary>
		/// Parsing the XML document.
		/// </summary>
		/// <param name="node">A single node in the XML document.</param>
		/// <param name="path">The path from the XML root node to the current node.</param>
		private void ParseXmlDocument(XmlNode node, string path = "")
		{
			foreach (XmlNode item in node.ChildNodes)
			{
				if (item.HasChildNodes)
				{
					this.ParseXmlDocument(item, ConfigurationPath.Combine(path, item.Name));
					continue;
				}

				XmlNode keyNode = item;

				if (item.NodeType == XmlNodeType.Text)
				{
					keyNode = item.ParentNode;
					path = keyNode.ParentNode == this.doc.DocumentElement ? "" : path.Substring(0, path.LastIndexOf('.'));
				}

				string key = keyNode.Attributes["name"]?.Value ?? keyNode.Attributes["key"]?.Value ?? keyNode.Name;
				string value = item.Value ?? item.Attributes["value"]?.Value ?? item.Attributes["connectionString"]?.Value ?? item.InnerText;

				this.data.Add(ConfigurationPath.Combine(path, key).ToLower(), value);
			}
		}
	}
}