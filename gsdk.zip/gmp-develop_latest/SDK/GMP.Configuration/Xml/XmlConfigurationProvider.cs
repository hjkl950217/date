﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:52:48
*
***************************************************************************/

using System;
using System.IO;
using GMP.Configuration.File;

namespace GMP.Configuration.Xml
{
    /// <summary>
    /// A XML file based <see cref="FileConfigurationProvider"/>.
    /// </summary>
    public class XmlConfigurationProvider : FileConfigurationProvider
    {
        /// <summary>
        /// Initializes a new instance with the specified source.
        /// </summary>
        /// <param name="source">The source settings.</param>
        public XmlConfigurationProvider(XmlConfigurationSource source) : base(source)
        { }

        /// <summary>
        /// Loads the XML data from a stream.
        /// </summary>
        /// <param name="stream">The stream to read.</param>
        public override void Load(Stream stream)
        {
            try
            {
                this.Data = XmlConfigurationFileParser.Parse(stream);
                ConfigurationDecrypt.Decrypt(Data);
            }
            catch (Exception e)
            {
                throw new FormatException("Could not parse the xml file.", e);
            }
        }
    }
}