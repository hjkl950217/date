﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/10/12 0:54:12
*
***************************************************************************/

using GMP.Configuration.File;

namespace GMP.Configuration.Xml
{
	/// <summary>
	/// Represents a XML file as an <see cref="IConfigurationSource"/>.
	/// </summary>
	public class XmlConfigurationSource : FileConfigurationSource
	{
		/// <summary>
		/// Builds the <see cref="XmlConfigurationProvider"/> for this source.
		/// </summary>
		/// <param name="builder">The <see cref="IConfigurationBuilder"/>.</param>
		/// <returns>A <see cref="XmlConfigurationProvider"/></returns>
		public override IConfigurationProvider Build(IConfigurationBuilder builder)
			=> new XmlConfigurationProvider(this);
	}
}