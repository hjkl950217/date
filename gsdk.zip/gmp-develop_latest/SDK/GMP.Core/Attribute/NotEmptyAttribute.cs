﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-26 星期三 14:45:07
*
***************************************************************************/

namespace System.ComponentModel.DataAnnotations
{
    /// <summary>
    /// 指定数据字段为必填且不能为空数组
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter, AllowMultiple = false)]
    public class NotEmptyAttribute : RequiredAttribute
    {
        /// <summary>
        /// 检查数据
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override bool IsValid(object value)
        {
            return value.IsNotNullOrEmpty();
        }
    }
}