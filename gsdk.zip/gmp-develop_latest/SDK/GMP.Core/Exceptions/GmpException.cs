﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 10:23:57
*
***************************************************************************/

using System;
using System.Net;

namespace GMP.Exceptions
{
    /// <summary>
    /// GMP业务异常
    /// </summary>
    public class GmpException : Exception
    {
        /// <summary>
        /// Success
        /// </summary>
        public const int OK_200 = 200;

        /// <summary>
        /// Unknown error.
        /// </summary>
        public const int UNKNOWN = -1;

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="code"></param>
        /// <param name="errorData"></param>
        /// <param name="message"></param>
        /// <param name="httpStatusCode"></param>
        /// <param name="innerException"></param>
        public GmpException(
            int code,
            object errorData,
            string message,
            HttpStatusCode httpStatusCode,
            Exception innerException)
            : base(message, innerException)
        {
            if (code == 0)
            {
                code = UNKNOWN;
            }

            this.Code = code;
            this.HttpStatusCode = httpStatusCode;
            this.ErrorData = errorData ?? new object();
        }

        /// <summary>
        /// 返回时的Http状态码
        /// </summary>
        public HttpStatusCode HttpStatusCode { get; set; }

        /// <summary>
        /// 业务状态码
        /// </summary>
        public int Code { get; protected set; }

        /// <summary>
        /// 异常时需要返回给前端的数据
        /// </summary>
        public object ErrorData { get; set; }

        #region 快捷方法

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(OK_200, new object(), string.Empty, httpStatusCode, null);
        }

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="message"></param>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(
            string message,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(OK_200, new object(), message, httpStatusCode, null);
        }

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="code"></param>
        /// <param name="message"></param>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(
            int code,
            string message,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(code, new object(), message, httpStatusCode, null);
        }

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="errorData"></param>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(
            object errorData,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(OK_200, errorData, string.Empty, httpStatusCode, null);
        }

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="code"></param>
        /// <param name="errorData"></param>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(
            int code,
            object errorData,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(code, errorData, string.Empty, httpStatusCode, null);
        }

        /// <summary>
        /// 初始化<see cref="GmpException"/>
        /// </summary>
        /// <param name="code"></param>
        /// <param name="message"></param>
        /// <param name="errorData"></param>
        /// <param name="httpStatusCode"></param>
        public static GmpException New(
            int code,
            string message,
            object errorData,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            return new GmpException(code, errorData, message, httpStatusCode, null);
        }

        #endregion 快捷方法
    }
}