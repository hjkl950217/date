﻿using System.Globalization;
using System.Text;

namespace System
{
	/// <summary>
	/// Decimal扩展类
	/// </summary>
	public static class DecimalExtension
	{
		#region 格式化相关

		/// <summary>
		/// 默认decimal格式
		/// </summary>
		public static string[] decimalFormats = GetFormatStringArray_ForFloatingPoint(0, 16);

		#region 内部代码

		/// <summary>
		/// 获取浮点类型的格式化字符串的数组
		/// </summary>
		/// <param name="start"></param>
		/// <param name="max"></param>
		/// <returns>例： re ["0.000","0.0000"]。个数说明: 如传递0到16,则返回17个数据</returns>
		private static string[] GetFormatStringArray_ForFloatingPoint(int start = 0, int max = 16)
		{
			int length = max - start;
			string[] result = new string[length + 1];

			for (int i = 0 ; i < result.Length ; i++)
			{
				result[i] = GetFormatString(i + start);
			}

			return result;

			string GetFormatString(int decimals)
			{
				if (decimals == 0) return "0";

				char[] formatChars = new char[decimals + 2];
				formatChars[0] = '0';
				formatChars[1] = '.';

				for (int i = 2 ; i < decimals + 2 ; i++)
				{
					formatChars[i] = '0';
				}

				return new string(formatChars);
			}
		}

		private static string BaseFormatMethod(Func<int, decimal> value, int decimals)
		{
			if (decimals < 0) decimals = 0;
			if (decimals > 16) throw new ArgumentException($"{decimals} cannot be greater than 16", nameof(decimals));

			return value(decimals)
				.ToString(decimalFormats[decimals]);
		}

		#endregion 内部代码

		/// <summary>
		/// 返回 Decimal去掉小数位再保留到指定的精度位 的字符串
		/// </summary>
		/// <param name="value"></param>
		/// <param name="decimals">要保留的小数位，最小0 最大16。如果传递值小于0则按0处理，大于16则报错</param>
		/// <returns></returns>
		public static string ToStringByFloor(
			this decimal value,
			int decimals = 2)
		{
			return BaseFormatMethod(num => Math.Floor(value), decimals);
		}

		/// <summary>
		/// 返回 Decimal去4舍5入后再保留到指定的精度位 的字符串
		/// </summary>
		/// <param name="value"></param>
		/// <param name="decimals">要保留的小数位，最小0 最大16。如果传递值小于0则按0处理，大于16则报错</param>
		/// <param name="mode"></param>
		/// <returns></returns>
		public static string ToStringByRound(
			this decimal value,
			int decimals = 2,
			MidpointRounding mode = MidpointRounding.ToEven)
		{
			return BaseFormatMethod(num => Math.Round(value, num, mode), decimals);
		}

		/// <summary>
		/// 只保留整数部分后，再把值转换为指定精度，保留固定小数位.最少1位
		/// </summary>
		/// <param name="value">要处理的值</param>
		/// <param name="accuracyNum">小数点后的位数</param>
		/// <returns></returns>
		[Obsolete("【弃用】请使用Math.Floor方法,返回字符串请使用ToStringByFloor")]
		public static decimal FloorExt(this decimal value, int accuracyNum = 1)
		{
			if (accuracyNum <= 0)
				throw new ArgumentException(@"When attempting 'FloorExt', the accuracyNum parameter cannot be less than 0", nameof(accuracyNum));

			//处理格式化字符串
			StringBuilder startStr = new StringBuilder();
			startStr.Append("{0:0.");

			for (int i = 0 ; i < accuracyNum ; i++)//添加小数点后的位数
			{
				startStr.Append("0");
			}
			startStr.Append("}");

			//舍去多余部分
			value = Math.Floor(value);

			//固定精度
			string str = string.Format(CultureInfo.InvariantCulture, startStr.ToString(), value);

			return Convert.ToDecimal(str);
		}

		#endregion 格式化相关
	}
}