﻿using System.Linq;
using System.Linq.Expressions;

namespace System.Collections.Generic
{
    /// <summary>
    /// IEnumerable 扩展类
    /// </summary>
    public static class IEnumerableExtension
    {
        /// <summary>
        /// foreach的方法版
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="action"></param>
        public static void For<T>(this IEnumerable<T> source, Action<T> action)
        {
            foreach (T item in source)
            {
                action(item);
            }
        }

        #region WhereIf

        public static IEnumerable<TSource> WhereIf<TSource>(
            this IEnumerable<TSource> source,
            Func<bool> isCondition,
            Func<TSource, bool> predicate)
        {
            return isCondition() ? System.Linq.Enumerable.Where(source, predicate) : source;
        }

        public static IEnumerable<TSource> WhereIf<TSource>(
            this IEnumerable<TSource> source,
            bool isCondition,
            Func<TSource, bool> predicate)
        {
            return IEnumerableExtension.WhereIf(source, () => isCondition, predicate);
        }

        public static IQueryable<TSource> WhereIf<TSource>(
            this IQueryable<TSource> source,
            Func<bool> isCondition,
            Expression<Func<TSource, bool>> predicate)
        {
            return isCondition() ? System.Linq.Queryable.Where(source, predicate) : source;
        }

        public static IQueryable<TSource> WhereIf<TSource>(
            this IQueryable<TSource> source,
            bool isCondition,
            Expression<Func<TSource, bool>> predicate)
        {
            return IEnumerableExtension.WhereIf(source, () => isCondition, predicate);
        }

        #endregion WhereIf
    }
}