﻿namespace System
{
	public static class IntExtension
	{
		/// <summary>
		/// 转换为bool类型
		/// <para>大于0为true。0及以下为false</para>
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static bool ToBool(this int value)
		{
			return value > 0 ? true : false;
		}

		/// <summary>
		/// 转换为bool类型
		/// <para>大于0为true。0及以下为false</para>
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static bool ToBool(this int? value)
		{
			return value.GetValueOrDefault() > 0;
		}
	}
}