﻿using System.Linq;
using System.Text;
using GMP.Extensions;
using GMP.Json;
using Newtonsoft.Json;

namespace System
{
    /// <summary>
    /// 字符串扩展类
    /// </summary>
    public static partial class StringExtension
    {
        /// <summary>
        /// 默认分割符集合
        /// </summary>
        public static readonly char[] DefualtSeparators = new[] { ',', ';' };

        /// <summary>
        /// 转换成对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="jsonStr"></param>
        ///  <param name="settings"></param>
        /// <returns></returns>
        public static T ToObjectExt<T>(this string jsonStr, JsonSerializerSettings settings = null)
        {
            return JsonConvert.DeserializeObject<T>(jsonStr, settings ?? JsonSerializerSettingConst.StorageSetting);
        }

        /// <summary>
        /// 转换成对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="jsonStr"></param>
        /// <param name="defaultValue"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        public static T ToObjectOrDefaultExt<T>(this string jsonStr, T defaultValue = default, JsonSerializerSettings settings = null)
        {
            if (jsonStr.IsNullOrEmpty()) return defaultValue;
            return StringExtension.ToObjectExt<T>(jsonStr, settings);
        }

        #region 基础类型与string之间的转换

        /// <summary>
        /// 基础转换,转换失败时会报错
        /// </summary>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="str">要转换的字符串</param>
        /// <param name="convert">转换的方法</param>
        /// <returns>类型为<typeparamref name="TValue"/>的值</returns>
        /// <exception cref="ArgumentException">The parameter 'str' is invalid、Empty、Null</exception>
        private static TValue BaseConvert<TValue>(
          this string str,
          Func<string, TValue> convert)
        {
            if (str.IsNullOrEmpty() == true)
                throw new ArgumentException("The parameter 'str' is invalid、Empty、Null", nameof(str));

            return convert(str);
        }

        /// <summary>
        /// 基础转换,转换失败时会返回默认值
        /// </summary>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="str">要转换的字符串</param>
        /// <param name="defaultValue">默认值</param>
        /// <param name="convert">转换的方法</param>
        /// <returns>类型为<typeparamref name="TValue"/>的值</returns>
        private static TValue TryBaseConvert<TValue>(
          this string str,
          TValue defaultValue,
          Func<string, TValue> convert)
        {
            if (str.IsNullOrEmpty())
            {
                return defaultValue;
            }
            try
            {
                return convert(str);
            }
            catch
            {
                return defaultValue;
            }
        }

        public static int ToInt32(this string str)
        {
            return str.BaseConvert(System.Convert.ToInt32);
        }

        public static int ToInt32OrDefault(this string str, int defaultValue = 0)
        {
            return str.TryBaseConvert(defaultValue, System.Convert.ToInt32);
        }

        public static bool ToBool(this string str)
        {
            return str.BaseConvert(System.Convert.ToBoolean);
        }

        public static bool ToBoolOrDefault(this string str, bool defaultValue = false)
        {
            return str.TryBaseConvert(defaultValue, System.Convert.ToBoolean);
        }

        public static decimal ToDecimal(this string str)
        {
            return str.BaseConvert(System.Convert.ToDecimal);
        }

        public static decimal ToDecimalOrDefault(
            this string str,
            decimal defaultValue = 0.00M)
        {
            return str.TryBaseConvert(defaultValue, System.Convert.ToDecimal);
        }

        public static double ToDouble(this string str)
        {
            return str.BaseConvert(System.Convert.ToDouble);
        }

        public static double ToDoubleOrDefault(
            this string str,
            double defaultValue = 0.00)
        {
            return str.TryBaseConvert(defaultValue, System.Convert.ToDouble);
        }

        #endregion 基础类型与string之间的转换

        /// <summary>
        /// string转换为MD5字符串,null或""会返回""
        /// </summary>
        /// <param name="str">要加密的字符串</param>
        /// <param name="is32">是否返回32位长度，为false时返回16位</param>
        /// <returns></returns>
        public static string ToMD5(this string str, bool is32 = true)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// 判断两个字符串是否相等，忽略大小写
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        public static bool EqualsIgnoreCase(this string str1, string str2)
        {
            return string.Equals(str1, str2, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// 判断两个字符串是否相等，忽略大小写，忽略首尾空格
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        public static bool EqualsLoose(this string str1, string str2)
        {
            return string.Equals(str1?.Trim(), str2?.Trim(), StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// 分割为数组
        /// </summary>
        /// <param name="source">要处理的字符串</param>
        /// <param name="separators">要分割的字符串.
        /// 默认使用 ,或 ;  参考：<see cref="StringExtension.DefualtSeparators"/>
        /// </param>
        /// <param name="selector">字符串的处理，默认使用Trim().ToUpper()</param>
        /// <returns></returns>
        public static string[] SplitToArray(
            this string source,
            char[] separators = null,
            Func<string, string> selector = null)
        {
            if (source.IsNullOrEmpty())
            {
                return Array.Empty<string>();
            }

            selector = selector ?? (t => t.Trim().ToUpper());
            return source
                .Split(separators
                        ?? StringExtension.DefualtSeparators,
                        StringSplitOptions.RemoveEmptyEntries)
                .Where(i => !string.IsNullOrWhiteSpace(i))
                .Select(i => selector(i))
                .ToArray();
        }

        /// <summary>
        /// 分割为数组 [仅适用于string as成object类型的情况]
        /// </summary>
        /// <param name="source">要处理的字符串</param>
        /// <param name="separators">要分割的字符串.
        /// 默认使用 ,或 ;  参考：<see cref="StringExtension.DefualtSeparators"/>
        /// </param>
        /// <param name="selector">字符串的处理，默认使用Trim().ToUpper()</param>
        /// <returns></returns>
        public static string[] SplitToArray(
            this object source,
            char[] separators = null,
            Func<string, string> selector = null)
        {
            if (source is string)
            {
                string str = source.ToString();
                return str.SplitToArray(separators, selector);
            }
            throw new System.NotSupportedException();
        }

        /// <summary>
        /// 截取字符串，默认从0开始截取。强兼容版本
        /// <para>如果<paramref name="length"/>大于<paramref name="source"/>的长度，则截取<paramref name="source"/>的长度</para>
        /// </summary>
        /// <param name="source">为null或长度为0时返回<see cref="string.Empty"/></param>
        /// <param name="length">要截取的长度。不能小于0</param>
        /// <param name="startIndex">开始截取的索引号。默认为0,不能小于0</param>
        /// <returns></returns>
        public static string SubstringExt(this string source, int length, int startIndex = 0)
        {
            if (source.IsNullOrEmpty()) return string.Empty;
            if (length < 0) throw new ArgumentException("The parameter must be greater than or equal to 0", nameof(length));
            if (startIndex < 0) throw new ArgumentException("The parameter must be greater than or equal to 0", nameof(startIndex));

            length = length > source.Length ? source.Length : length;//如果参数比实际值大，则用实际值

            return source.Substring(startIndex, length);
        }

        /// <summary>
        /// 转换为byte[]
        /// </summary>
        /// <param name="source"></param>
        /// <param name="encoding">编码格式，默认<see cref="Encoding.UTF8"/></param>
        /// <returns></returns>
        public static byte[] ToBytes(this string source, Encoding encoding = null)
        {
            encoding = encoding ?? Encoding.UTF8;
            return source.BaseConvertAndDefalut(Array.Empty<byte>(), encoding.GetBytes);
        }
    }
}