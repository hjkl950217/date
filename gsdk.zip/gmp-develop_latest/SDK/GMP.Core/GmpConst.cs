﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/22 星期四 17:33:50
*
***************************************************************************/

namespace GMP
{
    /// <summary>
    /// 项目常量
    /// </summary>
    public static partial class GmpConst
    {
        /// <summary>
        /// 常用的appid
        /// </summary>
        public static class AppId
        {
            /// <summary>
            /// 文档管理
            /// </summary>
            public const string DMS = "dms";

            /// <summary>
            /// 记录管理
            /// </summary>
            public const string RMS = "rms";

            /// <summary>
            /// 培训管理
            /// </summary>
            public const string TMS = "tms";

            /// <summary>
            /// 档案管理
            /// </summary>
            public const string AMS = "ams";

            /// <summary>
            /// 质量管理
            /// </summary>
            public const string QMS = "qms";

            /// <summary>
            /// 供应商管理
            /// </summary>
            public const string SMS = "sms";

            /// <summary>
            /// 计量管理
            /// </summary>
            public const string MIS = "mis";

            /// <summary>
            /// 项目管理
            /// </summary>
            public const string PMS = "pms";

            /// <summary>
            /// 验证管理
            /// </summary>
            public const string VMS = "vms";

            /// <summary>
            /// 基础设施项目
            /// </summary>
            public const string GMP = "gmp";

            /// <summary>
            /// 基础设施项目-配置中心
            /// </summary>
            public const string Config = "config";
        }
    }
}