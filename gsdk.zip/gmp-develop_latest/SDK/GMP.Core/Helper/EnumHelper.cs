﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace GMP.Helper
{
    /// <summary>
    /// 枚举帮助类
    /// </summary>
    /// <remarks>
    /// 等待重构为有类型缓存的
    /// </remarks>
    public static class EnumHelper
    {
        #region 帮助类内部区-内部类-内部字段-内部方法

        /// <summary>
        /// 缓存的枚举结构
        /// </summary>
        protected class EnumData
        {
            /// <summary>
            /// 枚举值的名字，不是枚举名！
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// 枚举值
            /// </summary>
            /// <remarks>因为从反射出来的数据类型是object</remarks>
            public object EnumValue { get; set; }

            /// <summary>
            /// 枚举值对应的基础类型值
            /// </summary>
            public object BaseValue { get; set; }

            /// <summary>
            /// 枚举值对应的基础类型值-string格式
            /// </summary>
            public string BaseValueString { get; set; }

            /// <summary>
            /// 枚举的基础类型数据
            /// </summary>
            public Type BaseValueType { get; set; }

            /// <summary>
            /// 枚举本身的类型数据
            /// </summary>
            public Type EnumType { get; set; }

            /// <summary>
            /// 获取枚举值，上面的特性
            /// </summary>
            public Attribute[] AttributeList { get; set; }
        }

        /// <summary>
        /// 枚举结构缓存
        /// </summary>
        private static readonly ConcurrentDictionary<string, List<EnumData>> EnumStructCache = new ConcurrentDictionary<string, List<EnumData>>();

        /// <summary>
        /// 提取枚举的结构
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        private static List<EnumData> GetEnumData(Type tEnum)
        {
            List<EnumData> enumDataList = new List<EnumData>();
            Type enumType = tEnum;

            //获得枚举的字段数据
            FieldInfo[] fields = enumType
                 .GetFields(BindingFlags.Static | BindingFlags.Public);

            foreach (FieldInfo item in fields)
            {
                //解析数据
                object enumValue = item.GetValue(null);
                Type baseType = System.Enum.GetUnderlyingType(enumValue.GetType());
                Attribute[] attributeArry = item
                    .GetCustomAttributes<Attribute>()
                    .ToArray();

                //组合
                EnumData tempData = new EnumData()
                {
                    Name = item.Name,
                    EnumValue = enumValue,
                    EnumType = enumType,

                    AttributeList = attributeArry,

                    BaseValueType = baseType,
                    BaseValue = Convert.ChangeType(enumValue, baseType),
                    BaseValueString = System.Enum.Format(enumType, enumValue, "D")
                };

#pragma warning disable S125 // Sections of code should not be "commented out"
                //找问题时可以用这个一行一行的
                //EnumData tempData = new EnumData();
                //tempData.Name = item.Name;
                //tempData.EnumValue = enumValue;
                //tempData.EnumType = enumType;
                //tempData.BaseValueType = baseType;
                //tempData.BaseValue = Convert.ChangeType(enumValue , baseType);
                //tempData.BaseValueString = Enum.Format(enumType , enumValue , "D");
#pragma warning restore S125 // Sections of code should not be "commented out"

                //保存
                enumDataList.Add(tempData);
            }

            return enumDataList;
        }

        /// <summary>
        /// 获取或添加枚举数据。数据源为 (私有)EnumHelper.EnumStructCache
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        private static List<EnumData> GetOrAddEnumCache(Type tEnum)
        {
            List<EnumData> result = EnumStructCache
                 .GetOrAdd(
                 tEnum.Name,
                 t =>
                 {
                     return GetEnumData(tEnum);
                 });

            return result;
        }

        #endregion 帮助类内部区-内部类-内部字段-内部方法

        #region 公共-获取枚举的结构

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TValue">
        /// 枚举对应的值类型.<para></para>
        /// 程序使用：一般为明确写在枚举上的类型，如果没有写，则为int.<para></para>
        /// UI显示：传递string
        /// </typeparam>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        public static IDictionary<string, TValue> GetEnumStruct<TValue>(Type tEnum)
        // where TEnum : struct
        {
            Dictionary<string, TValue> resultList = new Dictionary<string, TValue>();

            //获取枚举结构数据
            List<EnumData> fieldList = GetOrAddEnumCache(tEnum);

            //遍历数据并组合成Dictionary
            foreach (EnumData item in fieldList)
            {
                try
                {
                    TValue value = (TValue)item.BaseValue;
                    resultList.Add(item.Name, value);
                }
                catch (InvalidCastException ex)
                {
                    throw new InvalidCastException(
                        $"获取枚举结构时，枚举值的类型传递错误。枚举名:{item.EnumType.Name}",
                        ex);
                }
            }

            return resultList;
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TEnum">枚举类型</typeparam>
        /// <typeparam name="TValue">
        /// 枚举对应的值类型.<para></para>
        /// 程序使用：一般为明确写在枚举上的类型，如果没有写，则为int.<para></para>
        /// UI显示：传递string
        /// </typeparam>
        /// <returns></returns>
        public static IDictionary<string, TValue> GetEnumStruct<TEnum, TValue>()
        // where TEnum : struct
        {
            return GetEnumStruct<TValue>(typeof(TEnum));
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <returns></returns>
        public static IDictionary<string, string> GetEnumStruct(Type tEnum)
        // where TEnum : Enum
        {
            Dictionary<string, string> resultList = new Dictionary<string, string>();

            //获取枚举结构数据
            List<EnumData> fieldList = GetOrAddEnumCache(tEnum);

            //遍历数据并组合成Dictionary
            foreach (EnumData item in fieldList)
            {
                resultList.Add(item.Name, item.BaseValueString);
            }

            return resultList;
        }

        /// <summary>
        /// 获取枚举的结构
        /// </summary>
        /// <typeparam name="TEnum">枚举类型</typeparam>
        /// <returns></returns>
        public static IDictionary<string, string> GetEnumStruct<TEnum>()
        // where TEnum : Enum
        {
            return GetEnumStruct(typeof(TEnum));
        }

        #endregion 公共-获取枚举的结构

        #region 公共-获取枚举上的Attribute

        /// <summary>
        ///获取枚举值上的默认第一个特性
        /// </summary>
        /// <typeparam name="TAttribute"></typeparam>
        /// <param name="tEnum">枚举的Type数据</param>
        /// <param name="enumValue">枚举值</param>
        /// <returns></returns>
        public static TAttribute GetAttribute<TAttribute>(Type tEnum, object enumValue)
            where TAttribute : Attribute
        {
            //获取枚举结构数据
            List<EnumData> fieldList = GetOrAddEnumCache(tEnum);

            //获取枚举值上面的特性集合
            Attribute[] attributeArry = fieldList
                .FirstOrDefault(t => enumValue.Equals(t.EnumValue))
                ?.AttributeList;

            if (attributeArry == null) return null;

            return attributeArry.FirstOrDefault(t => t is TAttribute) as TAttribute;
        }

        /// <summary>
        ///获取枚举值上的默认第一个特性
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <typeparam name="TAttribute"></typeparam>
        /// <returns></returns>
        public static TAttribute GetAttribute<TEnum, TAttribute>(TEnum enumValue)
            where TAttribute : Attribute
        {
            return GetAttribute<TAttribute>(typeof(TEnum), enumValue);
        }

        #endregion 公共-获取枚举上的Attribute
    }
}