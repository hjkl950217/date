﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/23 星期五 13:44:01
*
***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace GMP.Json
{
    public class OnlyBaseTypeContractResolver : DefaultContractResolver
    {
        public static OnlyBaseTypeContractResolver Instance = new OnlyBaseTypeContractResolver();

        protected override IList<JsonProperty> CreateProperties(
            Type type,
            MemberSerialization memberSerialization)
        {
            IList<JsonProperty> list = base.CreateProperties(type, memberSerialization);

            //只保留string和基本类型
            return list
                .Where(t => t.PropertyType != null)
                .Where(t => t.PropertyType.IsPublic
                    && (t.PropertyType == typeof(string) || !t.PropertyType.IsClass))
                .ToList();
        }
    }
}