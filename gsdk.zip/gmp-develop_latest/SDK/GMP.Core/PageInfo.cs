﻿using System.Xml.Serialization;

namespace GMP
{
    /// <summary>
    /// 分页信息
    /// </summary>
    [XmlRoot("PagingInfo")]
    public partial class PageInfo
    {
        /// <summary>
        /// 分页的开始行
        /// </summary>
        /// <remarks>
        /// 比如分页大小是5
        /// <para>第一页传0，返回12345</para>
        /// <para>第一页传5，返回6789 10</para>
        /// </remarks>
        [XmlElement(nameof(PageInfo.StartRowIndex))]
        public int? StartRowIndex { get; set; }

        /// <summary>
        /// 分页大小
        /// </summary>
        [XmlElement(nameof(PageInfo.PageSize))]
        public int? PageSize { get; set; }

        /// <summary>
        /// 用来排序的字段名
        /// </summary>
        [XmlElement(nameof(PageInfo.SortField))]
        public string SortField { get; set; }

        /// <summary>
        /// 排序类型
        /// </summary>
        [XmlElement(nameof(PageInfo.SortType))]
        public SortType? SortType { get; set; }
    }

    public partial class PageInfo
    {
        /// <summary>
        /// 默认分页大小
        /// </summary>
        public const int PageSize_Default = 50;

        /// <summary>
        /// 获取一个不分页，页面大小无限的分页对象。
        /// <para>通常情况下这种数据适用于要求传递分页字段，但业务上又不分页的时候。</para>
        /// </summary>
        public static PageInfo GetNonPaging()
        {
            return new PageInfo
            {
                StartRowIndex = 0,
                PageSize = int.MaxValue,
                SortType = GMP.SortType.ASC
            };
        }

        /// <summary>
        /// 返回一个默认大小的分页对象。<para></para>
        /// 默认大小参见<see cref="PageInfo.PageSize_Default"/>
        /// </summary>
        public static PageInfo GetDefaultPaging()
        {
            return new PageInfo
            {
                StartRowIndex = 0,
                PageSize = PageInfo.PageSize_Default,
                SortType = GMP.SortType.ASC
            };
        }
    }
}