﻿using System.Xml.Linq;

namespace GMP
{
    public static class PageInfoExtension
    {
        /// <summary>
        /// 获取<see cref="PageInfo"/>的XML结构。<para></para>
        /// </summary>
        /// <returns></returns>
        public static XElement ToXml(this PageInfo pageInfo)
        {
            XElement pageElement = new XElement("PageInfo");

            XElement startRowIndex = new XElement(nameof(PageInfo.StartRowIndex), pageInfo.StartRowIndex);
            XElement pageSize = new XElement(nameof(PageInfo.PageSize), pageInfo.PageSize);
            XElement sortField = new XElement(nameof(PageInfo.SortField), pageInfo.SortField);
            XElement sortType = new XElement(nameof(PageInfo.SortType), pageInfo.SortType.ToString());

            pageElement.Add(startRowIndex);
            pageElement.Add(pageSize);
            pageElement.Add(sortField);
            pageElement.Add(sortType);

            return pageElement;
        }
    }
}