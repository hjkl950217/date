﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 14:16:17
*
***************************************************************************/

using System;
using System.Text;

namespace GMP.Cryptos.Base
{
	/// <summary>
	/// Provides the abstract base class from common properties and methods for encryption and decryption.
	/// </summary>
	public abstract class CryptoBase
	{
		/// <summary>
		/// Gets or sets the key used to encrypt and decrypt the algorithm.
		/// </summary>
		public string Key { get; set; }

		/// <summary>
		/// Gets or sets the IV used to encrypt and decrypt the algorithm.
		/// </summary>
		public string IV { get; set; }

		/// <summary>
		/// Initializes a new instance of the class.
		/// </summary>
		public CryptoBase()
		{
			this.Key = string.Empty;
			this.IV = string.Empty;
		}

		/// <summary>
		/// Initializes a new instance of the  class.
		/// </summary>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		public CryptoBase(string key) : this(key, string.Empty) { }

		/// <summary>
		/// Initializes a new instance of the class.
		/// </summary>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		/// <param name="iv">The IV used to encrypt and decrypt the algorithm.</param>
		public CryptoBase(string key, string iv)
		{
			this.Key = key;
			this.IV = iv;
		}

		/// <summary>
		/// Returns a ciphertext encrypted using the specified algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext using the specified algorithm encrypted.</returns>
		public abstract string Encrypt(string plaintext);

		/// <summary>
		/// Returns a plaintext decrypted using the specified algorithm.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns>A plaintext decrypted using the specified algorithm.</returns>
		public virtual string Decrypt(string ciphertext)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Converts a string to an array of bytes using the default encoding.
		/// </summary>
		/// <param name="str">A string to be converted.</param>
		/// <param name="length">
		/// Optionally, specify the length of the converted string,
		/// adding a zero to the end of the string when the length
		/// of the original string does not meet the specified length,
		/// the original string is truncated if it exceeds the specified length.
		/// </param>
		/// <returns>An array of bytes</returns>
		public virtual byte[] StringToBytes(string str, int length = 0)
		{
			if (length > 0)
			{
				str = str.PadRight(length, '0').Substring(0, length);
			}

			return Encoding.Default.GetBytes(str);
		}

		/// <summary>
		/// Converts an array of bytes to a string using the default encoding.
		/// </summary>
		/// <param name="bytes">An array of bytes</param>
		/// <returns>A <see cref="string"/> object.</returns>
		public virtual string BytesToString(byte[] bytes)
		{
			return Encoding.Default.GetString(bytes).TrimEnd('\0');
		}
	}
}