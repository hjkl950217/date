﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 14:16:27
*
***************************************************************************/

using System.Text;

namespace GMP.Cryptos.Base
{
	/// <summary>
	/// Provides an abstract base class from which all implementations
	/// of hash encryption algorithms derive.
	/// </summary>
	public abstract class HashAlgorithm : CryptoBase
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="HashAlgorithm"/> class.
		/// </summary>
		public HashAlgorithm() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="HashAlgorithm"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt the algorithm.</param>
		public HashAlgorithm(string key) : base(key) { }

		/// <summary>
		/// Returns a ciphertext encrypted using the hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public abstract override string Encrypt(string plaintext);

		/// <summary>
		/// Calculates the hash value of the string using the specified hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <param name="algorithm">An instance of a hash algorithm.</param>
		/// <returns>A string that represents the hash value.</returns>
		public string GetHash(string plaintext, System.Security.Cryptography.HashAlgorithm algorithm)
		{
			byte[] plaintextBytes = this.StringToBytes(plaintext);
			byte[] ciphertextBytes = algorithm.ComputeHash(plaintextBytes);

			return this.BytesToString(ciphertextBytes);
		}

		/// <summary>
		/// Converts an array of bytes to a string.
		/// </summary>
		/// <param name="bytes">An array of bytes.</param>
		/// <returns></returns>
		public override string BytesToString(byte[] bytes)
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0 ; i < bytes.Length ; i++)
			{
				sb.Append(bytes[i].ToString("x2"));
			}

			return sb.ToString();
		}
	}
}