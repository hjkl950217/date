﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 14:16:46
*
***************************************************************************/

namespace GMP.Cryptos.Base
{
	/// <summary>
	/// Provides an abstract base class from which all implementations
	/// of symmetric encryption and decryption algorithms derive.
	/// </summary>
	public abstract class SymmetricAlgorithm : CryptoBase
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="SymmetricAlgorithm"/> class.
		/// </summary>
		public SymmetricAlgorithm() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="SymmetricAlgorithm"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		public SymmetricAlgorithm(string key) : base(key) { }

		/// <summary>
		/// Initializes a new instance of the <see cref="SymmetricAlgorithm"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		/// <param name="iv">The IV used to encrypt and decrypt the algorithm.</param>
		public SymmetricAlgorithm(string key, string iv) : base(key, iv) { }

		/// <summary>
		/// Returns a ciphertext encrypted using the specified algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns></returns>
		public abstract override string Encrypt(string plaintext);

		/// <summary>
		/// Returns a plaintext decrypted using the specified algorithm.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns></returns>
		public abstract override string Decrypt(string ciphertext);
	}
}