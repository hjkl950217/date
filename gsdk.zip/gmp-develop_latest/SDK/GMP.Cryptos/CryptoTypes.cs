﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 14:59:43
*
***************************************************************************/

using System;
using GMP.Cryptos.Base;
using GMP.Cryptos.Hash;
using GMP.Cryptos.Symmetric;

namespace GMP.Cryptos
{
	/// <summary>
	/// Provides all supported data encryption types.
	/// </summary>
	public static class CryptoTypes
	{
		/// <summary>
		/// AES symmetric encryption algorithm.
		/// </summary>
		public static CryptoBase AES => new AES();

		/// <summary>
		/// Base64 encryption and decryption.
		/// </summary>
		public static CryptoBase BASE64 => new BASE64();

		/// <summary>
		/// DES symmetric encryption algorithm.
		/// </summary>
		public static CryptoBase DES => new DES();

		/// <summary>
		///
		/// </summary>
		public static CryptoBase RC4 => throw new NotImplementedException();

		/// <summary>
		/// RSA symmetric encryption algorithm.
		/// </summary>
		public static CryptoBase RSA => new RSA();

		/// <summary>
		/// MD5 hash encryption algorithm.
		/// </summary>
		public static CryptoBase MD5 => new MD5();

		/// <summary>
		/// SHA1 hash encryption algorithm.
		/// </summary>
		public static CryptoBase SHA1 => new SHA1();

		/// <summary>
		/// SHA256 hash encryption algorithm.
		/// </summary>
		public static CryptoBase SHA256 => new SHA256();

		/// <summary>
		/// SHA384 hash encryption algorithm.
		/// </summary>
		public static CryptoBase SHA384 => new SHA384();

		/// <summary>
		/// SHA512 hash encryption algorithm.
		/// </summary>
		public static CryptoBase SHA512 => new SHA512();

		/// <summary>
		/// HMACMD5 hash encryption algorithm.
		/// </summary>
		public static CryptoBase HMACMD5 => new HMACMD5();

		/// <summary>
		/// HMACSHA1 hash encryption algorithm.
		/// </summary>
		public static CryptoBase HMACSHA1 => new HMACSHA1();

		/// <summary>
		/// HMACSHA256 hash encryption algorithm.
		/// </summary>
		public static CryptoBase HMACSHA256 => new HMACSHA256();

		/// <summary>
		/// HMACSHA384 hash encryption algorithm.
		/// </summary>
		public static CryptoBase HMACSHA384 => new HMACSHA384();

		/// <summary>
		/// HMACSHA512 hash encryption algorithm.
		/// </summary>
		public static CryptoBase HMACSHA512 => new HMACSHA512();
	}
}