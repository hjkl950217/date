﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:01:33
*
***************************************************************************/

using GMP.Cryptos.Base;

namespace GMP.Cryptos
{
	/// <summary>
	/// Provides uniform invocation for various encryption types.
	/// The class cannot be inherited.
	/// </summary>
	public class Encryptor
	{
		private readonly CryptoBase cryptor = null;

		/// <summary>
		/// Gets or sets the Key used to encrypt and decrypt the algorithm.
		/// </summary>
		public string Key { get => this.cryptor.Key; set => this.cryptor.Key = value; }

		/// <summary>
		/// Gets or sets the IV used to encrypt and decrypt the algorithm.
		/// </summary>
		public string IV { get => this.cryptor.IV; set => this.cryptor.IV = value; }

		/// <summary>
		/// Initialize a new instance of the <see cref="Encryptor"/> class.
		/// </summary>
		/// <param name="cryptor">The crypto class of the specified type.</param>
		public Encryptor(CryptoBase cryptor)
		{
			this.cryptor = cryptor;
		}

		/// <summary>
		/// Initialize a new instance of the <see cref="Encryptor"/> class.
		/// </summary>
		/// <param name="cryptor">The crypto class of the specified type.</param>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		public Encryptor(CryptoBase cryptor, string key) : this(cryptor)
		{
			this.Key = key;
		}

		/// <summary>
		/// Initialize a new instance of the <see cref="Encryptor"/> class.
		/// </summary>
		/// <param name="cryptor">The crypto class of the specified type.</param>
		/// <param name="key">The key used to encrypt and decrypt the algorithm.</param>
		/// <param name="iv">the iv used to encrypt and decrypt the algorithm.</param>
		public Encryptor(CryptoBase cryptor, string key, string iv) : this(cryptor, key)
		{
			this.IV = iv;
		}

		/// <summary>
		/// Returns a ciphertext encrypted using the specified algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns></returns>
		public string Encrypt(string plaintext)
		{
			return this.cryptor.Encrypt(plaintext);
		}

		/// <summary>
		/// Returns a plaintext decrypted using the specified algorithm.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns></returns>
		public string Decrypt(string ciphertext)
		{
			return this.cryptor.Decrypt(ciphertext);
		}
	}
}