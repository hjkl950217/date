﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:49:25
*
***************************************************************************/

using GMP.Cryptos.Base;

namespace GMP.Cryptos.Hash
{
	/// <summary>
	/// Provides HMACSHA384 hash encryption algorithm.
	/// </summary>
	public class HMACSHA384 : HashAlgorithm
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="HMACSHA384"/> class.
		/// </summary>
		public HMACSHA384() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="HMACSHA384"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt the algorithm.</param>
		public HMACSHA384(string key) : base(key) { }

		/// <summary>
		/// Returns a ciphertext encrypted using the HMACSHA384 hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <remarks>It is different from that calculated by network platform.</remarks>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public override string Encrypt(string plaintext)
		{
			string ciphertext = string.Empty;
			byte[] plaintextBytes = this.StringToBytes(base.Key ?? "");

			System.Security.Cryptography.HMACSHA384 sha = new System.Security.Cryptography.HMACSHA384(plaintextBytes);
			ciphertext = this.GetHash(plaintext, sha);

			return ciphertext;
		}
	}
}