﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:49:37
*
***************************************************************************/

using GMP.Cryptos.Base;

namespace GMP.Cryptos.Hash
{
	/// <summary>
	/// Provides HMACSHA512 hash encryption algorithm.
	/// </summary>
	public class HMACSHA512 : HashAlgorithm
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="HMACSHA512"/> class.
		/// </summary>
		public HMACSHA512() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="HMACSHA512"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt the algorithm.</param>
		public HMACSHA512(string key) : base(key) { }

		/// <summary>
		/// Returns a ciphertext encrypted using the HMACSHA512 hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public override string Encrypt(string plaintext)
		{
			string ciphertext = string.Empty;
			byte[] plaintextBytes = this.StringToBytes(base.Key ?? "");

			System.Security.Cryptography.HMACSHA512 sha = new System.Security.Cryptography.HMACSHA512(plaintextBytes);
			ciphertext = this.GetHash(plaintext, sha);

			return ciphertext;
		}
	}
}