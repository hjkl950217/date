﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:49:50
*
***************************************************************************/

using GMP.Cryptos.Base;

namespace GMP.Cryptos.Hash
{
	/// <summary>
	/// Provides MD5 hash encryption algorithm.
	/// </summary>
	public class MD5 : HashAlgorithm
	{
		/// <summary>
		/// Returns a 16 length ciphertext encrypted using the MD5 hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public string Encrypt16(string plaintext)
		{
			string ciphertext = string.Empty;

			ciphertext = this.Encrypt(plaintext);
			ciphertext = ciphertext.Substring(7, 16);

			return ciphertext;
		}

		/// <summary>
		/// Returns a ciphertext encrypted using the MD5 hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public override string Encrypt(string plaintext)
		{
			string ciphertext = string.Empty;

			System.Security.Cryptography.MD5 sha = System.Security.Cryptography.MD5.Create();
			ciphertext = this.GetHash(plaintext, sha);

			return ciphertext;
		}
	}
}