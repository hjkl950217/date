﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:48:06
*
***************************************************************************/

using GMP.Cryptos.Base;

namespace GMP.Cryptos.Hash
{
	/// <summary>
	/// Provides SHA384 hash encryption algorithm.
	/// </summary>
	public class SHA384 : HashAlgorithm
	{
		/// <summary>
		/// Returns a ciphertext encrypted using the SHA384 hash algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext encrypted using the hash algorithm.</returns>
		public override string Encrypt(string plaintext)
		{
			string ciphertext = string.Empty;

			System.Security.Cryptography.SHA384 sha = System.Security.Cryptography.SHA384.Create();
			ciphertext = this.GetHash(plaintext, sha);

			return ciphertext;
		}
	}
}