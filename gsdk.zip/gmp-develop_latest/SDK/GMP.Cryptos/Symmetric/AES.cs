﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:34:35
*
***************************************************************************/

using System;
using System.IO;
using System.Security.Cryptography;

namespace GMP.Cryptos.Symmetric
{
	/// <summary>
	/// Provides AES symmetric encryption algorithm.
	/// </summary>
	public class AES : Base.SymmetricAlgorithm
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="AES"/> class.
		/// </summary>
		public AES() { }

		/// <summary>
		/// Initializes a new instance of the <see cref="AES"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt algorithm.</param>
		public AES(string key) : this(key, key) { }

		/// <summary>
		/// Initializes a new instance of the <see cref="AES"/> class.
		/// </summary>
		/// <param name="key">The key used to encrypt algorithm.</param>
		/// <param name="iv">The IV used to encrypt algorithm.</param>
		public AES(string key, string iv) : base(key, iv) { }

		/// <summary>
		/// Returns a ciphertext encrypted using AES symmetric encryption algorithm.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext using the specified algorithm encrypted.</returns>
		public override string Encrypt(string plaintext)
		{
			string ciphertext = string.Empty;

			if (string.IsNullOrEmpty(this.Key))
			{
				throw new ArgumentNullException(nameof(plaintext));
			}

			//AES requires a key of 32 bit length and a iv of 16 bit length.
			byte[] plaintextBytes = this.StringToBytes(plaintext);
			byte[] keyBytes = this.StringToBytes(this.Key, 32);
			byte[] ivBytes = this.StringToBytes(this.IV ?? DateTime.Now.Ticks.ToString(), 16);

			//Use the specified decryption mode to create the decryptor.
			RijndaelManaged provider = new RijndaelManaged();
			provider.Mode = CipherMode.ECB;
			provider.Padding = PaddingMode.Zeros;
			ICryptoTransform transform = provider.CreateEncryptor(keyBytes, ivBytes);

			//Decrypt using the specified decryption mode.
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
			cs.Write(plaintextBytes, 0, plaintextBytes.Length);
			cs.FlushFinalBlock();

			//bytes to base64
			ciphertext = Convert.ToBase64String(ms.ToArray());

			return ciphertext;
		}

		/// <summary>
		/// Returns a plaintext decrypted using the AES symmetric encryption algorithm.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns>A plaintext decrypted using the specified algorithm.</returns>
		public override string Decrypt(string ciphertext)
		{
			string plaintext = string.Empty;

			//AES requires a key of 32 bit length and a iv of 16 bit length.
			byte[] ciphertextBytes = Convert.FromBase64String(ciphertext);
			byte[] keyBytes = this.StringToBytes(this.Key, 32);
			byte[] ivBytes = this.StringToBytes(this.IV ?? DateTime.Now.Ticks.ToString(), 16);

			//Use the specified decryption mode to create the decryptor.
			RijndaelManaged provider = new RijndaelManaged();
			provider.Mode = CipherMode.ECB;
			provider.Padding = PaddingMode.Zeros;
			ICryptoTransform transform = provider.CreateDecryptor(keyBytes, ivBytes);

			//Decrypt using the specified decryption mode.
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
			cs.Write(ciphertextBytes, 0, ciphertextBytes.Length);
			cs.FlushFinalBlock();

			//Bytes to string.
			plaintext = this.BytesToString(ms.ToArray());

			return plaintext;
		}
	}
}