﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:42:56
*
***************************************************************************/

using System;
using System.Text;
using GMP.Cryptos.Base;

namespace GMP.Cryptos.Symmetric
{
	/// <summary>
	/// Provides methods of base64 encryption and decryption.
	/// </summary>
	public class BASE64 : CryptoBase
	{
		/// <summary>
		/// Returns a ciphertext encrypted using the BASE64.
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext using the specified algorithm encrypted.</returns>
		public override string Encrypt(string plaintext)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(plaintext);
			return Convert.ToBase64String(bytes);
		}

		/// <summary>
		/// Returns a plaintext decrypted using the BASE64.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns></returns>
		public override string Decrypt(string ciphertext)
		{
			byte[] bytes = Convert.FromBase64String(ciphertext);
			return Encoding.UTF8.GetString(bytes);
		}
	}
}