﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 15:34:42
*
***************************************************************************/

using System;
using System.IO;
using System.Security.Cryptography;

namespace GMP.Cryptos.Symmetric
{
    /// <summary>
    /// Provides DES symmetric encryption algorithm.
    /// </summary>
    public class DES : Base.SymmetricAlgorithm
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DES"/> class.
        /// </summary>
        public DES() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="DES"/> class.
        /// </summary>
        /// <param name="key">The key used to encrypt algorithm.</param>
        public DES(string key) : base(key, "") { }

        /// <summary>
        /// Initializes a new instance of the <see cref="DES"/> class.
        /// </summary>
        /// <param name="key">The key used to encrypt algorithm.</param>
        /// <param name="iv">The IV used to encrypt algorithm.</param>
        public DES(string key, string iv) : base(key, iv) { }

        /// <summary>
        /// Returns a ciphertext encrypted using DES symmetric encryption algorithm.
        /// </summary>
        /// <param name="plaintext">A string that represents the plaintext.</param>
        /// <returns>A ciphertext using the specified algorithm encrypted.</returns>
        public override string Encrypt(string plaintext)
        {
            string ciphertext = string.Empty;

            //DES requires 8-bit keys and iv
            byte[] plaintextBytes = this.StringToBytes(plaintext);
            byte[] keyBytes = base.StringToBytes(this.Key, 8);
            byte[] ivBytes = base.StringToBytes(this.IV, 8);

            //Use the specified decryption mode to create the decryptor.
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            provider.Mode = CipherMode.ECB;
            provider.Padding = PaddingMode.Zeros;
            ICryptoTransform transform = provider.CreateEncryptor(keyBytes, ivBytes);

            //Decrypt using the specified decryption mode.
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
            cs.Write(plaintextBytes, 0, plaintextBytes.Length);
            cs.FlushFinalBlock();

            //Bytes to base64
            ciphertext = Convert.ToBase64String(ms.ToArray());

            return ciphertext;
        }

        /// <summary>
        /// Returns a plaintext decrypted using the DES symmetric encryption algorithm.
        /// </summary>
        /// <param name="ciphertext">A string that represents the ciphertext.</param>
        /// <returns>A plaintext decrypted using the specified algorithm.</returns>
        public override string Decrypt(string ciphertext)
        {
            string plaintext = string.Empty;

            //DES requires 8-bit keys and iv
            byte[] ciphertextBytes = Convert.FromBase64String(ciphertext);
            byte[] keyBytes = this.StringToBytes(this.Key, 8);
            byte[] ivBytes = this.StringToBytes(this.IV, 8);

            //Use the specified decryption mode to create the decryptor.
            DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
            provider.Mode = CipherMode.ECB;
            provider.Padding = PaddingMode.Zeros;
            ICryptoTransform transform = provider.CreateDecryptor(keyBytes, ivBytes);

            //Decrypt using the specified decryption mode.
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
            cs.Write(ciphertextBytes, 0, ciphertextBytes.Length);
            cs.FlushFinalBlock();

            //Bytes to string.
            plaintext = this.BytesToString(ms.ToArray());

            return plaintext;
        }
    }
}