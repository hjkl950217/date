﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: heng.yang 2020/9/30 16:14:56
*
***************************************************************************/

using System;
using System.Security.Cryptography;
using System.Xml;

namespace GMP.Cryptos.Symmetric
{
	/// <summary>
	/// Provides RSA symmetric encryption algorithm.
	/// </summary>
	public class RSA : Base.SymmetricAlgorithm
	{
		/// <summary>
		/// Gets an RSA public key.
		/// </summary>
		public string PublicKey { get; private set; }

		/// <summary>
		/// Gets an RSA private key.
		/// </summary>
		public string PrivateKey { get; private set; }

		/// <summary>
		/// Generates a pair of public and private keys
		/// </summary>
		public void GenerateRSAKey()
		{
			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
			this.PrivateKey = rsa.ToXmlStringEx(true);
			this.PublicKey = rsa.ToXmlStringEx(false);
		}

		/// <summary>
		/// Returns a ciphertext encrypted using the public key
		/// </summary>
		/// <param name="plaintext">A string that represents the plaintext.</param>
		/// <returns>A ciphertext using the specified algorithm encrypted.</returns>
		public override string Encrypt(string plaintext)
		{
			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
			rsa.FromXmlStringEx(this.PublicKey);

			byte[] ciphertextBytes = rsa.Encrypt(this.StringToBytes(plaintext), false);

			return Convert.ToBase64String(ciphertextBytes);
		}

		/// <summary>
		/// Returns the plaintext decrypted with the private key.
		/// </summary>
		/// <param name="ciphertext">A string that represents the ciphertext.</param>
		/// <returns>A plaintext decrypted using the specified algorithm.</returns>
		public override string Decrypt(string ciphertext)
		{
			RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
			rsa.FromXmlStringEx(this.PrivateKey);

			byte[] plaintextBytes = rsa.Decrypt(Convert.FromBase64String(ciphertext), false);

			return this.BytesToString(plaintextBytes);
		}
	}

	/// <summary>
	/// Extend the FromXmlString and ToXmlString methods for RAS to support .net Core.
	/// </summary>
	public static class RSAExtension
	{
		/// <summary>
		/// Extend the FromXmlString method.
		/// </summary>
		/// <param name="rsa">RSA algorithm class.</param>
		/// <param name="xmlString">An XML document format string.</param>
		public static void FromXmlStringEx(this System.Security.Cryptography.RSA rsa, string xmlString)
		{
			RSAParameters parameters = new RSAParameters();
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.LoadXml(xmlString);

			if (xmlDoc.DocumentElement.Name.Equals("RSAKeyValue"))
			{
				foreach (XmlNode node in xmlDoc.DocumentElement.ChildNodes)
				{
					switch (node.Name)
					{
						case "Modulus": parameters.Modulus = Convert.FromBase64String(node.InnerText); break;
						case "Exponent": parameters.Exponent = Convert.FromBase64String(node.InnerText); break;
						case "P": parameters.P = Convert.FromBase64String(node.InnerText); break;
						case "Q": parameters.Q = Convert.FromBase64String(node.InnerText); break;
						case "DP": parameters.DP = Convert.FromBase64String(node.InnerText); break;
						case "DQ": parameters.DQ = Convert.FromBase64String(node.InnerText); break;
						case "InverseQ": parameters.InverseQ = Convert.FromBase64String(node.InnerText); break;
						case "D": parameters.D = Convert.FromBase64String(node.InnerText); break;
					}
				}
			}
			else
			{
				throw new NotSupportedException("Invalid XML RSA key.");
			}

			rsa.ImportParameters(parameters);
		}

		/// <summary>
		/// Extend the ToXmlString method.
		/// </summary>
		/// <param name="rsa">RSA algorithm class.</param>
		/// <param name="includePrivateParameters"></param>
		/// <returns>Returns a String representation of an XML document.</returns>
		public static string ToXmlStringEx(this System.Security.Cryptography.RSA rsa, bool includePrivateParameters)
		{
			RSAParameters parameters = rsa.ExportParameters(includePrivateParameters);

			if (includePrivateParameters)
			{
				return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent><P>{2}</P><Q>{3}</Q><DP>{4}</DP><DQ>{5}</DQ><InverseQ>{6}</InverseQ><D>{7}</D></RSAKeyValue>",
					Convert.ToBase64String(parameters.Modulus),
					Convert.ToBase64String(parameters.Exponent),
					Convert.ToBase64String(parameters.P),
					Convert.ToBase64String(parameters.Q),
					Convert.ToBase64String(parameters.DP),
					Convert.ToBase64String(parameters.DQ),
					Convert.ToBase64String(parameters.InverseQ),
					Convert.ToBase64String(parameters.D));
			}

			return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent></RSAKeyValue>",
					Convert.ToBase64String(parameters.Modulus),
					Convert.ToBase64String(parameters.Exponent));
		}
	}
}