﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-06-29 星期二 9:58:36
*
***************************************************************************/

namespace GMP.Db.Abstractions.Const
{
    /// <summary>
    /// 加密常量
    /// </summary>
    public static class EncryptionConst
    {
        /// <summary>
        /// 默认DES秘钥
        /// </summary>
        public const string Defualt_Key_DES = "GMP";
    }
}