﻿namespace GMP.Db.Abstractions.Const
{
    public static class EntityConst
    {
        /// <summary>
        /// 列名-ID
        /// </summary>
        public const string CLOLUMN_NAME_ID = "Id";

        /// <summary>
        /// 列名-创建时间
        /// </summary>
        public const string CLOLUMN_NAME_CREATE_TIME = "createTime";

        /// <summary>
        /// 列名-修改时间
        /// </summary>
        public const string CLOLUMN_NAME_MODIFIED_TIME = "modifiedTime";

        /// <summary>
        /// 列名-更新ID
        /// </summary>
        public const string CLOLUMN_NAME_CREATE_ID = "createId";

        /// <summary>
        /// 列名-修改ID
        /// </summary>
        public const string CLOLUMN_NAME_UPDATE_ID = "updateId";

        /// <summary>
        /// 列名-有效性
        /// </summary>
        public const string CLOLUMN_NAME_VALIDITY = "Validity";

        /// <summary>
        /// 列名-公司ID
        /// </summary>
        public const string CLOLUMN_NAME_COMPANY_ID = "CompanyId";
    }
}