﻿using Microsoft.Extensions.DependencyInjection;

namespace GMP.Db.Abstractions
{
    /// <summary>
    /// 数据库上下文建造者
    /// </summary>
    /// <typeparam name="TDbOption"></typeparam>
    public abstract class DbContextBuilder<TDbOption>
        where TDbOption : GmpDbBaseOption
    {
        /// <summary>
        /// 初始化<see cref="DbContextBuilder{TDbOption}"/>
        /// </summary>
        /// <param name="dbOption"></param>
        /// <param name="services"></param>
        protected DbContextBuilder(TDbOption dbOption, IServiceCollection services)
        {
            this.GmpDbOption = dbOption;
            this.Services = services;
        }

        /// <summary>
        /// gmp db 配置对象
        /// </summary>
        public TDbOption GmpDbOption { get; }

        /// <summary>
        /// IOC配置集合
        /// </summary>
        public IServiceCollection Services { get; }

        /// <summary>
        /// 浅拷贝一个配置
        /// </summary>
        /// <returns></returns>
        public TDbOption CloneOption()
        {
            return (TDbOption)this.GmpDbOption.Clone();
        }
    }
}