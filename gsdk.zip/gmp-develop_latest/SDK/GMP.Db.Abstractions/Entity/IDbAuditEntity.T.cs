﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:18:25
*
***************************************************************************/

using System;

namespace GMP.Db.Abstractions.Entity
{
    /// <summary>
    /// 标记需要审计的实体
    /// </summary>
    public interface IDbAuditEntity<Tid> : IDbEntity<Tid>
    {
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateTime { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime ModifiedTime { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        public string CreateId { get; set; }

        /// <summary>
        /// 更新人ID
        /// </summary>
        public string UpdateId { get; set; }
    }
}