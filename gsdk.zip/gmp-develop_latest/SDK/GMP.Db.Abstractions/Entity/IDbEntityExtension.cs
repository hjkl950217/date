﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:18:25
*
***************************************************************************/

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace GMP.Db.Abstractions.Entity
{
    /// <summary>
    /// <see cref="IDbAuditEntity"/>扩展
    /// </summary>
    public static class IDbEntityExtension
    {
        #region 清理导航属性

        public static ConcurrentDictionary<Type, object> AssignFuncDic = new ConcurrentDictionary<Type, object>();

        /// <summary>
        /// 清理导航属性
        /// </summary>
        /// <typeparam name="TDbEntity"></typeparam>
        /// <typeparam name="Tid"></typeparam>
        /// <param name="dbEntity"></param>
        /// <returns></returns>
        public static TDbEntity CleanNavigationProperty<TDbEntity, Tid>(this TDbEntity dbEntity)
            where TDbEntity : class, IDbEntity<Tid>
        {
            if (dbEntity == null)
            {
                throw new ArgumentNullException(nameof(dbEntity));
            }

            Type entityTypeInfo = typeof(TDbEntity);
            Func<TDbEntity, TDbEntity> assignFunc = IDbEntityExtension.AssignFuncDic
                .GetOrAdd(entityTypeInfo, BuildAssignFunc().Compile())
                as Func<TDbEntity, TDbEntity>;

            return assignFunc(dbEntity);

            LambdaExpression BuildAssignFunc()
            {
                Type entityTypeInfo = typeof(TDbEntity);
                Type stringTypeInfo = typeof(string);
                ParameterExpression paramExpression = Expression.Parameter(entityTypeInfo, "t");//准备参数t

                //获取要赋值的属性
                PropertyInfo[] propertyInfos = entityTypeInfo.GetProperties()
                     .Where(t => t.CanWrite
                         && !t.PropertyType.IsValueType
                         && (t.PropertyType != stringTypeInfo && Nullable.GetUnderlyingType(t.PropertyType) == null)
                         )
                     .ToArray();

                //准备return标签
                LabelTarget returnTarget = Expression.Label(entityTypeInfo);
                GotoExpression returnExpression = Expression.Return(returnTarget, paramExpression, entityTypeInfo);
                LabelExpression returnLabel = Expression.Label(returnTarget, Expression.Constant(null, entityTypeInfo));

                //生成赋值表达式
                Expression[] assignExps = propertyInfos
                    .Select(t =>
                    {
                        MemberExpression propExp = Expression.Property(paramExpression, t);//获取属性访问表达式 t.xx
                        return Expression.Assign(propExp, Expression.Constant(null, t.PropertyType)) as Expression;//赋值 t.xx=null
                    })
                    .Concat(new LabelExpression[] { returnLabel })//return t;
                    .ToArray();
                ;

                //打包
                BlockExpression body = Expression.Block(assignExps);
                Expression<Func<TDbEntity, TDbEntity>> funcExp = Expression.Lambda<Func<TDbEntity, TDbEntity>>(body, paramExpression);

                return funcExp;
            }
        }

        /// <summary>
        /// 清理导航属性
        /// </summary>
        /// <param name="dbEntity"></param>
        /// <returns></returns>
        public static IDbEntity<string> CleanNavigationProperty<TDbEntity>(this TDbEntity dbEntity)
              where TDbEntity : class, IDbEntity<string>
        {
            return dbEntity.CleanNavigationProperty<TDbEntity, string>();
        }

        /// <summary>
        /// 批量清理导航属性
        /// </summary>
        /// <typeparam name="TDbEntity"></typeparam>
        /// <typeparam name="Tid"></typeparam>
        /// <param name="dbEntities"></param>
        /// <returns></returns>
        public static IEnumerable<TDbEntity> BatchCleanNavigationProperty<TDbEntity, Tid>(this IEnumerable<TDbEntity> dbEntities)
             where TDbEntity : class, IDbEntity<Tid>
        {
            if (dbEntities == null)
            {
                throw new ArgumentNullException(nameof(dbEntities));
            }

            dbEntities = dbEntities
                .Select(t =>
                {
                    IDbEntityExtension.CleanNavigationProperty<TDbEntity, Tid>(t);
                    return t;
                });

            return dbEntities;
        }

        #endregion 清理导航属性
    }
}