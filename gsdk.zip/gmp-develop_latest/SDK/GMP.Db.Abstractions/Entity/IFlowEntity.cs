﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-26 星期三 16:11:56
*
***************************************************************************/

using GMP.Db.Abstractions.Enum;

namespace GMP.Db.Abstractions.Entity
{
    /// <summary>
    /// 标记流程实体
    /// </summary>
    /// <remarks>
    /// 新建实体:ef实体特性不允许继承，接口中的代码中用于新建实体时复制用的。<para></para>
    /// 其它:接口中的字段是流程需要的，继承接口是规定属性必须叫的这个名字
    /// </remarks>
    public interface IFlowEntity
    {
        #region 流程字段

        /// <summary>
        /// 流程状态<see cref="FlowStatusEnum"/>
        /// </summary>
        public string FlowStatus { get; set; }

        /// <summary>
        /// 流程ID
        /// </summary>
        public string Process { get; set; }

        /// <summary>
        /// 流程实例号
        /// </summary>
        public string Incident { get; set; }

        #endregion 流程字段
    }
}