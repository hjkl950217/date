﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:18:25
*
***************************************************************************/

namespace GMP.Db.Abstractions.Entity
{
    /// <summary>
    /// 标记公司
    /// </summary>
    public interface IOrg
    {
        /// <summary>
        /// 公司Id
        /// </summary>
        public string OrgId { get; set; }
    }
}