﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021/4/21 星期三 15:18:25
*
***************************************************************************/

namespace GMP.Db.Abstractions.Entity
{
    /// <summary>
    /// 标记有效性
    /// </summary>
    public interface IValidity
    {
        /// <summary>
        /// 指数据库中某条数据的有效性,非业务字段。对应<see cref="GMP.Db.Abstractions.Enum.Validity"/>
        /// </summary>
        /// <remarks>
        ///
        /// 因eform限制，静态列表对应varchar类型，所以这里用string接收。
        /// 项目里可以这样写:
        /// <code>
        /// [NotMapped]
        /// public Validity ValidityEnum { get => (Validity)this.Validity.ToInt32(); set => this.Validity = value.GetValueString(); }
        /// </code>
        /// </remarks>
        public string Validity { get; set; }
    }
}