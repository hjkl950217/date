﻿/***************************************************************************
*
* Macrowing Pharm GMP Quality Management System
* http://www.macrowing.com
*
* Copyright (c) Macrowing Pharm Technology Co.,Ltd
* All Rights Reserved.
*
* Technical Support: Pharm R&D Team
* Creator: xueyi.wang 2021-5-26 星期三 16:13:53
*
***************************************************************************/

using System.ComponentModel;

namespace GMP.Db.Abstractions.Enum
{
    /// <summary>
    /// 流程状态
    /// </summary>
    [Description("流程状态")]
    public enum FlowStatusEnum
    {
        /// <summary>
        /// 默认值
        /// </summary>
        Default = 0,

        /// <summary>
        /// 审批中
        /// </summary>
        UnderApproval = 20,

        /// <summary>
        /// 审批完成
        /// </summary>
        Completed = 30,

        /// <summary>
        /// 审批终止
        /// </summary>
        Termination = 90
    }
}