﻿# MPS-公共库介绍
@[公共库]

在迁移到微服务后，不同的项目在引用组件上会有一些差异，同时工具代码也会分散到各处。为了统一管理组件库引用、工具代码、部分业务代码封装，诞生了这个公共库。

目前此公共库适用于.Net core 的web项目。所有公共库中的东西都有详细的注释和备注，具体的查看定义即可。如果发现有注释错误或遗留，请联系公共库的维护人员。
本说明只针对mkpl-sdk-core项目

名词说明： 
- 后缀为`Option`的说明是项目级别的配置。
- 后缀为`Config`的说明是配置在`Config Service`上的。

[toc]

## 组件封装介绍

1. FileCliet--针对文件上传、下载
2. HttpClient--针对Http请求
3. MqClient--针对MQ发送
4. NairCache--KV型分布式缓存（以后可能移除二次封装，使用Mis-Hub中的原生组件）

## 配置封装介绍

1. Web项目启动类-ProgramHelper
2. Mvc配置封装-MvcCoreMPSExtension
2.1日志配置封装-LogExtension
2.2 Cors配置封装-CORSExtension
2.3 API版本配置封装-ApiVersionMPSExtension
3. 自动文档生成-Swagger
3.1 自定义配置-SwaggerMPSOption
3.2 配置封装-SwaggerMPSExtension

## 错误处理介绍

1. 全局异常处理-ErrorHandlingMiddleware
2. DTO验证错误处理-MpsValidationFilter

## 工具代码介绍
1. Helper类-Helpers文件夹中若干帮助类
2. 扩展方法-{Extensions}文件夹中若干扩展


## 项目与配置
当项目中引用此公共库后，需要在`Startup.cs`中注册`需要的服务`和配置`Http请求流水线` 。下面会详细介绍各种组件、服务的配置和使用。



### 1.服务注册

#### Swagger

一般配置：
``` csharp
			//注册服务
            //配置-Swagger
            services.AddSwaggerMPS(t =>
            {
                t.ConfigList = new List<Info>()
                {
                    new Info (){Title="PolicyViolation",Version="v1"},
                    new Info (){Title="TaxSettingForUSA",Version="v1"},
                    new Info (){Title="Account",Version="v1"}
                };
            });
     
           //配置HTTP请求
           //添加swagger
           app.UseSwaggerMPS();//需要在UseStaticFiles之前
           
```
当API中有新加分组时，像上面一样添加新的info数据就好。

使用的`SwaggerMpsOption`配置结构如下：
``` csharp

   //
    // 摘要:
    //     MPS组-配置Swagger的模型
    public class SwaggerMpsOption
    {
        public SwaggerMpsOption();
        //
        // 摘要:
        //     分组的数据
        //
        // 备注:
        //     1.项目中有几个GroupName就需要写几乎个 2.Info的版本信息格式为:v1 v2 需要小写 3.版本建议传递对应Group中支持的最高版本 4.没有写GroupName特性的会在所有分组中
        public IList<Info> ConfigList { get; set; }
        //
        // 摘要:
        //     需要包括的XML注释文件
        //
        // 备注:
        //     1.不要传递完全限定名 2.默认可以不传 3.默认有三个： "ApiDoc.xml","ApiFacadeDoc.xml","ApiEntityDoc.xml"
        //     4.要让注释完整显示，需要让web项目的启动根目录有这些文件
        public IList<string> XmlFileNameList { get; set; }
        //
        // 摘要:
        //     要启用的环境列表.请使用ApplicationEnvConst里面的环境
        // 备注:
        //     默认添加 GQC GDEV Development
        public IList<string> EnvEnableList { get; set; }
    }

```

对于`XmlFileNameList`和`EnvEnableList`属性，配置后会使用配置的。只有当没有配置过才会使用默认的这些。

#### MVC

一般配置：
``` csharp
			//注册服务
            //配置-MVC
            services.AddMvcCoreMPS(this);//这个this一定要带
            services.AddApiVersionMPS();//API版本控制
            
            //配置HTTP请求
            //这个配置需要在配置HTTP请求方法的最后一行，确保是最后调用的
            app.UseMvc();
           
```
具体配置可参考：`MvcCoreMPSExtension.cs`文件,目前MVC配置不提供选项。统一使用公共库中的配置。

#### 组件注册
``` csharp

//注册服务-按需注册
services.AddHttpClientMPS();//MPS组HttpClient
services.AddNairCacheMPS();//Nair服务
services.AddMpsMQClientMPS();//MQ服务
services.AddFileClientMPS();//FileClient服务
services.AddResponseCompressionMPS();//注册压缩服务
services.AddResponseCaching();注册响应缓存服务
services.AddLocalizationMPS();//多语言服务

//HTTP请求配置
app.UseResponseCaching();//启用响应缓存
app.UseSimpleExceptionHandlerMPS();//启用MPS组的简单异常处理中间件
app.UseAllowCORSMPS();//启用跨域支持 具体配置请参考方法说明
app.UseResponseCompressionMPS();//启用请求压缩
app.UesLocalizationMPS();//启用多语言
```

异常处理中间件需要配置为倒数`第二个`，倒数第一个为`app.UseMvc();`

### 2. 组件使用

组件都会涉及到在`Config Servie`上配置，并且公共库中针对配置的`获取和检测`已有处理。如果发现有配置错误，但是公共库没有提示或提示错误，请联系公共库维护者修复。

公共库的配置都在`MKPL_Common`中。项目会使用自己的配置而不是用公共的。依赖的配置会在下面专门讲解

#### FileClient
依赖：`MKPL_Common/File_Config`

在项目的构造方法中添加工厂接口的获取:
``` csharp
class Demo(IMpsFileClientFactory mpsFileClientFactory)
```

然后通过工厂的方法获取对应的`IMpsFileClient`，关于`IMpsFileClient`的使用，请自行查看方法上面的注释。方法和参数的注释已经非常详尽了。

#### HttpClient
依赖：`MKPL_Common/AllAPIConfig`

在项目的构造方法中添加工厂接口的获取:
``` csharp
class Demo(IMpsHttpClientFactory mpsHttpClientFactory)
```

然后调用`IMpsHttpClientFactory`的方法获取不同请求方式的`IMpsHttpClient`，方法中会需要`teamNameKey`这个团队名。请使用公共库常量：`TeamNameConst`，不要自己写个字符串哦！`TeamNameConst`里面已经过内置了一批团队名。

创建好`IMpsHttpClient`后，直接使用他的方法即可。具体的使用在方法注释上有详细说明，下面介绍了一些参数。

关于请求方法中涉及到的一些通用参数：
- `apiKey`:`Confer Service`配置中的APIkey，在项目中会在`实体层`,内建`ApiKeyConst.cs` 用来存放这些字面量。
- `queryData`:Get请求中，`?`后面的查询字符串。比如要构建`?A=1&B=ttt`，只需要传递
`new{A=1,B="ttt"}`.
- `requestData`:Post请求时会用到。是指请求其它API时传递的Body数据。
- `RequestHead`：请求头对象，这个对象是公共库定义的。一般来说不需要管他，当请求的API有特殊要求时，再传递这个对象。需要时再参考类的定义即可，有详细注释说明。
- `queryStrList`:替换配置中{0}这种占位符的。一般来说，调用其它API时URL上没有查询字符串或者是固定的。但有些特殊API需要动态的替换里面的值，这种情况下使用此属性.


queryStrList举例: 
配置中： `xxx\abc?a={0}&b={1}`  
程序中：`client.Get("key",new{},null,1111,555)`
后面的`111 555`就会赋值到`params object[] queryStrList`中，然后动态替换掉上面URL的{0},{1}

####  MqClient
依赖：`MKPL_Common/MessageQueue_Config`

在项目的构造方法中添加工厂接口的获取:
``` csharp
class Demo(IMQClient mqClient)
```

发送MQ需要几步：
1. 构造MQ消息体
2. New一个MQHeader
3. 调用接口方法发送

**示例**：
``` csharp
object request = new object();//第一步
MQHeader mQHeader = new MQHeader(){Action ="Test"};//第二步

//第三步
PublishResultInfo publishResultInfo = this.mQClient.SendMessage(
request ,
"你的Queue Key"，
mQHeader 
)
//第四步，可按实际情况返回。
 return publishResultInfo.MessageId;
```

- `PublishResultInfo`的属性说明：
- `IsSucceed`：是否发送成功
- `MessageId`:发送成功的消息ID，为Guid的格式。可能MQ系统中追查
- `ErrorCode`和`ErrorMessage`：发生错误时的错误代码和错误信息

`PublishResultInfo`是`Newegg.MIS.Baymax.MQ`提供的


#### Excel Client
.Net Core导出组件，目前支持基于模板的导出，在使用时只需要将数据写入到文件，
组件内部会采用格式刷的方式将模板中的样式应用到新写入的单元格。

导出一个excel需要如下几步： 
1. 构造导出模板的文件信息
2. 通过`BuildExcelWithTemplate`方法向模板中的第一个Sheet写入数据
3. 如果需要写多个Sheet，通过`AddSheet`方法向指定的Sheet写入数据
4. 通过拓展方法`SaveAsByte`将返回的MemoryStream转为byte[]
5. 指定Content Type,通过`File`方法返回一个文件流，浏览器download文件

**注意事项** 
1. `BuildExcelWithTemplate`方法需要先于`AddSheet`方法调用，
如果需要导出的文件只有一个Sheet，只需要调用`BuildExcelWithTemplate`即可，如果需要写多个Sheet，在写第二个Sheet时需要将`BuildExcelWithTemplate`的返回值作为参数传入`AddSheet`方法


**示例**
``` csharp
//导出模板的名称
string templateName = "RFQ Export Template.xlsx";

//要操作的Sheet的index，从1开始
int sheetIndex = 2;

//Sheet中开始写数据的行，从1开始
int startRow = 3;

//构造需要导出的文件信息
FileInfo excelTemplate = new FileInfo($"{this._env.WebRootPath}{Path.DirectorySeparatorChar}template{Path.DirectorySeparatorChar}{templateName}");

//指定文件地址，获得Excel文件并写入第一个Sheet
MemoryStream excelStream = this._excelClient.BuildExcelWithTemplate<ExportModel>(exportData, excelTemplate, startRow);

//如果需要写多个Sheet，通过AddSheet方法向一个指定的Sheet页写入数据
excelStream = this._excelExport.AddSheet<ExportModel>(excelStream, data, sheetIndex, startRow);

//将memoryStream转为byte数组并关闭流
byte[] excelByte = excelStream.SaveAsByte();

//以xlxs的contentType返回excel文件，浏览器自动download
return File(excelByte, ContentTypeConst.Excel, "RFQ List Export.xlsx");
```



#### NairCache

此组件不久会重构或者删除，目前暂时不提供文档。有需要的可联系公共库管理员

#### 多语言

公共库的多语言是在`Microsoft.AspNetCore.Localization`的基础上包装了一层。增加了一种支持。逻辑：在Http头中识别`MPS-Language`,然后取对应的资源文件,大小写敏感

判断顺序：
1. MPS头    MPS-Language
2. QueryString
3. cookie 
4.  Accept-Language

PS:使用前先在[错误代码维护平台](http://172.16.168.32:9992)或修改你的错误信息。然后选择`.net core`导出

**使用步骤：**
``` csharp
//1.在构造方法中注入
public Test(IStringLocalizer<ErrorCode> stringLocalizer){}

//2.在需要地方直接使用
string a=this.L[ErrorCode.Seller_10054];//返回具体信息
string code= nameof(ErrorCode.Seller_10054);//返回"Seller_10054" 这个code是返回给前端使用的

```

更多本地化器参考：[微软官方文档](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/localization?view=aspnetcore-2.1#make-the-apps-content-localizable)

PS：因框架限制，所以`ErrorCode`中的常量都是string类型。
PPS：注入的时候必须是ErrorCode这个类，不要写其它！ 因为C#这边的管理模式就是这样的。一个类文件代表一组资源(eg. ErrorCode.cs) ,与类同名的资源文件+语言代码(eg. ErrorCode.en-US.resx)。

### 3.配置详解

.net core这边的组件使用的配置`有些是新建，有些不是`。涉及到.net core的部分请以文档为准！


#### AllApiConfig

Http组件中使用的配置，对应MKPL_Common下的AllAPIConfig节点。
- `DevPlatformHost`:配置下面的一级属性，默认的host地址。配置的API网关的地址。
- `TeamApiConfigList`：配置下面的一级属性，存引用其它团队或MPS微服务的配置。结果为KV型，`不是对象`哦！ key为团队名，value为具体的配置。

**团队**节点：
- `AppName`：描述性属性，组件不会使用。
- `BaseToken`:调用其它团队时需要配置这样的Token，在发送Http请求时会带上- `Authorization `头。这个头不管有没有配置都会带上，不需要Token的API也不会由这个影响。
- `ApiConfigList`:配置详细API的节点。同样是`KV型`哦！

**ApiConfigList**节点：
- `key`:发送HTTP请求是传递的参数，需要一一对应。
- `Host`:默认没有，会使用默认host地址。当有特殊要求时再配置此节点
- `Address`：请求中的URL，这个必须配置。以`/`开头。有查询字符串时，业务上又固定，可以写死。也可以写`{0}`这样的占位符，发送请求时传递参数动态替换。
- `Token`：默认没有，会使用团队级别的`BaseToken`。通常情况下请求其它团队使用组件中的`GetOAuthClient`方法获取对应的`IMpsHttpClient`，发送请求时会统一修改为OAuth格式。

#### FileConfig

File组件中的配置，对应MKPL_Common下的File_Config节点。

**Dfis**节点:使用DFIS组提供的文件服务时使用的配置。
- `UploadHostAddress`:上传Host地址
- `DownloadHostAddress`：下载Host地址
- `GroupInfoList`:分组配置的节点。当有新业务时会向DFIS申请一个组来存放对应的文件，这里会存放这些信息。

**GroupInfoList**节点：
- `Name`:程序中查找的Key,为兼容老项目，这里没有修改名字。在公共库中参数都是用key。
- `Group`：业务组的名字，MPS组中都是"MPS"
- `Type`:当有新业务时会向DFIS申请,他们会给一个type来存放对应的文件，这里的Type是这个意思。

这个配置一般不会动，了解即可。

#### MQConfig

Mq组件中的配置，对应MKPL_Common下的MessageQueue_Config节点。

- `GroupQueues`：消息组，设计时就是按不同组来设计MQ的配置，所以这里是一个数组。

**GroupQueues**节点：
- `GoupName`：组名。设计时，这个属性是给以后预留的。如果需要向其它团队的MQ通道中发送数据。这个字段马上就能用了。
- `DefaultPassword`:默认密码，在消息没有单独配置时，取的是MQ组上的默认密码
- `Queues`:团队下的消息组

**Queues**节点：
- `KeyName`:消息key，在发送MQ时需要指定。一般在项目中会有一个常量文件存放这个key
- `QueueName`:消息名，对应MQ系统上的具体MQ通道的名字。在刚开始时，key和name是一样的。如果需要修改消息名，修改配置就可以，不用修改代码。
- `Password`:密码。一般不配置，使用默认密码即可。如果MQ通道需要有自己的密码，可以配置。的属性说明：
- `IsSucceed`：是否发送成功
- `MessageId`:发送成功的消息ID，为Guid的格式。可能MQ系统中追查
- `ErrorCode`和`ErrorMessage`：发生错误时的错误代码和错误信息

`PublishResultInfo`是`Newegg.MIS.Baymax.MQ`提供的

#### NairCache

此组件不久会重构或者删除，目前暂时不提供文档。有需要的可联系公共库管理员


