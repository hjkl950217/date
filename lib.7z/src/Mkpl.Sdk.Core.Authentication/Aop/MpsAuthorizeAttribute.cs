﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities;
using System;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 认证
    /// </summary>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public sealed class MpsAuthorizeAttribute : AuthorizeAttribute, IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var options = context.HttpContext.RequestServices.GetService<IOptionsMonitor<MPSAuthenticationOptions>>();
            if (!options.CurrentValue.EnableFunctionalAuthorization) return;

            IAuthenticationCheck checkDelegate = context.HttpContext.RequestServices.GetService<IAuthenticationCheck>();
            BizValidationError<IActionResult> result = await checkDelegate.AuthorizeCheckEventHandlerAsync(context.HttpContext, options);

            if (result != null)
            {
                context.Result = result.ErrorObject;

                if (options.CurrentValue.EnableErrorMessage)
                {
                    context.HttpContext.Response.Headers[options.CurrentValue.ErrorHeaderName] = result.ErrorMessage;
                }
            }
            else
            {
                await next();
            }
        }
    }
}