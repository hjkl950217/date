﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication.Entities;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Helpers;
using Newegg.MIS.Baymax.Cache;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Authentication
{
    public static class AuthenticationLogic
    {
        #region 内部代码

        private static Task<BizValidationError<IActionResult>> ToTask(BizValidationError<IActionResult> result)
        {
            return Task.FromResult<BizValidationError<IActionResult>>(result);
        }

        private static void WriteObjectToHttpContext(
        HttpContext httpContext,
        string sessionObjStr)
        {
            if (sessionObjStr.IsNullOrEmpty())
            {
                httpContext.Items[AuthenticationConst.CurrentLoginCacheKey] = null;
            }
            else
            {
                var loginCacheObj = sessionObjStr.ToObjectExt<LoginCacheEntityPlus>();
                loginCacheObj.CurrentPlatformCode = httpContext.GetCurrentPlatformCode();
                httpContext.Items[AuthenticationConst.CurrentLoginCacheKey] = loginCacheObj;
            }
        }

        private static string GetErrorMsg(MPSAuthenticationOptions options, string errorDescription = null)
        {
            var currentEnv = EnvHelper.GetRunEnvEnum();
            bool isEnable = (options.EnableErrorMessageEnv & currentEnv) == currentEnv;
            if (!isEnable) return string.Empty;

            if (errorDescription == null)
            {
                return AuthenticationConst.ErrorStrPrefix;
            }
            else
            {
                return $"{AuthenticationConst.ErrorStrPrefix},error_description={errorDescription}";
            }
        }

        #endregion 内部代码

        #region 子验证方法

        public static Task<BizValidationError<IActionResult>> JwtTokenExistCheckAsync(
            HttpContext httpContext,
            IOptionsMonitor<MPSAuthenticationOptions> options)
        {
            if (!options.CurrentValue.EnableLoginAuthorize) return ToTask(null);

            string seiValue = httpContext.GetJwtSting(options.CurrentValue.TokenHeaderNames);

            // 返回
            if (seiValue.IsNullOrEmpty())
            {
                var bizValidationError = new BizValidationError<IActionResult>()
                {
                    CustomObject = new UnauthorizedResult(),
                    ErrorMessage = GetErrorMsg(options.CurrentValue, "jwt token is null or empty")
                };
                return ToTask(bizValidationError);
            }
            else
            {
                return ToTask(null);
            }
        }

        public static Task<BizValidationError<IActionResult>> PlatformCodeCheckAsync(
            HttpContext httpContext,
            IOptionsMonitor<MPSAuthenticationOptions> options)
        {
            if (!options.CurrentValue.EnableLoginAuthorize) return ToTask(null);

            string platformCode = httpContext.GetCurrentPlatformCode(options.CurrentValue.PlatformCodeHeadreName);
            bool checkResult = PlatformCodeHelper.CheckPlatformCode(platformCode);

            // 返回
            if (platformCode.IsNullOrEmpty() || !checkResult)
            {
                var bizValidationError = new BizValidationError<IActionResult>()
                {
                    CustomObject = new UnauthorizedResult(),
                    ErrorMessage = GetErrorMsg(options.CurrentValue, $"{options.CurrentValue.PlatformCodeHeadreName} error")
                };

                return ToTask(bizValidationError);
            }
            else
            {
                return ToTask(null);
            }
        }

        public static Task<BizValidationError<IActionResult>> SessionIdExistCheckAsync(
            HttpContext httpContext,
            IOptionsMonitor<MPSAuthenticationOptions> options)
        {
            if (!options.CurrentValue.EnableLoginAuthorize) return ToTask(null);

            string seiId = httpContext.GetSessionID(
                options.CurrentValue.TokenKeyName,
                options.CurrentValue.TokenHeaderNames
                );

            // 返回
            if (seiId.IsNullOrEmpty())
            {
                var bizValidationError = new BizValidationError<IActionResult>()
                {
                    CustomObject = new UnauthorizedResult(),
                    ErrorMessage = GetErrorMsg(options.CurrentValue, "sei value is null or empty,from jwt token")
                };
                return ToTask(bizValidationError);
            }
            else
            {
                return ToTask(null);
            }
        }

        public async static Task<BizValidationError<IActionResult>> RedisValueExistCheckAsync(
            HttpContext httpContext,
            IOptionsMonitor<MPSAuthenticationOptions> options)
        {
            if (!options.CurrentValue.EnableLoginAuthorize) return null;

            // 1. 获取redis值
            IRedisConnection redisConnection = httpContext.RequestServices.GetService<IRedisConnection>();

            string sessionID = httpContext.GetSessionID();
            string platformCode = httpContext.GetCurrentPlatformCode();
            string redisKey = string.Format(AuthenticationConst.RedisKeyTemplateForLoginCache, sessionID, platformCode);

            string redisValue = await redisConnection.ExecuteAsync(async t =>
            {
                return (await t?.StringGetAsync(redisKey)).ToString();
            });
            WriteObjectToHttpContext(httpContext, redisValue);//将redis的值写到httpContext中

            // 2.返回
            if (redisValue.IsNullOrEmpty())
            {
                var bizValidationError = new BizValidationError<IActionResult>()
                {
                    CustomObject = new UnauthorizedResult(),
                    ErrorMessage = GetErrorMsg(options.CurrentValue, "session invalid")
                };
                return bizValidationError;
            }
            else
            {
                return null;
            }
        }

        #endregion 子验证方法
    }
}