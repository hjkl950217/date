﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Authentication
{
    /// <summary>
    /// 认证检查
    /// </summary>
    /// <param name="httpContext"></param>
    /// <param name="options">认证选项</param>
    /// <returns>如果检查通过，则返回null,否则返回具体的信息</returns>
    internal delegate Task<BizValidationError<IActionResult>> AuthorizeCheckEventHandlerAsync(
        HttpContext httpContext,
        IOptionsMonitor<MPSAuthenticationOptions> options);

    public class DefaultAuthenticationCheck : IAuthenticationCheck
    {
        private readonly List<AuthorizeCheckEventHandlerAsync> checkFuncList = new List<AuthorizeCheckEventHandlerAsync>();

        public DefaultAuthenticationCheck()
        {
            this.checkFuncList.Add(AuthenticationLogic.PlatformCodeCheckAsync);
            this.checkFuncList.Add(AuthenticationLogic.JwtTokenExistCheckAsync);
            this.checkFuncList.Add(AuthenticationLogic.SessionIdExistCheckAsync);
            this.checkFuncList.Add(AuthenticationLogic.RedisValueExistCheckAsync);
        }

        public async Task<BizValidationError<IActionResult>> AuthorizeCheckEventHandlerAsync(
            HttpContext httpContext,
            IOptionsMonitor<MPSAuthenticationOptions> options)
        {
            foreach (var item in this.checkFuncList)
            {
                var result = await item(httpContext, options);
                if (result != null) return result;
            }

            return null;
        }
    }
}