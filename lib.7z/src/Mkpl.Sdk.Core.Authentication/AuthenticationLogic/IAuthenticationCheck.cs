﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Authentication
{
    public interface IAuthenticationCheck
    {
        /// <summary>
        /// 认证检查方法
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="options"></param>
        /// <returns>第一个检查不通过的结果。如果全部检查通过，则返回null</returns>
        Task<BizValidationError<IActionResult>> AuthorizeCheckEventHandlerAsync(
        HttpContext httpContext,
        IOptionsMonitor<MPSAuthenticationOptions> options);
    }
}