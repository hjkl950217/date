﻿using AspectCore.DependencyInjection;
using AspectCore.DynamicProxy;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Newegg.MIS.Baymax.Cache;
using System.Net;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 授权
    /// </summary>
    public sealed class FunctionAttribute : AbstractInterceptorAttribute
    {
        private readonly string functionKey;

        /// <summary>
        ///
        /// </summary>
        /// <param name="functionKey">要检查的功能名字。值请和"MPS_Portal_Function"中的FunctionKey列的值一样。注意大小写、空格</param>
        public FunctionAttribute(string functionKey)
        {
            this.functionKey = functionKey;
        }

        [FromServiceContext]
        public IRedisConnection RedisConnection { get; set; }

        [FromServiceContext]
        public IHttpContextAccessor HttpContextAccessor { get; set; }

        public override async Task Invoke(AspectContext context, AspectDelegate next)
        {
            var options = context.ServiceProvider
                .GetService<IOptionsMonitor<MPSAuthenticationOptions>>();
            if (!options.CurrentValue.EnableFunctionalAuthorization) return;

            //1.获取userID
            int? userID = this.HttpContextAccessor
                .HttpContext
                .GetCurrentLoginCache()
                ?.UserInfo
                ?.UserID;

            if (userID == null)
            {
                //在这里抛出异常才可以跳过控制器那一层，直接返回想要的状态码和消息了
                //如果不是抛异常，有可能在控制器中被动作方法重写返回行为，状态码就变了
                throw new BusinessException(this.GetErrorMsg(true), statusCode: HttpStatusCode.BadRequest);
            }

            //2.从redis中取值来判断是否有权限
            string fKey = string.Format(AuthenticationConst.FunctionKey_TemplateForCheck, userID);

            var isFunction = await this.RedisConnection
                .ExecuteAsync(t => t.HashExistsAsync(fKey, this.functionKey));

            if (!isFunction)
            {
                throw new BusinessException(this.GetErrorMsg(false), statusCode: HttpStatusCode.Unauthorized);
            }

            await next.Invoke(context);
        }

        private string GetErrorMsg(bool byNoId = false)
        {
            if (byNoId)
            {
                return $"Function '{this.functionKey}' Authentication error,data not fund from id";
            }
            else
            {
                return $"Function '{this.functionKey}' Authentication error,data not fund";
            }
        }
    }
}