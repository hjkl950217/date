﻿namespace Mkpl.Sdk.Core.Authentication
{
    public static class AuthenticationConst
    {
        /// <summary>
        /// 解析JWT值时，存放中间数据的key名。数据存放在<see cref="Microsoft.AspNetCore.Http.HttpContext.Items"/>中
        /// </summary>
        public const string SessionObjcetKey = "MpsSessionKey";

        /// <summary>
        /// 从Jwt对象中取session id的key
        /// </summary>
        public const string SessionIdKey = "sei";

        /// <summary>
        /// 从redis中获取sessionId对应数据的key.<para></para>
        /// 用sessionid格式化后再使用<para></para>
        /// 0填充 SessionId,1填充platformCode
        /// </summary>
        public const string RedisKeyTemplateForLoginCache = "mps_login_{0}_{1}";

        /// <summary>
        /// 验证成功之后向http context中写登陆数据的key
        /// </summary>
        public const string CurrentLoginCacheKey = "CurrentLoginCache";

        /// <summary>
        /// 从redis中验证权限的key模版<para></para>
        /// 0填充UserID.<para></para>
        /// 使用： mps.function.2 testFunction 如果存在则代表2这个user有testFunction这个权限
        /// </summary>
        public const string FunctionKey_TemplateForCheck = "mps.function.{0}";

        /// <summary>
        /// 用来验证seller是否有InternalAdmin权限的key.用在hash
        /// </summary>
        public const string FunctionKey_InternalSellerKey = "internalAdmin_edit";

        public const string ErrorStrPrefix = "Bearer error=\"invalid_token\"";

        /// <summary>
        /// 返回错误消息时的模版。<para></para>
        /// 0为消息类型，默认使用<see cref="ErrorStrPrefix"/> <para></para>
        /// 1为消息描述
        /// </summary>
        public const string ErrorStrTemplate = "{0},error_description={1}";
    }
}