﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    public class JwtToken
    {
#pragma warning disable CS1574 // XML 注释中有无法解析的 cref 特性

        /// <summary>
        /// 获取jwt验证配置的api完整地址。赋值给<see cref="JwtBearerOptions.Authority"/>
        /// </summary>
        public string JwtTokenServer { get; set; }

        /// <summary>
        /// 验证时间时，允许的最大偏移量.赋值给<see cref="JwtBearerOptions.TokenValidationParameters.ClockSkew"/>
        /// </summary>
        public TimeSpan ClockSkew { get; set; }

        /// <summary>
        /// jwt验证中允许的Issuer。 赋值给<see cref="JwtBearerOptions.TokenValidationParameters.ValidIssuers"/>
        /// </summary>
        public List<string> ValidIssuers { get; set; }

        /// <summary>
        /// 是否验证Issuer。赋值给<see cref="JwtBearerOptions.TokenValidationParameters.ValidateIssuer"/>
        /// </summary>
        public bool ValidateIssuer { get; set; }

#pragma warning restore CS1574 // XML 注释中有无法解析的 cref 特性
    }
}