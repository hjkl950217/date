﻿using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    public class JwtToken
    {
        public string JwtTokenServer { get; set; }

        public TimeSpan ClockSkew { get; set; }

        public List<string> ValidIssuers { get; set; }

        public bool ValidateIssuer { get; set; }
    }
}