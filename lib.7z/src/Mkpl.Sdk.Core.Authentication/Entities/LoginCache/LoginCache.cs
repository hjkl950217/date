﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    public class LoginCache
    {
        /// <summary>
        /// 登陆时要缓存的数据
        /// </summary>
        public List<LoginCacheEntity> CacheData { get; set; }
    }
}