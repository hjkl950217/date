﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    /// <summary>
    /// 登陆缓存实体
    /// </summary>
    /// <remarks>
    /// 使用：
    /// 1.在登陆的最后一个API会写类对应的json数据到redis
    /// 2.认证完成后，会从redis中取出缓存数据，序列化
    /// </remarks>
    public class LoginCacheEntity
    {
        /// <summary>
        /// 当前请求中对应的seller基本信息
        /// </summary>
        public virtual SellerCache SellerInfo { get; set; }

        /// <summary>
        /// 当请请求中的User基本信息
        /// </summary>
        public virtual UserCache UserInfo { get; set; }

        /// <summary>
        /// 当前请求中对应的Seller支持的平台。值参考<see cref="PlatformConst.PlatformCodeList"/>
        /// </summary>
        public virtual List<string> PlatformCodeList { get; set; }
    }
}