﻿namespace Mkpl.Sdk.Core.Authentication.Entities
{
    /// <summary>
    /// 登陆缓存实体Plus
    /// </summary>
    /// <remarks>
    /// 使用：认证完成后，注入到HttpContext中，提供给业务开发使用
    /// </remarks>
    public class LoginCacheEntityPlus : LoginCacheEntity
    {
        /// <summary>
        /// 当前登陆者使用的平台
        /// </summary>
        public string CurrentPlatformCode { get; set; }
    }
}