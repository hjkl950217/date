﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    /// <summary>
    /// 缓存的seller信息
    /// </summary>
    public class SellerCache
    {
        public string SellerID { get; set; }
        public string SellerName { get; set; }

        /// <summary>
        /// 注册时选择的地址，代表卖家属于那一个国家
        /// </summary>
        public string BusinessRegionCode { get; set; }

        /// <summary>
        /// Seller账户状态
        /// </summary>
        public SellerStatusEnum SellerStatus { get; set; }

        /// <summary>
        /// seller角色类型
        /// </summary>
        public SellerRoleTypeEnum SellerRoleType { get; set; }
    }
}