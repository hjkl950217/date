﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Authentication.Entities
{
    /// <summary>
    /// 缓存的user信息.取至 [MKTPLS].[dbo].[EDI_Seller_User] 表的字段
    /// </summary>
    public class UserCache
    {
        public int UserID { get; set; }

        /// <summary>
        ///  UserName
        ///  不推荐原因：因系统设计原因，只有内部用户才会维护这个字段，所以不推荐使用。若您的业务中需要此字段，可以考虑使用<see cref="UserCache.LoginEmailAddress"/>。以后还有可能启用所以设置为 internal ，不开放给业务项目使用
        /// </summary>
        [System.Obsolete("不推荐使用")]
        internal string UserName { get; set; }

        public int CustomerNumber { get; set; }

        /// <summary>
        /// 登陆邮箱地址。在edi_seller_user表中对应UserEmailAddress
        /// </summary>
        public string LoginEmailAddress { get; set; }

        /// <summary>
        /// User账户状态
        /// </summary>
        public UserStatusEnum UserStatus { get; set; }
    }
}