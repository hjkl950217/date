﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Authentication.Entities.Options
{
    /// <summary>
    /// MPS认证授权选项
    /// </summary>
    public class MPSAuthenticationOptions
    {
        public static MPSAuthenticationOptions GetDefault()
        {
            MPSAuthenticationOptions options = new MPSAuthenticationOptions();
            options.RestConfigurationToDefault();
            return options;
        }

        /// <summary>
        /// 默认获取token的 HeaderName集合
        /// </summary>
        public static string[] DefaultTokenHeaderNames = new string[]
        {
            HttpHeaderNameConst.MpsJwtTokenInQueryString,
            HttpHeaderNameConst.MpsJwtToken
        };

        #region 字段名称配置

        /// <summary>
        /// 设置或获取，认证不通过时向响应头中写错误信息的名字
        /// </summary>
        public string ErrorHeaderName { get; set; }

        /// <summary>
        /// 从请求头中获取平台代码的头
        /// </summary>
        public string PlatformCodeHeadreName { get; set; }

        /// <summary>
        /// 从jwt对象的Payload中获取sellerID的key 名
        /// </summary>
        public string TokenKeyName { get; set; }

#pragma warning disable CA1819 // Properties should not return arrays

        /// <summary>
        /// 获取token的 HeaderName集合
        /// 框架会按 header->queryString->form的顺序查找。支持传递多个key名，但只会返回匹配上的第一个
        /// </summary>
        public string[] TokenHeaderNames { get; set; }

#pragma warning restore CA1819 // Properties should not return arrays

        #endregion 字段名称配置

        #region 大功能配置

        /// <summary>
        /// 启用登陆认证,默认开启<para></para>
        /// 启用此选项意味着：当API方法上配置了<see cref="MpsAuthorizeAttribute"/>后,每次请求都会检查Token
        /// </summary>
        public bool EnableLoginAuthorize { get; set; }

        /// <summary>
        /// 启用功能授权,默认开启<para></para>
        /// 启用此选项意味着：在接口或可重写的方法上配置了<see cref="FunctionAttribute"/>后，每次调用都会检查当前用户是否具有<see cref="FunctionAttribute"/>中配置的对应权限
        /// </summary>
        public bool EnableFunctionalAuthorization { get; set; }

        /// <summary>
        /// 是否启用
        /// </summary>
        public bool Enable => this.EnableLoginAuthorize || this.EnableFunctionalAuthorization;

        #endregion 大功能配置

        #region 其它配置

        /// <summary>
        /// 启用错误信息,默认开启<para></para>
        /// 启用此选项意味着：当检查有错误发生时，响应头中的<see cref="HttpHeaderNameConst.UnAuthorizationDescription"/>会带上错误信息
        /// </summary>
        public bool EnableErrorMessage { get; set; }

        #endregion 其它配置
    }
}