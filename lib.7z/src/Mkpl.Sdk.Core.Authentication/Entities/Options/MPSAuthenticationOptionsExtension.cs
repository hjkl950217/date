﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Env;

namespace Mkpl.Sdk.Core.Authentication.Entities.Options
{
    public static class MPSAuthenticationOptionsExtension
    {
        /// <summary>
        /// 设置配置为默认值
        /// </summary>
        /// <param name="options"></param>
        public static void RestConfigurationToDefault(this MPSAuthenticationOptions options)
        {
            if (options == null)
            {
                throw new System.ArgumentNullException(nameof(options));
            }

            options.ErrorHeaderName = HttpHeaderNameConst.UnAuthorizationDescription;
            options.PlatformCodeHeadreName = HttpHeaderNameConst.MpsPlatformCode;
            options.TokenKeyName = AuthenticationConst.SessionIdKey;
            options.TokenHeaderNames = MPSAuthenticationOptions.DefaultTokenHeaderNames;
            options.EnableLoginAuthorize = true;
            options.EnableFunctionalAuthorization = true;
            options.EnableErrorMessage = EnvironmentInfo.Gobal.IsGdev()
                || EnvironmentInfo.Gobal.IsGqc();
        }
    }
}