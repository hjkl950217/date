﻿using Microsoft.Extensions.Primitives;
using Mkpl.Sdk.Core;
using Mkpl.Sdk.Core.Authentication;
using Mkpl.Sdk.Core.Authentication.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace Microsoft.AspNetCore.Http
{
    public delegate StringValues GetValueFromRequestMethod(
        HttpRequest request,
        string keyName);

    public static class HttpContextExtensions2
    {
        #region 基础方法

        private static readonly List<GetValueFromRequestMethod> GetValueFromHttpMehodList = new List<GetValueFromRequestMethod>()
        {
            (request,keyName) => request.Headers.ContainsKey(keyName)
                ?request.Headers[keyName]
                :StringValues.Empty,
            (request, keyName) => request.QueryString.HasValue && request.Query.ContainsKey(keyName)
                ? request.Query[keyName]
                :StringValues.Empty,
            (request, keyName) => request.HasFormContentType && request.Query.ContainsKey(keyName)
                ?request.Form[keyName]
                :StringValues.Empty
        };

        /// <summary>
        /// 按一定顺序从请求中获取数据<para></para>
        /// 顺序：Header->QueryString->Form
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="keyNames">获取数据的key名</param>
        /// <returns></returns>
        public static string BaseGetValue(this HttpContext httpContext, params string[] keyNames)
        {
            foreach (var key in keyNames)
            {
                foreach (var item in GetValueFromHttpMehodList)
                {
                    StringValues result = item(httpContext.Request, key);
                    if (result != StringValues.Empty) return result.ToString();
                }
            }
            return string.Empty;
        }

        #endregion 基础方法

        /// <summary>
        /// 获取<see cref="JwtSecurityToken"/>数据，如果<see cref="HttpHeaderNameConst"/>没有值或取值失败,则返回null
        /// </summary>
        /// <param name="httpContext"></param>
        ///  <param name="keyNames"></param>
        /// <returns></returns>
        public static JwtSecurityToken GetJwtObject(
            this HttpContext httpContext,
            string[] keyNames = null)
        {
            bool isExist = httpContext.Items.TryGetValue(AuthenticationConst.SessionObjcetKey, out object jwtObj);
            if (isExist)
            {
                return jwtObj as JwtSecurityToken;
            }
            else
            {
                string jwtValue = httpContext.GetJwtSting(keyNames);

                if (jwtValue.IsNullOrEmpty()) return null;

                JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
                JwtSecurityToken result = jwtSecurityTokenHandler.ReadJwtToken(jwtValue);//解析

                httpContext.Items[AuthenticationConst.SessionObjcetKey] = result;
                return result;
            }
        }

        /// <summary>
        /// 获取sessionId，获取不到时返回null
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="tokenKeyName"></param>
        /// <param name="keyNames">获取jwt token的key集合</param>
        /// <returns></returns>
        public static string GetSessionID(
            this HttpContext httpContext,
            string tokenKeyName = AuthenticationConst.SessionIdKey,
            string[] keyNames = null)
        {
            return httpContext.GetJwtObject(keyNames)
                ?.Payload[tokenKeyName]
                ?.ToString();
        }

        /// <summary>
        /// 获取Jwt字符串.使用默认规则
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="keyNames"></param>
        /// <returns>Jwt字符串.如果获取不到则返回null</returns>
        public static string GetJwtSting(this HttpContext httpContext, string[] keyNames = null)
        {
            //场景要求jwt这个头在第一个

            keyNames = keyNames ?? new string[]
            {
                HttpHeaderNameConst.MpsJwtTokenInQueryString,
                HttpHeaderNameConst.MpsJwtToken
            };

            return httpContext.BaseGetValue(keyNames);
        }

        /// <summary>
        /// 获取Jwt字符串.使用头:<see cref="HttpHeaderNameConst.MpsJwtToken"/><para></para>
        /// 请使用<see cref="GetJwtSting(HttpContext, string[])"/>
        ///
        /// 2019-09-29 lynn 兼容新老两套取token的规则，有可能有2个头
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="tokenHeaderName"></param>
        /// <returns>Jwt字符串.如果获取不到则返回null</returns>
        [System.Obsolete("已过时,请参考备注使用新方法")]
        public static string GetJwtSting(this HttpContext httpContext,
            string tokenHeaderName = HttpHeaderNameConst.MpsJwtToken)
        {
            return httpContext.BaseGetValue(tokenHeaderName);
        }

        /// <summary>
        /// 获取当前请求中的平台代码。使用头:<see cref="HttpHeaderNameConst.MpsPlatformCode"/>
        /// </summary>
        /// <param name="httpContext"></param>
        /// <param name="platformCodeHeadreName"></param>
        /// <returns>请求中的平台代码，如果获取不到则返回null</returns>
        public static string GetCurrentPlatformCode(this HttpContext httpContext, string platformCodeHeadreName = HttpHeaderNameConst.MpsPlatformCode)
        {
            return httpContext.BaseGetValue(platformCodeHeadreName).ToUpper().Trim();
        }

        /// <summary>
        /// [AppContext]获取当前用户的数据
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns>当前用户的数据,获取失败时返回null</returns>
        public static LoginCacheEntityPlus GetCurrentLoginCache(this HttpContext httpContext)
        {
            return httpContext.Items[AuthenticationConst.CurrentLoginCacheKey] as LoginCacheEntityPlus;
        }
    }
}