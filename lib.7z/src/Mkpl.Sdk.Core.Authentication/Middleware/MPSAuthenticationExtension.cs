﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Mkpl.Sdk.Core.Authentication;
using Mkpl.Sdk.Core.Authentication.Entities;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    public static class MPSAuthenticationExtension
    {
        /// <summary>
        /// 请使用<see cref="MPSAuthenticationExtension.AddAuthenticationMPS(IServiceCollection, IConfiguration, Action{MPSAuthenticationOptions}, Action{AuthenticationBuilder})"/><para></para>
        ///
        /// 启用MPS认证服务。<para></para>
        /// 启用此服务后还需要在http管道处， mvc的上面调用<see cref="AuthAppBuilderExtensions.UseAuthentication(IApplicationBuilder)"/>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <param name="tokenHeaderName">默认为X-Authorization-JWT</param>
        /// <param name="authenticationBuilderAction"></param>
        [System.Obsolete("已弃用，请参考说明使用请方法")]
        public static void AddAuthenticationMps(
            this IServiceCollection services,
            IConfiguration configuration,

            string tokenHeaderName = HttpHeaderNameConst.MpsJwtToken,
            Action<AuthenticationBuilder> authenticationBuilderAction = null)
        {
            services.AddAuthenticationMPS(
                configuration,
                configureOptions: null,
                authenticationBuilderAction: authenticationBuilderAction);
        }

        /// <summary>
        /// 启用MPS认证服务。<para></para>
        /// 启用此服务后还需要在http管道处， mvc的上面调用<see cref="AuthAppBuilderExtensions.UseAuthentication(IApplicationBuilder)"/><para></para>
        ///
        /// 依赖：redis  注册服务方法：<see cref="MpsRedisClientExtension.AddMpsRedisClientMPS(IServiceCollection, IConfiguration, string, string, Func{System.Collections.Generic.IEnumerable{Client.IRedisProvider}})"/>获取
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <param name="configureOptions">配置认证的选项，可选.默认情况下PRD,PRE屏蔽</param>
        /// <param name="authenticationBuilderAction"></param>
        public static void AddAuthenticationMPS(
            this IServiceCollection services,
            IConfiguration configuration,
            Action<MPSAuthenticationOptions> configureOptions = null,
            Action<AuthenticationBuilder> authenticationBuilderAction = null)
        {
            //注册配置对象
            services.Configure<MPSAuthenticationOptions>(t =>
            {
                MPSAuthenticationOptions.ConfigureDefaultMPSAuthenticationOptions(t);
                configureOptions?.Invoke(t);
            });

            //注册认证检查
            //开关在检查代码中控制，因为配置项在运行时支持修改的
            services.AddAuthorize(
                configuration,
                authenticationBuilderAction);
            services.AddSingleton<IAuthenticationCheck, DefaultAuthenticationCheck>();

            //授权的控制在 FunctionAttribute.cs 中 因为使用 AspectCore 无法在这里控制它不注入
            //所以在 FunctionAttribute.cs 中去获取配置。当 EnableFunctionalAuthorization==false的时候， 里面会直接返回，不进行处理
        }

        private static void AddAuthorize(
            this IServiceCollection services,
            IConfiguration configuration,
            Action<AuthenticationBuilder> authenticationBuilderAction = null)
        {
            configuration.CheckNull(nameof(configuration));
            JwtToken config = configuration.GetFromJson<JwtToken>("JwtToken");
            if (config == null)
            {
                throw new ArgumentNullException($"Data failed to get from Config Service.", "JwtToken");
            }
            //配置jwt token认证
            var jwtCore = services.AddAuthentication("Bearer")
                .AddJwtBearer("Bearer", options =>
                {
                    options.TokenValidationParameters.ValidateIssuer = config.ValidateIssuer;
                    options.TokenValidationParameters.ValidIssuers = config.ValidIssuers;
                    options.TokenValidationParameters.ClockSkew = config.ClockSkew;
                    options.Audience = "seller_portal";
                    options.Authority = config.JwtTokenServer;
                    options.RequireHttpsMetadata = false;
                    options.Events = new JwtBearerEvents()
                    {
                        OnMessageReceived = i =>
                        {
                            var mpsOptions = i.HttpContext
                                .RequestServices
                                .GetService<IOptionsMonitor<MPSAuthenticationOptions>>();

                            i.Token = i.HttpContext
                                .GetJwtSting(mpsOptions.CurrentValue.TokenHeaderNames);
                            return Task.CompletedTask;
                        }
                    };
                });

            //追加自定义配置
            authenticationBuilderAction?.Invoke(jwtCore);
        }
    }
}