﻿using Microsoft.Extensions.CommandLineUtils;

namespace Mkpl.Sdk.Core.Job
{
    public static class CommandOptionExtensions
    {
        public static T GetValueOrDefault<T>(this CommandOption option, T defaultValue)
        {
            return option.HasValue()
                ? (T)System.Convert.ChangeType(option.Value(), typeof(T))
                : defaultValue;
        }
    }
}