﻿using Microsoft.Extensions.CommandLineUtils;
using Mkpl.Sdk.Core.Env;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Job
{
    public class CommandOptionsSource : IEnvironmentInfoSource
    {
        private readonly Dictionary<string, CommandOption> options;

        public CommandOptionsSource(params CommandOption[] options)
        {
           this.options = options.ToDictionary(i => i.Template, StringComparer.OrdinalIgnoreCase);
        }

        public string Get(string key)
        {
            if (options.TryGetValue(key, out var option))
            {
                return option.Value();
            }
            else
            {
                return null;
            }
        }
    }
}
