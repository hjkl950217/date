﻿using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Job
{
    /// <summary>
    /// Job的基类
    /// </summary>
    public abstract class JobBase
    {
        /// <summary>
        /// 执行任务
        /// </summary>
        public virtual void Execute()
        {
            this.ExecuteAsync().GetAwaitResult();
        }

        public virtual Task ExecuteAsync()
        {
            return Task.CompletedTask;
        }
    }
}