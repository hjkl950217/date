﻿using Microsoft.Extensions.CommandLineUtils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Helpers;
using Newegg.MIS.Baymax.AOP;
using Newegg.MIS.Baymax.Cache;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Mkpl.Sdk.Core.Job
{
    /// <summary>
    /// Job引导程序
    /// </summary>
    public class JobBootstrapper
    {
        /// <summary>
        /// 配置名.默认情况下读取 MKPL_Backend_Task-{configName}的配置<para></para>
        /// 一般为当前领域的。如OrderSyncToSolrJob的配置就在Job_Order下面
        /// </summary>
        private readonly string configName;

        public IServiceCollection Services { get; } = new ServiceCollection();
        public IConfigurationBuilder ConfigBuilder { get; } = new ConfigurationBuilder();
        public CommandLineApplication App { get; }

        /// <summary>
        /// 初始化化一个<see cref="JobBootstrapper"/>实例
        /// </summary>
        /// <param name="configName">
        /// 配置名.默认情况下读取 MKPL_Backend_Task-{configName}的配置<para></para>
        /// 一般为当前领域的。如OrderSyncToSolrJob的配置就在Job_Order下面
        /// </param>
        /// <param name="cacheSystemConfig">需要自定义的缓存配置</param>
        public JobBootstrapper(string configName,
            List<RedisConfig> cacheSystemConfig = null)
        {
            this.configName = configName;
            this.App = new CommandLineApplication();
            this.App.HelpOption("-h");
            this.App.OnExecute(() =>
            {
                this.App.ShowHelp();
                return 2;
            });

            //注册一些基本的服务
            this.Services.AddSingleton(this.App);
            this.Services.UseBaymax();
            this.Services.AddEggKeeper();
        }

        /// <summary>
        /// 运行Job
        /// </summary>
        /// <param name="args"></param>
        /// <param name="assemblies"></param>
        public void Run(string[] args, params Assembly[] assemblies)
        {
            this.RegisterJobs(assemblies);
            this.App.Execute(args);
        }

        /// <summary>
        /// 注册所有Job
        /// </summary>
        /// <param name="assemblies">其它要注册的程序集</param>
        private void RegisterJobs(Assembly[] assemblies)
        {
            var types = AppDomain.CurrentDomain.GetAssemblies()
                .Union(assemblies)
                .SelectMany(i =>
                {
                    try
                    {
                        return i.GetExportedTypes();
                    }
                    catch
                    {
                        return new Type[0];
                    }
                })
                .Where(i => i.IsClass
                            && i.IsPublic
                            && i.IsAbstract == false
                            && i.IsSubclassOf(typeof(JobBase)))
                .Distinct();

            foreach (var type in types)
            {
                this.RegisterCommand(type.Name, type);
            }
        }

        /// <summary>
        /// 注册job
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="type"></param>
        public void RegisterCommand(string jobName, Type type)
        {
            this.App.Command(jobName, command =>
            {
                #region 1. 配置命令对象

                command.HelpOption("-h");
                var env = command.Option("--env", "[Require]Run Environment. Default gdev.   eg. gdev gqc pre prd", CommandOptionType.SingleValue);

                var totalServiceCount = command.Option("--total", "The total count of runs of this job. Default 1", CommandOptionType.SingleValue);
                var sequence = command.Option("--sequence", "The current instance number of the job.Default 1", CommandOptionType.SingleValue);

                var systemName = command.Option("--system-name", $"Specify the System Name used by the job config.Default value is '{JobFrameDefaultVariable.SystemName}'", CommandOptionType.SingleValue);
                var db = command.Option("--db", " Specify DB Directory.Refer to the DB folder name in your project.Default value is 'db'", CommandOptionType.SingleValue);
                var noBalance = command.Option("--no-db-balance", "No use db balance.", CommandOptionType.NoValue);

                var eggkeeperCluster = command.Option("--eggkeeper-cluster", "Specify the eggkeeper cluster.    eg.gdev,gqc,wh7,e4,e11", CommandOptionType.SingleValue);
                var logLevelComm = command.Option("--logLevel", "Specify log level.Default is Error.  eg.Trace Debug Information Warning Error Critical None", CommandOptionType.SingleValue);
                var isAutoTest = command.Option("--at", "Enable automated test environment", CommandOptionType.NoValue);
                var redisCluster = command.Option("--redis-cluster", "Specify the eggkeeper cluster.    eg.default,e4,e11", CommandOptionType.SingleValue);

                #endregion 1. 配置命令对象

                #region 2. 配置处理流程

                command.OnExecute(() =>
                {
                    #region 0.解析参数

                    string envValue = env.GetValueOrDefault(JobFrameDefaultVariable.DefaultEnvName).ToLower();
                    string eggkeeperClusterStr = eggkeeperCluster.GetValueOrDefault(string.Empty).ToUpper();
                    eggkeeperClusterStr = this.GetEggkeeperCluster(envValue, eggkeeperClusterStr);

                    string jobSysName = systemName.GetValueOrDefault(JobFrameDefaultVariable.SystemName);
                    string commSysName = JobFrameDefaultVariable.CommonSystemName;

                    string redisClusterStr = redisCluster.GetValueOrDefault("default");
                    int totalCount = totalServiceCount.GetValueOrDefault(1);
                    int sequenceCount = sequence.GetValueOrDefault(1) - 1;
                    string logLeveStr = logLevelComm.GetValueOrDefault(string.Empty);
                    string dbDirectory = db.GetValueOrDefault(Path.Combine(Directory.GetCurrentDirectory(), "db"));

                    var commandObj = new
                    {
                        envValue,
                        eggkeeperClusterStr,
                        jobSysName,
                        commSysName,
                        redisClusterStr,
                        totalCount,
                        sequenceCount,
                        logLeveStr,
                        dbDirectory
                    };
                    Console.WriteLine($"all command:{commandObj.ToJsonExt()}");

                    #endregion 0.解析参数

                    #region 1. 各种注册

                    //注册DB服务和对应配置文件
                    this.SetDBConfig(dbDirectory, envValue);

                    //注册配置服务
                    this.ConfigBuilder.UseEggKeeper(envValue, jobSysName, false, eggkeeperClusterStr);
                    this.ConfigBuilder.UseEggKeeper(
                        envValue,
                        commSysName,
                        false,
                        eggkeeperClusterStr);

                    //注册job中的静态注册服务的方法
                    this.RegistratServices(jobName, type);

                    //注册配置接口
                    IConfigurationRoot config = this.ConfigBuilder.Build();
                    this.Services.TryAddSingleton<IConfiguration>(config);

                    //注册job和它的配置
                    this.Services.AddSingleton(typeof(JobBase), type);
                    this.Services.AddSingleton<JobConfig>(t =>
                    {
                        return this.GetJobConfig(
                            jobName: jobName,
                            systemName: jobSysName,
                            configName: this.configName,
                            envValue: envValue,
                            totalServiceCount: totalCount,
                            sequenceNumber: sequenceCount,
                            configuration: config);
                    });

                    //注册log接口和配置log等级
                    bool isLogInfo = logLevelComm.HasValue();
                    Func<LogLevel, bool> logFilter = t => true;

                    if (isLogInfo)
                    {
                        bool isParse = Enum.TryParse(logLeveStr, true, out LogLevel logLevel);

                        if (!isParse)
                        {
                            Console.WriteLine("[Error] --logLevel value error.");
                            return 255;
                        }

                        logFilter = (level) => level >= logLevel;
                    }
                    else
                    {
                        logFilter = LogExtension.defaultLogFilter;
                    }

                    this.Services.AddLogging(i =>
                    {
                        i.AddConsole();
                        i.AddFilter(logFilter);
                    });

                    #endregion 1. 各种注册

                    #region 2.执行job

                    var provider = this.Services.ToAopProvider();
                    var job = provider.GetRequiredService<JobBase>();
                    job.Execute();//等待任务执行完毕

                    #endregion 2.执行job

                    return 0;
                });

                #endregion 2. 配置处理流程
            });
        }

        private string GetEggkeeperCluster(string env, string commandValue)
        {
            if (commandValue.IsNotNullOrEmpty()) return commandValue;//有配置命令则用命令的

            //PRD定死E11
            //PRE机房在E11，但是egg服务只有WH7。eggkeeper里已经针对pre处理过
            if (EnvHelper.IsPrd(env)) return "E11";
            else if (EnvHelper.IsPre(env)) return "WH7";
            else return env;
        }

        /// <summary>
        /// 设置DB连接文件
        /// </summary>
        /// <param name="dbDirectory"></param>
        /// <param name="envValue"></param>
        private void SetDBConfig(string dbDirectory, string envValue)
        {
            //排除所有db开头的文件，只包含 db.{envValue}.xml
            if (Directory.Exists(dbDirectory))
            {
                var excludeFileNames = Directory.EnumerateFiles(dbDirectory, "db.*.xml", SearchOption.AllDirectories)
                .Select(i => i.Replace(dbDirectory + Path.DirectorySeparatorChar, ""))
                .ToArray();

                this.Services
                    .UseMSSql()
                    .UseDataAccessConfigFromDirectory(dbDirectory, excludeFileNames, $"db.{envValue}.xml");
            }
        }

        /// <summary>
        /// 调用job实现中的方法注册服务
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="jobType"></param>
        /// <param name="methodName">方法名</param>
        private void RegistratServices(
            string jobName,
            Type jobType,
            string methodName = JobFrameDefaultVariable.RegistrationMethodName)
        {
            try
            {
                var method = jobType.GetMethod(methodName, BindingFlags.Static | BindingFlags.Public);
                method?.Invoke(null, new object[] { this.Services, this.ConfigBuilder });
            }
            catch
            {
                Console.WriteLine($"[Warning] No Found ConfigServices static method for {jobName}.");
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="systemName">取配置失败时，报错用的</param>
        /// <param name="configName"></param>
        /// <param name="totalServiceCount"></param>
        /// <param name="sequenceNumber"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public JobConfig GetJobConfig(
          string jobName,
          string systemName,
          string configName,
          string envValue,
          int totalServiceCount,
          int sequenceNumber,
          IConfigurationRoot configuration)
        {
            JobConfig jobConfig = new JobConfig();
            jobConfig.TotalService = totalServiceCount;
            jobConfig.SequenceNumber = sequenceNumber;

            if (configuration[configName] == null)
            {
                Console.WriteLine($"[Error] No Found config {this.configName} in {systemName} for Job.");
            }
            else
            {
                /*
                 *  dict
                 * key: job名
                 * value-Key:配置名
                 * value-Value:配置值
                 */
                var dict = configuration
                    .GetFromJson<Dictionary<string, Dictionary<string, object>>>(configName);
                var jobConfigDic = dict.GetOrDefault(jobName);

                jobConfig.Config = jobConfigDic ?? new Dictionary<string, object>();
                if (jobConfigDic.IsNotNullOrEmpty())
                {
                    SetBaseConfig(jobConfig, jobConfigDic);
                    jobConfig.Env = EnvHelper.ConvertToEnvEnum(envValue);
                }
            }

            return jobConfig;
        }

        private static void SetBaseConfig(JobConfig jobConfig, Dictionary<string, object> jobConfigDic)
        {
            jobConfig.ProcessCount = jobConfigDic
                .GetOrDefault(nameof(JobConfig.ProcessCount))
                .ToInt32OrDefault(JobConfig.DefaultProcessCount);

            jobConfig.BlockSellerList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.BlockSellerList), string.Empty)
                .ToString()
                .SplitToArray();

            jobConfig.SpecialSellerList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.SpecialSellerList), string.Empty)
                .ToString()
                .SplitToArray();

            jobConfig.BlockUserList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.BlockUserList), string.Empty)
                .ToString()
                .SplitToArray();

            jobConfig.SpecialUserList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.SpecialUserList), string.Empty)
                .ToString()
                .SplitToArray();
        }
    }
}