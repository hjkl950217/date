﻿using AspectCore.Extensions.DependencyInjection;
using Microsoft.Extensions.CommandLineUtils;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.DB;
using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Mkpl.Sdk.Core.Job
{
    /// <summary>
    /// Job引导程序
    /// </summary>
    public class JobBootstrapper
    {
        /// <summary>
        /// 配置名.默认情况下读取 MKPL_Backend_Task-》{configName}的配置<para></para>
        /// 一般为当前领域的。如OrderSyncToSolrJob的配置就在Job_Order下面
        /// </summary>
        private readonly string configName;

        /// <summary>
        /// 领域名
        /// </summary>
        private readonly string domainName;

        public IServiceCollection Services { get; } = new ServiceCollection();
        public IConfigurationBuilder ConfigBuilder { get; } = new ConfigurationBuilder();
        public CommandLineApplication App { get; }

        /// <summary>
        /// 【已弃用】初始化化一个<see cref="JobBootstrapper"/>实例<para></para>
        /// 请使用<see cref="JobBootstrapper(string,string)"/>
        /// </summary>
        /// <param name="configName">
        /// 配置名,格式必须为"Job_XXXX".默认情况下读取 MKPL_Backend_Task->{configName}的配置<para></para>
        /// 一般为当前领域的。如OrderSyncToSolrJob的配置就在Job_Order下面
        /// </param>
        [System.Obsolete("已弃用")]
        public JobBootstrapper(string configName)
            : this(configName.Replace("Job_", ""), configName)
        {
        }

        /// <summary>
        /// 初始化化一个<see cref="JobBootstrapper"/>实例
        /// </summary>
        /// <param name="domainName">领域名</param>
        /// <param name="configName">
        /// 配置名.默认情况下读取 MKPL_Backend_Task->{configName}的配置<para></para>
        /// 一般为当前领域的。如OrderSyncToSolrJob的配置就在Job_Order下面
        /// </param>
        public JobBootstrapper(string domainName, string configName)
        {
            if (configName.IsNullOrEmpty() || !configName.Contains("Job_"))
            {
#pragma warning disable S112 // General exceptions should never be thrown
                throw new ApplicationException($"{nameof(configName)} error.{nameof(configName)} cannot be empty and the format must be 'Job_XXX'");
#pragma warning restore S112 // General exceptions should never be thrown
            }

            this.domainName = domainName;
            this.configName = configName;
            this.App = new CommandLineApplication();
            this.App.HelpOption("-h");
            this.App.OnExecute(() =>
            {
                this.App.ShowHelp();
                return 2;
            });

            //注册一些基本的服务
            this.Services.AddSingleton(this.App);
            this.Services.UseBaymax();
            this.Services.AddEggKeeper();
        }

        /// <summary>
        /// 运行Job
        /// </summary>
        /// <param name="args"></param>
        /// <param name="assemblies"></param>
        public void Run(string[] args, params Assembly[] assemblies)
        {
            this.RegisterJobs(assemblies);
            this.App.Execute(args);
        }

        /// <summary>
        /// 注册所有Job
        /// </summary>
        /// <param name="assemblies">其它要注册的程序集</param>
        private void RegisterJobs(Assembly[] assemblies)
        {
            var types = AppDomain.CurrentDomain.GetAssemblies()
                .Union(assemblies)
                .SelectMany(i =>
                {
                    try
                    {
                        return i.GetExportedTypes();
                    }
                    catch
                    {
                        return Array.Empty<Type>();
                    }
                })
                .Where(i => i.IsClass
                            && i.IsPublic
                            && i.IsAbstract == false
                            && i.IsSubclassOf(typeof(JobBase)))
                .Distinct();

            foreach (var type in types)
            {
                this.RegisterCommand(type.Name, type);
            }
        }

        /// <summary>
        /// 注册job
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="type"></param>
        public void RegisterCommand(string jobName, Type type)
        {
            this.App.Command(jobName, command =>
            {
                #region 1. 配置命令对象

                command.HelpOption("-h");
                var env = command.Option("--env", "[Require]Run Environment. Default gdev.   eg. gdev gqc pre prd", CommandOptionType.SingleValue);

                var totalServiceCount = command.Option("--total", "The total count of runs of this job. Default 1", CommandOptionType.SingleValue);
                var sequence = command.Option("--sequence", "The current instance number of the job.Default 1", CommandOptionType.SingleValue);

                var systemName = command.Option("--system-name", $"Specify the System Name used by the job config.Default value is '{JobFrameDefaultVariable.SystemName}'", CommandOptionType.SingleValue);
                var db = command.Option("--db", " Specify DB Directory.Refer to the DB folder name in your project.Default value is 'db'", CommandOptionType.SingleValue);

                var clusterLocation = command.Option("--cluster-location", "Specify the cluster location.    wh7,e4,e11", CommandOptionType.SingleValue);
                var eggkeeperCluster = command.Option("--eggkeeper-cluster", "Specify the eggkeeper cluster.    eg.gdev,gqc,wh7,e4,e11", CommandOptionType.SingleValue);
                var logLevelComm = command.Option("--logLevel", "Specify log level.Default is Error.  eg.Trace Debug Information Warning Error Critical None", CommandOptionType.SingleValue);
                var isAutoTest = command.Option("--at", "Enable automated test environment", CommandOptionType.NoValue);
                var redisCluster = command.Option("--redis-cluster", "Specify the eggkeeper cluster.    eg.default,e4,e11", CommandOptionType.SingleValue);
                var configServiceDbKey = command.Option("--config-service-db-key", "db key in config service", CommandOptionType.SingleValue);

                #endregion 1. 配置命令对象

                #region 2. 配置处理流程

                command.OnExecute(() =>
                {
                    #region 0.解析参数

                    var source = new CommandOptionsSource(env, db, configServiceDbKey, clusterLocation, eggkeeperCluster, redisCluster, isAutoTest, systemName);
                    var environmentInfo = EnvironmentInfo.Gobal;
                    environmentInfo.Init(source,
                        new RunEnvHandler(env.Template),
                        new MapHandler(EnvironmentNames.DbDirectory, db.Template, defaultValue: Path.Combine(Directory.GetCurrentDirectory(), "db")),
                        new ConfigServiceDbKeyHandler(configServiceDbKey.Template),
                        new ClusterLocationHandler(clusterLocation.Template),
                        new EggkeeperClusterLocationHandler(eggkeeperCluster.Template),
                        new RedisClusterLocationHandler(redisCluster.Template),
                        new AutoTestHandler(isAutoTest.Template),
                        new DomainNameHandler(systemName.Template, JobFrameDefaultVariable.SystemName),
                        new IsUTHandler(),
                        new GensisHandler());

                    int totalCount = totalServiceCount.GetValueOrDefault(1);
                    int sequenceCount = sequence.GetValueOrDefault(1) - 1;
                    string logLeveStr = logLevelComm.GetValueOrDefault(string.Empty);

                    #endregion 0.解析参数

                    #region 1. 各种注册

                    var envValue = environmentInfo.GetRunEnv();
                    var clusterStr = environmentInfo.GetClusterLocation();
                    var eggkeeperClusterStr = environmentInfo.GetEggkeeperClusterLocation();
                    var jobSysName = environmentInfo.GetDomainName();
                    //注册配置服务
                    this.ConfigBuilder.UseEggKeeper(envValue, jobSysName, false, eggkeeperClusterStr);
                    this.ConfigBuilder.UseEggKeeper(
                        envValue,
                        JobFrameDefaultVariable.CommonSystemName,
                        false,
                        eggkeeperClusterStr);

                    //注册job中的静态注册服务的方法
                    this.RegistratServices(jobName, type);

                    //注册配置接口
                    IConfigurationRoot config = this.ConfigBuilder.Build();
                    this.Services.TryAddSingleton<IConfiguration>(config);

                    //向皮卡丘添加配置文件
                    Services.AddDb(config, environmentInfo.GetDbDirectory(), environmentInfo.GetConfigServiceDbKey(), clusterStr, $"MKPL_{jobName}");
                    Services.AddSingleton(environmentInfo);
                    //注册job和它的配置
                    this.Services.AddSingleton(typeof(JobBase), type);
                    this.Services.AddSingleton<JobConfig>(t =>
                    {
                        return this.GetJobConfig(
                            jobName: jobName,
                            systemName: jobSysName,
                            configName: this.configName,
                            envValue: envValue,
                            totalServiceCount: totalCount,
                            sequenceNumber: sequenceCount,
                            configuration: config);
                    });

                    //注册log接口和配置log等级
                    bool isLogInfo = logLevelComm.HasValue();
                    Func<LogLevel, bool> logFilter = t => true;

                    if (isLogInfo)
                    {
                        bool isParse = Enum.TryParse(logLeveStr, true, out LogLevel logLevel);

                        if (!isParse)
                        {
                            Console.WriteLine("[Error] --logLevel value error.");
                            return 255;
                        }

                        logFilter = (level) => level >= logLevel;
                    }
                    else
                    {
                        logFilter = LogExtension.defaultLogFilter;
                    }

                    this.Services.AddLogging(i =>
                    {
                        i.AddConsole();
                        i.AddFilter(logFilter);
                    });

                    #endregion 1. 各种注册

                    #region 2.执行job

                    this.Services.ConfigureDynamicProxy(i =>
                     {
                         i.ThrowAspectException = false;
                     });
                    var provider = this.Services.BuildDynamicProxyProvider();
                    var job = provider.GetRequiredService<JobBase>();
                    job.Execute();//等待任务执行完毕

                    #endregion 2.执行job

                    return 0;
                });

                #endregion 2. 配置处理流程
            });
        }

        /// <summary>
        /// 调用job实现中的方法注册服务
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="jobType"></param>
        /// <param name="methodName">方法名</param>
        private void RegistratServices(
            string jobName,
            Type jobType,
            string methodName = JobFrameDefaultVariable.RegistrationMethodName)
        {
            try
            {
                var method = jobType.GetMethod(methodName, BindingFlags.Static | BindingFlags.Public);
                method?.Invoke(null, new object[] { this.Services, this.ConfigBuilder });
            }
            catch
            {
                Console.WriteLine($"[Warning] No Found ConfigServices static method for {jobName}.");
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="systemName">取配置失败时，报错用的</param>
        /// <param name="configName"></param>
        /// <param name="envValue"></param>
        /// <param name="totalServiceCount"></param>
        /// <param name="sequenceNumber"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public JobConfig GetJobConfig(
          string jobName,
          string systemName,
          string configName,
          string envValue,
          int totalServiceCount,
          int sequenceNumber,
          IConfigurationRoot configuration)
        {
            JobConfig jobConfig = new JobConfig();
            jobConfig.TotalService = totalServiceCount;
            jobConfig.SequenceNumber = sequenceNumber;

            if (configuration[configName] == null)
            {
                Console.WriteLine($"[Error] No Found config {this.configName} in {systemName} for Job.");
            }
            else
            {
                /*
                 *  dict
                 * key: job名
                 * value-Key:配置名
                 * value-Value:配置值
                 */
                var dict = configuration
                    .GetFromJson<Dictionary<string, Dictionary<string, object>>>(configName);
                var jobConfigDic = dict.GetOrDefault(jobName);

                jobConfig.Config = jobConfigDic ?? new Dictionary<string, object>();
                if (jobConfigDic.IsNotNullOrEmpty())
                {
                    SetBaseConfig(jobConfig, jobConfigDic);
                }
            }

            return jobConfig;
        }

        private static void SetBaseConfig(JobConfig jobConfig, Dictionary<string, object> jobConfigDic)
        {
            jobConfig.ProcessCount = jobConfigDic
                .GetOrDefault(nameof(JobConfig.ProcessCount))
                .ToInt32OrDefault(JobConfig.DefaultProcessCount);

            jobConfig.BlockSellerList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.BlockSellerList), string.Empty)
                .SplitToArray();

            jobConfig.SpecialSellerList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.SpecialSellerList), string.Empty)
                .SplitToArray();

            jobConfig.BlockUserList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.BlockUserList), string.Empty)
                .SplitToArray();

            jobConfig.SpecialUserList = jobConfigDic
                .GetOrDefault(nameof(JobConfig.SpecialUserList), string.Empty)
                .SplitToArray();
        }
    }
}