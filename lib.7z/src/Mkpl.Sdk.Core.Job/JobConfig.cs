﻿using System.Collections.Generic;
using System.Xml.Linq;

namespace Mkpl.Sdk.Core.Job
{
    /// <summary>
    /// Job的配置
    /// </summary>
    public class JobConfig
    {
        public const int DefaultTotalService = 1;
        public const int DefaultSequenceNumber = 1;
        public const int DefaultProcessCount = 2000;

        /// <summary>
        /// 总实例数, 默认值为1。来源是命令行中的 --total
        /// </summary>
        public int TotalService { get; set; } = JobConfig.DefaultTotalService;

        /// <summary>
        /// 当前的实例号,默认值为0，来源是命令行中的 --sequence
        /// <para>配置时请从1开始</para>
        /// </summary>
        public int SequenceNumber { get; set; } = JobConfig.DefaultSequenceNumber;

        /// <summary>
        /// Job处理的最大数据量, 2000。来源是Config Service上面的Job配置
        /// </summary>
        public int ProcessCount { get; set; } = JobConfig.DefaultProcessCount;

        /// <summary>
        /// 取至配置中的BlockSellerList.以','或';'分割
        /// </summary>
        public string[] BlockSellerList { get; set; } = new string[0];

        /// <summary>
        /// <see cref="BlockSellerList"/>的XML版本。
        /// </summary>
        /// <example>
        /// <![CDATA[
        /// <BlockSellerList>
        ///     <BlockSeller>XXXX</BlockSeller>
        /// </BlockSellerList>
        /// ]]>
        /// </example>
        public string BlockSellerListXML
        {
            get
            {
                return this.CreateXml(
                    this.BlockSellerList,
                    "BlockSellerList",
                    "BlockSeller")
                    .ToString();
            }
        }

        /// <summary>
        /// 取至配置中的SpecialSellerList.以','或';'分割
        /// </summary>
        public string[] SpecialSellerList { get; set; } = new string[0];

        /// <summary>
        /// <see cref="SpecialSellerList"/>的XML版本。
        /// </summary>
        /// <example>
        /// <![CDATA[
        /// <SpecialSellerList>
        ///     <SpecialSeller>XXXX</SpecialSeller>
        /// </SpecialSellerList>
        /// ]]>
        /// </example>
        public string SpecialSellerListXML
        {
            get
            {
                return this.CreateXml(
                    this.SpecialSellerList,
                    "SpecialSellerList",
                    "SpecialSeller")
                    .ToString();
            }
        }

        /// <summary>
        /// BlockUserList.以','或';'分割
        /// </summary>
        public string[] BlockUserList { get; set; } = new string[0];

        /// <summary>
        /// <see cref="BlockUserList"/>的XML版本。
        /// </summary>
        /// <example>
        /// <![CDATA[
        /// <BlockUserList>
        ///     <BlockUser>XXXX</BlockUser>
        /// </BlockUserList>
        /// ]]>
        /// </example>
        public string BlockUserListXML
        {
            get
            {
                return this.CreateXml(
                    this.BlockUserList,
                    "BlockUserList",
                    "BlockUser")
                    .ToString();
            }
        }

        /// <summary>
        /// 取至配置中的SpecialUserList.以','或';'分割
        /// </summary>
        public string[] SpecialUserList { get; set; } = new string[0];

        /// <summary>
        /// <see cref="SpecialUserList"/>的XML版本。
        /// </summary>
        /// <example>
        /// <![CDATA[
        /// <SpecialUserList>
        ///     <SpecialUser>XXXX</SpecialUser>
        /// </SpecialUserList>
        /// ]]>
        /// </example>
        public string SpecialUserListXML
        {
            get
            {
                return this.CreateXml(
                    this.SpecialUserList,
                    "SpecialUserList",
                    "SpecialUser")
                    .ToString();
            }
        }

        /// <summary>
        /// 配置集合,包括job下面的所有配置
        /// </summary>
        public Dictionary<string, object> Config { get; set; } = new Dictionary<string, object>();

        /// <summary>
        /// 生成XML字符串
        /// </summary>
        /// <param name="data"></param>
        /// <param name="rootName"></param>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        private XElement CreateXml(IEnumerable<string> data, string rootName, string nodeName)
        {
            XElement root = new XElement(rootName);
            foreach (var item in data)
            {
                root.Add(new XElement(nodeName, item.Trim().ToUpper()));
            }

            return root;
        }
    }
}