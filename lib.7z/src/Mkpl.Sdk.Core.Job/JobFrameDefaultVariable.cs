﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Job
{
    /// <summary>
    /// 用在<see cref="JobBootstrapper"/>中一些默认变量的值，包括一些用来提示的字符串
    /// </summary>
   public static class JobFrameDefaultVariable
    {
        /// <summary>
        /// 默认的环境名
        /// </summary>
        public const string DefaultEnvName = "gdev";

        /// <summary>
        /// job配置的系统名
        /// </summary>
        public const string SystemName = "MKPL_Backend_Task";

        /// <summary>
        /// 公共配置的系统名
        /// </summary>
        public const string CommonSystemName = "MKPL_Common";

        /// <summary>
        /// 自动化测试时，连接config service添加的后缀
        /// </summary>
        public const string At_SuffixForConfigService = "_AutoTest";

        /// <summary>
        /// 检查DB是否维护的sql命令名 特殊情况下才会通过命令改变
        /// </summary>
        public const string CheckDbMaintainCommandName = "MaintainDBCheck";

        /// <summary>
        /// Job中 用来注册服务的方法名
        /// </summary>
        public const string RegistrationMethodName = "ConfigServices";
    }
}
