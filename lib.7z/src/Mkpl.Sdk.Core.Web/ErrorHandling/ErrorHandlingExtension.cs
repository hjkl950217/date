﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ErrorHandlingExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ErrorHandlingExtension created at  4/27/2018 2:19:15 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.AspNetCore.Builder;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// add mps exception Middleware
    /// </summary>
    public static class ErrorHandlingExtension
    {
        /// <summary>
        /// 注册MPS错误处理中间件
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseSimpleExceptionHandlerMPS(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ErrorHandlingMiddleware>();
        }
    }
}