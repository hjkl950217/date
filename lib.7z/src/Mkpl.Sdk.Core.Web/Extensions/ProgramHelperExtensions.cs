﻿using Mkpl.Sdk.Core.Helpers;
using System.Collections.Generic;

namespace Microsoft.AspNetCore.Hosting
{
    public static class ProgramHelperExtensions
    {
        /// <summary>
        /// 请在ProgramHelper后面运行此方法以启动web应用
        /// </summary>
        /// <typeparam name="TStartup">项目中的Startup类</typeparam>
        /// <param name="programHelper">初始化过的ProgramHelper</param>
        public static void MpsRun<TStartup>(this ProgramHelper<TStartup> programHelper)
            where TStartup : class
        {
            IWebHost webHost = programHelper
                .BuildWebHost()
                .Build();

            //如果是UT，将不调用.Run()
            if (!programHelper.CommandList.ContainsValueExt("UT", "true"))
            {
                webHost.Run();
            }

            //现在没有使用AriesDocTool了  所以先把这个代码注释掉
#pragma warning disable S125 // Sections of code should not be "commented out"
            //Action action = () =>
            //{
            //    programHelper
            //    .BuildWebHost()
            //    .Build()
            //    .Run(programHelper.Args);
            //};

            //AriesDocTool.Run(
            //  typeof(TStartup),
            //  programHelper.Args,
            //  action);

#pragma warning restore S125 // Sections of code should not be "commented out"
        }
    }
}