﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SwaggerMPSMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SwaggerMPSMiddleware created at  2018-04-10 星期二 08:54:57
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.DependencyInjection;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// MPS组-配置Api版本控制服务
    /// </summary>
    public static class ApiMpsExtension
    {
        /// <summary>
        /// 注册与配置API版本控制服务
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <remarks>
        /// 主要是用来配置
        /// </remarks>
        public static void AddApiVersionMPS(this IServiceCollection services)
        {
            //增加API版本控制
            services.AddApiVersioning(opt =>
            {
                //返回时，头部显示API版本
                opt.ReportApiVersions = true;
                //版本不明确时使用默认版本
                opt.AssumeDefaultVersionWhenUnspecified = true;

                /*
                 * //指定默认版本用
                 * opt.DefaultApiVersion = new ApiVersion( 1 , 0 )
                 */

                //路由规则中的版本参数名
                //string[] parameterNames = new string[] { "version" }; //
                opt.ApiVersionReader = new QueryStringApiVersionReader("version");
            });
        }
    }
}