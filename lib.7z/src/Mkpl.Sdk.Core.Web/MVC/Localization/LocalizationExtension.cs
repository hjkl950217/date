﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Mkpl.Sdk.Core
{
    public static class LocalizationExtension
    {
        /// <summary>
        /// 注册MPS组本地化服务
        /// </summary>
        /// <param name="services"></param>
        /// <param name="setLanageCodeAction">要附加的语言代码</param>
        /// <param name="defaultLanage">默认语言代码</param>
        /// <remarks>默认:en-US、zh-CN、zh-TW</remarks>
        /// <returns></returns>
        public static IServiceCollection AddLocalizationMPS(this IServiceCollection services,
            Action<string[]> setLanageCodeAction = null,
            string defaultLanage = "en-US")
        {
            //1.准备工作

            //配置要支持的语言代码集合
            string[] languageCodes = new string[]
            {
                "en-US",
                "zh-CN","zh-TW"
            };
            setLanageCodeAction?.Invoke(languageCodes);//调用委托再次设置支持的集合

            /*
             * 文化信息确定的顺序：
             * 0.自定义的
             * 1.QueryStringRequestCultureProvider
             * 2.CookieRequestCultureProvider
             * 3.AcceptLanguageHeaderRequestCultureProvider
             * 
             */

            // 2. 配置
            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.SetDefaultCulture(defaultLanage);
                options.AddSupportedCultures(languageCodes);
                options.AddSupportedUICultures(languageCodes);

                options.RequestCultureProviders.Insert(0, new MpsHeaderRequestCultureProvider(languageCodes));
            });

            services.AddLocalization();
            return services;
        }

        /// <summary>
        /// 启用MPS组本地化中间件
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UesLocalizationMPS(this IApplicationBuilder app)
        {
            app.UseRequestLocalization();

            return app;
        }
    }
}