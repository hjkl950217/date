﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Primitives;
using System.Linq;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// MPS自定义头文化信息的提供者
    /// </summary>
    /// <remarks>
    /// 目前只认一个值，没有权重、多个文化值一类的区别。
    /// </remarks>
    public class MpsHeaderRequestCultureProvider : RequestCultureProvider
    {
        /// <summary>
        /// 支持的语言代码
        /// </summary>
        private readonly string[] languageCode;

        public MpsHeaderRequestCultureProvider(string[] languageCodes)
        {
            this.languageCode = languageCodes;
        }

        /// <summary>
        /// 确定提供者文化结果
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public override Task<ProviderCultureResult> DetermineProviderCultureResult(HttpContext httpContext)
        {
            StringValues mpsLanguage = httpContext.Request.Headers["MPS-Language"];

            if (this.languageCode.Any(t => t == mpsLanguage))
            {
                var providerResultCulture = new ProviderCultureResult(mpsLanguage.ToString(), mpsLanguage.ToString());
                return Task.FromResult(providerResultCulture);
            }
            else
            {
                return RequestCultureProvider.NullProviderCultureResult;
            }
        }
    }
}