﻿using Mkpl.Sdk.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Middleware.CorsMiddleware
{
    /// <summary>
    /// 为跨域中间件准备的**脚本**代码
    /// <para>跨域配置是静态代码，内部方法是静态的。为方便测试才独立出来</para>
    /// </summary>
    public class CorsScriptMethod
    {
        /// <summary>
        /// 构建允许的跨域集合
        /// <para>最后的白名单：默认允许+项目中配置的+其它来源 的交集</para>
        /// </summary>
        /// <param name="originConfigAction">配置来源的委托</param>
        /// <param name="otherAllowOrigin">要添加的允许列表集合</param>
        /// <returns></returns>
        public string[] BuildAllowOriginList(
            Action<List<string>> originConfigAction = null,
            params string[] otherAllowOrigin)
        {
            // [1]默认允许集合
            List<string> originList = new List<string>()
            {
                "newegg.org",
                "newegg.com",
                "newegg.cn",
                "localhost"
            };
            // [2]项目中配置的
            originConfigAction?.Invoke(originList);//不为空则用委托附加

            // [3]其它来源
            if (otherAllowOrigin != null)
            {
                originList.AddRange(otherAllowOrigin);
            }

            // [4] 去重
            string[] result = originList.Distinct().ToArray();

            // [5]返回
            return result;
        }

        /// <summary>
        /// 环境变量中允许的跨域，变量名
        /// </summary>
        public const string CorsOriginFromEnv = "CorsOriginFromEnv";

        /// <summary>
        /// 从环境变量中获取允许的跨域配置
        /// <para>变量名：<see cref="CorsScriptMethod.CorsOriginFromEnv"/> 以'|'分割</para>
        /// </summary>
        /// <returns></returns>
        public string[] GetAllowOriginFromEnv()
        {
            string corsStr = EnvHelper.GetVariableFromEnv(CorsScriptMethod.CorsOriginFromEnv);

            return corsStr.Split(new char[] { '|' })
                    .Select(t => t?.Trim())
                    .Where(t => t.Any())
                    .ToArray();
        }
    }
}