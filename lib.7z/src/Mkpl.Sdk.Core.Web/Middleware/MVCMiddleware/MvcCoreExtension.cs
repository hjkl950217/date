﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MvcCoreMPSMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MvcCoreMPSMiddleware created at  2018-04-10 星期二 09:54:07
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;
using System.Reflection;

namespace Mkpl.Sdk.Core
{
    public static class MvcCoreMpsExtension
    {
        /// <summary>
        /// 注册路由、MVC和对应的服务配置
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setup">Setup类实例，一般在Setup类中使用传this即可</param>
        /// <param name="mvcCoreBuilderAction">自定义设置<see cref="IMvcCoreBuilder"/>，用于某些情况下可追加新的配置</param>
        /// <param name="mvcOptionAction">自定义设置<see cref="MvcOptions"/>，用于某些情况下可追加新的配置</param>
        public static IMvcCoreBuilder AddMvcCoreMPS(
            this IServiceCollection services,
            object setup,
            Action<IMvcCoreBuilder> mvcCoreBuilderAction = null,
            Action<MvcOptions> mvcOptionAction = null)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            //配置路由匹配忽略大小写
            services.AddRouting(options =>
            {
                options.LowercaseUrls = true;
            });

            #region 配置MvcCore

            //PS：#endregion的附近有';'来结束mvc的配置
            var mvcCore = services.AddMvcCore(opt =>
            {
                //添加绑定模型时的验证
                opt.Filters.Add<MpsValidationFilter>();

                mvcOptionAction?.Invoke(opt);//追加自定义的配置
            });

            //添加APIExplorer
            mvcCore.AddApiExplorer();

            //配置Json序列化
            mvcCore.AddJsonOptions(options =>
             {
                 //将解析器设置为Newtonsoft.Json
                 //options.SerializerSettings.ContractResolver = new DefaultContractResolver();//默认为大驼峰
                 options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();//小驼峰

                 //忽略空值
                 //options.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;

                 //设置Newtonsoft.Json.JsonSerializer的引用循环处理选项。
                 options.SerializerSettings.ReferenceLoopHandling = JsonSerializerSettingConst.DefaultSetting.ReferenceLoopHandling;

                 //设置缩进
                 options.SerializerSettings.Formatting = JsonSerializerSettingConst.DefaultSetting.Formatting;

                 //使用Newtonsoft.Json里的enum转换器
                 foreach (var item in JsonSerializerSettingConst.DefaultSetting.Converters)
                 {
                     if (item is IsoDateTimeConverter) continue;//先临时屏蔽，使用.net core框架自带的

                     options.SerializerSettings.Converters.Add(item);
                 }
             });
            mvcCore.AddJsonFormatters();

            //添加CORS服务
            mvcCore.AddCors();

            //添加请求参数验证器-注册webapi程序集的所有验证规则
            mvcCore.AddFluentValidation(fv =>
            {
                //这里setup实例对应的程序集才是webapi那个程序集
                //所以这样取才能取到最正确的
                fv.RegisterValidatorsFromAssembly(Assembly.GetAssembly(setup.GetType()));

                //兼容ASP.NET的内置验证
                // fv.RunDefaultMvcValidationAfterFluentValidationExecutes = true;
            });

            // mvcCore.AddFormatterMappings()

            #endregion 配置MvcCore

            //配置HTTP上下文访问器
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            //追加自定义配置
            mvcCoreBuilderAction?.Invoke(mvcCore);

            return mvcCore;
        }

        /// <summary>
        /// [过时]注册路由、MVC和对应的服务配置
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setup">Setup类实例，一般在Setup类中使用传this即可</param>
        /// <param name="globalRoutePrefix">全局路由前缀，按新的要求，应该配置为:"mkpl/{j/n}"</param>
        /// <param name="mvcOptionAction">自定义设置<see cref="IMvcCoreBuilder"/>，用于某些情况下可追加新的配置</param>
        /// <remarks>
        /// 此方法使用早期的代码来配置全局路由前缀,2.1中已经发现换失效。请使用<see cref="AddMvcCoreMPS(IServiceCollection, object, Action{IMvcCoreBuilder}, Action{MvcOptions})"/>方法。<para></para>
        ///
        /// 配置路由前缀请在http配置处调用<see cref="UsePathBaseExtensions.UsePathBase(IApplicationBuilder, PathString)"/>方法
        /// </remarks>
        [Obsolete("参考说明使用新方法")]
        public static IMvcCoreBuilder AddMvcCoreMPS(
            this IServiceCollection services,
            object setup,
            string globalRoutePrefix = null,
            Action<IMvcCoreBuilder> mvcOptionAction = null)
        {
            return services.AddMvcCoreMPS(
                setup,
                mvcCoreBuilderAction:
                mvcOptionAction, mvcOptionAction: opt => opt.UseCentralRoutePrefix(globalRoutePrefix));
        }
    }
}