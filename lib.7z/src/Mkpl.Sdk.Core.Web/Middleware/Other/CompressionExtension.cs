﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.DependencyInjection;
using System.IO.Compression;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 压缩中间件的扩展
    /// </summary>
    public static class CompressionExtension
    {
        /// <summary>
        /// 添加压缩服务
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddResponseCompressionMPS(this IServiceCollection services)
        {
            //显示添加压缩服务
            services.AddResponseCompression(options =>
            {
                options.Providers.Add<GzipCompressionProvider>();

                //自定义压缩提供程序时的
                //options.Providers.Add<CustomCompressionProvider>();
                //options.MimeTypes =
                //    ResponseCompressionDefaults.MimeTypes.Concat(
                //        new[] { "image/svg+xml" });
            });

            //配置对应压缩服务
            services.Configure<GzipCompressionProviderOptions>(options =>
            {
                options.Level = CompressionLevel.Fastest;
            });

            return services;
        }

        /// <summary>
        /// 启用压缩服务
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseResponseCompressionMPS(this IApplicationBuilder app)
        {
            app.UseResponseCompression();

            return app;
        }
    }
}