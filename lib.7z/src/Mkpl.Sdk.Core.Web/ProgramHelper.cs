﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using Mkpl.Sdk.Core.DB;
using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Newegg.MIS.Baymax.AOP;
using Newegg.MIS.EggKeeper.Sdk;
using System.IO;

namespace Mkpl.Sdk.Core.Helpers
{
    /*
     * 本来不应该存在 “Mkpl.Sdk.Core.Helpers”这样的命名空间
     * 但是发现的时候已经有了，这个类又用的地方又多，所以这个类暂时保留在此命名空间下
     *
     */

    /// <summary>
    /// MPS组web应用启动帮助类
    /// </summary>
    /// <typeparam name="TStartup">项目中的Startup类</typeparam>
    public class ProgramHelper<TStartup>
        where TStartup : class
    {
        #region 属性

        public EnvironmentInfo EnvironmentInfo { get; protected set; }

        public string[] Args { get; protected set; }

        #endregion 属性

        /// <summary>
        /// <![CDATA[初始化一个Mkpl.Sdk.Core.Helpers.ProgramHelper<TStartup>实例]]>
        /// </summary>
        /// <param name="domainName">领域名，如Seller就传递Seller，推荐用公共库的常量</param>
        /// <param name="args">自定义参数</param>
        /// <remarks>
        /// Microsoft.AspNetCore.WebHost类的
        /// <para>public static IWebHostBuilder CreateDefaultBuilder(string[] args)的描述</para>
        /// </remarks>
        public ProgramHelper(string domainName, string[] args)
        {
            //环境变量
            var source = new EnvironmentVariableSource();
            EnvironmentInfo = EnvironmentInfo.Gobal;
            EnvironmentInfo.Init(source,
                new RunEnvHandler(EnvironmentNames.AspnetCoreEnvironment),
                new MapHandler(EnvironmentNames.AspnetCoreUrls),
                new MapHandler(EnvironmentNames.DbDirectory, defaultValue: Path.Combine(Directory.GetCurrentDirectory(), "DBConfigs")),
                new ConfigServiceDbKeyHandler(),
                new ClusterLocationHandler(),
                new EggkeeperClusterLocationHandler(),
                new RedisClusterLocationHandler(),
                new AutoTestHandler(),
                new DomainNameHandler(value: domainName),
                new IsUTHandler(),
                new GensisHandler());
        }

        #region 各种配置方法

        /// <summary>
        /// 初始化eggkeeper和SQL连接配置
        /// </summary>
        /// <param name="builder"></param>
        protected virtual void InitConfig(IConfigurationBuilder builder)
        {
            var env = EnvironmentInfo.GetRunEnv();
            var eggkeeperClusterLocation = EnvironmentInfo.GetEggkeeperClusterLocation();
            var domainName = EnvironmentInfo.GetDomainName();
            //添加ConfigService上的配置
            builder.AddEnvironmentVariables()
                .UseEggKeeper(env, "NeweggTracingConfig", true, eggkeeperClusterLocation)
                .UseEggKeeper(env, "MKPL_Common", true, eggkeeperClusterLocation)
                .UseEggKeeper(env, $"MKPL_{domainName}", true, eggkeeperClusterLocation);
            SetAutoTest(builder, env, eggkeeperClusterLocation, domainName);
        }

        private void SetAutoTest(IConfigurationBuilder builder, string env, string eggkeeperClusterLocation, string domainName)
        {
            if (EnvironmentInfo.IsAutoTest())
            {
                /*
                 * 获取AT的代码必须要在后面，不能写在上面3个配置的上面
                 * 因为: .net core的配置系统有多个配置源，会从后向前读取。
                 * 当开启at之后，配置会先取到'AutoTest'里面的。
                 */
                string commSysName = "MKPL_Common_AutoTest";
                string serSysName = $"MKPL_{domainName}_AutoTest";

                void useConfig(string sysName)
                {
                    bool isExists = EggKeeperFactory.Instance.GetEggKeeper().Exists($"/{sysName}");
                    if (isExists)
                    {
                        builder.UseEggKeeper(env, sysName, true, eggkeeperClusterLocation);
                    }
                }

                useConfig(commSysName);
                useConfig(serSysName);
            }
        }

        /// <summary>
        /// 添加SQL语句文件
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        protected virtual void InitDB(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDb(configuration, EnvironmentInfo.GetDbDirectory(), EnvironmentInfo.GetConfigServiceDbKey(),
                EnvironmentInfo.GetClusterLocation(), $"MKPL_{EnvironmentInfo.GetDomainName()}_Csharp");
        }

        #endregion 各种配置方法

        #region 创建IWebHost

        /// <summary>
        /// 创建MPS组微服务对应的IWebHost
        /// </summary>
        /// <returns></returns>
        public IHostBuilder BuildWebHost(string[] args)
        {
            /* new WebHostBuilder() */
            return Host.CreateDefaultBuilder(args)
               .ConfigureAop()
               .ConfigureWebHostDefaults(webBuilder =>
               {
                   webBuilder.UseStartup<TStartup>()
                       .UseKestrel(options => options.AddServerHeader = false)
                       .UseUrls(EnvironmentInfo.GetListenUrl())
                       .ConfigureServices((host, services) =>
                       {
                           services.AddSingleton(EnvironmentInfo);
                           this.InitDB(services, host.Configuration);
                       })
                       .ConfigureLogging(i => i.AddFilter("Microsoft.Hosting.Lifetime", LogLevel.Information)
                                            .AddFilter("Microsoft", LogLevel.Warning));
               })
               .UseContentRoot(Directory.GetCurrentDirectory())
               .ConfigureAppConfiguration(config => this.InitConfig(config));
        }

        #endregion 创建IWebHost

        /// <summary>
        /// 请在ProgramHelper后面运行此方法以启动web应用
        /// </summary>
        public void MpsRun()
        {
            var webHost = this
                .BuildWebHost(Args)
                .Build();

            //如果是UT，将不调用.Run()
            if (!EnvironmentInfo.IsUT())
            {
                webHost.Run();
            }
        }
    }
}