﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Mkpl.Sdk.Core.Web.Routes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class ExternalRouteAttribute : RouteAttribute
    {
        public const string ExternalRouteBase = "external/mkpl/n/";

        public ExternalRouteAttribute(string template) : base(ExternalRouteBase + template)
        {
        }
    }
}