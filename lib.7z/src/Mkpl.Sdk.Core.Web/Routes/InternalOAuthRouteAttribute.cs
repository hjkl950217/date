﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Web.Routes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class InternalOAuthRouteAttribute : RouteAttribute
    {
        public const string InternalOAuthRouteBase = "o/mkpl/n/";

        public InternalOAuthRouteAttribute(string template) : base(InternalOAuthRouteBase + template)
        {
        }
    }
}
