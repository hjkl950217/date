﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Mkpl.Sdk.Core.Web.Routes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class InternalRouteAttribute : RouteAttribute
    {
        public const string InternalRouteBase = "mkpl/n/";

        public InternalRouteAttribute(string template) : base(InternalRouteBase + template)
        {
        }
    }
}