﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SwaggerMPSMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SwaggerMPSMiddleware created at  2018-04-10 星期二 08:54:57
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.OpenApi.Models;
using Mkpl.Sdk.Core.Env;

namespace Mkpl.Sdk.Core
{
    public static class SwaggerMpsExtension
    {
        /// <summary>
        /// 注册Swagger和Swagger服务配置
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setConfigAction">设置Swagger配置</param>
        /// <remarks>
        /// 主要是用来配置
        /// <para>注意：需要配置的环境与注释文件同时满足才可以开启</para>
        /// </remarks>
        public static void AddSwaggerMPS(
            this IServiceCollection services,
            Action<SwaggerMpsOption> setConfigAction = null)
        {
            #region 是否开启判断和初始化数据

            //初始化配置
            SwaggerMpsOption config = InitConfig();//获取一个初始化过的配置
            if (setConfigAction == null) setConfigAction = t => { };
            setConfigAction(config);//用传入的委托把config 初始化
            services.AddTransient<SwaggerMpsOption>(t => { return config; });

            //文件和环境判断，不存在则不开启
            if (IsEndibleSwagger(config) == false) return;
            services.AddTransient(t => { return config; });//把配置放入服务集合中

            #endregion 是否开启判断和初始化数据

            services.AddSwaggerGen(options =>
            {
                options.DescribeAllEnumsAsStrings();//在描述枚举类型时使用枚举名称，而不是它们的整数值
                                                    // options.DescribeAllParametersInCamelCase();//让请求中的参数以驼峰命名出现
                                                    // options.DescribeStringEnumsInCamelCase();//让枚举类型使用驼峰命名

                //默认是以控制器名分组，暂时关闭这个
                //options.TagActionsBy(api => api.RelativePath);//API分组显示

                //按配置生成swagger文档
                foreach (var item in config.ConfigList)
                {
                    /*
                     *  第一个参数：路由json文件时要用
                     *  第二个参数：页面上显示的数据。而API中配置的版本参数也需要后这里对应上
                     */

                    options.SwaggerDoc(item.Title, item);
                }

                //options.SwaggerDoc("v2", new Info
                //{
                //    Title = "MyApiDocV2",
                //    Version = "v2",
                //    Description = "第二版API",
                //    TermsOfService = "服务条款：巴拉巴拉巴拉...",
                //    Contact = new Contact() { Name = "lynn", Email = "lnn@newegg.com", Url = "http://none.com" }
                //});

                //用生成的XML注释文档增强SwaggerUI
                string basePath = AppContext.BaseDirectory;
                //string basePath = PlatformServices.Default.Application.ApplicationBasePath;
                foreach (var item in config.XmlFileNameList)
                {
                    string apiPath = Path.Combine(basePath, item);
                    options.IncludeXmlComments(apiPath);
                }

                //是否忽略没有标记HTTP动词的方法
                //options.DocInclusionPredicate( ( docName , apiDesc ) =>
                //{
                //    if( apiDesc.HttpMethod == null ) return false;
                //    return true;
                //} );
            });
        }

        /// <summary>
        /// 配置Swagger请求
        /// </summary>
        /// <param name="app"></param>
        /// <param name="routePrefix">
        /// 需要指定的路由前缀，默认为apidoc，指定后的访问格式为{routPrefix}/apidoc/
        /// </param>
        /// <remarks>
        /// <para>注意：需要配置的环境与注释文件同时满足才可以开启</para>
        /// 从GLOBAL_ROUTE_PREFIX环境变量或routPrefix参数中都取不到时默认路由前缀为api
        /// <para>优先级：</para>
        /// <para>1.routPrefix参数，访问格式为{routPrefix}/apidoc/</para>
        /// <para>2.GLOBAL_ROUTE_PREFIX环境变量，访问格式为{变量值}/apidoc/</para>
        /// <para>3.默认前缀api，访问格式为 {host}/apidoc</para>
        /// </remarks>
        /// <returns></returns>
        public static IApplicationBuilder UseSwaggerMPS(
            this IApplicationBuilder app,
            string routePrefix = null)
        {
            #region 是否开启判断和初始化数据

            //获取配置
            SwaggerMpsOption config = app.ApplicationServices.GetService<SwaggerMpsOption>();

            //文件和环境判断，不存在则不开启
            if (IsEndibleSwagger(config) == false) return app;

            #endregion 是否开启判断和初始化数据

            #region 处理Swagger访问前缀

            /*
             * 这一步生成的routeStr
             * 是直接在页面中输入{host}/{routeStr}访问Swagger用的
             *
             * GLOBAL_ROUTE_PREFIX是以前DAE1.0的路由前缀，新版不需要
             *
             */

            routePrefix = routePrefix ?? Environment.GetEnvironmentVariable("GLOBAL_ROUTE_PREFIX");
            string routeStr = routePrefix.IsNullOrEmpty() == true
                ? "apidoc"
                : $"{routePrefix?.Trim().ToLower()}/apidoc";

            Console.WriteLine($"Swagger RoutePrefix：-{routeStr}-");

            #endregion 处理Swagger访问前缀

            #region json文件生成

            string jsonPrefix = string.Empty;

            /*
             * json文件前缀的处理
             *
             * 当项目部署在创世纪时，在主机地址前需要添加项目ID
             * 这个前缀是生成的html js中访问数据时，使用的json地址
             *
             * 资源文件的生成不需要处理这个前缀
             * 但json的访问路径是生成在swagger的html js文件中的，所以要处理
             *
             *
             */

            //动态添加创世纪分配的项目ID
            //当项目部署在创世纪时，在主机地址前需要添加项目ID
            string projectId = EnvironmentInfo.Gobal.GetGenesisProjectId();//获取创世纪中的项目ID
            if (!string.IsNullOrWhiteSpace(projectId)) jsonPrefix = $"{projectId}/{routeStr}";
            else jsonPrefix = routeStr;

            // 生成JSON文件的模版，生成json文件时的一些配置
            app.UseSwagger(c =>
            {
                //[swagger]这里的{documentName}就是注册服务时  SwaggerDoc方法的第一个参数
                c.RouteTemplate = routeStr + "/{documentName}/swagger.json";

                //处理swagger中发请求时的前缀
                /*
                 * swagger中请求时，curl中使用的地址，是从swagger.json文件中获取的
                 * 这里的处理就是当有项目ID时，让生成的json文件中带上这个ID
                 */
                if (!string.IsNullOrWhiteSpace(projectId))
                {
                    c.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        swaggerDoc.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"/{projectId}" } };
                    });
                }
            });

            //允许中间件使用swagger-ui（HTML，JS，CSS等），指定SwaggerUI所需要的JSON文件路径。
            //地址不能与控制器的路由重复
            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = routeStr;//swagger首页地址，写1就是{host}/1
                foreach (var item in config.ConfigList)
                {
                    //第二个参数 是右上角下拉框里面的数据
                    c.SwaggerEndpoint($"/{jsonPrefix}/{item.Title}/swagger.json", item.Title);
                }
            });

            #endregion json文件生成

            return app;
        }

        /// <summary>
        /// 是否开启Swagger，需要环境或文件都要同时满足
        /// </summary>
        /// <param name="mpsOption">需要判断的文件名，不是完全限定名</param>
        /// <returns></returns>
        private static bool IsEndibleSwagger(SwaggerMpsOption mpsOption)
        {
            //判断环境
            bool isEnv = EnvironmentInfo.Gobal.IsGdev() || EnvironmentInfo.Gobal.IsGqc();

            //判断文件
            bool existsList = mpsOption.XmlFileNameList
                .Select(t =>
                {
                    string basePath = AppDomain.CurrentDomain.BaseDirectory;//获取程序的基目录
                    string xmlPath = Path.Combine(basePath, t);//组合成完全限定名
                    return File.Exists(xmlPath);//判断是否存在
                })
                .All(t => t == true);

            return isEnv && existsList;//环境或文件都要同时满足才可以开启
        }

        /// <summary>
        /// 初始化一个SwaggerMPS配置
        /// </summary>
        /// <param name="option">初始化一个配置</param>
        /// <returns></returns>
        private static SwaggerMpsOption InitConfig(SwaggerMpsOption option = null)
        {
            option = option ?? new SwaggerMpsOption();

            //没有传递时初始化一个默认配置
            option.XmlFileNameList = option.XmlFileNameList ?? new List<string>()
            {
                "ApiDoc.xml",
                "ApiFacadeDoc.xml",
                "ApiEntityDoc.xml"
            };

            option.ConfigList = option.ConfigList ?? new List<OpenApiInfo>()
            {
                new OpenApiInfo (){ Title ="Api",Version="v1"}
            };

            return option;
        }
    }
}