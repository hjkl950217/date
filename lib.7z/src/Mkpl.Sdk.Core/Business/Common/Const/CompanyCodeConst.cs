﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CompanyCodeConst.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   CompanyCodeConst created at  7/14/2018 1:20:27 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// The class of CompanyCodeConst.
    /// </summary>
    public static class CompanyCodeConst
    {
        /// <summary>
        /// USA Company Code
        /// </summary>
        public const int CompanyCode_USA = 1003;

        /// <summary>
        /// USB Company Code
        /// </summary>
        public const int CompanyCode_USB = 1200;

        /// <summary>
        /// CAN Company Code
        /// </summary>
        public const int CompanyCode_CAN = 1021;
    }
}