﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 国家代码常量
    /// </summary>
    public static class CountryCodeConst
    {
        /// <summary>
        /// 指的是B2B平台,有些地方在CountryCode处也存的USB或B2B
        /// </summary>
        public const string USB = "USB";

        /// <summary>
        /// 加拿大(Canada)  两位代码:CA
        /// </summary>
        public const string CAN = "CAN";

        /// <summary>
        /// 美国(United States)  两位代码:UM
        /// </summary>
        public const string USA = "USA";

        /// <summary>
        /// (Albania)  两位代码:AL
        /// </summary>
        public const string ALB = "ALB";

        /// <summary>
        /// (Australia)  两位代码:AU
        /// </summary>
        public const string AUS = "AUS";

        /// <summary>
        /// (China)  两位代码:CN
        /// </summary>
        public const string CHN = "CHN";

        /// <summary>
        /// (Denmark)  两位代码:DK
        /// </summary>
        public const string DNK = "DNK";

        /// <summary>
        /// (France)  两位代码:FR
        /// </summary>
        public const string FRA = "FRA";

        /// <summary>
        /// (Hong Kong)  两位代码:HK
        /// </summary>
        public const string HKG = "HKG";

        /// <summary>
        /// (India)  两位代码:IN
        /// </summary>
        public const string IND = "IND";

        /// <summary>
        /// (Israel)  两位代码:IL
        /// </summary>
        public const string ISR = "ISR";

        /// <summary>
        /// (Italy)  两位代码:IT
        /// </summary>
        public const string ITA = "ITA";

        /// <summary>
        /// (Japan)  两位代码:JP
        /// </summary>
        public const string JPN = "JPN";

        /// <summary>
        /// (Korea)  两位代码:KR
        /// </summary>
        public const string KOR = "KOR";

        /// <summary>
        /// (Luxembourg)  两位代码:LU
        /// </summary>
        public const string LUX = "LUX";

        /// <summary>
        /// (Netherlands)  两位代码:NL
        /// </summary>
        public const string NLD = "NLD";

        /// <summary>
        /// (Singapore)  两位代码:SG
        /// </summary>
        public const string SGP = "SGP";

        /// <summary>
        /// (Spain)  两位代码:ES
        /// </summary>
        public const string ESP = "ESP";

        /// <summary>
        /// (Taiwan)  两位代码:TW
        /// </summary>
        public const string TWN = "TWN";

        /// <summary>
        /// (Turkey)  两位代码:TR
        /// </summary>
        public const string TUR = "TUR";

        /// <summary>
        /// (United Kingdom)  两位代码:GB
        /// </summary>
        public const string GBR = "GBR";
    }
}