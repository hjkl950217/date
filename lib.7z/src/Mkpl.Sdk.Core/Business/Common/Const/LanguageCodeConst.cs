﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LanguageCodeConst.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   LanguageCodeConst created at  7/14/2018 1:22:27 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 语言代码.如 zh-cn.小写
    /// </summary>
    public static class LanguageCodeConst
    {
        /// <summary>
        /// 英文
        /// </summary>
        public const string LanguageCode_EN_US = "en-us";

        /// <summary>
        /// 简体中文
        /// </summary>
        public const string LanguageCode_ZH_CN = "zh-cn";

        /// <summary>
        /// 繁体中文
        /// </summary>
        public const string LanguageCode_ZH_TW = "zh-tw";
    }
}