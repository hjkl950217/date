﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PlatformConst.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   PlatformConst created at  4/27/2018 8:44:36 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 平台标记常量（非CountryCode）
    /// </summary>
    /// <remarks>
    /// 有可能值和CountryCode一样，但代表的意义是平台而不是CountryCode
    /// </remarks>
    public static class PlatformConst
    {
        /// <summary>
        /// 指的是USA-B2C平台
        /// </summary>
        /// <remarks>
        /// USA国家的B2C平台，类似中国的淘宝\京东
        /// </remarks>
        public const string Platform_USA = "USA";

        /// <summary>
        /// 指的是USA-B2B平台
        /// </summary>
        /// <remarks>
        /// USA国家的B2B平台，类似中国的阿里巴巴
        /// </remarks>
        public const string Platform_USB = "USB";

        /// <summary>
        /// 加拿大平台
        /// </summary>
        /// <remarks>
        /// CAN国家的B2C平台,类似中国的淘宝\京东。
        /// <para>但此平台的卖家发货也只能发到CAN</para>
        /// </remarks>
        public const string Platform_CAN = "CAN";

        /// <summary>
        /// 中国平台(为以后预留)
        /// </summary>
        public const string Platform_CHN = "CHN";

        /// <summary>
        /// 香港平台(为以后预留)
        /// </summary>
        public const string Platform_HKG = "HKG";

        /// <summary>
        /// 台湾平台(为以后预留)
        /// </summary>
        public const string Platform_TWN = "TWN";

        /// <summary>
        /// 平台代码集合
        /// </summary>
        public static readonly string[] PlatformCodeList = new string[]
        {
            PlatformConst.Platform_USA,
            PlatformConst.Platform_USB,
            PlatformConst.Platform_CAN,
            PlatformConst.Platform_HKG,
            PlatformConst.Platform_TWN,
        };
    }
}