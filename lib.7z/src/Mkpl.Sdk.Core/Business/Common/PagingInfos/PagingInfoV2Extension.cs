﻿using System.Xml.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public static class PagingInfoV2Extension
    {
        /// <summary>
        /// 获取<see cref="PagingInfoV2"/>的XML结构。<para></para>
        /// </summary>
        /// <remarks>
        /// 若需要string格式的，请使用<see cref="ObjectExtension.ToXmlExtV2{T}(T, bool)"/>
        /// </remarks>
        /// <returns></returns>
        public static XElement ToXml(this PagingInfoV2 pagingInfoV2)
        {
            XElement pageElement = new XElement("PageInfo");

            var startRowIndex = new XElement(nameof(PagingInfoV2.StartRowIndex), pagingInfoV2.StartRowIndex);
            var pageSize = new XElement(nameof(PagingInfoV2.PageSize), pagingInfoV2.PageSize);
            var sortField = new XElement(nameof(PagingInfoV2.SortField), pagingInfoV2.SortField);
            var sortType = new XElement(nameof(PagingInfoV2.SortType), pagingInfoV2.SortType.ToString());

            pageElement.Add(startRowIndex);
            pageElement.Add(pageSize);
            pageElement.Add(sortField);
            pageElement.Add(sortType);

            return pageElement;
        }
    }
}