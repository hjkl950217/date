﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core
{
    public static class PlatformCodeHelper
    {
        /// <summary>
        /// 检查集合是否全部是PlatformCode,如果有一个不是则检查失败。<para></para>
        /// 大小写敏感、空格敏感<para></para>
        /// 场景推荐：请求体的验证
        /// </summary>
        /// <param name="platformCodeList"></param>
        /// <returns></returns>
        public static bool CheckPlatformCode(IEnumerable<string> platformCodeList)
        {
            bool result;
            foreach (var item in platformCodeList.Distinct())
            {
                result = PlatformConst.PlatformCodeList.Contains(item);
                if (!result) return false;
            }
            return true;
        }

        /// <summary>
        /// 检查数据是否为PlatformCode,如果不是则检查失败。<para></para>
        /// 大小写敏感、空格敏感<para></para>
        /// 场景推荐：请求体的验证
        /// </summary>
        /// <param name="platformCode"></param>
        /// <returns></returns>
        public static bool CheckPlatformCode(string platformCode)
        {
            return CheckPlatformCode(new string[] { platformCode });
        }
    }
}