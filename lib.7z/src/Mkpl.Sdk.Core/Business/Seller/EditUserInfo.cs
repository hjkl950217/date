﻿using System;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 基础实体--编辑数据的信息。包括编辑人、ID、时间
    /// </summary>
    public abstract class EditInfo
    {
        /// <summary>
        /// 插入数据的UserID<para></para>
        /// 没有特殊要求，则固定存放LoginUser.UserID<para></para>
        /// EDI_Seller_User -> UserID
        /// </summary>
        public int InUserID { get; set; }

        /// <summary>
        /// 插入数据的User<para></para>
        /// 没有特殊要求，则固定存放LoginUser.EmailAddress<para></para>
        /// EDI_Seller_User -> EmailAddress
        /// </summary>
        public string InUser { get; set; }

        /// <summary>
        /// 插入数据的时间<para></para>
        /// 没有特殊要求，则固定存放 数据库的 GetDate()<para></para>
        /// </summary>
        public DateTime InDate { get; set; }

        /// <summary>
        /// 修改数据的UserID<para></para>
        /// 没有特殊要求，则固定存放LoginUser.UserID<para></para>
        /// EDI_Seller_User -> UserID
        /// </summary>
        public int LastEditUserID { get; set; }

        /// <summary>
        /// 修改数据的User<para></para>
        /// 没有特殊要求，则固定存放LoginUser.EmailAddress<para></para>
        /// EDI_Seller_User -> EmailAddress
        /// </summary>
        public string LastEditUser { get; set; }

        /// <summary>
        /// 修改数据的时间<para></para>
        /// 没有特殊要求，则固定存放 数据库的 GetDate()<para></para>
        /// </summary>
        public DateTime LastEditDate { get; set; }
    }
}