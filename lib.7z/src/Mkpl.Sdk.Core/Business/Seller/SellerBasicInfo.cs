﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SellerBasicInfo.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   SellerBasicInfo created at  5/5/2018 3:53:42 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 卖家基础信息
    /// </summary>
    /// <remarks>
    /// 主要从MKTPLS.dbo.EDI_Seller_BasicInfo中查询
    /// </remarks>
    [System.Obsolete("已弃用")]
    public class SellerBasicInfo : SellerIDInfo
    {
        /// <summary>
        /// 卖家类型，国内或国际
        /// </summary>
        public SellerTypeEnum SellerType { get; set; }

        /// <summary>
        /// 卖家支付方式
        /// </summary>
        public SellerPaymentTypeEnum PaymentType { get; set; }

        /// <summary>
        /// 合作伙伴推荐ID-由那一种合作伙伴推荐过来
        /// </summary>
        /// <remarks>
        /// 对应取值：MKTPLS.dbo.EDI_Seller_BasicInfo.ReferredByCode
        /// 和mktpls.dbo.MPS_Seller_ReferredByList中的 ReferredByCode是对应关系。
        /// 在Seller微服务中有专门的接口查询伙伴信息
        /// </remarks>
        public int PartnerID { get; set; }

        public bool IsUIHSeller { get; set; }

        public bool IsSeller { get; set; }

        /// <summary>
        /// 语言代码，如"en-US"
        /// </summary>
        /// <remarks>
        /// 正确格式为"zh-CN"这样前2位小写，后2位大写。但以前没有按规范来，所以这里不强制处理
        /// </remarks>
        public string LanguageCode { get; set; }

        /// <summary>
        /// 账户对应的老板所在的平台代码
        /// </summary>
        public int OwnerCompanyCode { get; set; }

        /// <summary>
        /// 平台代码
        /// </summary>
        public int CompanyCode { get; set; }

        /// <summary>
        /// Seller账户状态
        /// </summary>
        public SellerStatusEnum SellerStatus { get; set; }

        /// <summary>
        /// EC网站上的参数 url上的key。
        /// </summary>
        /// <remarks>
        /// 这个key出现在卖家店铺首页的URL中
        /// </remarks>
        public string SellerUrlKey { get; set; }

        /// <summary>
        /// 测试卖家标记。详情参考备注
        /// </summary>
        /// <remarks>
        /// NonTest--> 0   非测试，真实卖家,数据库中存的是0或null
        /// Internal-->1   内部测试卖家,通常用做GQC测试,数据库中存的是1
        /// Sandbox-->2   沙箱测试卖家,通常用做PRE测试,数据库中存的是2.
        /// </remarks>
        public int TestingTag { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        /// <remarks>
        /// 对应取值：MKTPLS.dbo.EDI_Seller_BasicInfo.InDate<para></para>
        /// 需要名字再调用其它的方法取得国家名字
        /// </remarks>
        public DateTime CreateDate { get; set; }

        /// <summary> 
        /// Seller税收设置类型(VF、ISO、PSP) 
        /// </summary> 
        /// <remarks>
        /// 来自EDI_Seller_BasicInfo表的SellerModel字段
        /// </remarks>
        public string SellerModel { get; set; }

        /// <summary> 
        /// Seller是否开启允许Customer免税(Tax Exemption) 
        /// </summary> 
        /// <remarks>
        /// 来自EDI_Seller_BasicInfo表的EnableCustomerTaxExemption字段
        /// </remarks>
        public bool EnableCustomerTaxExemption { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        /// <remarks>
        /// 取至 EDI_Seller_BasicInfo 表的 PhoneNumber 字段。<para></para>
        /// 因为表中的数据存在字符，所以这里是string类型
        /// </remarks>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// 联系邮箱(非登陆邮箱)
        /// </summary>
        /// <remarks>
        /// 取至 EDI_Seller_BasicInfo 表的 EmailAddress 字段。<para></para>
        /// </remarks>
        public string EmailAddress { get; set; }
    }
}