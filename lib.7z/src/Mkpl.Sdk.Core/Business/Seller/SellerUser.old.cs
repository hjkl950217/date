﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// Seller账户信息
    /// </summary>
    [Obsolete("已弃用此类")]
    public class SellerUser
    {
        /// <summary>
        /// 客户编号，登录后就会有这个
        /// </summary>
        public int CustomerNumber { get; set; }

        /// <summary>
        /// 卖家ID，如BHD6
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// 账户邮件地址(也就是登陆的邮箱)
        /// </summary>
        public string UserEmailAddress { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        /// <remarks>
        /// 认证中间件目前在使用这个属性，为了自动化测试API时，中间件能写入数据
        /// </remarks>
        public int UserID { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 账户状态-是否禁一类的
        /// </summary>
        public UserStatusEnum UserStatus { get; set; }

        /// <summary>
        /// 标识内部卖家还是外部卖家
        /// </summary>
        public UserTypeEnum UserType { get; set; }

        /// <summary>
        /// Seller账户的状态
        /// </summary>
        public SellerStatusEnum SellerStatus { get; set; }

        /// <summary>
        /// 业务平台代码<para></para>
        /// 具体值参考： <see cref="PlatformConst"/>
        /// </summary>
        public string PlatformCode { get; set; }
    }
}