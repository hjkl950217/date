﻿namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 卖家ID信息，非常基本的类型
    /// </summary>
    /// <remarks>
    /// 主要从 MKTPLS.dbo.EDI_Seller_User 中查询
    /// </remarks>
    [System.Obsolete("已弃用")]
    public class UserIDInfo
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 客户编号，登录后就会有这个
        /// </summary>
        public int CustomerNumber { get; set; }

        /// <summary>
        /// 登录名
        /// </summary>
        /// <remarks>
        /// 取至 MKTPLS.dbo.EDI_Seller_User 的 UserEmailAddress字段
        /// </remarks>
        public string LoginEmailAddress { get; set; }

        private string platformCode = string.Empty;

        /// <summary>
        /// 平台代码，一般是三位大写.<para></para>
        /// </summary>
        public string PlatformCode
        {
            get { return this.platformCode; }
            set
            {
                this.platformCode = value?.Trim().ToUpper();
            }
        }

        private string sellerID = string.Empty;

        /// <summary>
        /// 卖家ID，如BHD6
        /// </summary>
        public string SellerID
        {
            get { return this.sellerID; }
            set
            {
                this.sellerID = value?.Trim().ToUpper();
            }
        }
    }
}