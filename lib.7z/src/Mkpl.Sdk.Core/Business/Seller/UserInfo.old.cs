﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 账户信息
    /// </summary>
    /// <remarks>
    /// 认证时不需要用
    /// </remarks>
    [Obsolete("已弃用此类")]
    public class UserInfo : SellerUser
    {
        #region 针对B2B平台账户

        /// <summary>
        /// 姓
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// 名
        /// </summary>
        public string LastName { get; set; }

        #endregion 针对B2B平台账户

        /// <summary>
        /// 平台代码，如1003
        /// </summary>
        public int CompanyCode { get; set; }

        /// <summary>
        /// 三位国家代码，如"USA"
        /// </summary>
        public string CountryCode { get; set; }

        /// <summary>
        /// 标示是那一个市场平台
        /// </summary>
        public MarketPlatformEnum CurrentPlatform { get; set; }

        /// <summary>
        /// 用于对比用户闯过来的hashpassword是不是正确的
        /// </summary>
        public string HashPassword { get; set; }

        public string AccountSecretKey { get; set; }

        /// <summary>
        /// 两步验证中的秘钥种子
        /// </summary>
        public string ManualEntryKey { get; set; }

        /// <summary>
        /// 语言代码，如"en-us"
        /// </summary>
        public string LanguageCode { get; set; }

        /// <summary>
        /// 老板的账户对应的平台号，如1003
        /// </summary>
        public int OwnerCompanyCode { get; set; }

        #region 数据时间、创建、编辑信息

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? InDate { get; set; }

        /// <summary>
        /// 编辑时间
        /// </summary>
        public DateTime? EditDate { get; set; }

        /// <summary>
        /// 编辑者的用户ID
        /// </summary>
        public string EditUserID { get; set; }

        /// <summary>
        /// 编辑者的用户名
        /// </summary>
        public string EditUserName { get; set; }

        /// <summary>
        /// 创建者用户ID
        /// </summary>
        public string InUserID { get; set; }

        /// <summary>
        /// 创建者用户名
        /// </summary>
        public string InUserName { get; set; }

        #endregion 数据时间、创建、编辑信息
    }
}