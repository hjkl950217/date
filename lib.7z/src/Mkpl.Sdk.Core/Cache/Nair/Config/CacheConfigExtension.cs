﻿using Mkpl.Sdk.Core.Exceptions;
using System.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public static class CacheConfigExtension
    {
        /// <summary>
        /// 获取时间间隔，会在配置的基础上乘以指定的倍数，默认60
        /// </summary>
        /// <param name="cacheConfig"></param>
        /// <param name="key"></param>
        /// <param name="time">倍数</param>
        /// <returns></returns>
        public static int GetInterval(this CacheConfig cacheConfig, string key, int time = 60)
        {
            bool isExists = cacheConfig.NairConfigList.Any(t => t.Key == key);
            if (isExists == false)
            {
                throw new ConfigException("failed to get from Config Service.", $"Cache_Config.{nameof(CacheConfig.NairConfigList)}");
            }

            return cacheConfig.NairConfigList[key] * time;
        }
    }
}