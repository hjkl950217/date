﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Nair
{
    /// <summary>
    /// Nair缓存接口
    /// </summary>
    public interface INairCache
    {
        /// <summary>
        /// 获取数据,没有时返回null
        /// </summary>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>一个字符串，获取不到为""</returns>
        string Get(string key, int expired = -1);

        /// <summary>
        /// 获取数据,没有时返回null
        /// </summary>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>一个字符串，获取不到为""</returns>
        string TryGet(string key, int expired = -1);

        /// <summary>
        /// 获取数据,没有时返回T的默认值
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>
        /// 针对值类型：<para>如果获取不到，会抛出异常，这里不会处理异常</para>
        /// 针对string：<para>  如果获取不到，返回的是""</para>
        /// 针对其他引用类型：<para>如果获取不到，返回的是null</para>
        /// </returns>
        T Get<T>(string key, int expired = -1);

        /// <summary>
        /// 获取数据,没有时返回T的默认值,不管成功与否都*不会*抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>
        /// 针对值类型：<para>如果获取不到，会抛出异常，这里不会处理异常</para>
        /// 针对string：<para>  如果获取不到，返回的是""</para>
        /// 针对其他引用类型：<para>如果获取不到，返回的是null</para>
        /// </returns>
        T TryGet<T>(string key, int expired = -1);

        ///// <summary>
        ///// (暂时不提供)获取一堆数据（不会刷新过期时间）
        ///// </summary>
        ///// <typeparam name="T">要获取的数据类型</typeparam>
        ///// <param name="keys">key集合</param>
        ///// <returns></returns>
        //Dictionary<string, T> Get<T>(IEnumerable<string> keys);

        /// <summary>
        /// 添加数据。存在则更新数据，不存在则新增，和Put效果一样，失败会抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="value">需要更新的数据</param>
        /// <param name="expired">默认时间为5分钟</param>
        /// <returns></returns>
        void Add<T>(string key, T value, int expired = CachaTimeConst.Minute_5);

        /// <summary>
        /// 删除key，失败会抛出异常
        /// </summary>
        /// <param name="key">键名</param>
        /// <returns></returns>
        /// <remarks>
        /// 只是帮调用了Remove方法，为了照顾所有人的使用习惯，包了一次
        /// </remarks>
        void Delete(string key);

        /// <summary>
        /// 删除key，不管成功与否都*不会*抛出异常
        /// </summary>
        /// <param name="key">键名</param>
        /// <returns></returns>
        /// <remarks>
        /// 只是帮调用了Remove方法，为了照顾所有人的使用习惯，包了一次
        /// </remarks>
        void TryDelete(string key);

        ///// <summary>
        ///// （暂时不要使用，还未研究过,使用会抛出异常）增量更新
        ///// </summary>
        ///// <param name="key">键名</param>
        ///// <param name="value"></param>
        ///// <param name="defaultvalue"></param>
        ///// <param name="expired"></param>
        ///// <returns></returns>
        //int Incr(string key, int value, int defaultvalue, int expired = 0);

        #region 辅助方法

        /// <summary>
        /// 克隆一个新的NairCache
        /// </summary>
        /// <param name="option">配置对象</param>
        /// <remarks>当需要修改Nair配置时可以使用这个方法，类似DB访问中切换数据库</remarks>
        INairCache CloneChache(NairCacheOption option);

        #endregion 辅助方法
    }
}