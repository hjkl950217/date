﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Nair.Sdk;
using System;

namespace Mkpl.Sdk.Core.Nair
{
    public class NairCache : INairCache
    {
        #region 私有字段

        /// <summary>
        /// Nair客户端
        /// </summary>
        private readonly INairClient nairClient;

        /// <summary>
        /// 项目中的默认时间 ,默认为一天
        /// </summary>
        public int DefultExpired { get; private set; }

        /// <summary>
        /// Nair数据库名，相当与表名
        /// </summary>
        public string DatebaseName { get; private set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; private set; }

        #endregion 私有字段

        /// <summary>
        /// 内部使用,用于克隆接口
        /// </summary>
        /// <param name="nairClient"></param>
        private NairCache(INairClient nairClient) { this.nairClient = nairClient; }

        public NairCache(INairFactory nairFactory, NairCacheOption option)
        {
            this.nairClient = nairFactory.GetNairClient();
            this.DatebaseName = option.DatebaseName;
            this.DefultExpired = option.DefultExpired;
            this.Password = option.Password;
        }

        #region 私有方法

        /// <summary>
        /// 非try方法都应该检查key的情况，key为空直接抛出异常
        /// </summary>
        /// <param name="key"></param>
        /// <param name="methodName"></param>
        protected virtual void BaseCheck<T>(T key, string methodName) where T : class
        {
            if (key.IsNullOrEmpty() == true)
                throw new ArgumentNullException("key", $"Key is null,{methodName} method for INairCache");
        }

        /// <summary>
        /// String类型的基础Get方法
        /// </summary>
        /// <param name="getOrTryGet">get方法，以委托传入</param>
        /// <param name="key"></param>
        /// <param name="expired"></param>
        /// <returns></returns>
        protected virtual T BaseGet<T>(
        Func<string, string, string, T> getOrTryGet,
        string key,
        int expired = -1)
        {
            //针对值类型
            //    如果获取不到，会抛出异常，这里不会处理异常

            //针对string
            //    如果获取不到，返回的是""

            //针对其他引用类型
            //    如果获取不到，返回的是null

            //[1]取值
            T result = default(T);
            result = getOrTryGet(this.DatebaseName, key, this.Password);

            //[2]处理过期情况
            if (expired < 1) return result;

            bool isString = result.EqualsType(typeof(string));
            if (isString == true)
            {
                this.nairClient.Put(
                    this.DatebaseName,
                    key,
                    result.ToString(),
                    expired, this.Password);
            }
            else
            {
                this.nairClient.Put<T>(
                   this.DatebaseName,
                   key,
                   result,
                   expired, this.Password);
            }

            return result;
        }

        #endregion 私有方法

        #region 操作方法

        /// <summary>
        /// 获取数据,没有时返回null
        /// </summary>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>一个字符串，获取不到为""</returns>
        public string Get(string key, int expired = -1)
        {
            this.BaseCheck(key, nameof(this.Get));

            return this.BaseGet(
                this.nairClient.Get,
                key,
                expired);
        }

        /// <summary>
        /// 获取数据,没有时返回T的默认值
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>
        /// 针对值类型：<para>如果获取不到，会抛出异常，这里不会处理异常</para>
        /// 针对string：<para>  如果获取不到，返回的是""</para>
        /// 针对其他引用类型：<para>如果获取不到，返回的是null</para>
        /// </returns>
        public T Get<T>(string key, int expired = -1)
        {
            this.BaseCheck(key, $"{nameof(this.Get)}<T>");

            return this.BaseGet<T>(
                 this.nairClient.Get<T>,
                 key,
                 expired);
        }

        /// <summary>
        /// 获取数据,没有时返回null
        /// </summary>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>一个字符串，获取不到为""</returns>
        public string TryGet(string key, int expired = -1)
        {
            this.BaseCheck(key, nameof(this.TryGet));

            return this.BaseGet(
                 this.nairClient.TryGet,
                 key,
                 expired);
        }

        /// <summary>
        /// 获取数据,没有时返回T的默认值,不管成功与否都*不会*抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="expired">
        /// 默认为-1，为绝对过期（传0也是），代表不修改过期时间。<para></para>
        /// 大于0，为滑动过期，代表会修改过期时间。
        /// </param>
        /// <returns>
        /// 针对值类型：<para>如果获取不到，会抛出异常，这里不会处理异常</para>
        /// 针对string：<para>  如果获取不到，返回的是""</para>
        /// 针对其他引用类型：<para>如果获取不到，返回的是null</para>
        /// </returns>
        public T TryGet<T>(string key, int expired = -1)
        {
            this.BaseCheck(key, $"{nameof(this.TryGet)}<T>");

            return this.BaseGet<T>(
                 this.nairClient.TryGet<T>,
                 key,
                 expired);
        }

        /// <summary>
        /// 添加数据。存在则更新数据，不存在则新增，和Put效果一样，失败会抛出异常
        /// </summary>
        /// <typeparam name="T">要获取的数据类型</typeparam>
        /// <param name="key">键名</param>
        /// <param name="value">需要更新的数据</param>
        /// <param name="expired">默认时间为5分钟</param>
        /// <returns></returns>
        public void Add<T>(string key, T value, int expired = CachaTimeConst.Minute_5)
        {
            this.BaseCheck(key, nameof(this.Add));

            //处理过期情况
            if (expired == -1) expired = this.DefultExpired;

            try
            {
                this.nairClient.Put<T>(this.DatebaseName, key, value, expired, this.Password);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(
                    $"Put Data from Nair happen Exception:{ex.Message}",
                    paramName: key,
                    innerException: ex);
            }
        }

        /// <summary>
        /// 删除key，失败会抛出异常
        /// </summary>
        /// <param name="key">键名</param>
        /// <returns></returns>
        /// <remarks>
        /// 只是帮调用了Remove方法，为了照顾所有人的使用习惯，包了一次
        /// </remarks>
        public void Delete(string key)
        {
            this.BaseCheck(key, nameof(this.Delete));
            this.nairClient.Remove(this.DatebaseName, key, this.Password);
        }

        /// <summary>
        /// 删除key，不管成功与否都*不会*抛出异常
        /// </summary>
        /// <param name="key">键名</param>
        /// <returns></returns>
        /// <remarks>
        /// 只是帮调用了Remove方法，为了照顾所有人的使用习惯，包了一次
        /// </remarks>
        public void TryDelete(string key)
        {
            this.BaseCheck(key, nameof(this.TryDelete));
            this.nairClient.TryRemove(this.DatebaseName, key, this.Password);
        }

        #endregion 操作方法

        #region 辅助方法

        /// <summary>
        /// 克隆一个新的NairCache
        /// </summary>
        /// <param name="option">配置对象</param>
        /// <remarks>当需要修改Nair配置时可以使用这个方法，类似DB访问中切换数据库</remarks>
        public INairCache CloneChache(NairCacheOption option)
        {
            var newChache = new NairCache(this.nairClient)
            {
                DatebaseName = option.DatebaseName,
                DefultExpired = option.DefultExpired,
                Password = option.Password
            };

            return newChache;
        }

        #endregion 辅助方法
    }
}