﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    //redisClient Center
    public class DefaultRedisClient : IMpsRedisClient
    {
        /*
         *
         * 这个类充当的是Redis Client Center的概念，是对所有IMpsRedisClient调用的一个总封装
         *
         * 都会执行真实的IMpsRedisClient实现，所以不会实现这个方法
         *
         *
         */

        public int Order { get; set; } = int.MinValue;//这个属性不会使用，只是为了代码完整性
        public IMpsRedisClient Next { get; set; }

        public DefaultRedisClient(IEnumerable<IRedisProvider> redisProviders)
        {
            redisProviders.CheckNullOrEmpty(nameof(redisProviders));

            IMpsRedisClient[] mpsRedisClients = redisProviders
                .Select(t => t.GetRedisClient())
                .OrderBy(t => t.Order)
                .ToArray();

            //排序
            this.Next = mpsRedisClients[0];
            IMpsRedisClient temp = mpsRedisClients[0];
            foreach (var item in mpsRedisClients.Skip(1))
            {
                temp.Next = item;
                temp = item;
            }
        }

        private TResult NextExecute<TResult>(Func<IMpsRedisClient, TResult> func)
        {
            return func(this.Next);
        }

        public Task<bool> HashDeleteAsync(RedisKey key, RedisValue hashField, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.HashDeleteAsync(key, hashField, flags));
        }

        public Task<long> HashDeleteAsync(RedisKey key, RedisValue[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.HashDeleteAsync(key, hashFields, flags));
        }

        public Task HashSetAsync(RedisKey key, HashEntry[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.HashSetAsync(key, hashFields, flags));
        }

        public Task<bool> HashSetAsync(RedisKey key, RedisValue hashField, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.HashSetAsync(key, hashField, value, when, flags));
        }

        public Task<long> KeyDeleteAsync(RedisKey[] keys, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.KeyDeleteAsync(keys, flags));
        }

        public Task<bool> KeyDeleteAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.KeyDeleteAsync(key, flags));
        }

        public Task<bool> KeyExpireAsync(RedisKey key, TimeSpan? expiry, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.KeyExpireAsync(key, expiry, flags));
        }

        public Task<bool> KeyRenameAsync(RedisKey key, RedisKey newKey, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.KeyRenameAsync(key, newKey, when, flags));
        }

        public Task<RedisValue> ListLeftPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListLeftPopAsync(key, flags));
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListLeftPushAsync(key, values, flags));
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListLeftPushAsync(key, value, when, flags));
        }

        public Task<RedisValue> ListRightPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListRightPopAsync(key, flags));
        }

        public Task<RedisValue> ListRightPopLeftPushAsync(RedisKey source, RedisKey destination, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListRightPopLeftPushAsync(source, destination, flags));
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListRightPushAsync(key, value, when, flags));
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.ListRightPushAsync(key, values, flags));
        }

        public Task<long> SetAddAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.SetAddAsync(key, values, flags));
        }

        public Task<bool> SetAddAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.SetAddAsync(key, value, flags));
        }

        public Task<long> StringAppendAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.StringAppendAsync(key, value, flags));
        }

        public Task<bool> StringSetAsync(RedisKey key, RedisValue value, TimeSpan? expiry = null, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.StringSetAsync(key, value, expiry, when, flags));
        }

        public Task<bool> StringSetAsync(KeyValuePair<RedisKey, RedisValue>[] values, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.NextExecute(t => t.StringSetAsync(values, when, flags));
        }
    }
}