﻿using Newegg.MIS.Baymax.Cache;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// 直连Redis的<see cref="IMpsRedisClient"/>
    /// </summary>
    public class DirectRedisClient : IMpsRedisClient
    {
        private readonly IRedisConnection redisConnection;

        public DirectRedisClient(IRedisConnection redisConnection)
        {
            redisConnection.CheckNull(nameof(redisConnection));

            this.redisConnection = redisConnection;
        }

        public int Order { get; set; }
        public IMpsRedisClient Next { get; set; }

        private async Task<TResult> BaseExecuteAsync<TResult>(
            Func<IDatabaseAsync, Task<TResult>> redisFunc,
            Func<IMpsRedisClient, Task<TResult>> clientFunc)
        {
            var result = await this.redisConnection.ExecuteAsync(redisFunc);
            await clientFunc(this.Next);
            return result;
        }

        private async Task<TResult> BaseBatchExecuteAsync<TResult>(
            Func<IDatabaseAsync, Task<TResult>> redisFunc,
            Func<IMpsRedisClient, Task<TResult>> clientFunc)
        {
            var result = await this.redisConnection.BatchExecuteAsync(redisFunc);
            await clientFunc(this.Next);
            return result;
        }

        private async Task BaseExecuteAsync(
            Action<IDatabaseAsync> redisAction,
            Action<IMpsRedisClient> clientAction)
        {
            await this.redisConnection.ExecuteAsync(redisAction);
            clientAction(this.Next);
        }

        public Task<bool> HashDeleteAsync(RedisKey key, RedisValue hashField, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.HashDeleteAsync(key, hashField, flags),
                t => t.HashDeleteAsync(key, hashField, flags)
                );
        }

        public Task<long> HashDeleteAsync(RedisKey key, RedisValue[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.HashDeleteAsync(key, hashFields, flags),
                t => t.HashDeleteAsync(key, hashFields, flags)
                );
        }

        public Task HashSetAsync(RedisKey key, HashEntry[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.HashSetAsync(key, hashFields, flags),
                t => t.HashSetAsync(key, hashFields, flags)
                );
        }

        public Task<bool> HashSetAsync(RedisKey key, RedisValue hashField, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.HashSetAsync(key, hashField, value, when, flags),
                t => t.HashSetAsync(key, hashField, value, when, flags)
                );
        }

        public Task<long> KeyDeleteAsync(RedisKey[] keys, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.KeyDeleteAsync(keys, flags),
                t => t.KeyDeleteAsync(keys, flags)
                );
        }

        public Task<bool> KeyDeleteAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.KeyDeleteAsync(key, flags),
                t => t.KeyDeleteAsync(key, flags)
                );
        }

        public Task<bool> KeyExpireAsync(RedisKey key, TimeSpan? expiry, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.KeyExpireAsync(key, expiry, flags),
                t => t.KeyExpireAsync(key, expiry, flags)
                );
        }

        public Task<bool> KeyRenameAsync(RedisKey key, RedisKey newKey, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.KeyRenameAsync(key, newKey, when, flags),
                t => t.KeyRenameAsync(key, newKey, when, flags)
                );
        }

        public Task<RedisValue> ListLeftPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListLeftPopAsync(key, flags),
                t => t.ListLeftPopAsync(key, flags)
                );
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListLeftPushAsync(key, values, flags),
                t => t.ListLeftPushAsync(key, values, flags)
                );
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListLeftPushAsync(key, value, when, flags),
                t => t.ListLeftPushAsync(key, value, when, flags)
                );
        }

        public Task<RedisValue> ListRightPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListRightPopAsync(key, flags),
                t => t.ListRightPopAsync(key, flags)
                );
        }

        public Task<RedisValue> ListRightPopLeftPushAsync(RedisKey source, RedisKey destination, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListRightPopLeftPushAsync(source, destination, flags),
                t => t.ListRightPopLeftPushAsync(source, destination, flags)
                );
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListRightPushAsync(key, value, when, flags),
                t => t.ListRightPushAsync(key, value, when, flags)
                );
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.ListRightPushAsync(key, values, flags),
                t => t.ListRightPushAsync(key, values, flags)
                );
        }

        public Task<long> SetAddAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.SetAddAsync(key, values, flags),
                t => t.SetAddAsync(key, values, flags)
                );
        }

        public Task<bool> SetAddAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.SetAddAsync(key, value, flags),
                t => t.SetAddAsync(key, value, flags)
                );
        }

        public Task<long> StringAppendAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.StringAppendAsync(key, value, flags),
                t => t.StringAppendAsync(key, value, flags)
                );
        }

        public Task<bool> StringSetAsync(RedisKey key, RedisValue value, TimeSpan? expiry = null, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseExecuteAsync(
                t => t.StringSetAsync(key, value, expiry, when, flags),
                t => t.StringSetAsync(key, value, expiry, when, flags)
                );
        }

        public Task<bool> StringSetAsync(KeyValuePair<RedisKey, RedisValue>[] values, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            return this.BaseBatchExecuteAsync(
                t => t.StringSetAsync(values, when, flags),
                t => t.StringSetAsync(values, when, flags)
                );
        }
    }
}