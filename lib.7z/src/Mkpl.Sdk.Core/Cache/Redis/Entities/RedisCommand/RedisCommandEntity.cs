﻿namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 写完Redis后，写其它集群使用的
    /// </summary>
    public abstract class RedisCommandEntity : RedisExpireEntity
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="redisCommand"></param>
        /// <exception cref="System.ArgumentException">当<paramref name="redisCommand"/>检查不过时，会抛出此异常</exception>
        protected RedisCommandEntity(RedisCommandTypeEnum redisCommand)
        {
            this.redisCommandTypeEnum = redisCommand;

            bool isSuccess = this.CheckRedisCommandType(redisCommand);
            if (!isSuccess) throw new System.TypeAccessException($"type error:{redisCommand}");
        }

        private RedisCommandTypeEnum redisCommandTypeEnum;

        /// <summary>
        /// 命令类型
        /// </summary>
        public virtual RedisCommandTypeEnum RedisCommand
        {
            get => this.redisCommandTypeEnum;
            protected set => this.redisCommandTypeEnum = value;
        }

        /// <summary>
        /// 设置Redis命令.有些实体对应多个命令，所以需要增加类型检查
        /// </summary>
        /// <remarks>
        /// 子类实现时选择自己实体对应的命令
        /// </remarks>
        /// <param name="redisCommand"></param>
        protected abstract bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand);

        /// <summary>
        /// 发送消息时的Key
        /// </summary>
        /// <remarks>
        /// 调用Kafka时都要转换成String<para></para>
        /// 多key：比如mset del这种没有单独的key时，需要将多个key拼接起来. {key1}{key2}....<para></para>
        /// 单key：直接就是key
        /// </remarks>
        public abstract string Key { get; }

        /// <summary>
        /// 转换成redis信息，用于调试、日志等
        /// </summary>
        /// <returns></returns>
        public virtual string ToInfo(string append = null)
        {
            return $"CommandType:{this.RedisCommand.GetDescription()},key:{this.Key},ExpireMode:{this.ExpireMode},RedisSetMode:{this.RedisSetMode}.{append}";
        }

        /*
*

  RedisSetMode ->when
      EX->Exists
      NX->NotExists

  RedisExpireMode ->expiry
      EX->秒
      PX ->毫秒

*/

        /*
         *  目前支持的字段 不用命令使用不同的字段
 private RedisCommand redisCommand;
	private String key;
	private List<String> keys;
	private String field;
	private List<String> fields;
	private String value;
	private List<String> values;
	private Map<String, String> keyValuePairs;
	private String newKey;
	private RedisExpireMode expireMode;
	private RedisSetMode redisSetMode;
	private Long expireTime;
         */
    }
}