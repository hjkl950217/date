﻿namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_Hash : RedisCommandEntity
    {
        public RedisCommandEntity_Hash(string key, string hKey, string hValue)
         : base(RedisCommandTypeEnum.Hset)
        {
            this.Key = key;
            this.HKey = hKey;
            this.HValue = hValue;
        }

        public string HKey { get; set; }
        public string HValue { get; set; }

        public override string Key { get; }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return true;
        }

        public override string ToInfo(string append = null)
        {
            return base.ToInfo($"hKey:{this.HKey},hValue:{this.HValue}.{append}");
        }
    }
}