﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_HashDelete : RedisCommandEntity
    {
        public RedisCommandEntity_HashDelete(
         string key,
         IEnumerable<string> fields)
         : base(RedisCommandTypeEnum.Hdel)
        {
            this.Key = key;
            this.Fields = fields;
        }

        public override string Key { get; }
        public IEnumerable<string> Fields { get; set; }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return redisCommand == RedisCommandTypeEnum.Hdel;
        }
    }
}