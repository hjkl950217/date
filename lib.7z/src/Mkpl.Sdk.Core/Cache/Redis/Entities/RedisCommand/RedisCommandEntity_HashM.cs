﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_HashM : RedisCommandEntity
    {
        public RedisCommandEntity_HashM(string key, Dictionary<string, string> keyValuePairs)
            : base(RedisCommandTypeEnum.Hmset)
        {
            this.Key = key;
            this.KeyValuePairs = keyValuePairs;
        }

        public override string Key { get; }

        /// <summary>
        /// Key为Hkey，Value为Hvalue
        /// </summary>
        public Dictionary<string, string> KeyValuePairs { get; set; }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return redisCommand == RedisCommandTypeEnum.Hmset;
        }

        public override string ToInfo(string append = null)
        {
            return base.ToInfo($"key:{this.Key},value:{this.KeyValuePairs.ToJsonExt()}.{append}");
        }
    }
}