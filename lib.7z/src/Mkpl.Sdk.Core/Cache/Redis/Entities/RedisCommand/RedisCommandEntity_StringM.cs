﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_StringM : RedisCommandEntity
    {
        public RedisCommandEntity_StringM(IEnumerable<KeyValuePair<string, string>> keyValuePairs)
            : base(RedisCommandTypeEnum.Mset)
        {
            this.KeyValuePairs = keyValuePairs;
        }

        public override string Key
        {
            get => this.KeyValuePairs.ConcatKey();
        }

        /// <summary>
        /// Key为Hkey，Value为Hvalue
        /// </summary>
        public IEnumerable<KeyValuePair<string, string>> KeyValuePairs { get; set; }

        public override string ToInfo(string append = null)
        {
            return base.ToInfo($"value:{this.KeyValuePairs.ToJsonExt()}.{append}");
        }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return redisCommand == RedisCommandTypeEnum.Mset;
        }
    }
}