﻿using System;

namespace Mkpl.Sdk.Core.Entities
{
    public class RedisExpireEntity
    {
        /// <summary>
        /// 过期时间模式
        /// </summary>
        public RedisExpireTimeModeEnum? ExpireMode { get; set; }

        /// <summary>
        /// 设置 添加数据的模式
        /// </summary>
        public RedisSetModeEnum? RedisSetMode { get; set; }

        public long? ExpireTime { get; protected set; }

        /// <summary>
        /// 设置过期时间
        /// </summary>
        /// <param name="expiry"></param>
        public void SetExpireTime(TimeSpan? expiry = null)
        {
            if (expiry != null)
            {
                this.ExpireTime = (long)expiry.Value.TotalMilliseconds;
                this.ExpireMode = RedisExpireTimeModeEnum.Milliseconds;
            }
        }

        /// <summary>
        /// 设置 添加数据的模式
        /// </summary>
        /// <param name="onlyExistExecute">为true时，仅在key存在时执行</param>
        public void SetRedisSetMode(bool onlyExistExecute)
        {
            if (onlyExistExecute)
            {
                this.RedisSetMode = RedisSetModeEnum.OnlyExist;
            }
            else
            {
                this.RedisSetMode = RedisSetModeEnum.NotExist;
            }
        }
    }
}