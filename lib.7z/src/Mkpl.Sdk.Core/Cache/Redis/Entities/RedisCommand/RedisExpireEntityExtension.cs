﻿using StackExchange.Redis;

namespace Mkpl.Sdk.Core.Entities
{
    public static class RedisExpireEntityExtension
    {
        public static void SetRedisSetMode(this RedisExpireEntity redisExpireEntity, When when)
        {
            switch (when)
            {
                case When.Exists:
                    redisExpireEntity.SetRedisSetMode(true);
                    break;

                case When.NotExists:
                    redisExpireEntity.SetRedisSetMode(false);
                    break;

                case When.Always:
                default:
                    break;
            }
        }
    }
}