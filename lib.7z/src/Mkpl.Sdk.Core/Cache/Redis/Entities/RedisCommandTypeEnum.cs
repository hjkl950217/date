﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities
{
#pragma warning disable S2344

    /// <summary>
    /// Redis命令类型
    /// </summary>
    [UseDescriptionForJson]
    public enum RedisCommandTypeEnum
#pragma warning restore S2344
    {
        [EnumDescription(Description: "APPEND")]
        Append,

        [EnumDescription(Description: "SADD")]
        Sadd,

        [EnumDescription(Description: "DEL")]
        Del,

        [EnumDescription(Description: "HDEL")]
        Hdel,

        [EnumDescription(Description: "SET")]
        Set,

        [EnumDescription(Description: "MSET")]
        Mset,

        [EnumDescription(Description: "HSET")]
        Hset,

        [EnumDescription(Description: "HMSET")]
        Hmset,

        [EnumDescription(Description: "RENAME")]
        Rename,

        [EnumDescription(Description: "HSETNX")]
        [System.Obsolete("NX版本是语法糖,暂不提供")]
        HsetNX,

        [EnumDescription(Description: "MSETNX")]
        [System.Obsolete("NX版本是语法糖,暂不提供")]
        MsetNX,

        [EnumDescription(Description: "SETNX")]
        [System.Obsolete("NX版本是语法糖,暂不提供")]
        SetNX,

        [EnumDescription(Description: "RENAMENX")]
        [System.Obsolete("NX版本是语法糖,暂不提供")]
        RenameNX,

        [EnumDescription(Description: "EXPIRE")]
        Expire,

        [EnumDescription(Description: "LPUSH")]
        Lpush,

        [EnumDescription(Description: "RPUSH")]
        Rpush,

        [EnumDescription(Description: "LPOP")]
        Lpop,

        [EnumDescription(Description: "RPOP")]
        Rpop
    }
}