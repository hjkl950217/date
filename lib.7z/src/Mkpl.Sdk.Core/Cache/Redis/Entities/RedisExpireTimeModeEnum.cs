﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// redis过期时间模式
    /// </summary>
    [UseDescriptionForJson]
    public enum RedisExpireTimeModeEnum
    {
        /// <summary>
        /// 以秒为单位的过期时间
        /// </summary>
        /// <remarks>
        /// 我们都会以毫秒传递。如果用秒，也会转换为毫秒
        /// </remarks>
        [EnumDescription(Description: "EX")]
        Seconds,

        /// <summary>
        /// 以毫秒为单位的过期时间
        /// </summary>
        [EnumDescription(Description: "PX")]
        Milliseconds
    }
}