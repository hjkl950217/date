﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// Redis设置过期时间的模式
    /// </summary>
    [UseDescriptionForJson]
    public enum RedisSetModeEnum
    {
        /// <summary>
        /// 仅在Key不存在的时候执行Set
        /// </summary>
        [EnumDescription(Description: "XX")]
        NotExist,

        /// <summary>
        /// 仅在Key存在的时候执行Set
        /// </summary>
        [EnumDescription(Description: "XX")]
        OnlyExist
    }
}