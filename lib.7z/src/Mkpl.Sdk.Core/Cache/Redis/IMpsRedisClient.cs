﻿using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS redis接口
    /// </summary>
    /// <remarks>
    /// to 后续实现：<para></para>
    /// 配置IOC的关系时，请不要配置接口的关系，直接向IOC中配置实现。由框架统一配置接口与实现的关系。
    ///
    /// 错： <see cref="ServiceCollectionServiceExtensions.AddSingleton{IMpsRedisClient,EndRedisClient}(IServiceCollection)"/>
    /// 对：  <see cref="ServiceCollectionServiceExtensions.AddSingleton{EndRedisClient}(IServiceCollection)"/>
    /// </remarks>
    public interface IMpsRedisClient
    {
        /// <summary>
        /// 调用顺序<para></para>
        /// 由框架指定或自定义实现时指定,请不要随便乱指定。<para></para>
        /// </summary>
        /// <remarks>
        /// 框架执行逻辑：<para></para>
        /// 按order升序排序,按顺序调用。但要不要调用下一个<see cref="IMpsRedisClient"/>，要不要用他的返回值由每个实现自己决定
        /// </remarks>
        int Order { get; set; }

        /// <summary>
        /// 下一个<see cref="IMpsRedisClient"/>，由框架负责赋值
        /// </summary>
        IMpsRedisClient Next { get; set; }

        //append
        [Obsolete("未实现")]
        Task<long> StringAppendAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None);

        //sadd
        [Obsolete("未实现")]
        Task<long> SetAddAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None);

        //sadd
        [Obsolete("未实现")]
        Task<bool> SetAddAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None);

        //del
        Task<long> KeyDeleteAsync(RedisKey[] keys, CommandFlags flags = CommandFlags.None);

        //del
        Task<bool> KeyDeleteAsync(RedisKey key, CommandFlags flags = CommandFlags.None);

        //hdel
        Task<bool> HashDeleteAsync(RedisKey key, RedisValue hashField, CommandFlags flags = CommandFlags.None);

        //hdel
        Task<long> HashDeleteAsync(RedisKey key, RedisValue[] hashFields, CommandFlags flags = CommandFlags.None);

        //hset
        //hsetnx
        Task HashSetAsync(RedisKey key, HashEntry[] hashFields, CommandFlags flags = CommandFlags.None);

        //hset
        //hsetnx
        Task<bool> HashSetAsync(RedisKey key, RedisValue hashField, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //rename
        //renamenx
        [Obsolete("未实现")]
        Task<bool> KeyRenameAsync(RedisKey key, RedisKey newKey, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //set
        //setnx
        Task<bool> StringSetAsync(RedisKey key, RedisValue value, TimeSpan? expiry = null, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //mset
        //msetnx
        Task<bool> StringSetAsync(KeyValuePair<RedisKey, RedisValue>[] values, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //expire
        [Obsolete("未实现")]
        Task<bool> KeyExpireAsync(RedisKey key, TimeSpan? expiry, CommandFlags flags = CommandFlags.None);

        //lpush
        [Obsolete("未实现")]
        Task<long> ListLeftPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None);

        //lpush
        [Obsolete("未实现")]
        Task<long> ListLeftPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //rpush
        [Obsolete("未实现")]
        Task<long> ListRightPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None);

        //rpush
        [Obsolete("未实现")]
        Task<long> ListRightPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None);

        //lpop
        [Obsolete("未实现")]
        Task<RedisValue> ListLeftPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None);

        //rpop
        [Obsolete("未实现")]
        Task<RedisValue> ListRightPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None);

        //rpop
        [Obsolete("未实现")]
        Task<RedisValue> ListRightPopLeftPushAsync(RedisKey source, RedisKey destination, CommandFlags flags = CommandFlags.None);
    }
}