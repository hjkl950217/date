﻿using StackExchange.Redis;
using System;
using System.Threading.Tasks;

namespace Newegg.MIS.Baymax.Cache
{
    public static class IRedisConnectionExtension
    {
        private static Func<IDatabaseAsync, Task> TryExecuteAndInvoke(Action<IDatabaseAsync> action)
        {
            return c =>
            {
                action?.Invoke(c);
                (c as IBatch)?.Execute();//如果是Batch类的操作，则需要显式提交
                return Task.CompletedTask;
            };
        }

        private static Func<IDatabaseAsync, Task<T>> TryExecuteAndInvoke<T>(Func<IDatabaseAsync, Task<T>> func)
        {
            return c =>
           {
               var result = func?.Invoke(c);
               (c as IBatch)?.Execute();//如果是Batch类的操作，则需要显式提交
               Task.WhenAll(result);
               return result;
           };
        }

        /// <summary>
        /// 批量执行-非查询
        /// </summary>
        /// <param name="redisConnection"></param>
        /// <param name="excuteAction"></param>
        /// <remarks>
        /// Batch接口去操作是为了保证顺序性，所以不是特别需要时，不推荐。<para></para>
        /// 传递的委托中不允许出现await关键字，只能返回Task类型的数据。需要在外面自己取出来
        /// </remarks>
        /// <returns></returns>
        public static async Task BatchExecuteAsync(
            this IRedisConnection redisConnection,
            Action<IDatabaseAsync> excuteAction)
        {
            await redisConnection
                .BaseExecuteAsync(TryExecuteAndInvoke(excuteAction), t => t.CreateBatch());
        }

        /// <summary>
        /// 批量执行-设置或获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="redisConnection"></param>
        /// <param name="excuteFunc"></param>
        /// <remarks>
        /// Batch接口去操作是为了保证顺序性，所以不是特别需要时，不推荐。<para></para>
        /// 传递的委托中不允许出现await关键字，只能返回Task类型的数据。需要在外面自己取出来
        /// </remarks>
        /// <returns></returns>
        public static async Task<T> BatchExecuteAsync<T>(
            this IRedisConnection redisConnection,
            Func<IDatabaseAsync, Task<T>> excuteFunc)
        {
            return await redisConnection
                .BaseExecuteAsync(TryExecuteAndInvoke(excuteFunc), t => t.CreateBatch());
        }

        /// <summary>
        /// 单个执行-非查询
        /// </summary>
        /// <param name="redisConnection"></param>
        /// <param name="excuteAction"></param>
        /// <returns></returns>
        public static async Task ExecuteAsync(
            this IRedisConnection redisConnection,
            Action<IDatabaseAsync> excuteAction)
        {
            await redisConnection.BaseExecuteAsync(TryExecuteAndInvoke(excuteAction), t => t);
        }

        /// <summary>
        /// 单个执行-设置或获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="redisConnection"></param>
        /// <param name="excuteFunc"></param>
        /// <returns></returns>
        public static async Task<T> ExecuteAsync<T>(
            this IRedisConnection redisConnection,
            Func<IDatabaseAsync, Task<T>> excuteFunc)
        {
            return await redisConnection.BaseExecuteAsync(TryExecuteAndInvoke(excuteFunc), t => t);
        }

        private static async Task<T> BaseExecuteAsync<T>(
            this IRedisConnection redisConnection,
            Func<IDatabaseAsync, Task<T>> excuteFunc,
            Func<IDatabase, IDatabaseAsync> createClient)
        {
            IDatabase redisClient = await redisConnection.GetDatabaseAsync();
            IDatabaseAsync client = createClient(redisClient);

            if (excuteFunc == null) return default;
            else return await excuteFunc.Invoke(client);
        }

        private static async Task BaseExecuteAsync(
            this IRedisConnection redisConnection,
            Func<IDatabaseAsync, Task> excuteAction,
            Func<IDatabase, IDatabaseAsync> createClient)
        {
            IDatabase redisClient = await redisConnection.GetDatabaseAsync();
            IDatabaseAsync client = createClient(redisClient);

            if (excuteAction == null) await Task.CompletedTask;
            else await excuteAction.Invoke(client);
        }
    }
}