﻿namespace Mkpl.Sdk.Core.Client
{
    public interface IRedisProvider
    {
        IMpsRedisClient GetRedisClient();
    }
}