﻿using Confluent.Kafka;
using Mkpl.Sdk.Core.Entities;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    /// <summary>
    /// ProducerBuilder包装类
    /// </summary>
    public interface IProducerBuilderWrapper
    {
        IProducer<string, RedisCommandEntity> Build(ProducerConfig config);
    }
}