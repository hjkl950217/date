﻿using Confluent.Kafka;
using Mkpl.Sdk.Core.Convert;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System.Linq;
using System.Text;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    public class KafkaSerializer<T> : ISerializer<T>
    {
        private readonly JsonSerializerSettings settings;

        public KafkaSerializer()
        {
            this.settings = JsonSerializerSettingConst.GetSettingForStorage();
            this.settings.ContractResolver = new CamelCasePropertyNamesContractResolver();//使用camel命名法

            this.settings.Converters = this.settings.Converters
                .Where(t => t.GetType() != typeof(StringEnumConverter))
                .ToList();
            this.settings.Converters.Add(new DescriptionEnumWriteConverter());
            this.settings.Converters.Add(new DictionaryPascalCaseKeyWriteConverter());
        }

        public byte[] Serialize(T data, SerializationContext context)
        {
            return this.SerializeToByte(data);
        }

        public string SerializeToString(T data)
        {
            return JsonConvert.SerializeObject(data, this.settings);
        }

        public byte[] SerializeToByte(T data)
        {
            return Encoding.UTF8.GetBytes(this.SerializeToString(data));
        }
    }
}