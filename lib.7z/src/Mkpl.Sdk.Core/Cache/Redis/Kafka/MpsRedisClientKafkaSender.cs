﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Entities;
using System;
using System.Text;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    public class MpsRedisClientKafkaSender : IMpsRedisClientKafkaSender
    {
        private readonly IProducerBuilderWrapper producerBuilderWrapper;
        private readonly ILogger<MpsRedisClientKafkaSender> logger;
        private readonly string topic;
        private readonly ProducerConfig producerConfig;
        private readonly object mutex;
        private bool connecting = false;
        private IProducer<string, RedisCommandEntity> producer;

        /// <summary>
        /// 初始化一个<see cref="MpsRedisClientKafkaSender"/>实例
        /// </summary>
        /// <param name="producerBuilderWrapper"></param>
        /// <param name="logger"></param>
        /// <param name="topic">用Kafka发送消息的topic，相当于MQ中的MQ消息通道</param>
        /// <param name="kafkaAddress"></param>
        public MpsRedisClientKafkaSender(
            IProducerBuilderWrapper producerBuilderWrapper,
            ILogger<MpsRedisClientKafkaSender> logger,
            string topic,
            string kafkaAddress)
        {
            this.producerBuilderWrapper = producerBuilderWrapper;
            this.logger = logger;
            this.mutex = new object();
            this.topic = topic;

            this.producerConfig = new ProducerConfig
            {
                BootstrapServers = kafkaAddress
            };
            this.ConnectKafka();
        }

        /// <summary>
        /// 连接kafka
        /// </summary>
        private void ConnectKafka()
        {
            lock (this.mutex)
            {
                if (this.connecting) return;
                this.connecting = true;
            }

            this.producer = this.producerBuilderWrapper.Build(this.producerConfig);

            lock (this.mutex)
            {
                this.connecting = false;
            }
        }

        public async Task Send(string key, RedisCommandEntity body)
        {
            try
            {
                await this.BaseSend(body.Key, body);
            }
            catch (Exception ex)
            {
                this.WhenException(ex, body);
            }
        }

        private async Task BaseSend(string key, RedisCommandEntity body)
        {
            if (this.producer == null)
            {
                if (!this.connecting) this.ConnectKafka();
                return;
            }

            var message = new Message<string, RedisCommandEntity>()
            {
                Key = key,
                Value = body
            };
            await this.producer.ProduceAsync(this.topic, message);
        }

        private void WhenException(Exception exception, RedisCommandEntity redisCommandEntity)
        {
            StringBuilder logStr = new StringBuilder();
            logStr.AppendLine("Sync to Cluster Error");
            logStr.AppendLine($"connect info:{this.GetConnectInfo()}");
            logStr.AppendLine($"redis command info: {redisCommandEntity.ToInfo()}");

            void LogException(Exception ex)
            {
                if (ex.InnerException == null) return;

                logStr.AppendLine($"Exception type:{ex.GetType().FullName},Exception msg :{ex.Message},StackTrace:{ex.StackTrace}");
            }
            LogException(exception);

            this.logger.LogWarning(logStr.ToString());
        }

        private string GetConnectInfo()
        {
            return $"kafa serverAddress: {this.producerConfig.BootstrapServers},topic:{this.topic}";
        }
    }
}