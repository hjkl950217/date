﻿using Confluent.Kafka;
using Mkpl.Sdk.Core.Entities;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    public class ProducerBuilderWrapper : IProducerBuilderWrapper
    {
        public IProducer<string, RedisCommandEntity> Build(ProducerConfig config)
        {
            var builder = new ProducerBuilder<string, RedisCommandEntity>(config);
            builder.SetKeySerializer(this.GetSerializer<string>());
            builder.SetValueSerializer(this.GetSerializer<RedisCommandEntity>());

            return builder.Build();
        }

        private ISerializer<T> GetSerializer<T>()
        {
            return new KafkaSerializer<T>();
        }
    }
}