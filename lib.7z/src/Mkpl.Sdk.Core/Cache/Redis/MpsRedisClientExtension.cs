﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Client.Kafka;
using Mkpl.Sdk.Core.Env;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core
{
    public static class MpsRedisClientExtension
    {
        /// <summary>
        /// 注册与配置 MPS组RedisClient
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="configuration">配置接口</param>
        /// <param name="configName">配置名。具体请参考<see cref="CacheExtension.AddRedis(IServiceCollection, IConfiguration, string, string)"/>
        /// </param>
        /// <param name="customRedisProviderFactory"> 添加自定义的<see cref="IRedisProvider"/>实现 </param>
        public static void AddMpsRedisClientMPS(
            this IServiceCollection services,
            IConfiguration configuration,
            string configName = "RedisServer",
            Func<IEnumerable<IRedisProvider>> customRedisProviderFactory = null)
        {
            //1.配置redis
            string redisCluster = EnvironmentInfo.Gobal.GetRedisClusterLocation();

            services.AddRedis(
                configuration,
                configName,
                redisCluster
               );
            services.AddCacheEntend();

            //2. 配置redis Client
            services.AddSingleton<IProducerBuilderWrapper, ProducerBuilderWrapper>();
            services.AddSingleton<IMpsRedisClientKafkaSender>(t =>
            {
                IProducerBuilderWrapper wrapper = t.GetService<IProducerBuilderWrapper>();

                string topic = EnvironmentInfo.Gobal.GetRedisKafkaTopic();
                string kafkaAddress = EnvironmentInfo.Gobal.GetRedisKafkaServer();
                return new MpsRedisClientKafkaSender(
                    wrapper,
                    t.GetService<ILogger<MpsRedisClientKafkaSender>>(),
                    topic,
                    kafkaAddress);
            });

            services.AddRedisProvider<DirectRedisClient>(100);
            services.AddRedisProvider<SyncToClusterRedisClient>(200);
            services.AddRedisProvider<EndRedisClient>(int.MaxValue);

            if (customRedisProviderFactory != null)
            {
                foreach (var item in customRedisProviderFactory())
                {
                    services.AddSingleton(item);
                }
            }

            // 3. 注册直接使用的接口
            services.AddSingleton<IMpsRedisClient, DefaultRedisClient>();
        }

        private static IServiceCollection AddRedisProvider<TImplement>(
            this IServiceCollection services,
            int orderNumber)
            where TImplement : class, IMpsRedisClient
        {
            services.AddSingleton<TImplement>();//目前只使用IRedisProvider来获取，没有直接获取实现的
            services.AddSingleton<IRedisProvider>(t =>
            {
                TImplement mpsRedisClient = t.GetService<TImplement>();
                mpsRedisClient.Order = orderNumber;
                return new RedisProvider(mpsRedisClient);
            });

            return services;
        }
    }
}