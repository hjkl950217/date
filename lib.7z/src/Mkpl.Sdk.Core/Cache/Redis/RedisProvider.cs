﻿namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// 代表不同的
    /// </summary>
    public class RedisProvider : IRedisProvider
    {
        private readonly IMpsRedisClient mpsRedisClient;

        public RedisProvider(IMpsRedisClient mpsRedisClient)
        {
            this.mpsRedisClient = mpsRedisClient;
        }

        IMpsRedisClient IRedisProvider.GetRedisClient()
        {
            return this.mpsRedisClient;
        }
    }
}