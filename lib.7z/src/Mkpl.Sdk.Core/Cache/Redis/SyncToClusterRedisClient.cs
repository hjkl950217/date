﻿using Mkpl.Sdk.Core.Client.Kafka;
using Mkpl.Sdk.Core.Entities;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    public class SyncToClusterRedisClient : IMpsRedisClient
    {
        private readonly IMpsRedisClientKafkaSender mpsRedisClientKafkaSender;

        public SyncToClusterRedisClient(IMpsRedisClientKafkaSender mpsRedisClientKafkaSender)
        {
            this.mpsRedisClientKafkaSender = mpsRedisClientKafkaSender;
        }

        public int Order { get; set; }
        public IMpsRedisClient Next { get; set; }

        public TResult Send<TResult>(
            RedisCommandEntity redisCommandEntity,
            Func<IMpsRedisClient, TResult> func)
        {
            this.mpsRedisClientKafkaSender.Send(redisCommandEntity.Key, redisCommandEntity);
            return func(this.Next);
        }

        public Task<bool> HashDeleteAsync(RedisKey key, RedisValue hashField, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试通过
            RedisCommandEntity_HashDelete redis = new RedisCommandEntity_HashDelete(key, new string[] { hashField });

            return this.Send(redis, t => t.HashDeleteAsync(key, hashField, flags));
        }

        public Task<long> HashDeleteAsync(RedisKey key, RedisValue[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试通过
            RedisCommandEntity_HashDelete redis = new RedisCommandEntity_HashDelete(key, hashFields.ToEnumerable());

            return this.Send(redis, t => t.HashDeleteAsync(key, hashFields, flags));
        }

        public Task HashSetAsync(RedisKey key, HashEntry[] hashFields, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试通过
            var hValues = hashFields.ToDictionary(t => (string)t.Name, t => (string)t.Value);

            RedisCommandEntity_HashM redis = new RedisCommandEntity_HashM(key, hValues);

            return this.Send(redis, t => t.HashSetAsync(key, hashFields, flags));
        }

        public Task<bool> HashSetAsync(RedisKey key, RedisValue hashField, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            RedisCommandEntity_Hash redis = new RedisCommandEntity_Hash(key, hashField, value);

            return this.Send(redis, t => t.HashSetAsync(key, hashField, value, when, flags));
        }

        public Task<long> KeyDeleteAsync(RedisKey[] keys, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试
            //直连通过 联调没过
            RedisCommandEntity_Delete redis = new RedisCommandEntity_Delete(keys.ToEnumerable());

            return this.Send(redis, t => t.KeyDeleteAsync(keys, flags));
        }

        public Task<bool> KeyDeleteAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试
            //直连通过 联调没过

            RedisCommandEntity_Delete redis = new RedisCommandEntity_Delete(new string[] { key });

            return this.Send(redis, t => t.KeyDeleteAsync(key, flags));
        }

        public Task<bool> KeyExpireAsync(RedisKey key, TimeSpan? expiry, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<bool> KeyRenameAsync(RedisKey key, RedisKey newKey, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<RedisValue> ListLeftPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> ListLeftPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<RedisValue> ListRightPopAsync(RedisKey key, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<RedisValue> ListRightPopLeftPushAsync(RedisKey source, RedisKey destination, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue value, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> ListRightPushAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> SetAddAsync(RedisKey key, RedisValue[] values, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<bool> SetAddAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<long> StringAppendAsync(RedisKey key, RedisValue value, CommandFlags flags = CommandFlags.None)
        {
            throw new NotImplementedException();
        }

        public Task<bool> StringSetAsync(KeyValuePair<RedisKey, RedisValue>[] values, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试通过
            RedisCommandEntity_StringM redis = new RedisCommandEntity_StringM(values.ToEnumerable());
            redis.SetRedisSetMode(when);

            return this.Send(redis, t => t.StringSetAsync(values, when, flags));
        }

        public Task<bool> StringSetAsync(RedisKey key, RedisValue value, TimeSpan? expiry = null, When when = When.Always, CommandFlags flags = CommandFlags.None)
        {
            //GQC测试通过
            RedisCommandEntity_String redis = new RedisCommandEntity_String(key, value, RedisCommandTypeEnum.Set);
            redis.SetExpireTime(expiry);
            redis.SetRedisSetMode(when);

            return this.Send(redis, t => t.StringSetAsync(key, value, expiry, when, flags));
        }
    }
}