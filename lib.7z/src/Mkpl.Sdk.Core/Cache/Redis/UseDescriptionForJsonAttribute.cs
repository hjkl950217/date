﻿using System;

namespace Mkpl.Sdk.Core.Entities.Attribute
{
    /// <summary>
    /// 标记枚举类为Redis命令类型
    /// </summary>
    [AttributeUsage(AttributeTargets.Enum, AllowMultiple = false, Inherited = true)]
    public sealed class UseDescriptionForJsonAttribute : System.Attribute
    {
    }
}