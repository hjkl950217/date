﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsHttpClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsHttpClient created at  4/28/2018 3:09:11 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS-HttpClient工厂接口
    /// </summary>
    public interface IMpsFileClientFactory
    {
        /// <summary>
        /// 获取DFIS文件操作客户端
        /// </summary>
        /// <remarks>使用MKPL_Common/File_Config下的DFIS节点</remarks>
        /// <returns></returns>
        IMpsFileClient GetDfisFileClient();
    }
}