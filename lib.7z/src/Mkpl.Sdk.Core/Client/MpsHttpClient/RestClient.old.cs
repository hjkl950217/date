﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Client
{
    //代表里面的东西被废弃了，以后会删除

    public partial class RestClient
    {
    }
}
