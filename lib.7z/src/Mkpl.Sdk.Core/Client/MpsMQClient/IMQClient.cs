﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   IMQClient created at  5/12/2018 10:50:08 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS组-MQ客户端
    /// </summary>
    public partial interface IMQClient
    {
        /// <summary>
        /// 发送JSON消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="otherHeader">要附加的头数据</param>
        /// <param name="headerAction">要附加的处理</param>
        /// <remarks>
        /// queue的key不一定要在QueueKeyConst类中，只要在Config service上有就行。<para></para>
        /// 此方法永远有返回值，不会返回null.
        /// </remarks>
        /// <returns></returns>
        PublishResultInfo SendMessage<T>(
              T message,
              string queueKeyConst,
              MQHeaderV2 header,
              IEnumerable<KeyValuePair<string, string>> otherHeader,
              Action<IEnumerable<KeyValuePair<string, string>>> headerAction) 
            where T : class;
    }
}