﻿using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Client
{
    public static class IMQClientExtension
    {
        /// <summary>
        /// 发送JSON消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header)
            where T : class
        {
            return mQClient.SendMessage(message, queueKeyConst, header, null, null);
        }

        /// <summary>
        /// 发送JSON消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="otherHeader">要附加的头数据</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header,
              IEnumerable<KeyValuePair<string, string>> otherHeader)
            where T : class
        {
            return mQClient.SendMessage(message, queueKeyConst, header, otherHeader, null);
        }

        /// <summary>
        /// 发送JSON消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="headerAction">要附加的处理</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header,
              Action<IEnumerable<KeyValuePair<string, string>>> headerAction)
            where T : class
        {
            return mQClient.SendMessage(message, queueKeyConst, header, null, headerAction);
        }
    }
}