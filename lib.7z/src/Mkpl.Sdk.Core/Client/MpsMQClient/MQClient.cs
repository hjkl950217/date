﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQClient created at  5/12/2018 10:50:36 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// The class of MQClient.
    /// </summary>
    public partial class MQClient : IMQClient
    {
        /// <summary>
        /// MQ配置-ConfigService
        /// </summary>
        private readonly GroupQueue groupQueue;

        /// <summary>
        /// MQ发送接口
        /// </summary>
        private readonly IMessagePublisher messagePublisher;

        public MQClient(MQConfig mQConfig, IMessagePublisher messagePublisher)
        {
            this.groupQueue = mQConfig.GroupQueues
                  .FirstOrDefault(t => t.GoupName == QueueGoupNameConst.Team_MKPL);
            this.messagePublisher = messagePublisher;

            if (this.groupQueue == null)
            {
                throw new InvalidOperationException($"GroupQueue Config is not found,Group Key:{QueueGoupNameConst.Team_MKPL}");
            }
        }

        /// <summary>
        /// 基础发送方法
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="otherHeader">要附加的头数据</param>
        /// <param name="headerAction">要附加的处理</param>
        /// <returns></returns>
        public virtual PublishResultInfo SendMessage<T>(
            T message,
            string queueKeyConst,
            MQHeaderV2 header,
            IEnumerable<KeyValuePair<string, string>> otherHeader,
            Action<IEnumerable<KeyValuePair<string, string>>> headerAction)
            where T : class
        {
            if (header == null)
            {
                throw new ArgumentNullException(nameof(header), "The parameter ' header' cannot be empty when sending MQ");
            }

            if (message.IsNullOrEmpty() == true)
            {
                throw new ArgumentNullException(nameof(message), "The parameter ' message' cannot be empty when sending MQ");
            }

            Queue queue = this.groupQueue.FindQueue(queueKeyConst);

            //【1】 处理头
            List<KeyValuePair<string, string>> headerList = header.CreteHeaderList(queue.KeyName);
            headerList.AddRange(header.OtherHeader);//添加对象内的其它header
            if (otherHeader != null) headerList.AddRange(otherHeader);//添加方法参数中的header
            headerAction?.Invoke(headerList);//调用委托处理header

            //【1.5】 临时添加格式
            //
            bool isAccept = headerList.Any(t => t.Key.EqualsIgnoreCase("Accept"));
            bool isContentType = headerList.Any(t => t.Key.EqualsIgnoreCase("Content-Type"));

            if (isAccept == false)
            {
                headerList.Add(new KeyValuePair<string, string>("Accept", "application/json"));
            }
            if (isContentType == false)
            {
                headerList.Add(new KeyValuePair<string, string>("Content-Type", "application/json"));
            }

            //【2】发送
            PublishResultInfo result = this.messagePublisher.SendMessage(
                message,
                queue.QueueName,
                contentType: MessageContentType.Json,
                password: queue.Password,
                headers: headerList
                );

            return result;
        }
    }
}