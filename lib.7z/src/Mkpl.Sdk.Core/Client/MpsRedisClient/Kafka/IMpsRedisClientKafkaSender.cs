﻿using Mkpl.Sdk.Core.Entities;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    public interface IMpsRedisClientKafkaSender
    {
        Task Send(string key, RedisCommandEntity body);
    }
}