﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Client.Kafka
{
    public static class MpsRedisClientKafkaConfig
    {
        public const string Topic_E4 = "MKPL_Redis_Command_E4";
        public const string Topic_E11 = "MKPL_Redis_Command_E11";

        public const string Serveraddress_WH7 = "e7-kfk-conn-dir.newegg.org:8383";
        public const string Serveraddress_GQC = "172.16.168.80:8092";

        /// <summary>
        /// 按不同的机房位置获取topic
        /// </summary>
        /// <param name="redisCluster">redis机房位置,可选值:<see cref="ApplicationEnvConst"/> </param>
        /// <returns></returns>
        public static string GetTopic(string redisCluster)
        {
            switch (redisCluster)
            {
                case EngineRoomConst.E11:
                    return MpsRedisClientKafkaConfig.Topic_E4;

                case EngineRoomConst.E4:
                    return MpsRedisClientKafkaConfig.Topic_E11;

                case ApplicationEnvConst.GDEV:
                case ApplicationEnvConst.GQC:
                    return MpsRedisClientKafkaConfig.Topic_E4;

                default:
                    throw new System.NotSupportedException(redisCluster);
            }
        }

        /// <summary>
        /// 按不同的机房位置获取topic
        /// </summary>
        /// <param name="location">环境,可选值:<see cref="ApplicationEnvConst"/></param>
        /// <returns></returns>
        public static string GetServerAddress(string location)
        {
            switch (location)
            {
                case ApplicationEnvConst.PRE:
                case EngineRoomConst.E11:
                case EngineRoomConst.E4:
                    return MpsRedisClientKafkaConfig.Serveraddress_WH7;

                case ApplicationEnvConst.GDEV:
                case ApplicationEnvConst.GQC:
                    return MpsRedisClientKafkaConfig.Serveraddress_GQC;

                default:
                    throw new System.NotSupportedException(location);
            }
        }
    }
}