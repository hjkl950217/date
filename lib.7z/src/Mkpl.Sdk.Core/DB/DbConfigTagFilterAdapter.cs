﻿using Newegg.MIS.Pikaq.Abstraction;
using Newegg.MIS.Pikaq.Config;
using System.Linq;

namespace Mkpl.Sdk.Core.DB
{
    public class DbConfigTagFilterAdapter : IDbConfigHandler
    {
        private readonly string tag;
        private readonly bool includeNoTag;

        public DbConfigTagFilterAdapter(string tag, bool includeNoTag = true)
        {
            this.tag = tag;
            this.includeNoTag = includeNoTag;
        }

        public DbConfig Handle(DbConfig config)
        {
            config.ConnectionStrings = config.ConnectionStrings
                .Where(i => IsValidDbTag(i.Tag))
                .ToList();
            return config;
        }

        private bool IsValidDbTag(string dbTag)
        {
            return string.IsNullOrWhiteSpace(dbTag)
                                ? includeNoTag
                                : string.IsNullOrWhiteSpace(tag) || tag.EqualsIgnoreCase(dbTag);
        }
    }
}