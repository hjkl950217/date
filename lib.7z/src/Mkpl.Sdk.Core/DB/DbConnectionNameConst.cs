﻿using System;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 连接字符串
    /// </summary>
    /// <remarks>
    /// 为何存在此常量？
    /// <para>1.有时会需要同一个SQL语句，切换不同的数据库，所以需要这个常量来标示使用那一个连接字符串</para>
    /// <para>2.常量名对应连接文件中的数据库别名</para>
    /// </remarks>
    public static class DbConnectionNameConst
    {
        /// <summary>
        /// 读库，代表访问的读库集群
        /// </summary>
        [Obsolete("已弃用,此连接库不再使用,请使用HisQuery")]
        public const string QueryDB = "QueryDB";

        /// <summary>
        /// 读库，代表访问的读库集群
        /// </summary>
        public const string HisQuery = "HisQuery";

        /// <summary>
        /// 写库，服务器名-MKTPLS
        /// </summary>
        public const string MKTPLS = "MKTPLS";

        /// <summary>
        /// 服务器名-SSB
        /// </summary>
        public const string SSB = "SSB";

        /// <summary>
        /// 服务器名-D2WHP01
        /// </summary>
        public const string D2WHP01 = "D2WHP01";

        /// <summary>
        /// 服务器名-ABSSQL
        /// </summary>
        public const string ABSSQL = "ABSSQL";

        /// <summary>
        /// 服务器名-S7OVSDB04
        /// </summary>
        [Obsolete("已弃用,此连接库不再使用")]
        public const string S7OVSDB04 = "S7OVSDB04";

        /// <summary>
        /// 服务器名-NEWSQL
        /// </summary>
        [Obsolete("已弃用,此连接库不再使用")]
        public const string NEWSQL = "NEWSQL";

        /// <summary>
        /// 写库
        /// </summary>
        [Obsolete("已弃用,此连接库不再使用")]
        public const string EHISSQL = "EHISSQL";
    }
}