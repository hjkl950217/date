﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newegg.MIS.Pikaq.Config;
using Newegg.MIS.Pikaq.Config.Adapter;

namespace Mkpl.Sdk.Core.DB
{
    public static class DbExtension
    {
        public static IServiceCollection AddDb(this IServiceCollection services, IConfiguration configuration,
            string dbDirectory, string configServiceDbKey, string location, string appName)
        {
            return services.UseMSSql()
                .UseDataAccessConfigFromHandler(dbDirectory,
                    new MultipleDbConfigAdapter(
                            new EggkeeperDbConfigAdapter(configuration, configServiceDbKey),
                            new DbConfigTagFilterAdapter(location),
                            new DecryptConnectionStringAdapter(),
                            new ReplaceApplicationNameAdapter(appName)))
                .TryAddSingletonService<ISSBClient, SSBClient>();
        }
    }
}