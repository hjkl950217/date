﻿using Newegg.MIS.Pikaq.Abstraction;
using Newegg.MIS.Pikaq.Config;

namespace Mkpl.Sdk.Core.DB
{
    public class ReplaceApplicationNameAdapter : IDbConfigHandler
    {
        private readonly string appName;

        public ReplaceApplicationNameAdapter(string appName)
        {
            this.appName = appName;
        }

        public DbConfig Handle(DbConfig config)
        {
            foreach (var connection in config.ConnectionStrings)
            {
                connection.ConnectionString = connection.ConnectionString.Replace("{#app}", appName);
            }

            return config;
        }
    }
}