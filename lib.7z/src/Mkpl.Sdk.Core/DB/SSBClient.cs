﻿using Newegg.MIS.Pikaq.Abstraction;

namespace Mkpl.Sdk.Core
{
    public interface ISSBClient
    {
        void SendSSB(string ssbXML, bool isUseReadDB = true);
    }

    public class SSBClient : ISSBClient
    {
        private readonly IDbManager dbManager;

        public SSBClient(IDbManager dbManager)
        {
            this.dbManager = dbManager;
        }

        public void SendSSB(string ssbXML, bool isUseReadDB = true)
        {
            var command = dbManager.GetCommand(isUseReadDB ? "MKPLCOMMON_SendSSB_Read" : "MKPLCOMMON_SendSSB_Write");
            command.ExecuteNonQuery(new { SSBXml = ssbXML });
        }
    }
}