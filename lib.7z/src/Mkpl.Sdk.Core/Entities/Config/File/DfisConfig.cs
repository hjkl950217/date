﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// dfis上下载文件用的配置
    /// </summary>
    public class DfisConfig
    {
        /// <summary>
        /// 上传地址
        /// </summary>
        public string UploadHostAddress { get; set; }

        /// <summary>
        /// 下载地址
        /// </summary>
        public string DownloadHostAddress { get; set; }

        /// <summary>
        /// 配置信息组
        /// </summary>
        public List<DfisConfigInfo> GroupInfoList { get; set; }
    }
}