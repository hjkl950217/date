﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApiEntity.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ApiEntity created at  4/28/2018 11:02:04 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 配置中的通用API数据模型
    /// </summary>
    public class ApiEntity
    {
        /// <summary>
        /// 请求域名
        /// </summary>
        public string Host { get; set; }

        /// <summary>
        /// 请求地址，域名后面的东西
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 登录中用到的Token，不需要时配置的null
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// （扩展）自定义对象
        /// </summary>
        public object CustomEntity { get; set; }

        /// <summary>
        /// 标示api唯一的数据
        /// </summary>
        /// <remarks>
        /// 为API处理提供优化用的，业务项目中不要使用。
        /// </remarks>
        public string ApiUniqueKey { get; set; }
    }
}