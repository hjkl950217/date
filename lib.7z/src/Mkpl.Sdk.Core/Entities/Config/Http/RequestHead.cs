﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RequestHead.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   RequestHead created at  4/28/2018 10:56:46 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    public class RequestHead
    {
        /// <summary>
        /// 初始化RequestHead实例
        /// </summary>
        public RequestHead()
        {
            this.Accept = "application/json";
            this.ContentType = "application/json";

            this.CustomHeaderList = new Dictionary<string, string>();
        }

        /// <summary>
        /// 初始化RequestHead实例
        /// </summary>
        /// <param name="accept">请求头中的Accept</param>
        public RequestHead(string accept) : this()
        {
            this.Accept = accept;
        }

        /// <summary>
        /// HttpClient请求中的UserAgent，默认没有使用
        /// </summary>
        public string UserAgent { get; set; }

        /// <summary>
        /// 请求体格式，默认为application/json
        /// </summary>
        public string Accept { get; protected set; }

        /// <summary>
        /// 期望的响应体格式，默认为application/json
        /// </summary>
        public string ContentType { get; protected set; }

        /// <summary>
        /// 自定义的头部，new对象时已经初始化引用
        /// </summary>
        /// <remarks>
        /// key 就是请求头部中的key
        /// value  就是请求头部中key对应的数据
        /// </remarks>
        public Dictionary<string, string> CustomHeaderList { get; set; }
    }
}