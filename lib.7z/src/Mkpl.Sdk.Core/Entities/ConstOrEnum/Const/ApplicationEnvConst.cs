﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum.Enum;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 程序环境常量
    /// </summary>
    /// <remarks>GDEV GQC PRE E11这种</remarks>
    public static class ApplicationEnvConst
    {
        /// <summary>
        /// 开发者环境，等同GDEV<para></para>
        /// 推荐使用<see cref="ApplicationEnvEnum.Development"/>
        /// </summary>
        public const string Development = "Development";

        /// <summary>
        /// 开发者环境<para></para>
        /// 推荐使用<see cref="ApplicationEnvEnum.GDEV"/>
        /// </summary>
        public const string GDEV = "GDEV";

        /// <summary>
        /// 集成测试环境<para></para>
        /// 推荐使用<see cref="ApplicationEnvEnum.GQC"/>
        /// </summary>
        public const string GQC = "GQC";

        /// <summary>
        /// 产品测试环境<para></para>
        /// 推荐使用<see cref="ApplicationEnvEnum.PRE"/>
        /// </summary>
        public const string PRE = "PRE";

        /// <summary>
        /// 正式产品环境<para></para>
        /// 推荐使用<see cref="ApplicationEnvEnum.PRD"/>
        /// </summary>
        public const string PRD = "PRD";
    }
}