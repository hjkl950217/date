﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 缓存时间常量，以秒为单位
    /// </summary>
    public static class CachaTimeConst
    {
        public const int Second_5 = 5;
        public const int Second_10 = 10;
        public const int Second_30 = 30;
        public const int Second_45 = 45;
        public const int Minute_5 = 5 * 60;
        public const int Minute_15 = 15 * 60;
        public const int Minute_30 = 30 * 60;
        public const int Minute_45 = 45 * 60;
        public const int Hour_1 = 1 * 60 * 60;
        public const int Hour_2 = 2 * 60 * 60;
        public const int Hour_4 = 4 * 60 * 60;
        public const int Hour_6 = 6 * 60 * 60;
        public const int Hour_8 = 8 * 60 * 60;
        public const int Hour_12 = 12 * 60 * 60;
        public const int Hour_16 = 16 * 60 * 60;

        /// <summary>
        /// int最大值，约等于68.09626年
        /// </summary>
        public const int Forever = int.MaxValue;
    }
}