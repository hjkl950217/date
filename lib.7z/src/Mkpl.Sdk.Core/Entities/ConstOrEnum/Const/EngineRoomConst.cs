﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    public static class EngineRoomConst
    {
        /// <summary>
        /// 线上E11机房
        /// </summary>
        public const string E11 = "E11";

        /// <summary>
        /// 线上E4机房
        /// </summary>
        public const string E4 = "E4";

        /// <summary>
        /// 线上WH7机房
        /// </summary>
        public const string WH7 = "WH7";
    }
}