﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MarketPlatformConst.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MarketPlatformConst created at  7/14/2018 1:27:51 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// The class of MarketPlatformConst.
    /// </summary>
    public static class MarketPlatformConst
    {
        /// <summary>
        ///
        /// </summary>
        public const string MarketPlatform_USA = "SellerPortal_USA_B2C";

        public const string MarketPlatform_USB = "SellerPortal_USA_B2B";
        public const string MarketPlatform_CAN = "SellerPortal_CAN_B2C";
        public const string MarketPlatform_NA = "NA";
    }
}