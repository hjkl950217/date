﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    public static class PagingInfoConst
    {
        /// <summary>
        /// 默认分页大小
        /// </summary>
        public const int PageSize_Default = 50;
    }
}