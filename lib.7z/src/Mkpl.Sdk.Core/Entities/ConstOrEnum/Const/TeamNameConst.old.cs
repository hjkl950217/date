﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TeamNameConst.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   TeamNameConst created at  4/28/2018 2:05:14 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 团队名常量。(新开始业务,推荐使用<see cref="TeamNameEnum"/>枚举)
    /// </summary>
    [Obsolete("请参考说明使用新方法")]
    public static class TeamNameConst
    {
        #region 其它团队名

        /// <summary>
        /// 台湾-EC团队名
        /// </summary>
        public const string TwEc = "TwEc";

        /// <summary>
        /// 成都-EC团队名
        /// </summary>
        public const string CdEc = "CdEc";

        /// <summary>
        /// 上海-EC团队名
        /// </summary>
        public const string ShEc = "ShEc";

        /// <summary>
        /// 西安-EC团队名
        /// </summary>
        public const string XaEc = "XaEc";

        /// <summary>
        /// 西安-NE SO团队
        /// 主要是和solr相关
        /// </summary>
        public const string XaNESO = "XaNESO";

        /// <summary>
        /// 台湾-B2B团队名
        /// </summary>
        public const string TwB2b = "TwB2B";

        /// <summary>
        /// 西安-Im团队名
        /// </summary>
        public const string XaIm = "XaIm";

        /// <summary>
        /// 台湾-Im团队名
        /// </summary>
        public const string TwIm = "TwIm";

        /// <summary>
        /// 成都-ET团队名
        /// </summary>
        public const string CdEt = "CdEt";

        /// <summary>
        /// 成都-ACCT团队名
        /// </summary>
        public const string CdAcct = "CdAcct";

        /// <summary>
        /// 成都-BI团队名
        /// </summary>
        public const string CdBi = "CdBi";

        /// <summary>
        /// 成都-BTS团队名
        /// </summary>
        public const string CdBts = "CdBts";

        /// <summary>
        /// 成都-OZZO团队名
        /// </summary>
        public const string CdOzzo = "CdOzzo";

        /// <summary>
        /// 成都-PO团队名
        /// </summary>
        public const string CdPo = "CdPo";

        /// <summary>
        /// 成都-DFIS团队名
        /// </summary>
        public const string CdDfis = "CdDfis";

        /// <summary>
        /// 成都-ESB团队名
        /// </summary>
        public const string CdEsb = "CdEsb";

        /// <summary>
        /// 成都-DBA团队名
        /// </summary>
        public const string CdDba = "CdDba";

        #endregion 其它团队名

        #region 组内微服务名

        /// <summary>
        /// MPS组-Item微服务名
        /// </summary>
        public const string Item = "Item";

        /// <summary>
        /// MPS组-认证微服务名
        /// </summary>
        public const string Authentication = "Authentication";

        /// <summary>
        /// MPS组-Seller微服务名
        /// </summary>
        public const string Seller = "Seller";

        /// <summary>
        /// MPS组-Order微服务名
        /// </summary>
        public const string Order = "Order";

        /// <summary>
        /// MPS组-ApproveCenter微服务名
        /// </summary>
        public const string ApproveCenter = "ApproveCenter";

        /// <summary>
        /// MPS组-以前老API项目的名字
        /// </summary>
        public const string RestAPI = "MKPLRestAPI";

        #endregion 组内微服务名
    }
}