﻿using Mkpl.Sdk.Core.Entities.Attribute;
using System;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum.Enum
{
    [Flags]
    public enum ApplicationEnvEnum
    {
        [EnumDescription(Description: ApplicationEnvConst.Development)]
        Development = 0b1,

        [EnumDescription(Description: ApplicationEnvConst.GDEV)]
        GDEV = 0b10,

        [EnumDescription(Description: ApplicationEnvConst.GQC)]
        GQC = 0b100,

        [EnumDescription(Description: ApplicationEnvConst.PRE)]
        PRE = 0b1000,

        [EnumDescription(Description: ApplicationEnvConst.PRD)]
        PRD = 0b10000
    }
}