﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 平台标示
    /// </summary>
    public enum MarketPlatformEnum
    {
        /// <summary>
        /// USA国家的B2C平台，类似中国的淘宝\京东
        /// </summary>
        SellerPortal_USA_B2C = 0,

        /// <summary>
        /// USA国家的B2B平台，类似中国的阿里巴巴
        /// </summary>
        SellerPortal_USA_B2B = 1,

        /// <summary>
        /// CAN国家的B2C平台,类似中国的淘宝\京东。
        /// <para>但此平台的卖家发货也只能发到CAN</para>
        /// </summary>
        SellerPortal_CAN_B2C = 2,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_All = 3,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_Newegg_USA_B2C = 4,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_Newegg_CN_B2C = 5,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_Amazon_US_B2C = 6,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_Ebay_US_B2C = 7,

        /// <summary>
        /// 早期一个项目，现在已弃用
        /// </summary>
        UIH_Rakuten_US_B2C = 8,

        NA = 9
    }
}