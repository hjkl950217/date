﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// Seller账户状态
    /// </summary>
    public enum SellerStatusEnum
    {
        /// <summary>
        /// DB值：C
        /// </summary>
        [EnumDescription(ShowValue: "Close", DbValue: "C")]
        Close = 67,

        /// <summary>
        /// DB值：D
        /// </summary>
        [EnumDescription(ShowValue: "Inactive", DbValue: "D")]
        Inactive = 68,

        /// <summary>
        /// DB值：N
        /// </summary>
        [EnumDescription(ShowValue: "New", DbValue: "N")]
        New = 78,

        /// <summary>
        /// DB值：O
        /// </summary>
        [EnumDescription(ShowValue: "Open", DbValue: "O")]
        Open = 79,

        /// <summary>
        /// DB值：S
        /// </summary>
        [EnumDescription(ShowValue: "Suspend", DbValue: "S")]
        Suspend = 83,

        /// <summary>
        /// DB值：T
        /// </summary>
        [EnumDescription(ShowValue: "Terminate", DbValue: "T")]
        Terminate = 84
    }
}