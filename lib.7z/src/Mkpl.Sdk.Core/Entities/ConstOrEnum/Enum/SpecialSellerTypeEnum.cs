﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 特殊卖家标记
    /// </summary>
    public enum SpecialSellerTypeEnum
    {
        /// <summary>
        /// 联络卖家 DB值：L
        /// </summary>
        [EnumDescription(ShowValue: "LianLuoFristParty", DbValue: "L")]
        LianLuoFristParty = 76
    }
}