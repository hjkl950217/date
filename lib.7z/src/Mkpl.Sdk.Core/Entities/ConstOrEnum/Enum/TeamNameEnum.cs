﻿using Mkpl.Sdk.Core.Entities.Attribute;
using System;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 团队名枚举
    /// </summary>
    /// <remarks>
    /// 对其它团队：团队名<para></para>
    /// 对MPS微服务：微服务名，当一个虚拟的小组<para></para>
    /// </remarks>
    public enum TeamNameEnum
    {
        /*
         *
         * 使用EnumDescription的Description属性来描述
         *
         */

        #region 其它团队

        /// <summary>
        /// EC团队名,包括4地
        /// </summary>
        [EnumDescription(Description: "EC")]
        EC,

        /// <summary>
        /// ET团队名
        /// </summary>
        [EnumDescription(Description: "ET")]
        ET,

        /// <summary>
        /// ACCT团队名
        /// </summary>
        [EnumDescription(Description: "ACCT")]
        ACCT,

        /// <summary>
        /// BTS团队名
        /// </summary>
        [EnumDescription(Description: "BTS")]
        BTS,

        /// <summary>
        /// OZZO团队名
        /// </summary>
        [EnumDescription(Description: "OZZO")]
        OZZO,

        /// <summary>
        /// PO团队名
        /// </summary>
        [EnumDescription(Description: "PO")]
        PO,

        /// <summary>
        /// NESO团队名
        /// </summary>
        [EnumDescription(Description: "NESO")]
        NESO,

        /// <summary>
        /// TW-B2B团队名
        /// </summary>
        [EnumDescription(Description: "B2B")]
        B2B,

        /// <summary>
        /// IM团队名
        /// </summary>
        [EnumDescription(Description: "IM")]
        IM,

        /// <summary>
        /// DBA团队名
        /// </summary>
        [EnumDescription(Description: "DBA")]
        DBA,

        /// <summary>
        /// BI团队名
        /// </summary>
        [EnumDescription(Description: "BI")]
        BI,

        /// <summary>
        /// PS团队名
        /// </summary>
        [EnumDescription(Description: "PS")]
        PS,

        #endregion 其它团队

        #region MPS-微服务

        /// <summary>
        /// MPS组-Item微服务名
        /// </summary>
        [EnumDescription(Description: "Item")]
        Item,

        /// <summary>
        /// MPS组-认证微服务名
        /// </summary>
        [EnumDescription(Description: "Authentication")]
        Authentication,

        /// <summary>
        /// MPS组-Seller微服务名
        /// </summary>
        [EnumDescription(Description: "Seller")]
        Seller,

        /// <summary>
        /// MPS组-Order微服务名
        /// </summary>
        [EnumDescription(Description: "Order")]
        Order,

        /// <summary>
        /// MPS组-ApproveCenter微服务名
        /// </summary>
        [EnumDescription(Description: "ApproveCenter")]
        ApproveCenter,

        /// <summary>
        /// MPS组-RMA微服务名
        /// </summary>
        [EnumDescription(Description: "RMA")]
        RMA,

        /// <summary>
        /// MPS组-以前老API项目的名字
        /// </summary>
        [EnumDescription(Description: "MKPLRestAPI")]
        MKPLRestAPI,

        /// <summary>
        /// 公共工具服务，包括java/chsarp的项目。由URL区分
        /// </summary>
        [EnumDescription(Description: "CommonService")]
        CommonService,

        /// <summary>
        /// MPS组-以前老订阅端项目的名字。新的开发中要求订阅端也写到微服务中
        /// </summary>
        [EnumDescription(Description: "Backend")]
        Backend,

        /// <summary>
        /// MPS组最老的定时脚本，运行在job console上面的
        /// </summary>
        [EnumDescription(Description: "Job_OldJob")]
        Job_OldJob,

        /// <summary>
        /// MPS组第二代定时脚本，运行在could task上面
        /// </summary>
        [EnumDescription(Description: "Job_Task")]
        Job_Task,

        /// <summary>
        /// MPS组第三代定时脚本，运行在could task上面，使用容器化部署，使用.net core版本开发
        /// </summary>
        [EnumDescription(Description: "Job_CoreJob")]
        Job_CoreJob,

        #endregion MPS-微服务

        #region 其它

        /// <summary>
        /// 外部-Salesforce公司
        /// </summary>
        [EnumDescription(Description: "External_Salesforce")]
        External_Salesforce,

        #endregion 其它

        #region 旧-以后不再使用

        /// <summary>
        /// MPS组-以前老API项目的名字
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "MKPLRestAPI")]
        RestAPI,

        /// <summary>
        /// 成都-EC团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdEc")]
        CdEc,

        /// <summary>
        /// 成都-ET团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdEt")]
        CdEt,

        /// <summary>
        /// 成都-ACCT团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdAcct")]
        CdAcct,

        /// <summary>
        /// 成都-BTS团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdBts")]
        CdBts,

        /// <summary>
        /// 成都-OZZO团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdOzzo")]
        CdOzzo,

        /// <summary>
        /// 成都-PO团队名
        /// </summary>
        [EnumDescription(Description: "CdPo")]
        CdPo,

        /// <summary>
        /// 成都-DFIS团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdDfis")]
        CdDfis,

        /// <summary>
        /// 成都-ESB团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdEsb")]
        CdEsb,

        /// <summary>
        /// 成都-DBA团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "CdDba")]
        CdDba,

        /// <summary>
        /// 台湾-EC团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "TwEc")]
        TwEc,

        /// <summary>
        /// 上海-EC团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "ShEc")]
        ShEc,

        /// <summary>
        /// 西安-EC团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "XaEc")]
        XaEc,

        /// <summary>
        /// 西安-NE SO团队
        /// 主要是和solr相关
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "XaNESO")]
        XaNeSo,

        /// <summary>
        /// 台湾-B2B团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "TwB2b")]
        TwB2b,

        /// <summary>
        /// 西安-Im团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "XaIm")]
        XaIm,

        /// <summary>
        /// 台湾-Im团队名
        /// </summary>
        [Obsolete("请参考说明使用新团队名")]
        [EnumDescription(Description: "TwIm")]
        TwIm,

        #endregion 旧-以后不再使用
    }
}