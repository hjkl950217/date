﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Entities
{
    public class ColumnInfo
    {
        //导出的列名，此处并未实际应用，帮助开发时比对列名导出是否正确
        public string Name { get; set; }

        //列导出的顺序，从1开始
        public int Ordinal { get; set; }

        public double? Width { get; set; }
    }
}
