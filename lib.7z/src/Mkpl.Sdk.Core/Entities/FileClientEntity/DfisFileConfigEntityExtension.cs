﻿namespace Mkpl.Sdk.Core.Entities
{
    public static class DfisFileConfigEntityExtension
    {
        /// <summary>
        /// 获取dfis文件的访问前缀 host+group+type
        /// </summary>
        /// <remarks>
        /// eg:http://DownHost:8080/Group1/Type1
        /// </remarks>
        /// <returns></returns>
        public static string GetDfisUrlPrefix(this DfisFileConfigEntity configEntity)
        {
            
            return $"{configEntity.DownloadHostAddress}/{configEntity.Group}/{configEntity.Type}";
        }
    }
}