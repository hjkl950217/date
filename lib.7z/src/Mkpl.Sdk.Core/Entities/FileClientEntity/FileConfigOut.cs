﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Entities
{
    public class FileConfigOut
    {
        public DfisFileConfigEntity Dfis { get; set; }
    }
}
