﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeader.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeader created at  5/12/2018 11:23:25 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// (已弃用)发送MQ时的头部数据
    /// <para>推荐使用<see cref="MQHeaderV2"/></para>
    /// </summary>
    /// <remarks>
    /// 老项目中叫MQMessageHeader
    /// </remarks>
    [Obsolete("请参考说明使用新方法")]
    public class MQHeader
    {
        /// <summary>
        /// 发送者
        /// </summary>
        /// <remarks>
        /// 微服务也使用"Portal2.0" 标示是那个平台发出
        /// </remarks>
        public const string Sender = "Portal2.0";

        public string Action { get; set; }

        public string CountryCode { get; set; }

        public string SellerID { get; set; }

        public string Version { get; set; }

     
    }
}