﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeader.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeader created at  5/12/2018 11:23:25 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 发送MQ时的头部数据
    /// </summary>
    /// <remarks>
    /// 老项目中叫MQMessageHeader
    /// </remarks>
    public class MQHeaderV2
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sendProject">
        /// 由那一个项目发送,选择自己的服务接口.如Item就传<see cref="TeamNameEnum.Item"/>
        /// </param>
        /// <param name="nameOfSender">发送者的名字.如Job就传递job的名字</param>
        public MQHeaderV2(TeamNameEnum sendProject,string nameOfSender)
        {
            this.SendProject = sendProject;
            this.SendName = nameOfSender;
        }

        /// <summary>
        /// 发送者名字
        /// </summary>
        public string SendName { get; set; }

        /// <summary>
        /// 发送项目
        /// </summary>
        public TeamNameEnum SendProject { get; }

        /// <summary>
        /// 行为，也可以理解为事件。
        /// <para>
        /// 一般MQ通道中会有多个订阅者，在订阅者中可以设置只接收什么样的Action
        /// 这个属性就是做这个使用的。所以也能理解为是事件
        /// </para>
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// 平台编码。
        /// <para>推荐使用<see cref="PlatformConst"/>中的值，减少硬编码</para>
        /// </summary>
        public string PlatformCode { get; set; }

        /// <summary>
        /// 消息和那一个卖家有关
        /// </summary>
        public string SellerID { get; set; }

        /// <summary>
        /// 消息版本
        /// <para>用来隔离消息结构变化的情况，默认为1</para>
        /// <para>发送MQ时为1位小数，如5-->5.0</para>
        /// </summary>
        public int Version { get; set; } = 1;

        /// <summary>
        /// 在MQ系统调用订阅者时添加的header,默认情况下不用管此属性
        /// </summary>
        public List<KeyValuePair<string, string>> OtherHeader { get; set; } = new List<KeyValuePair<string, string>>();
    }
}