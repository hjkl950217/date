﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeaderExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeaderExtension created at  5/12/2018 1:34:48 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// MQHeader扩展
    /// </summary>
    public static class MQHeaderV2Extension
    {
        /// <summary>
        /// 创建发送MQ时的KV集合
        /// </summary>
        /// <param name="mqHeader"></param>
        /// <param name="keyName">queue的key名</param>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> CreteHeaderList(
            this MQHeaderV2 mqHeader,
            string keyName)
        {
            if (mqHeader==null)
            {
                throw new ArgumentNullException(nameof(mqHeader));
            }
            if (string.IsNullOrWhiteSpace(keyName))
            {
                throw new ArgumentNullException(nameof(keyName), $"The QueueKey is null or empty");
            }


            string msgType = $"{keyName}_{mqHeader?.Action}";
            string sender = $"{mqHeader?.SendProject.GetDescription()}_{mqHeader.SendName}";

            List<KeyValuePair<string, string>> headerList = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("Sender", sender),
                new KeyValuePair<string, string>("MsgType",msgType),
                new KeyValuePair<string, string>("Action",mqHeader.Action),
                new KeyValuePair<string, string>("Version", mqHeader.Version.ToString("0.0"))//格式化成1位小数
            };

            if (string.IsNullOrWhiteSpace(mqHeader.PlatformCode) == false)
            {
                headerList.Add(new KeyValuePair<string, string>("PlatformCode", mqHeader.PlatformCode));
            }
            if (string.IsNullOrWhiteSpace(mqHeader.SellerID) == false)
            {
                headerList.Add(new KeyValuePair<string, string>("SellerID", mqHeader.SellerID));
            }
            return headerList;
        }
    }
}