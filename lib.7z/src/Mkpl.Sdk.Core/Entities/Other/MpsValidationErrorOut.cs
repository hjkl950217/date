﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// MPS-模型验证不过时返回给前端的数据
    /// </summary>
    public class MpsValidationErrorOut
    {
        /// <summary>
        /// KV型的错误信息集合
        /// </summary>
        /// <remarks>
        /// Key为错误字段名，Value为字段对应的错误信息集合
        /// </remarks>
        public Dictionary<string, List<string>> Errors { get; set; }
            = new Dictionary<string, List<string>>();
    }
}