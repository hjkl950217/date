﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Helpers;
using System;
using System.Xml.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// (已弃用)分页信息。推荐使用<see cref="PagingInfoV2"/>
    /// </summary>
    [Obsolete("请参考说明使用新方法")]
    public class PagingInfo
    {
        /// <summary>
        /// 分页的开始行
        /// </summary>
        /// <remarks>
        /// 比如分页大小是5
        /// <para>第一页传0，返回12345</para>
        /// <para>第一页传5，返回6789 10</para>
        /// </remarks>
        public int StartRowIndex { get; set; }

        /// <summary>
        /// 分页大小
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// 用来排序的字段名
        /// </summary>
        public string SortField { get; set; }

        /// <summary>
        /// 排序类型
        /// </summary>
        public SortTypeEnum SortType { get; set; }

        /// <summary>
        /// （已弃用）获取一个不使用默认的PagingInfo.推荐使用<see cref="PagingInfoV2"/>
        /// </summary>
        public static PagingInfo DefaultPaging
        {
            get => new PagingInfo
            {
                StartRowIndex = 0,
                PageSize = PagingInfoConst.PageSize_Default,
                SortType = SortTypeEnum.ASC
            };
        }

        /// <summary>
        /// （已弃用）获取一个不使用分页功能的PagingInfo.推荐使用<see cref="PagingInfoV2"/>
        /// </summary>
        /// <remarks>
        /// 有些业务可能要求带上PagingInfo但有不分页的情况
        /// </remarks>
        public static PagingInfo NonPaging
        {
            get => new PagingInfo
            {
                StartRowIndex = 0,
                PageSize = int.MaxValue,
                SortType = SortTypeEnum.ASC
            };
        }

        /// <summary>
        /// （已弃用）获取<see cref="PagingInfo"/>的XML结构。<para></para>
        ///  此类型已经弃用，停止维护。请修改为<see cref="PagingInfoV2"/>
        /// </summary>
        /// <returns></returns>
        public XElement ToXml()
        {
            XElement pageElement = new XElement("PageInfo");
            pageElement.Add(new XElement("StartRowIndex", this.StartRowIndex));
            pageElement.Add(new XElement("PageSize", this.PageSize));

            pageElement.Add(new XElement("SortField", this.SortField));
            pageElement.Add(new XElement("SortType", this.SortType.ToString()));

            return pageElement;
        }
    }
}