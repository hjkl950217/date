﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// SQL语句文件实体
    /// </summary>
    /// <remarks>
    /// 用于项目启动时导入SQL文件集合,项目中默认的文件夹名是DbCommandFiles.json
    /// </remarks>
    public class SqlCommandFiles
    {
        /// <summary>
        /// 配置的SQL文件集合
        /// </summary>
        /// <remarks>
        /// 需要带SQL DBConfigs前缀，如“SQL/Db_ApproveCenter.xml”
        /// </remarks>
        public List<string> SqlFiles { get; set; }
    }
}