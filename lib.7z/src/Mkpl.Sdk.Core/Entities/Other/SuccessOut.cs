﻿using System;
using System.Net;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 返回体-成功
    /// </summary>
    /// <remarks>
    /// 适合:某些API操作完成后仅仅只是需要告诉前端成功。<para></para>
    /// 这种情况下就适合使用此类
    /// </remarks>
    public class SuccessOut
    {
        public SuccessOut(
            string message = "Successfully",
            HttpStatusCode code = HttpStatusCode.OK
            )
        {
            this.Message = message;
            this.ResponseCode = (int)code;

            this.Time = DateTimeOffset.Now;
        }

        /// <summary>
        /// 消息
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// 响应码，通常情况下是由Http状态码转换成string
        /// </summary>
        public int ResponseCode { get; }

        /// <summary>
        /// 生成SuccessOut对象的时间
        /// </summary>
        public DateTimeOffset Time { get; }

        /// <summary>
        /// 自定义对象
        /// </summary>
        public object CustomObject { get; set; }
    }
}