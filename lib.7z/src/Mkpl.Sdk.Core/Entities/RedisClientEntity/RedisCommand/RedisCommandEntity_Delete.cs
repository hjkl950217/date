﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_Delete : RedisCommandEntity
    {
        public RedisCommandEntity_Delete(IEnumerable<string> keys)
            : base(RedisCommandTypeEnum.Del)
        {
            this.Keys = keys;
        }

        public override string Key => string.Concat(this.Keys);
        public IEnumerable<string> Keys { get; set; }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return redisCommand == RedisCommandTypeEnum.Del;
        }
    }
}