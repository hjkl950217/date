﻿namespace Mkpl.Sdk.Core.Entities
{
    public class RedisCommandEntity_String : RedisCommandEntity
    {
        public RedisCommandEntity_String(string key, string value, RedisCommandTypeEnum redisCommand)
            : base(redisCommand)
        {
            this.Key = key;
            this.Value = value;
        }

        protected override bool CheckRedisCommandType(RedisCommandTypeEnum redisCommand)
        {
            return redisCommand == RedisCommandTypeEnum.Set;
        }

        public override string Key { get; }
        public string Value { get; set; }

        public override string ToInfo(string append = null)
        {
            return base.ToInfo($"value:{this.Value}.{append}");
        }
    }
}