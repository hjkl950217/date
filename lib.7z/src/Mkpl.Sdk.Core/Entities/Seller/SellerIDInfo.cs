﻿namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 卖家ID信息，非常基本的类型
    /// </summary>
    /// <remarks>
    /// 主要从MKTPLS.dbo.EDI_Seller_BasicInfo中查询
    /// </remarks>
    public class SellerIDInfo
    {
        private string sellerID = string.Empty;

        /// <summary>
        /// 卖家ID，如BHD6
        /// </summary>
        public string SellerID
        {
            get { return this.sellerID; }
            set
            {
                this.sellerID = value?.Trim().ToUpper();
            }
        }

        /// <summary>
        /// 卖家名，一般是店铺名
        /// </summary>
        public string SellerName { get; set; }

        private string platformCode = string.Empty;

        /// <summary>
        /// 平台代码，一般是三位大写.<para></para>
        /// </summary>
        public string PlatformCode
        {
            get { return this.platformCode; }
            set
            {
                this.platformCode = value?.Trim().ToUpper();
            }
        }

        private string regionCountryCode = string.Empty;

        /// <summary>
        /// 邀请时对应的国家代码
        /// </summary>
        /// <remarks>
        /// 对应：MKTPLS.dbo.EDI_Seller_BasicInfo.BusinessRegionCode<para></para>
        /// 需要名字再调用其它的方法取得国家名字
        /// </remarks>
        public string RegionCountryCode
        {
            get { return this.regionCountryCode; }
            set
            {
                this.regionCountryCode = value?.Trim().ToUpper();
            }
        }
    }
}