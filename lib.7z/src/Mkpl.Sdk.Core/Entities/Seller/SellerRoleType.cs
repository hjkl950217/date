﻿using Mkpl.Sdk.Core.Entities.Attribute;
using System;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// Seller权限类型
    /// </summary>
    [Flags]
    public enum SellerRoleTypeEnum
    {
        /// <summary>
        /// 内部seller<para></para>
        /// 一般是指newegg的内部操作人员
        /// </summary>
        [EnumDescription(DbValue: "1")]
        InternalSeller = 0b0001, //1

        /// <summary>
        /// 一般seller<para></para>
        /// 一般是指真实seller
        /// </summary>
        [EnumDescription(DbValue: "64")]
        NormalSeller = 0b0100_0000 //64
    }
}