﻿using Mkpl.Sdk.Core.Env.Handlers;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Env
{
    public sealed class EnvironmentInfo
    {
        public static readonly EnvironmentInfo Gobal = new EnvironmentInfo();

        public void Init(IEnvironmentInfoSource source, params IEnvironmentInfoHandler[] handlers)
        {
            foreach (var handler in handlers)
            {
                handler.InitEnvironmentInfo(source, this);
            }

            foreach (var handler in handlers)
            {
                handler.Show(this);
            }
        }

        public Dictionary<string, Func<EnvironmentInfo, string>> EnvironmentVariables { get; } = new Dictionary<string, Func<EnvironmentInfo, string>>(StringComparer.OrdinalIgnoreCase);

        public void Add(string key, Func<EnvironmentInfo, string> getValue)
        {
            EnvironmentVariables.Add(key, getValue);
        }

        public bool TryGet(string key, out string value)
        {
            if (EnvironmentVariables.TryGetValue(key, out var getValue))
            {
                value = getValue?.Invoke(this);
                return true;
            }
            else
            {
                value = null;
                return false;
            }
        }
    }
}