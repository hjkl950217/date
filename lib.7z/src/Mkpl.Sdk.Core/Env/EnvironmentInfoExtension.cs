﻿namespace Mkpl.Sdk.Core.Env
{
    public static class EnvironmentInfoExtension
    {
        public static string Get(this EnvironmentInfo info, string key)
        {
            info.TryGet(key, out string value);
            return value;
        }

        public static bool IsGdev(this EnvironmentInfo info)
        {
            var env = info.GetRunEnv();
            return "gdev".EqualsIgnoreCase(env)
                || "development".EqualsIgnoreCase(env);
        }

        public static bool IsGqc(this EnvironmentInfo info)
        {
            var env = info.GetRunEnv();
            return "gqc".EqualsIgnoreCase(env);
        }

        public static bool IsPre(this EnvironmentInfo info)
        {
            var env = info.GetRunEnv();
            return "pre".EqualsIgnoreCase(env);
        }

        public static bool IsPrd(this EnvironmentInfo info)
        {
            var env = info.GetRunEnv();
            return "prd".EqualsIgnoreCase(env);
        }

        public static bool IsAutoTest(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.IsAutoTest).ToBoolOrDefault();
        }

        public static bool IsUT(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.IsUT).ToBoolOrDefault();
        }

        /// <summary>
        /// 获取当前的运行环境，如GDEV,GQC
        /// </summary>
        /// <param name="varbiable">判断自动化环境的变量名。默认为<see cref="CommomEnvNameConst.WebEnvName"/></param>
        /// <remarks>当ASPNETCORE_ENVIRONMENT对应的值没有数据时，默认为<see cref="ApplicationEnvConst.GDEV"/></remarks>
        /// <returns>一个长度大于0的字符串，或<see cref="ApplicationEnvConst.GDEV"/></returns>
        public static string GetRunEnv(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.RunEnv);
        }

        /// <summary>
        /// 获取当前的运行环境，如GDEV,GQC
        /// </summary>
        /// <param name="varbiable">判断自动化环境的变量名。默认为<see cref="CommomEnvNameConst.WebEnvName"/></param>
        /// <remarks>当ASPNETCORE_ENVIRONMENT对应的值没有数据时，默认为<see cref="ApplicationEnvConst.GDEV"/></remarks>
        /// <returns>一个长度大于0的字符串，或<see cref="ApplicationEnvConst.GDEV"/></returns>
        public static string GetEggkeeperClusterLocation(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.EggkeeperClusterLocation);
        }

        public static string GetListenUrl(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.AspnetCoreUrls);
        }

        public static string GetClusterLocation(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.ClusterLocation);
        }

        public static string GetDbDirectory(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.DbDirectory);
        }

        public static string GetConfigServiceDbKey(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.ConfigServiceDbKey);
        }

        public static string GetDomainName(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.DomainName);
        }

        public static string GetRedisClusterLocation(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.RedisClusterLocation);
        }

        public static string GetRedisKafkaServer(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.RedisKafkaServer);
        }

        public static string GetRedisKafkaTopic(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.RedisKafkaTopic);
        }

        public static string GetGenesisProjectId(this EnvironmentInfo info)
        {
            return info.Get(EnvironmentNames.GenesisProjectID);
        }
        
    }
}