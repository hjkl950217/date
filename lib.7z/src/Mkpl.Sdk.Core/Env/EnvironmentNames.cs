﻿namespace Mkpl.Sdk.Core.Env
{
    public static class EnvironmentNames
    {
        public const string DomainName = "DOMAIN_NAME";
        public const string AspnetCoreEnvironment = "ASPNETCORE_ENVIRONMENT";
        public const string AspnetCoreUrls = "ASPNETCORE_URLS";
        public const string RunEnv = "RUN_ENV";
        public const string DbDirectory = "DB_DIRECTORY";
        public const string ConfigServiceDbKey = "CONFIG_SERVICE_DB_KEY";
        public const string ClusterLocation = "CLUSTER_LOCATION";
        public const string EggkeeperClusterLocation = "EGGKEEPER_CLUSTER_LOCATION";
        public const string RedisClusterLocation = "REDIS_CLUSTER_LOCATION";
        public const string RedisKafkaServer = "REDIS_KAFKA_SERVER";
        public const string RedisKafkaTopic = "REDIS_KAFKA_TOPIC";

        /// <summary>
        /// 自动化环境的开关，一般配置为true或false 默认应该为false
        /// </summary>
        public const string IsAutoTest = "AUTO_TEST";

        public const string IsUT = "UT";
        public const string GenesisProjectID = "GENESIS_PROJECT_ID";
    }
}