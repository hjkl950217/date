﻿using System;

namespace Mkpl.Sdk.Core.Env
{
    public class EnvironmentVariableSource : IEnvironmentInfoSource
    {
        public string Get(string key)
        {
            return Environment.GetEnvironmentVariable(key);
        }
    }
}