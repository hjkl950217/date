﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class AutoTestHandler : MapHandler
    {
        public AutoTestHandler(string sourceKey = null) : base(EnvironmentNames.IsAutoTest, sourceKey, "false")
        {
        }
    }
}
