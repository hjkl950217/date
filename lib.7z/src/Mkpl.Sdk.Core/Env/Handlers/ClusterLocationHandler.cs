﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class ClusterLocationHandler : MapHandler
    {
        public ClusterLocationHandler(string sourceKey = null) : base(EnvironmentNames.ClusterLocation, sourceKey, "E11")
        {
        }
    }
}
