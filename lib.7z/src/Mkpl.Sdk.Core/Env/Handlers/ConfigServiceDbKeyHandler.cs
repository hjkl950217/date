﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class ConfigServiceDbKeyHandler : MapHandler
    {
        public ConfigServiceDbKeyHandler(string sourceKey = null) : base(EnvironmentNames.ConfigServiceDbKey, sourceKey, "dotnetDB")
        {
        }
    }
}
