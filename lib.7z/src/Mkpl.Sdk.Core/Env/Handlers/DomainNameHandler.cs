﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class DomainNameHandler : MapHandler
    {
        public DomainNameHandler(string sourceKey = null, string value = null) : base(EnvironmentNames.DomainName, sourceKey, value)
        {
        }
    }
}
