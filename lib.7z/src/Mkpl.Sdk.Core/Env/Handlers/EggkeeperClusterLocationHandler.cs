﻿namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class EggkeeperClusterLocationHandler : MapHandler
    {
        public EggkeeperClusterLocationHandler(string sourceKey = null) : base(EnvironmentNames.EggkeeperClusterLocation, sourceKey, null)
        {
        }

        public override void InitEnvironmentInfo(IEnvironmentInfoSource source, EnvironmentInfo info)
        {
            info.Add(key, i =>
            {
                var data = GetFromSource(source);
                if (!string.IsNullOrWhiteSpace(data)) return data;
                if (i.IsGdev() || i.IsGqc())
                {
                    return i.Get(EnvironmentNames.RunEnv);
                }
                else if (i.IsPre())
                {
                    return "WH7";
                }
                else
                {
                    return i.Get(EnvironmentNames.ClusterLocation);
                }
            });
        }
    }
}