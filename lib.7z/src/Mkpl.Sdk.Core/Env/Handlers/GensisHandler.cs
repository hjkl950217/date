﻿namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class GensisHandler : MapHandler
    {
        public GensisHandler() : base(EnvironmentNames.GenesisProjectID, null, null)
        {
        }
    }
}