﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public interface IEnvironmentInfoHandler
    {
        void InitEnvironmentInfo(IEnvironmentInfoSource source, EnvironmentInfo info);

        void Show(EnvironmentInfo info);
    }
}
