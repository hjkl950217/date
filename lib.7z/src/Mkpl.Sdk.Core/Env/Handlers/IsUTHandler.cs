﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class IsUTHandler : MapHandler
    {
        public IsUTHandler(string sourceKey = null) : base(EnvironmentNames.IsUT, sourceKey, "false")
        {
        }
    }
}
