﻿using System;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class MapHandler : IEnvironmentInfoHandler
    {
        protected readonly string key;
        protected readonly string sourceKey;
        protected readonly string defaultValue;

        public MapHandler(string key, string sourceKey = null, string defaultValue = null)
        {
            this.key = key;
            this.sourceKey = sourceKey ?? key;
            this.defaultValue = defaultValue;
        }

        public virtual void InitEnvironmentInfo(IEnvironmentInfoSource source, EnvironmentInfo info)
        {
            info.Add(key, i => GetFromSource(source));
        }

        public string GetFromSource(IEnvironmentInfoSource source)
        {
            var result = source.Get(sourceKey);
            if (string.IsNullOrWhiteSpace(result)
                && !string.IsNullOrWhiteSpace(defaultValue))
            {
                result = defaultValue;
            }
            return result;
        }

        public virtual void Show(EnvironmentInfo info)
        {
            Console.WriteLine($"{sourceKey} : {info.Get(key)}");
        }
    }
}