﻿using System;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class RedisClusterLocationHandler : MapHandler
    {
        public const string RedisKafkaServer_E7 = "e7-kfk-conn-dir.newegg.org:8383";
        public const string RedisKafkaServer_Test = "172.16.168.80:8092";

        public const string RedisKafkaCommand_E11 = "MKPL_Redis_Command_E11";
        public const string RedisKafkaCommand_E4 = "MKPL_Redis_Command_E4";

        public RedisClusterLocationHandler(string sourceKey = null) : base(EnvironmentNames.RedisClusterLocation, sourceKey, null)
        {
        }

        public override void InitEnvironmentInfo(IEnvironmentInfoSource source, EnvironmentInfo info)
        {
            info.Add(key, i =>
            {
                var data = GetFromSource(source);
                var result = string.IsNullOrWhiteSpace(data)
                     ? i.Get(EnvironmentNames.ClusterLocation)
                     : data;
                return result;
            });
            SetKafka(info);
        }

        public void SetKafka(EnvironmentInfo info)
        {
            info.Add(EnvironmentNames.RedisKafkaServer, i => info.IsPrd() || info.IsPre() ? RedisKafkaServer_E7 : RedisKafkaServer_Test);
            info.Add(EnvironmentNames.RedisKafkaTopic, i => info.GetRedisClusterLocation().EqualsIgnoreCase("e4") ? RedisKafkaCommand_E11 : RedisKafkaCommand_E4);
        }

        public override void Show(EnvironmentInfo info)
        {
            base.Show(info);
            Console.WriteLine($"{EnvironmentNames.RedisKafkaServer} : {info.Get(EnvironmentNames.RedisKafkaServer)}"); 
            Console.WriteLine($"{EnvironmentNames.RedisKafkaTopic} : {info.Get(EnvironmentNames.RedisKafkaTopic)}");
        }
    }
}