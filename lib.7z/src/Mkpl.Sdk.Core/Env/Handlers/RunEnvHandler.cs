﻿using Mkpl.Sdk.Core.Exceptions;

namespace Mkpl.Sdk.Core.Env.Handlers
{
    public class RunEnvHandler : MapHandler
    {
        public RunEnvHandler(string sourceKey) : base(EnvironmentNames.RunEnv, sourceKey, "GDEV")
        {
        }

        public override void InitEnvironmentInfo(IEnvironmentInfoSource source, EnvironmentInfo info)
        {
            base.InitEnvironmentInfo(source, info);
        }
    }
}