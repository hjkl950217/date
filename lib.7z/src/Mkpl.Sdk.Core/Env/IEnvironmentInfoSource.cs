﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Env
{
    public interface IEnvironmentInfoSource
    {
        string Get(string key);
    }
}
