﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ExcelMapAttribute.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ExcelMapAttribute created at  10/23/2018 9:32:00 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using System;

namespace Mkpl.Sdk.Core.Entities
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class ExcelMapAttribute : System.Attribute
    {
        public ExcelMapAttribute(string mapping)
        {
            this.Mapping = mapping;
        }

        /// <summary>
        /// 对应Excel的列名(这个是为了处理Excel的列名和实体属性不一样的情况)
        /// </summary>
        public string Mapping { get; }

        /// <summary>
        /// 控制生成的 Excel 的列顺序 (从1开始)
        /// </summary>
        public int Ordinal { get; set; }

        /// <summary>
        /// 控制生成的 Excel 的列宽 (不指定则自动适应)
        /// </summary>
        public double Width { get; set; }
    }
}