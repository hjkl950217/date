﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMpsExcelClient.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   IMpsExcelClient created at  9/7/2018 3:42:45 PM
// </summary>
//<Discription>
//
//</Discription>
// --------------------------------------------------------------------------------------------------------------------
using System.Collections.Generic;
using System.IO;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// The class of IMpsExcelClient.
    /// </summary>
    public interface IMpsExcelClient
    {
        /// <summary>
        ///读取指定的的Template并向其第一个Sheet写入数据,首先调用此方法获得内存流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data">需要导出的数据，一个集合</param>
        /// <param name="file">服务器上存放的要使用模板的文件名</param>
        /// <param name="startRow">开始写数据的行数，从1开始</param>
        /// <returns>返回一个MemoryStream</returns>
        MemoryStream BuildExcelWithTemplate<T>(List<T> data, FileInfo file, int startRow) where T : class;

        /// <summary>
        /// 往指定的Sheet写数据，传入BuildExcelWithTemplate返回的内存流
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPackage">BuildExcelWithTemplate方法返回的MemoryStream</param>
        /// <param name="data">需要导出的数据，一个集合</param>
        /// <param name="templateIndex">写数据的Sheet在模板中的位置，从1开始</param>
        /// <param name="startRow">开始写数据的行数，从1开始</param>
        /// <returns></returns>
        MemoryStream AddSheet<T>(MemoryStream excelPackage, List<T> data, int templateIndex, int startRow) where T : class;
    }
}
