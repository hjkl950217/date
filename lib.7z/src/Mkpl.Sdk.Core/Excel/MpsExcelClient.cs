﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsExcelClient.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsExcelClient created at  9/7/2018 3:46:01 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Sdk.Core.Entities;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// The class of MpsExcelClient.
    /// </summary>
    public class MpsExcelClient : IMpsExcelClient
    {
        //添加导出的属性信息的缓存
        protected static readonly Dictionary<Type, Dictionary<ColumnInfo, PropertyInfo>> _TypeColumnMappings = new Dictionary<Type, Dictionary<ColumnInfo, PropertyInfo>>();

        /// <summary>
        /// 读取指定的的Template并向第一个Sheet中写入数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data">需要导出的数据</param>
        /// <param name="file">用于导出的模板的名称，放在wwwroot下的template文件夹</param>
        /// <param name="startRow">写数据的起始行,从1开始</param>
        /// <returns></returns>
        public MemoryStream BuildExcelWithTemplate<T>(List<T> data, FileInfo file, int startRow) where T : class
        {
            using (ExcelPackage package = new ExcelPackage(file))
            {
                MemoryStream excelStream = new MemoryStream(package.GetAsByteArray());
                MemoryStream outPutSteam = this.AddSheet(excelStream, data, 1, startRow);
                return outPutSteam;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPackage"></param>
        /// <param name="data"></param>
        /// <param name="templateIndex"></param>
        /// <param name="startRow"></param>
        /// <returns></returns>
        public MemoryStream AddSheet<T>(MemoryStream excelPackage, List<T> data, int templateIndex, int startRow) where T : class
        {
            using (var package = new ExcelPackage(excelPackage))
            {
                //获取模板中指定的Sheet
                ExcelWorksheet currentSheet = package.Workbook.Worksheets[templateIndex];

                //获取实体对应的导出信息（列导出顺序）
                var columnMapping = GetTypeColumnMapping(typeof(T));

                //写入数据
                AppendRow(currentSheet, data, columnMapping, startRow);

                //获取数据的总行数，列数
                int maxRow = currentSheet.Dimension.End.Row;
                int maxColumn = currentSheet.Dimension.End.Column;

                //应用样式
                ApplyStyle(currentSheet, startRow, maxRow, maxColumn);

                MemoryStream excelStream = new MemoryStream(package.GetAsByteArray());
                //返回导出数据
                return excelStream;
            }
        }

        /// <summary>
        /// 获取列的导出顺序
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static Dictionary<ColumnInfo, PropertyInfo> GetTypeColumnMapping(Type type)
        {
            //如果内存中有本实体的导出信息，则不再解析，直接取用
            if (_TypeColumnMappings.ContainsKey(type))
            {
                return _TypeColumnMappings[type];
            }
            else
            {
                var columnMapping = new Dictionary<ColumnInfo, PropertyInfo>();
                var propertyInfoList = type.GetProperties();
                int currentOrdinal = 1;
                foreach (var property in propertyInfoList)
                {
                    var tempAttribute = property.GetCustomAttributes(typeof(ExcelMapAttribute), false);
                    if (tempAttribute.Length > 0)
                    {
                        var mapAttribute = tempAttribute[0] as ExcelMapAttribute;
                        int columnOrdinal = mapAttribute.Ordinal == 0 ? currentOrdinal : mapAttribute.Ordinal;
                        ColumnInfo columnInfo = new ColumnInfo()
                        {
                            Name = mapAttribute.Mapping,
                            Ordinal = columnOrdinal
                        };
                        columnMapping.Add(columnInfo, property);
                        currentOrdinal++;
                    }
                }
                //将导出信息加入缓存
                _TypeColumnMappings.Add(type, columnMapping);
                return columnMapping;
            }
        }

        /// <summary>
        /// 写入数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="currentSheet"></param>
        /// <param name="data">需要导出的数据</param>
        /// <param name="_columnMapping">属性和数据列的mapping关系</param>
        /// <param name="currentRowIndex">写数据的起始行</param>
        public int AppendRow<T>(ExcelWorksheet currentSheet, List<T> data, Dictionary<ColumnInfo, PropertyInfo> _columnMapping, int currentRowIndex)
        {
            if (data != null)
            {
                foreach (T singleData in data)
                {
                    foreach (var column in _columnMapping)
                    {
                        ExcelRange cell = currentSheet.Cells[currentRowIndex, column.Key.Ordinal];

                        cell.Value = column.Value.GetValue(singleData, null);
                    }
                    currentRowIndex++;
                }
            }
            return currentRowIndex;
        }

        /// <summary>
        /// 为相同列的数据单元格应用相同的样式
        /// </summary>
        /// <returns></returns>
        public ExcelWorksheet ApplyStyle(ExcelWorksheet currentSheet, int startRow, int maxRow, int maxColumn)
        {
            //遍历列
            for (int currentCol = 1 ; currentCol <= maxColumn ; currentCol++)
            {
                //从传入的起始行开始，为本列的所有单元格应用相同的样式
                for (int currentRow = startRow ; currentRow <= maxRow ; currentRow++)
                {
                    currentSheet.Cells[currentRow, currentCol].StyleID = currentSheet.Cells[startRow, currentCol].StyleID;
                }
            }
            //高度的需要单独设置，因为Height不属于Style对象
            for (int startRowindex = startRow ; startRowindex <= maxRow ; startRowindex++)
            {
                currentSheet.Row(startRowindex).Height = currentSheet.Row(startRow).Height;
                currentSheet.Row(startRowindex).StyleID = currentSheet.Row(startRow).StyleID;
            }
            currentSheet.Cells.Worksheet.Workbook.Styles.UpdateXml();
            return currentSheet;
        }
    }
}