﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsExcelExportExtension.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsExcelExportExtension created at  11/2/2018 10:25:34 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Sdk.Core.Middleware.MpsExcelExportMiddleware
{

    public static class MpsExcelClientExtension
    {
        /// <summary>
        /// The class of MpsExcelExportExtension.
        /// </summary>
        /// <summary>
        /// 注册与配置 MPS组ExcelExport
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        public static void AddExcelClientMPS(this IServiceCollection services)
        {
            //注册要用的数据节点
            services.UseEggKeeperSimplizer();

            //增加MPS组ExcelExport服务
            services.AddSingleton<IMpsExcelClient, MpsExcelClient>();
        }
    }
  
}
