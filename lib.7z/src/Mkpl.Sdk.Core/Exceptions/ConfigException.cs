﻿using System;

namespace Mkpl.Sdk.Core.Exceptions
{
    /// <summary>
    /// 配置方面的异常
    /// </summary>
    public class ConfigException : ApplicationException
    {
        public ConfigException() : base("A configuration error has occurred, please check the configuration")
        {
        }

        /// <summary>
        /// 用指定的错误消息初始化 Mkpl.Sdk.Core.Exceptions.ConfigException 类的新实例。
        /// </summary>
        /// <param name="message">错误描述</param>
        public ConfigException(string message) : base(message)
        {
        }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.ConfigException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="configName">发生错误的配置名</param>
        public ConfigException(string message, string configName)
            : base($"{message},Config Name:{configName}") { }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.ConfigException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="innerException">如果没有指定内部异常，则导致当前异常的异常或空引用
        /// （在Visual Basic中为Nothing）。
        /// </param>
        public ConfigException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// 使用指定的错误消息和对引起此异常的内部异常的引用初始化
        /// Mkpl.Sdk.Core.Exceptions.ConfigException 类的新实例。。
        /// </summary>
        /// <param name="message">错误描述</param>
        /// <param name="configName">发生错误的配置名</param>
        /// <param name="innerException">如果没有指定内部异常，则导致当前异常的异常或空引用
        /// （在Visual Basic中为Nothing）。
        /// </param>
        public ConfigException(string message, string configName, Exception innerException)
          : base($"{message},Config Name:{configName}", innerException) { }
    }
}