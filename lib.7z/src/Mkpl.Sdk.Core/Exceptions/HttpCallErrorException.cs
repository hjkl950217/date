﻿using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.Client;
using System;
using System.Net.Http;

namespace Mkpl.Sdk.Core.Exceptions
{
    /// <summary>
    /// HTTP请求时发生的异常
    /// </summary>
    public class HttpCallErrorException : HttpRequestException
    {
        public string RequestURL { get; protected set; }
        public ApiEntity ApiEntity { get; protected set; }
        public IRestApiClient RestApiClient { get; protected set; }

        /// <summary>
        /// 初始化一个<see cref="HttpCallErrorException"/>实例
        /// </summary>
        /// <param name="requestUrl">完整请求地址</param>
        /// <param name="apiEntity">当前的<see cref="ApiEntity"/></param>
        /// <param name="restApiClient">当前的<see cref="IRestApiClient"/></param>
        public HttpCallErrorException(
            string requestUrl,
            ApiEntity apiEntity,
            IRestApiClient restApiClient
            )
        {
            this.RequestURL = requestUrl;
            this.ApiEntity = apiEntity;
            this.RestApiClient = restApiClient;
        }
        /// <summary>
        /// 初始化一个<see cref="HttpCallErrorException"/>实例
        /// </summary>
        /// <param name="message">当前的错误信息</param>
        /// <param name="requestUrl">完整请求地址</param>
        /// <param name="apiEntity">当前的<see cref="ApiEntity"/></param>
        /// <param name="restApiClient">当前的<see cref="IRestApiClient"/></param>
        public HttpCallErrorException(
            string message,
            string requestUrl,
            ApiEntity apiEntity,
            IRestApiClient restApiClient
            ) : base(message)
        {
            this.RequestURL = requestUrl;
            this.ApiEntity = apiEntity;
            this.RestApiClient = restApiClient;
        }

        /// <summary>
        /// 初始化一个<see cref="HttpCallErrorException"/>实例
        /// </summary>
        /// <param name="message">当前的错误信息</param>
        /// <param name="inner">内部异常</param>
        /// <param name="requestUrl">完整请求地址</param>
        /// <param name="apiEntity">当前的<see cref="ApiEntity"/></param>
        /// <param name="restApiClient">当前的<see cref="IRestApiClient"/></param>
        public HttpCallErrorException(
            string message,
            Exception inner,
            string requestUrl,
            ApiEntity apiEntity,
            IRestApiClient restApiClient
            ) : base(message, inner)
        {
            this.RequestURL = requestUrl;
            this.ApiEntity = apiEntity;
            this.RestApiClient = restApiClient;
        }
    }
}