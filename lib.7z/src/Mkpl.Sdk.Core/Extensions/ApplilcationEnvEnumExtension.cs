﻿namespace Mkpl.Sdk.Core.Entities.ConstOrEnum.Enum
{
    public static class ApplilcationEnvEnumExtension
    {
        public static string ToEnvString(this ApplicationEnvEnum applilcationEnvEnum)
        {
            //string -> enum  在EnvHelper中

            return applilcationEnvEnum.GetDescription();
        }
    }
}