﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newtonsoft.Json;
using System.Text;

namespace Mkpl.Sdk.Core
{
    public static class ByteExtension
    {
        /// <summary>
        /// 将<see cref="byte[]"/>转换为<see cref="string"/>
        /// </summary>
        /// <param name="source"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string ToStr(this byte[] source, Encoding encoding = null)
        {
            encoding = encoding ?? Encoding.UTF8;
            return source.BaseConvertAndDefalut(string.Empty, encoding.GetString);
        }

        /// <summary>
        /// 将<see cref="byte[]"/>转换为<typeparamref name="TResult"/>
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="source"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static TResult ToObject<TResult>(this byte[] source, Encoding encoding = null)
        {
            return JsonConvert.DeserializeObject<TResult>(source.ToStr(), JsonSerializerSettingConst.StorageSetting);
        }
    }
}