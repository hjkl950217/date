﻿using Mkpl.Sdk.Core.Nair;
using System;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core
{
    public static class NairCacheExtension
    {
        /// <summary>
        /// 获取或添加数据<para></para>
        /// 如果获取到的数据为null或是0长度的数组,则调用<paramref name="dataFactory"/>创建数据并添加到nair中
        /// </summary>
        /// <typeparam name="T">数据的类型</typeparam>
        /// <param name="nairCache">缓存接口</param>
        /// <param name="key">数据的key</param>
        /// <param name="dataFactory">获取不到数据时，创建数据的委托</param>
        /// <returns></returns>
        public static T GetOrAdd<T>(
          this INairCache nairCache,
          string key,
          Func<T> dataFactory)
          where T : class
        {
            //包装成异步的委托
            Task<T> getDataAsync()
            {
                return Task.FromResult<T>(dataFactory?.Invoke());
            }

            return nairCache
                .GetOrAddAsync(key, getDataAsync)
                .GetAwaitResult<T>();
        }

        /// <summary>
        /// 异步获取或添加数据<para></para>
        /// 如果获取到的数据为null或是0长度的数组,则调用<paramref name="dataFactory"/>创建数据并添加到nair中
        /// </summary>
        /// <typeparam name="TResult">数据的类型</typeparam>
        /// <param name="nairCache">缓存接口</param>
        /// <param name="key">数据的key</param>
        /// <param name="dataFactory">获取不到数据时，创建数据的委托</param>
        /// <returns></returns>
        public static async Task<TResult> GetOrAddAsync<TResult>(
         this INairCache nairCache,
         string key,
         Func<Task<TResult>> dataFactory)
         where TResult : class
        {
            TResult result = default;
            result = nairCache.TryGet<TResult>(key);

            if (result.IsNullOrEmpty())
            {
                result = await dataFactory?.Invoke();
                nairCache.Add(key, result);
            }

            return result;
        }
    }
}