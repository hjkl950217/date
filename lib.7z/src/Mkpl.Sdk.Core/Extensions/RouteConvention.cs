﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Routing;
using System.Linq;

namespace Mkpl.Sdk.Core
{
    public class RouteConvention : IApplicationModelConvention
    {
        private readonly AttributeRouteModel _CentralPrefix;

        public RouteConvention(IRouteTemplateProvider routeTemplateProvider)
        {
            this._CentralPrefix = new AttributeRouteModel(routeTemplateProvider);
        }

        public void Apply(ApplicationModel application)
        {
            foreach (var selector in application.Controllers.SelectMany(i => i.Selectors))
            {
                selector.AttributeRouteModel = selector.AttributeRouteModel != null
                     ? AttributeRouteModel.CombineAttributeRouteModel(this._CentralPrefix, selector.AttributeRouteModel)
                    : this._CentralPrefix;
            }
        }
    }
}