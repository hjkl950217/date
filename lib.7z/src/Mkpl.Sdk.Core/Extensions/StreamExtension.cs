﻿using System.IO;

namespace Mkpl.Sdk.Core
{

    public static class StreamExtension
    {

        /// <summary>
        /// 将MemoryStream 转换为 byte数组
        /// </summary>
        /// <param name="memoryStream"></param>
        /// <returns></returns>
        public static byte[] SaveAsByte(this MemoryStream memoryStream)
        {
            if (memoryStream == null) return new byte[0];

            byte[] byteArray;
            using (memoryStream)
            {
                byteArray = memoryStream.ToArray();
            }
            return byteArray;
        }
    }
}
