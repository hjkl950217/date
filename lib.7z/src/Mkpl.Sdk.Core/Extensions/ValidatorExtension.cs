﻿namespace FluentValidation
{
    public static class ValidatorExtension
    {
        #region CheckSellerID

        /// <summary>
        /// 检查SellerID
        /// <para>不能为null或"",不忽略首位空格,长度必须是4位,忽略大小写</para>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ruleBuilder"></param>
        /// <returns></returns>
        public static IRuleBuilderOptions<T, string> CheckSellerID<T>(this IRuleBuilder<T, string> ruleBuilder)
        {
            return ruleBuilder
                .NotNull()
                .NotEmpty()
                .Length(4);
        }

        #endregion CheckSellerID

        #region Required

        /// <summary>
        /// 针对值类型的必填
        /// <para>值类型的字段，不填时有默认值，所以需要判断下是不是等于默认值</para>
        /// <para>bool不要用</para>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="ruleBuilder"></param>
        /// <param name="toCompare">要比较的值</param>
        /// <returns></returns>
        private static IRuleBuilderOptions<T, TProperty> Required<T, TProperty>(
            this IRuleBuilder<T, TProperty> ruleBuilder,
            TProperty toCompare)
        {
            return ruleBuilder
                .NotNull()
                .NotEmpty()
                .NotEqual(toCompare);
        }

        /// <summary>
        /// 引对引用类型的必填
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="ruleBuilder"></param>
        /// <returns></returns>
        public static IRuleBuilderOptions<T, TProperty> Required<T, TProperty>(this IRuleBuilder<T, TProperty> ruleBuilder)
            where TProperty : class
        {
            return ruleBuilder
                .NotNull()
                .NotEmpty();
        }

        /// <summary>
        /// 针对int类型的必填
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ruleBuilder"></param>
        /// <returns></returns>
        public static IRuleBuilderOptions<T, int> Required<T>(this IRuleBuilder<T, int> ruleBuilder)
        {
            return ruleBuilder.Required(0);//复用值类型的验证方法
        }

        #endregion Required
    }
}