﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.DFIS.Uploader;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Mkpl.Sdk.Core.Client
{
    public class DfisFileClient : IMpsFileClient
    {
        /// <summary>
        ///  dfis上传文件接口实例
        /// </summary>
        private readonly IDfispUploader dfispUploader;

        /// <summary>
        /// 获取下载配置
        /// </summary>
        private readonly IDownConfig downConfig;

        public DfisFileClient(IDfispUploader dfispUploader, IDownConfig downConfig)
        {
            this.downConfig = downConfig;
            this.dfispUploader = dfispUploader;
        }

        /// <summary>
        /// 构建一个存储在DFIS中的文件名
        /// </summary>
        /// <param name="key">配置中的key，ConfigService上是name</param>
        /// <param name="uploadIn"></param>
        /// <returns></returns>
        protected virtual string BuildFileName(string key, UploadIn uploadIn)
        {
            StringBuilder fileName = new StringBuilder();

            //sellerID
            fileName.Append(uploadIn.SellerID);
            fileName.Append("_");

            //业务标示
            if (uploadIn.BusinessName.IsNullOrEmpty() == false)//BusinessName有值
            {
                fileName.Append(uploadIn.BusinessName);
                fileName.Append("_");
            }

            //key
            if (uploadIn.IsAddKey == true)//Name有值
            {
                fileName.Append(key);
                fileName.Append("_");
            }

            //防重复代码
            string markKey = Guid.NewGuid().ToString().ToMD5(is32: false);
            fileName.Append(markKey);

            //添加文件扩展名-格式为 .XXX
            string extendName = Path.GetExtension(uploadIn.File.FileName);
            fileName.Append(extendName);

            return fileName.ToString();
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="key">上传配置中对应的key</param>
        /// <param name="uploadIn">上传数据</param>
        /// <remarks>
        /// 关于key:
        /// <para> key用来标示，配置在ConfigService上的具体配置。</para>
        /// <para>DFIS：MKPL_Common/File_Config下的DFIS节点，key对应GroupInfoList中的name</para>
        /// <para>其它还未支持</para>
        /// </remarks>
        /// <returns>返回上传后的结果</returns>
        public UploadOut UploadFile(string key, UploadIn uploadIn)
        {
            DfisFileConfigEntity config = this.GetCofnig(key).Dfis;
            string fileName = this.BuildFileName(key, uploadIn);
            Stream fileStream = uploadIn.File.OpenReadStream();

            //执行
            try
            {
                fileStream.Seek(0, SeekOrigin.Begin);//把流的标记重新定位到0
                this.dfispUploader.UploadFile(
                   postedStrem: fileStream,
                   filename: fileName,
                   uploadHostAddress: config.UploadHostAddress,
                   fileGroup: config.Group,
                   fileType: config.Type,
                   specialPath: null,
                   method: UploadMethod.Add);
            }
            catch (Exception ex)
            {
                throw new IOException($"Upload File Failed!,File:{uploadIn.File.FileName}", ex);
            }

            //准备返回的数据
            //fileName 在上面生成
            //eg: http://DownHost:8080/Group1/Type1/AAAA_096ECCA86D127E82.jpeg
            //eg2:http://DownHost:8080/Group1/Type1/AAAA_BusinessName_F6A070D57B80B92E.jpeg
            //eg3:http://DownHost:8080/Group1/Type1/AAAA_BusinessName_Name1_F6A070D57B80B92E.jpeg
            string filePath = $"{config.GetDfisUrlPrefix()}/{Uri.EscapeDataString(fileName)}";

            UploadOut result = new UploadOut()
            {
                FileName = fileName,
                FilePath = filePath,
                UploadFileName = uploadIn.File.FileName,
                HostAddress = config.DownloadHostAddress,
                SoucreType = FileSoucreTypeEnum.Dfis,
            };

            return result;
        }

        public FileConfigOut GetCofnig(string key)
        {
            return new FileConfigOut() { Dfis = this.downConfig.GetDfisDownConfig(key) };
        }

        public List<FileConfigOut> GetAllConfig()
        {
            List<FileConfigOut> result = new List<FileConfigOut>();
            foreach (var item in this.downConfig.GetAllKey())
            {
                result.Add(this.GetCofnig(item));
            }
            return result;
        }
    }
}