﻿namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// dfis上下载文件用的配置实体
    /// </summary>
    public class DfisConfigInfo
    {
        /// <summary>
        /// 配置信息组的key，标示是那一个配置.<para></para>
        /// 在公共库中会使用key而不是Name。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 业务分组
        /// </summary>
        /// <remarks>
        /// 通常为业务组名
        /// </remarks>
        public string Group { get; set; }

        /// <summary>
        /// 业务类型
        /// </summary>
        /// <remarks>
        /// 当有新业务时会向DFIS申请,他们会给一个type来存放对应的文件，这里的Type是这个意思。
        /// </remarks>
        public string Type { get; set; }
    }
}