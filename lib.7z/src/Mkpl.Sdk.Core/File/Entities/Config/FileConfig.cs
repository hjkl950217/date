﻿using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 文件操作的配置
    /// </summary>
    /// <remarks>
    /// 位于Config Service 的 MKPL_Common/File_Config  下面
    /// </remarks>
    [JsonEgg(ConfigName = "File_Config")]
    public class FileConfig
    {
        /// <summary>
        /// dfis上下载文件用的配置
        /// </summary>
        public DfisConfig Dfis { get; set; }
    }
}