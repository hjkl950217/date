﻿using System;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 文件类型帮助类
    /// </summary>
    public static class FileHelper
    {
        /// <summary>
        /// 用文件名的后缀获取对应的Http Content-Type值
        /// </summary>
        /// <param name="fileName">文件名。例：传递 "a.txt" "" ".txt" "txt"都可以</param>
        /// <remarks>
        /// 可利用<see cref="MimeMapping.MimeUtility.GetMimeMapping(string)"/>方法调试
        /// </remarks>
        /// <returns>
        /// 返回对应的HTTP Content-Type字符串.
        ///
        /// <para>返回：application/octet-stream</para>
        /// 如果传递的fileName参数找不到对应的MIME类型，则会返回此类型。
        /// 参考：https://github.com/h5bp/server-configs-nginx/blob/master/mime.types <para></para>
        /// </returns>
        /// <exception cref="ArgumentNullException">
        /// 如果传递的fileName参数为null或string.Empty则会引发此异常
        /// </exception>
        public static string GetContentType(string fileName)
        {
            //这是以前的代码
            //if(fileName.IsNullOrEmpty())
            //{
            //    throw new ArgumentNullException("value not be null",nameof(fileName));
            //}

            //return MimeMapping.MimeUtility.GetMimeMapping(fileName);

            return Newegg.MIS.Baymax.Utils.FileTypeHelper.GetContentType(fileName);
        }
    }
}