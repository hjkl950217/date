﻿using Newegg.DFIS.Uploader;
using System.IO;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// dfis上传文件接口（代理接口）
    /// </summary>
    /// <remarks>
    /// Newegg.DFIS.Uploader.HttpUploader的代理版<para></para>
    /// 因为在编写时Dfis.Uploader.Core是静态方法，无法模拟返回。
    /// 所以为了方便单元测试，用一个接口代理下。实现类其实就是调用HttpUploader里面的方法
    /// </remarks>
    public interface IDfispUploader
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="postedStrem">要上传的数据流</param>
        /// <param name="filename">上传后的文件名,相同会覆盖</param>
        /// <param name="uploadHostAddress">上传的主机地址</param>
        /// <param name="fileGroup">DFIS文件服务中的分组，类似文件空间</param>
        /// <param name="fileType">DFIS文件服务中分组下面的，类似文件夹</param>
        /// <param name="specialPath"></param>
        /// <param name="method">上传方式，参考<see cref="UploadMethod"/></param>
        void UploadFile(Stream postedStrem, string filename, string uploadHostAddress, string fileGroup, string fileType, string specialPath, UploadMethod method);
    }
}