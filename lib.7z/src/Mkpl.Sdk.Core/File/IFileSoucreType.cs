﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;

namespace Mkpl.Sdk.Core.Client
{
    public interface IFileSoucreType
    {
        /// <summary>
        /// 获取文件对应的数据源
        /// </summary>
        /// <returns></returns>
        FileSoucreTypeEnum GetFileSoucreType();
    }
}