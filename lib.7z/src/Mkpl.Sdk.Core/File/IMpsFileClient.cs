﻿using Mkpl.Sdk.Core.Entities;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Client
{
    public interface IMpsFileClient
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="key">上传配置中对应的key</param>
        /// <param name="uploadIn">上传数据</param>
        /// <remarks>
        /// 关于key:
        /// <para> key用来标示，配置在ConfigService上的具体配置。</para>
        /// <para>DFIS：MKPL_Common/File_Config下的DFIS节点，key对应GroupInfoList中的name</para>
        /// <para>其它还未支持</para>
        /// </remarks>
        /// <returns>返回上传后的结果</returns>
        UploadOut UploadFile(string key, UploadIn uploadIn);

        /// <summary>
        /// 获取<paramref name="key"/>对应的配置
        /// <param name="key">上传配置中对应的key</param>
        /// </summary>
        /// <returns></returns>
        FileConfigOut GetCofnig(string key);

        /// <summary>
        /// 获取所有config service上面关于file的配置
        /// </summary>
        /// <returns></returns>
        List<FileConfigOut> GetAllConfig();
    }
}