﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// The class of MpsHttpClient.
    /// </summary>
    public static class MpsFileClientExtension
    {
        /// <summary>
        /// 注册与配置 MPS组FileClient
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        public static void AddFileClientMPS(this IServiceCollection services)
        {
            //注册要用的数据节点
            services.UseEggKeeperSimplizer();
            services.AddSingletonConfiguration<FileConfig>();

            //增加MPS组FileClient服务
            services.AddSingleton<IDfispUploader, DfispUploader>();
            services.AddSingleton<IDownConfig, DownConfig>();
            services.AddSingleton<IMpsFileClientFactory, MpsFileClientFactory>();
        }
    }
}