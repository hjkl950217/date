﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core.Client
{
    public class MpsFileClientFactory : IMpsFileClientFactory
    {
        ///// <summary>
        ///// 整个文件配置
        ///// </summary>
       // private readonly FileConfig fileConfig;

        /// <summary>
        ///  dfis上传文件接口实例
        /// </summary>
        private readonly IDfispUploader dfispUploader;

        /// <summary>
        /// 获取下载配置
        /// </summary>
        private readonly IDownConfig downConfig;

        public MpsFileClientFactory(FileConfig fileConfig, IDfispUploader dfispUploader, IDownConfig downConfig)
        {
            if (fileConfig.IsNullOrEmpty() == true)
            {
                throw new ArgumentException($"object is null for '{nameof(FileConfig)}',Please check ConfigService");
            }

           // this.fileConfig = fileConfig;
            this.downConfig = downConfig;
            this.dfispUploader = dfispUploader;
        }

        protected virtual IMpsFileClient BaseBuild(FileSoucreTypeEnum fileSoucreTypeEnum)
        {
            //配置检测

            #region 按不同类型返回

            switch (fileSoucreTypeEnum)
            {
                case FileSoucreTypeEnum.Dfis:
                    return new DfisFileClient(this.dfispUploader, this.downConfig);

                case FileSoucreTypeEnum.FTP:
                    throw new NotImplementedException();

                default:
                    throw new InvalidOperationException($"Invalid Operation for BuildMpsFileClient,Error Type:{fileSoucreTypeEnum.ToString()}");
            }

            #endregion 按不同类型返回
        }

        /// <summary>
        /// 获取DFIS文件操作客户端
        /// </summary>
        /// <remarks>使用MKPL_Common/File_Config下的DFIS节点</remarks>
        /// <returns></returns>
        public IMpsFileClient GetDfisFileClient()
        {
            return this.BaseBuild(FileSoucreTypeEnum.Dfis);
        }
    }
}