﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Entities.ConstOrEnum.Enum;
using System;

namespace Mkpl.Sdk.Core.Helpers
{
    /// <summary>
    /// 环境帮助类
    /// </summary>
    public static class EnvHelper
    {
        /// <summary>
        /// 基础判断
        /// </summary>
        /// <param name="judgeExpression">判断表达式</param>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// <returns></returns>
        private static bool BaseJudge(Func<string, bool> judgeExpression, string envName = null)
        {
            envName = envName ?? EnvHelper.GetRunEnv();

            return judgeExpression(envName);
        }

        /// <summary>
        /// 判断当前环境是否是PRE PRD
        /// </summary>
        /// <returns>为true时表示是PRE PRD环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV GQC  Development时，返回的是false</para>
        /// <para>当取出的值是其它时，返回的是true</para>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// </remarks>
        public static bool IsPreOrPrd(string envName = null)
        {
            bool juge(string env)
            {
                return EnvHelper.IsPre(env) == true
                    || EnvHelper.IsPrd(env) == true;
            }

            return EnvHelper.BaseJudge(juge, envName);
        }

        /// <summary>
        /// 判断当前环境是否是PRD
        /// </summary>
        /// <returns>为true时表示是PRD环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于PRE、GQC、Development时，返回的是false</para>
        /// <para>当取出的值是其它时，返回的是true</para>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// </remarks>
        public static bool IsPrd(string envName = null)
        {
            bool juge(string env)
            {
                bool result = (env.EqualsLoose(ApplicationEnvConst.Development) == true)
                    || (env.EqualsLoose(ApplicationEnvConst.GDEV) == true)
                    || (env.EqualsLoose(ApplicationEnvConst.GQC) == true)
                    || (env.EqualsLoose(ApplicationEnvConst.PRE) == true);
                return result == false;//排除前面的 就是prd
            }

            return EnvHelper.BaseJudge(juge, envName);
        }

        /// <summary>
        /// 是否是产品测试环境
        /// </summary>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// <returns></returns>
        public static bool IsPre(string envName = null)
        {
            return EnvHelper.BaseJudge(
                t => t.EqualsLoose(ApplicationEnvConst.PRE) == true,
                envName);
        }

        /// <summary>
        /// 是否是集成测试环境
        /// </summary>
        /// <returns>为true时表示是开发环境环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV 或 Development时，返回的是true</para>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// </remarks>
        public static bool IsGqc(string envName = null)
        {
            return EnvHelper.BaseJudge(
                t => t.EqualsLoose(ApplicationEnvConst.GQC) == true,
                envName);
        }

        /// <summary>
        /// 是否是开发环境
        /// </summary>
        /// <returns>为true时表示是开发环境环境</returns>
        /// <remarks>
        /// 取环境变量中的ASPNETCORE_ENVIRONMENT值
        /// <para>当取出的值等于GDEV 或 Development时，返回的是true</para>
        /// <param name="envName">环境名。为null时会自己<see cref="EnvHelper.GetRunEnv"/>获取</param>
        /// </remarks>
        public static bool IsDev(string envName = null)
        {
            bool juge(string env)
            {
                return (env.EqualsLoose(ApplicationEnvConst.Development) == true)
                || (env.EqualsLoose(ApplicationEnvConst.GDEV) == true);
            }

            return EnvHelper.BaseJudge(juge, envName);
        }

        /// <summary>
        /// 获取当前的运行环境，如GDEV,GQC
        /// </summary>
        /// <param name="varbiable">环境变量名,获取运行环境</param>
        /// <remarks>当ASPNETCORE_ENVIRONMENT对应的值没有数据时，默认为GDEV</remarks>
        /// <returns>一个长度大于0的字符串，或“GDEV”</returns>
        public static string GetRunEnv(string varbiable = "ASPNETCORE_ENVIRONMENT")
        {
            string env = System.Environment.GetEnvironmentVariable(varbiable)
                ?.Trim()
                .ToUpper();

            return env.IsNullOrEmpty() ? ApplicationEnvConst.GDEV : env;
        }

        public static ApplicationEnvEnum GetRunEnvEnum(string varbiable = "ASPNETCORE_ENVIRONMENT")
        {
            return ConvertToEnvEnum(GetRunEnv(varbiable));
        }

        /// <summary>
        /// 获取创世纪中当前项目被分配的项目ID
        /// </summary>
        ///  <param name="varbiable">环境变量名,获取项目ID</param>
        /// <returns>如果取到则返回有值的数据，没有取到返回""</returns>
        public static string GetGenesisProjectId(string varbiable = "GENESIS_PROJECT_ID")
        {
            string projectId = Environment.GetEnvironmentVariable(varbiable);

            if (projectId.IsNullOrEmpty() == true)
            {
                projectId = string.Empty;
            }

            return projectId;
        }

        /// <summary>
        /// 获取环境变量的值
        /// </summary>
        /// <param name="varbiable">环境变量名，大小写敏感</param>
        /// <returns>获取不到时返回<see cref="string.Empty"/></returns>
        public static string GetVariableFromEnv(string varbiable)
        {
            string result = Environment.GetEnvironmentVariable(varbiable)
                ?? string.Empty;

            return result;
        }

        /// <summary>
        /// 获取当前程序运行的机房<para></para>
        /// 会将值转换成大写.<para></para>
        /// 固定值：GDEV,GQC,WH7,E4,E11<para></para>
        /// 产线总配置:WH7,E4,E11<para></para>
        /// GDEV:GDEV<para></para>
        /// GQC:GQC<para></para>
        /// PRE:E11<para></para>
        /// PRD:E4,E11<para></para>
        /// </summary>
        /// <param name="varbiable"></param>
        /// <returns></returns>
        public static string GetLocation(string varbiable = "HUMPBACK_CLUSTER_LOCATION")
        {
            if (EnvHelper.IsDev() || EnvHelper.IsGqc())
            {
                return EnvHelper.GetRunEnv();
            }
            else if (EnvHelper.IsPreOrPrd())
            {
                return GetVariableFromEnv(varbiable).ToUpper();
            }
            else
            {
                throw new System.NotSupportedException("env error");
            }
        }

        /// <summary>
        /// 讲环境值转换为枚举，匹配不上时会排除<see cref="System.NotSupportedException"/>
        /// </summary>
        /// <param name="envValue"></param>
        /// <exception cref="NotSupportedException">当<paramref name="envValue"/>的值与<see cref="ApplicationEnvConst"/>中不一致时会抛出</exception>
        /// <returns></returns>
        public static ApplicationEnvEnum ConvertToEnvEnum(string envValue)
        {
            envValue.CheckNull(nameof(envValue));

            switch (envValue)
            {
                case string _ when ApplicationEnvConst.Development.EqualsIgnoreCase(envValue):
                    return ApplicationEnvEnum.Development;

                case string _ when ApplicationEnvConst.GDEV.EqualsIgnoreCase(envValue):
                    return ApplicationEnvEnum.GDEV;

                case string _ when ApplicationEnvConst.GQC.EqualsIgnoreCase(envValue):
                    return ApplicationEnvEnum.GQC;

                case string _ when ApplicationEnvConst.PRE.EqualsIgnoreCase(envValue):
                    return ApplicationEnvEnum.PRE;

                case string _ when ApplicationEnvConst.PRD.EqualsIgnoreCase(envValue):
                    return ApplicationEnvEnum.PRD;

                default: throw new System.NotSupportedException($"not Supported value:{envValue}");
            }
        }
    }
}