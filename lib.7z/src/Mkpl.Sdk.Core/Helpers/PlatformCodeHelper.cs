﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Helpers
{
    public static class PlatformCodeHelper
    {
        /// <summary>
        /// 检查集合,检查失败后返回false.<para></para>
        /// 大小写敏感、空格敏感
        /// </summary>
        /// <param name="platformCodeList"></param>
        /// <returns></returns>
        public static bool CheckPlatformCode(IEnumerable<string> platformCodeList)
        {
            var result = (from a in platformCodeList.Distinct()
                          where a.IsNotNullOrEmpty()
                          && !PlatformConst.PlatformCodeList.Contains(a)
                          select a).Any();

            //排除掉默认平台值之后还有数据，则代表传递的数据不对
            return !result;
        }

        /// <summary>
        /// 检查集合,检查失败后返回false.<para></para>
        /// 大小写敏感、空格敏感
        /// </summary>
        /// <param name="platformCode"></param>
        /// <returns></returns>
        public static bool CheckPlatformCode(string platformCode)
        {
            return CheckPlatformCode(new string[] { platformCode });
        }

        /*
         *   修改后就是CheckPlatformCode的UT
    public class CheckPlatformCodeTest
        {
            [Fact]
            public void SingleData_True()
            {
                string[] testList = new string[] { PlatformConst.Platform_USA };
                TestController testController = MockHelper.GetMockTestController();

                bool result = testController.CheckPlatformCodeArry(testList);

                Assert.True(result);
            }

            [Fact]
            public void SingleData_False()
            {
                string[] testList = new string[] { "asd" };
                TestController testController = MockHelper.GetMockTestController();

                bool result = testController.CheckPlatformCodeArry(testList);

                Assert.False(result);
            }

            [Fact]
            public void SingleEmpty_True()
            {
                string[] testList = new string[] { string.Empty };
                TestController testController = MockHelper.GetMockTestController();

                bool result = testController.CheckPlatformCodeArry(testList);

                Assert.True(result);
            }

            [Fact]
            public void TwoData_True()
            {
                string[] testList = new string[] { PlatformConst.Platform_USA, PlatformConst.Platform_USB };
                TestController testController = MockHelper.GetMockTestController();

                bool result = testController.CheckPlatformCodeArry(testList);

                Assert.True(result);
            }

            [Fact]
            public void TwoData_False()
            {
                string[] testList = new string[] { "asd", PlatformConst.Platform_USB };
                TestController testController = MockHelper.GetMockTestController();

                bool result = testController.CheckPlatformCodeArry(testList);

                Assert.False(result);
            }
        }
         */
    }
}