﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OtherTeamConfig.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   OtherTeamConfig created at  4/28/2018 11:04:19 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.EggKeeper.Sdk.Default;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// 对其他团队API引用的数据
    /// </summary>
    /// <remarks>
    /// 位于Config Service上的MKPL_Common下的AllAPIConfig节点
    /// </remarks>
    [JsonEgg(ConfigName = "AllAPIConfig")]
    public class AllApiConfig
    {
        /// <summary>
        /// DeveloperPlatform上的API地址
        /// </summary>
        /// <remarks>
        /// 只有在团队中的BaseHost取不到时使用这个地址
        /// </remarks>
        public string DevPlatformHost { get; set; }

        private Dictionary<string, TeamConfigEntity> teamApiConfigList { get; set; }

        /// <summary>
        /// 其他团队api数据集合
        /// </summary>
        public Dictionary<string, TeamConfigEntity> TeamApiConfigList
        {
            get => teamApiConfigList;
            set
            {
                teamApiConfigList = new Dictionary<string, TeamConfigEntity>(value, StringComparer.OrdinalIgnoreCase);
                TeamApiEnumConfigList = new Dictionary<TeamNameEnum, TeamConfigEntity>();

                //如果teamApiConfigList中的值是泛型的，则添加到泛型
                foreach (TeamNameEnum item in Enum.GetValues(typeof(TeamNameEnum)))
                {
                    if (teamApiConfigList.TryGetValue(item.GetDescription(), out var teamConfig))
                    {
                        this.TeamApiEnumConfigList.TryAdd(item, teamConfig);
                    }
                }
            }
        }

        public Dictionary<TeamNameEnum, TeamConfigEntity> TeamApiEnumConfigList { get; protected set; }
    }
}