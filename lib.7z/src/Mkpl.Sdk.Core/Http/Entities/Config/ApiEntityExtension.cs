﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApiEntityExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   ApiEntityExtension created at  4/28/2018 1:28:31 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System.Text;

namespace Mkpl.Sdk.Core.Entities
{
    public static class ApiEntityExtension
    {
        /// <summary>
        /// 获取有域名的绝对请求地址
        /// </summary>
        /// <returns></returns>
        public static string GetAbsoluteURL(this ApiEntity apiEntity)
        {
            return $"{apiEntity.Host}{apiEntity.Address}";
        }

        /// <summary>
        /// 获取有域名的绝对请求地址,适用于GET方法有查询字符串的情况。
        /// </summary>
        /// <param name="apiEntity"></param>
        /// <param name="queryStrList">查询条件值，按请按顺序输入</param>
        /// <remarks>
        /// <para>数据格式请自己保证，这里不会做处理</para>
        /// 使用请参考<see cref="StringBuilder.AppendFormat(string, object[])"/>
        /// </remarks>
        /// <returns></returns>
        public static string GetAbsoluteURL(this ApiEntity apiEntity, params object[] queryStrList)
        {
            if (queryStrList.IsNullOrEmpty() == true) return apiEntity.GetAbsoluteURL();

            StringBuilder url = new StringBuilder();
            string formatBefore = GetAbsoluteURL(apiEntity);//处理?号前面的东西

            url.AppendFormat(formatBefore, queryStrList);

            return url.ToString();
        }
    }
}