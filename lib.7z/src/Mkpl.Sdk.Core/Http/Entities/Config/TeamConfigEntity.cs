﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OtherTeamConfigEntity.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   OtherTeamConfigEntity created at  4/28/2018 11:02:37 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    ///
    /// </summary>
    public class TeamConfigEntity
    {
        /// <summary>
        /// 基础Token
        /// </summary>
        public string BaseToken { get; set; }

        /// <summary>
        /// API数据集合
        /// </summary>
        public Dictionary<string, ApiEntity> ApiConfigList { get; set; }
    }
}