﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpHeaderConst.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   HttpHeaderConst created at  5/10/2018 1:32:24 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using System;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 在Http通信中需要的头部名常量
    /// </summary>
    public static class HttpHeaderNameConst
    {
        /// <summary>
        /// 认证中间件使用的头
        /// </summary>
        /// <remarks>
        /// 第一次重构登陆时使用此头，后面单点登陆上线后弃用。<para></para>
        ///
        /// 请使用:
        ///
        /// </remarks>
        [Obsolete("已弃用，请参考说明使用新头")]
        public const string MpsToken = "Authentication";

        /// <summary>
        /// MPS组老项目-认证中间件使用的头
        /// </summary>
        public const string MpsRestApiToken = "AuthorizationToken";

        /// <summary>
        /// 标准认证头
        /// </summary>
        public const string Authorization = "Authorization";

        /// <summary>
        /// 单点登陆后，认证中间件取token的头
        /// </summary>
        public const string MpsJwtToken = "X-Authorization-JWT";

        /// <summary>
        /// 单点登陆后，从QueryString取token的名
        /// </summary>
        public const string MpsJwtTokenInQueryString = "jwt";

        /// <summary>
        /// 源IP，通过API网关过来的请求需要用这个头取到真实源IP
        /// </summary>
        public const string XSoucreIP = "X-Source-IP";

        /// <summary>
        /// User-Agent头的名字
        /// </summary>
        public const string UserAgent = "User-Agent";

        /// <summary>
        /// Content-Type头的名字,响应内容的格式
        /// </summary>
        public const string ContentType = "Content-Type";

        /// <summary>
        /// Accept头的名字,表示接受什么类型
        /// </summary>
        public const string Accept = "Accept";

        /// <summary>
        /// Content-Language头的名字，响应内容的语言
        /// </summary>
        public const string ContentLanguage = "Content-Language";

        /// <summary>
        /// Cache-Control头的名字,缓存控制
        /// </summary>
        public const string CacheControl = "Cache-Control";

        /// <summary>
        /// 平台头的名字,用来标识当前请求需要请求那个平台
        /// </summary>
        public const string MpsPlatformCode = "MPS-PlatformCode";

        /// <summary>
        /// 认证失败时，用来描述错误信息的头
        /// </summary>
        public const string UnAuthorizationDescription = "WWW-Authenticate";
    }
}