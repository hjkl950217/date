﻿using Mkpl.Sdk.Core.Entities.Attribute;

namespace Mkpl.Sdk.Core.Entities.ConstOrEnum
{
    /// <summary>
    /// 客户端类型枚举
    /// </summary>
    public enum HttpClientTypeEnum
    {
        /// <summary>
        /// MPS的Rest类型，也就是普通的请求客户端
        /// </summary>
        [EnumDescription(Description: "MpsRest")]
        MpsRest,

        /// <summary>
        /// MPS的OAuth类型，也就是OAuth的请求客户端
        /// </summary>
        [EnumDescription(Description: "MpsOAuth")]
        MpsOAuth,
    }
}