﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Newegg.MIS.Baymax.Client.Attributes
{
    /// <summary>
    /// 使用方式：
    /// public interface ITestClient
    /// {
    ///     [MkplClientConfig(TeamNameEnum.CdEc, "apiKey")]
    ///     [HttpGet()]
    ///     string Get();
    /// }
    ///
    /// 更多使用参考 baymax 文档
    /// </summary>
    public sealed class MkplClientConfigAttribute : HttpClientConfigAttribute
    {
        private readonly TeamNameEnum teamNameKey;
        private readonly string apiKey;

        public MkplClientConfigAttribute(TeamNameEnum teamNameKey, string apiKey)
        {
            this.teamNameKey = teamNameKey;
            this.apiKey = apiKey;
        }

        public override void Config(IRestApiClient client, IConfiguration configuration, IServiceProvider serviceProvider)
        {
            var config = serviceProvider.GetRequiredService<AllApiConfig>();//取到api的配置
            if (config.TeamApiEnumConfigList.TryGetValue(this.teamNameKey, out TeamConfigEntity teamConfig))
            {
                ApiEntity apiConfig = teamConfig.FindApi(this.apiKey, config.DevPlatformHost);
                client.BaseUri = apiConfig.GetAbsoluteURL();
                client.SetOAuthToken(apiConfig.Token);
            }
            else
            {
                throw new ArgumentException($"key not found in '{nameof(AllApiConfig)}.TeamApiConfigList'  key: {this.teamNameKey}");
            }
        }
    }
}