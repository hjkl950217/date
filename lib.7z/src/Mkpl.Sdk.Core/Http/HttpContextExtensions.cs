﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   HttpExtension created at  4/14/2018 10:24:51 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Linq;

namespace Microsoft.AspNetCore.Http
{
    /// <summary>
    /// Http请求响应相关的扩展
    /// </summary>
    public static class HttpContextExtensions
    {
        /// <summary>
        /// 获取URL对象,获取失败时会返回null
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public static Uri GetUri(this HttpRequest request)
        {
            UriBuilder uriBuilder = new UriBuilder
            {
                Scheme = request?.Scheme,
                Host = request?.Host.Host,
                Path = request?.Path.ToString(),
                Query = request?.QueryString.ToString()
            };

            bool isNullUrl = uriBuilder.Host.IsNullOrEmpty();
            if (isNullUrl == true) return null;
            return uriBuilder.Uri;
        }

        /// <summary>
        /// 获取不带端口的绝对URL地址
        /// </summary>
        /// <param name="request"></param>
        /// <returns>获取不到时返回string.Empty，否则为不带端口的绝对URL地址</returns>
        public static string GetAbsoluteUri(this HttpRequest request)
        {
            string result = request?.GetUri()?.AbsoluteUri;
            return string.IsNullOrEmpty(result) == true ? string.Empty : result;
        }

        /// <summary>
        /// 获取远程客户端的 IP 主机地址<para></para>
        /// 会优先获取X-Source-IP，获取不到时会获取请求连接中的IP
        /// </summary>
        /// <returns>
        /// 优先获取X-Source-IP，获取不到时会获取请求连接中的IP.<para></para>
        /// 请求中的IP默认是"::1"
        /// </returns>
        public static string GetRemoteIpAddress(this HttpContext httpContext)
        {
            //X-Source-IP 不分大小写
            string xIP = httpContext.Request
                .Headers[HttpHeaderNameConst.XSoucreIP]
                .ToString();

            //请求中的IP地址
            string remoteIp = httpContext.Connection
                      .RemoteIpAddress
                      .ToString();

            string ip = xIP.IsNotNullOrEmpty() ? xIP : remoteIp;
            return ip;
        }
    }
}