﻿using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;

namespace Mkpl.Sdk.Core.Entities
{
    public class IPAddressRange
    {
        private byte[] beginIpv4;
        private byte[] beginIpv6;

        public string Begin
        {
            set
            {
                var (v4, v6) = ConvertIp(value);
                beginIpv4 = v4;
                beginIpv6 = v6;
            }
        }

        private byte[] endIpv4;
        private byte[] endIpv6;

        public string End
        {
            set
            {
                var (v4, v6) = ConvertIp(value);
                endIpv4 = v4;
                endIpv6 = v6;
            }
        }

        public bool IsInRangeByIpv6(string address)
        {
            byte[] addressBytes = IPAddress.Parse(address).GetAddressBytes();
            bool lowerBoundary = true, upperBoundary = true;

            for (int i = 0 ; i < beginIpv6.Length &&
                (lowerBoundary || upperBoundary) ; i++)
            {
                if ((lowerBoundary && addressBytes[i] < beginIpv6[i]) ||
                    (upperBoundary && addressBytes[i] > endIpv6[i]))
                {
                    return false;
                }

                lowerBoundary &= (addressBytes[i] == beginIpv6[i]);
                upperBoundary &= (addressBytes[i] == endIpv6[i]);
            }

            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool TryIsInRange(ref bool lowerBoundary, ref bool upperBoundary, byte currentValue, int index)
        {
            if ((lowerBoundary && currentValue < beginIpv4[index]) ||
               (upperBoundary && currentValue > endIpv4[index]))
            {
                return false;
            }
            lowerBoundary &= (currentValue == beginIpv4[index]);
            upperBoundary &= (currentValue == endIpv4[index]);
            return true;
        }

        public bool IsInRangeByIpv4(string address)
        {
            var index = 0;
            var result = true;
            byte currentValue = 0;
            bool lowerBoundary = true, upperBoundary = true;

            char ch;
            for (int i = 0 ; i < address.Length ; i++)
            {
                ch = address[i];
                if (ch == '.')
                {
                    result = TryIsInRange(ref lowerBoundary, ref upperBoundary, currentValue, index);
                    index++;
                    if (result)
                    {
                        currentValue = 0;
                    }
                    else
                    {
                        break;
                    }
                }
                else if ('0' <= ch && ch <= '9')
                {
                    currentValue = (byte)((currentValue * 10) + ch - '0');
                }
                else
                {
                    break;
                }
            }
            if (result)
            {
                result = TryIsInRange(ref lowerBoundary, ref upperBoundary, currentValue, index);
            }
            return result;
        }

        private static (byte[] ipv4, byte[] ipv6) ConvertIp(string ipString)
        {
            var ip = IPAddress.Parse(ipString);
            byte[] ipv4;
            byte[] ipv6;
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                ipv6 = ip.MapToIPv6().GetAddressBytes();
                ipv4 = ip.GetAddressBytes();
            }
            else
            {
                ipv6 = ip.GetAddressBytes();
                ipv4 = ip.MapToIPv4().GetAddressBytes();
            }

            return (ipv4, ipv6);
        }
    }
}