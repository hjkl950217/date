﻿using System.Collections.Generic;
using System.Linq;

namespace Mkpl.Sdk.Core.Entities
{
    public class IPAddressRangeCollection : List<IPAddressRange>
    {
        public bool IsInRange(string ip)
        {
            if (ip.Contains(":"))
            {
                return this.Any(i => i.IsInRangeByIpv6(ip));
            }
            else
            {
                return this.Any(i => i.IsInRangeByIpv4(ip));
            }
        }
    }
}