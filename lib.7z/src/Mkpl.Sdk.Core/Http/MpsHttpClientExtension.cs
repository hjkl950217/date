﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsHttpClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsHttpClient created at  4/28/2018 3:15:51 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.EggKeeper.Sdk.Default;

namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// The class of MpsHttpClient.
    /// </summary>
    public static class MpsHttpClientExtension
    {
        /// <summary>
        /// 注册与配置 MPS组Httplient
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        public static void AddHttpClientMPS(this IServiceCollection services)
        {
            //注册要用的数据节点
            services.UseEggKeeperSimplizer();
            services.AddSingletonConfiguration<AllApiConfig>();

            //增加MPS组HttpClient服务
            services.AddSingleton<IMpsHttpClientFactory, MpsHttpClientFactory>();
        }
    }
}