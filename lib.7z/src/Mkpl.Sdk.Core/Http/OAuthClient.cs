﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OAuthClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   OAuthClient created at  4/28/2018 11:23:28 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.Client;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// OAuth的HttpClient请求客户端
    /// </summary>
    /// <remarks>也相当与实现了IMpsHttpClient接口</remarks>
    public class OAuthClient : RestClient
    {
        /// <summary>
        /// OAuth的HttpClient请求客户端初始化
        /// </summary>
        /// <param name="clientFactory">Baymax注册的IRestApiClientFactory实例</param>
        /// <param name="devHost"> DeveloperPlatform上的API地址</param>
        /// <param name="teamConfigEntity"> 团队配置</param>
        public OAuthClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
            : base(clientFactory, devHost, teamConfigEntity)
        { }

        #region 内部方法

        protected override IRestApiClient BuildClient(
            RequestHead requestHead = null,
            string CustomToken = null,
            bool isStreamRequest = false)
        {
            IRestApiClient client = base.BuildClient(requestHead, CustomToken, isStreamRequest);

            //处理OAuth中的Authorization数据
            if (client.Authorization != null)
            {
                client.Authorization = $"Bearer {client.Authorization}";
            }

            return client;
        }

        #endregion 内部方法
    }
}