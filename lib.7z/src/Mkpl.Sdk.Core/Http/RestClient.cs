﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RestClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   RestClient created at  4/28/2018 10:59:58 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Exceptions;
using Newegg.MIS.Baymax.Client;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// 普通HttpClient请求客户端
    /// </summary>
    /// <remarks>
    /// 目前也是所有HttpClient的BaseClient
    /// <para>其他Client会继承这个类并重写内部方法</para>
    /// </remarks>
    public partial class RestClient : IMpsHttpClient
    {
        /// <summary>
        /// 团队节点的配置
        /// </summary>
        /// <remarks>
        /// 运行时由构造方法赋值，根据团队名字获取
        /// </remarks>
        protected virtual TeamConfigEntity TeamConfig { get; set; }

        protected virtual string DevPlatformHost { get; set; }
        protected readonly IRestApiClientFactory clientFactory;

        /// <summary>
        /// 普通HttpClient请求客户端初始化
        /// </summary>
        /// <param name="clientFactory">Baymax注册的IRestApiClientFactory实例</param>
        /// <param name="devHost"> DeveloperPlatform上的API地址</param>
        /// <param name="teamConfigEntity"> 团队配置</param>
        public RestClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
        {
            this.clientFactory = clientFactory;
            this.DevPlatformHost = devHost;
            this.TeamConfig = teamConfigEntity;
        }

        #region 内部方法

        /// <summary>
        /// 发送请求方法-按httpMethod调用对应的方法
        /// </summary>
        /// <typeparam name="TResult">接口类型</typeparam>
        /// <param name="apiKey">ConfigService上配置的，具体API配置对应的key</param>
        /// <param name="httpMethod">baymax中的HttpMethod</param>
        /// <param name="isStreamRequest">响应数据是否按流处理。效果：不序列化，直接返回响应流</param>
        /// <param name="requestData">请求数据</param>
        /// <param name="requestHead">请求头</param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        protected virtual Task<TResult> BaseRequest<TResult>(
            string apiKey,
            string httpMethod,
            bool isStreamRequest = false,
            object requestData = null,
            RequestHead requestHead = null,
            params object[] queryStrList)
        {
            //处理数据
            requestData = requestData ?? new { };

            //获取访问地址
            ApiEntity apiInfo = this.TeamConfig.FindApi(apiKey, this.DevPlatformHost);
            string requestUrl = apiInfo.GetAbsoluteURL(queryStrList);

            //构建请求客户端
            IRestApiClient client = this.BuildClient(
                requestHead,
                apiInfo.Token,
                isStreamRequest);

            try
            {
                //按不同的HTTP方法执行并直接返回
                switch (httpMethod)
                {
                    case HttpMethod.Post:
                        return client.PostAsync<TResult>(requestUrl, requestData);

                    case HttpMethod.Get:
                        return client.GetAsync<TResult>(requestUrl, requestData);

                    default:
                        throw new System.NotImplementedException("This HttpMethod not implement in mpsHttpClient");
                }
            }
            catch (Exception ex)
            {
                throw this.BuildHttpErrorException(requestUrl, apiInfo, client, ex);
            }
        }

        /// <summary>
        /// 内部创建IRestApiClient的方法
        /// </summary>
        /// <param name="requestHead"></param>
        /// <param name="CustomToken">要指定的Authorization值</param>
        /// <param name="isStreamRequest">响应数据是否按流处理。效果：不序列化，直接返回响应流</param>
        /// <returns></returns>
        protected virtual IRestApiClient BuildClient(
            RequestHead requestHead = null,
            string CustomToken = null,
            bool isStreamRequest = false)
        {
            //初始化数据
            if (requestHead == null) requestHead = this.GetDefaultHead();
            IRestApiClient client = this.clientFactory.Build(string.Empty);

            //循环添加自定义头部数据
            foreach (var item in requestHead.CustomHeaderList)
            {
                client.AddCustomHeader(item.Key, item.Value);
            }

            client.Authorization = CustomToken;
            client.SetUserAgent(requestHead.UserAgent);
            client.SetAccept(requestHead.Accept);
            client.ContentType = requestHead.ContentType;
            client.Proxy = WebRequest.DefaultWebProxy;
            client.IsThrowWebServiceException = true;//true时抛出原生的异常，不带处理

            //处理
            if (isStreamRequest == true)//自定义响应流反序列化
            {
                Stream custom(Stream stream, Type type)
                {
                    return stream;
                }
                client.RawDeserializer = custom;
            }

            return client;
        }

        /// <summary>
        /// 构建一个http请求异常，返回出去。
        /// </summary>
        /// <param name="requestUrl">完整请求地址</param>
        /// <param name="apiEntity">当前的<see cref="ApiEntity"/></param>
        /// <param name="restApiClient">当前的<see cref="IRestApiClient"/></param>
        /// <param name="ex">低层http调用组件返回的异常</param>
        /// <returns></returns>
        protected virtual HttpCallErrorException BuildHttpErrorException(
            string requestUrl,
            ApiEntity apiEntity,
            IRestApiClient restApiClient,
            Exception ex)
        {
            return new HttpCallErrorException(ex.Message, ex.InnerException, requestUrl, apiEntity, restApiClient);
        }

        #endregion 内部方法

        #region 接口实现

        #region 其它方法

        /// <summary>
        /// 获取一个默认的请求头对象
        /// </summary>
        /// <param name="accept"></param>
        /// <returns></returns>
        public RequestHead GetDefaultHead(string accept = null)
        {
            //为了以后方便扩展，所以获取默认头对象独立成一个方法了

            if (accept == null)
            {
                return new RequestHead();
            }
            else
            {
                return new RequestHead(accept);
            }
        }

        #endregion 其它方法

        #region GET

        /// <summary>
        /// 发送GET请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        public virtual TResult Get<TResult>(
            string apiKey,
            object queryData = null,
            RequestHead requestHead = null,
            params object[] queryStrList
            )
        {
            return this.GetAsync<TResult>(apiKey, queryData, requestHead, queryStrList)
                .GetAwaitResult();
        }

        /// <summary>
        /// 发送GET异步请求
        /// </summary>
        /// <typeparam name="TResult">返回数据要被序列化的类型</typeparam>
        /// <param name="apiKey">团队节点中配置的apiKey</param>.
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>请求的接口有特殊要求再传</para>
        /// </param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        public virtual Task<TResult> GetAsync<TResult>(
            string apiKey,
            object queryData = null,
            RequestHead requestHead = null,
            params object[] queryStrList
            )
        {
            return this.BaseRequest<TResult>(
                apiKey,
                HttpMethod.Get,
                isStreamRequest: false,
                requestData: queryData,
                requestHead: requestHead,
                queryStrList: queryStrList);
        }

        /// <summary>
        /// 发送GET异步请求,获取文件流
        /// </summary>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>以流方式请求时请传递指定Accept的RequestHead对象</para>
        /// </param>
        /// <param name="queryData">?号后面的数据</param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns>http中的响应流</returns>
        public virtual Task<Stream> GetStreamAsync(
            string apiKey,
            RequestHead requestHead,
            object queryData = null,
            params object[] queryStrList
            )
        {
            return this.BaseRequest<Stream>(
               apiKey,
               HttpMethod.Get,
               isStreamRequest: true,
               requestData: queryData,
               requestHead: requestHead,
               queryStrList: queryStrList);
        }

        #endregion GET

        #region POST

        /// <summary>
        /// 发送Post请求
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="apiKey"></param>
        /// <param name="requestData"></param>
        /// <param name="requestHead"></param>
        /// <remarks>
        /// 请求中的Authorization会取api节点中的数据
        /// </remarks>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        public virtual TResult Post<TResult>(
            string apiKey,
            object requestData,
            RequestHead requestHead = null,
            params object[] queryStrList)
        {
            return this.PostAsync<TResult>(apiKey, requestData, requestHead, queryStrList)
                .GetAwaitResult();
        }

        /// <summary>
        /// 发送Post请求
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="apiKey"></param>
        /// <param name="requestData"></param>
        /// <param name="requestHead"></param>
        /// <remarks>
        /// 请求中的Authorization会取api节点中的数据
        /// </remarks>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns></returns>
        public virtual Task<TResult> PostAsync<TResult>(
            string apiKey,
            object requestData,
            RequestHead requestHead = null,
            params object[] queryStrList)
        {
            return this.BaseRequest<TResult>(
                apiKey,
                HttpMethod.Post,
                isStreamRequest: false,
                requestData: requestData,
                requestHead: requestHead,
                queryStrList: queryStrList);
        }

        /// <summary>
        /// 发送POST异步请求,获取文件流
        /// </summary>
        /// <param name="apiKey">团队节点中配置的apiKey</param>
        /// <param name="requestHead">
        /// 请求头数据
        /// <para>以流方式请求时请传递指定Accept的RequestHead对象</para>
        /// </param>
        /// <param name="queryData">请求的数据</param>
        /// <param name="queryStrList">格式化数据，会替换掉url中的{0}这种占位符</param>
        /// <returns>http中的响应流</returns>
        public Task<Stream> PostStreamAsync(
            string apiKey,
            RequestHead requestHead,
            object queryData = null,
            params object[] queryStrList)
        {
            return this.BaseRequest<Stream>(
             apiKey,
             HttpMethod.Post,
             isStreamRequest: true,
             requestData: queryData,
             requestHead: requestHead,
             queryStrList: queryStrList);
        }

        #endregion POST

        #endregion 接口实现
    }
}