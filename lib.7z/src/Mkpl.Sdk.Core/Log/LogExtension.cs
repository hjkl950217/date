﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Log;
using Newegg.MIS.Baymax.Log;
using System;

namespace Mkpl.Sdk.Core
{
    public static class LogExtension
    {
        /// <summary>
        /// 默认的日志等级
        /// <para>只记录 Warning级别以上的。包括 Error/Critical</para>
        /// </summary>
        public static readonly Func<LogLevel, bool> defaultLogFilter = (level) =>
        {
            return level >= LogLevel.Warning;
        };

        public static readonly Func<string, LogLevel, bool> defaultLogFilterWithCategory = (category, level) =>
        {
            return LogExtension.defaultLogFilter(level);
        };

        /// <summary>
        /// 配置-MPS组的日志
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddLogMps(this IServiceCollection services)
        {
            //配置日志等级
            services.AddLogging(log =>
            {
                log.AddFilter(LogExtension.defaultLogFilter);//添加全局过滤器

                log.Services.TryAddSingletonService<ILog, LogClient>();
                log.Services.AddSingleton<ILoggerProvider>(t =>
                {
                    ILog logger = t.GetService<ILog>();
                    var contextAccessor = t.GetService<IHttpContextAccessor>();
                    ILoggerProvider loggerProvider = new MkplLoggerProvider(logger, contextAccessor, LogExtension.defaultLogFilterWithCategory);
                    return loggerProvider;
                });
            });

            return services;
        }
    }
}