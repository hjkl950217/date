﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newegg.MIS.Baymax.Log;
using System;

namespace Mkpl.Sdk.Core.Log
{
    public class MkplLogger : ILogger
    {
        private static readonly string[] traceHeaders = new string[]
        {
            "client-profile-key",
            "x-gateway-tid",
            "x-gateway-sid",
            "x-gateway-profileid"
        };

        private readonly ILogger log;
        private readonly IHttpContextAccessor contextAccessor;

        public MkplLogger(ILog log, IHttpContextAccessor contextAccessor, string category, Func<string, LogLevel, bool> filter)
        {
            this.log = new NeweggLogger(log, category, filter);
            this.contextAccessor = contextAccessor;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return log.BeginScope(state);
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return log.IsEnabled(logLevel);
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            string newFormatter(TState s, Exception e)
            {
                var message = formatter(s, e);
                var headers = contextAccessor.HttpContext?.Request?.Headers;
                if (headers != null)
                {
                    foreach (var item in traceHeaders)
                    {
                        if (headers.TryGetValue(item, out var value))
                        {
                            message = $"{item}: {value}{Environment.NewLine}{message}";
                        }
                    }
                }
                return message;
            }
            log.Log(logLevel, eventId, state, exception, newFormatter);
        }
    }
}