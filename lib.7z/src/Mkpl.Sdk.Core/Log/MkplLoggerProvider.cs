﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newegg.MIS.Baymax.Log;
using System;

namespace Mkpl.Sdk.Core.Log
{
    public class MkplLoggerProvider : ILoggerProvider
#pragma warning restore S3881 // "IDisposable" should be implemented correctly
    {
        private readonly ILog log;
        private readonly IHttpContextAccessor contextAccessor;
        private readonly Func<string, LogLevel, bool> filter;

        public MkplLoggerProvider(ILog log)
        {
            this.log = log;
        }

        public MkplLoggerProvider(ILog log, IHttpContextAccessor contextAccessor, Func<string, LogLevel, bool> filter) : this(log)
        {
            this.contextAccessor = contextAccessor;
            this.filter = filter;
        }

        public ILogger CreateLogger(string categoryName)
        {
            return new MkplLogger(this.log, contextAccessor, categoryName, filter);
        }

        public void Dispose()
        {
            // Method intentionally left empty.
        }
    }
}