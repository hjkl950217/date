﻿using Microsoft.AspNetCore.Http;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// API自动化测试用的MQClient.<para></para>
    /// 向API响应头中添加MQ调用信息
    /// </summary>
    public class AtApiRecordMQClient : MQClient
    {
        //https://git.newegg.org/marketplace/framework/c-sharp/mkpl-sdk-core/issues/40

        /// <summary>
        /// <see cref="HttpContext"/>获取器
        /// </summary>
        private readonly IHttpContextAccessor httpContextAccessor;

        /// <summary>
        /// MQ纪录头，自动化测试时，会向响应头中添加MQ信息。
        /// </summary>
        public const string MqRecordHeaderName = "MPS-MqSendingRecord";

        /// <summary>
        /// 初始化一个<see cref="AtApiRecordMQClient"/>实例
        /// </summary>
        /// <param name="mqConfig">MQ配置</param>
        /// <param name="messagePublisher">MQ服务提供者</param>
        /// <param name="httpContextAccessor"><see cref="HttpContext"/>获取器</param>
        public AtApiRecordMQClient(
            MQConfig mqConfig,
            IMessagePublisher messagePublisher,
            IHttpContextAccessor httpContextAccessor)
            : base(mqConfig, messagePublisher)
        {
            messagePublisher.CheckNull(nameof(messagePublisher));
            httpContextAccessor.CheckNull(nameof(httpContextAccessor));

            this.httpContextAccessor = httpContextAccessor;
        }

        public override PublishResultInfo SendMessage<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false)
        {
            //调用
            var result = base.messagePublisher.SendMessage(
                  request: request,
                  messageName: messageName,
                  password: password,
                  contentType: MessageContentType.Json,
                  headers: headers,
                  callbackUri: null,
                  subscribers: null,
                  noSerialize: false
                  );

            //纪录
            this.AddOrUpdateMqRecordInfo(
                this.httpContextAccessor
                , messageName
                , result.MessageId.ToString());

            return result;
        }

        public override async Task<PublishResultInfo> SendMessageAsync<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false)
        {
            //调用
            var result = await base.messagePublisher.SendMessageAsync(
                  request: request,
                  messageName: messageName,
                  password: password,
                  contentType: MessageContentType.Json,
                  headers: headers,
                  callbackUri: null,
                  subscribers: null,
                  noSerialize: false
                  );

            //纪录
            this.AddOrUpdateMqRecordInfo(
                this.httpContextAccessor
                , messageName
                , result.MessageId.ToString());

            return result;
        }

        private void AddOrUpdateMqRecordInfo(
            IHttpContextAccessor httpContextAccessor,
            string queueName,
            string mqID)
        {
            //获取并反序列化
            HttpResponse httpResponse = httpContextAccessor.HttpContext.Response;
            string valueStr = httpResponse.Headers[AtApiRecordMQClient.MqRecordHeaderName];
            var dic = valueStr
                .ToObjectExt<Dictionary<string, List<string>>>();

            //添加新mq id
            dic.GetOrAddNew(queueName)
                .Add(mqID);

            //序列化回headers
            httpResponse.Headers[AtApiRecordMQClient.MqRecordHeaderName] = dic.ToJsonExt();
        }
    }
}