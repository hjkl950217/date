﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQConfig.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQConfig created at  5/12/2018 10:51:34 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Newegg.MIS.EggKeeper.Sdk.Default;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Entities
{
    /// <summary>
    /// MQ配置
    /// </summary>
    /// <remarks>
    /// 位于Config Service 的 MKPL_Common/MessageQueue_Config  下面
    /// </remarks>
    [JsonEgg(ConfigName = "MessageQueue_Config")]
    public class MQConfig
    {
        /// <summary>
        /// MQ组
        /// </summary>
        /// <remarks>
        /// 暂时只有MKPL
        /// </remarks>
        public List<GroupQueue> GroupQueues { get; set; }
    }
}