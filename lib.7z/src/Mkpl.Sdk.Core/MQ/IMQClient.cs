﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IMQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   IMQClient created at  5/12/2018 10:50:08 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// MPS组-MQ客户端
    /// </summary>
    public partial interface IMQClient
    {
        PublishResultInfo SendMessage<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false);

        Task<PublishResultInfo> SendMessageAsync<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false);

        /// <summary>
        /// 获取所有发送设置的数据
        /// </summary>
        /// <returns></returns>
        GroupQueue GetGroupQueue();
    }
}