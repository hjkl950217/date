﻿using Microsoft.Net.Http.Headers;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    public static class IMQClientExtension
    {
        #region 基础方法

        /// <summary>
        /// 从mqClietn中取出Queue
        /// </summary>
        /// <param name="mQClient"></param>
        /// <param name="queueKey">queue的名字</param>
        /// <returns></returns>
        public static Queue GetQueue(this IMQClient mQClient, string queueKey)
        {
            return mQClient.GetGroupQueue().FindQueue(queueKey);
        }

        /// <summary>
        /// 私有-创建HearList
        /// </summary>
        /// <param name="queueKeyName">queue的key名</param>
        /// <param name="header">消息头</param>
        /// <param name="otherHeader">其它要添加的消息头</param>
        /// <returns></returns>
        public static List<KeyValuePair<string, string>> CreateHearList(
           string queueKeyName,
           MQHeaderV2 header,
           IEnumerable<KeyValuePair<string, string>> otherHeader = null)
        {
            queueKeyName.CheckNull(nameof(queueKeyName));
            header.CheckNull(nameof(header));

            List<KeyValuePair<string, string>> headerList = header.CreteHeaderList(queueKeyName);
            headerList.AddRange(header.OtherHeader);//添加对象内的其它header
            if (otherHeader != null) headerList.AddRange(otherHeader);//添加方法参数中的header

            return headerList;
        }

        #endregion 基础方法

        #region 发送-同步

        /// <summary>
        /// 发送Json消息到MQ系统
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">消息体</param>
        /// <param name="queueKeyConst">queue的key名</param>
        /// <param name="header">消息头</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header)
            where T : class
        {
            header.CheckNull(nameof(header));
            message.CheckNull(nameof(message));
            return mQClient.SendMessage(message, queueKeyConst, header, otherHeader: null);
        }

        /// <summary>
        /// 发送Json消息到MQ系统
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="otherHeader">要附加的头数据</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header,
              IEnumerable<KeyValuePair<string, string>> otherHeader)
            where T : class
        {
            header.CheckNull(nameof(header));
            message.CheckNull(nameof(message));

            IEnumerable<KeyValuePair<string, string>> otherHeaders = new KeyValuePair<string, string>[]
            {
                 new KeyValuePair<string, string>(HeaderNames.Accept, ContentTypeConst.Json),
                 new KeyValuePair<string, string>(HeaderNames.ContentType, ContentTypeConst.Json)
            };
            otherHeaders = otherHeader == null ? otherHeaders : otherHeaders.Concat(otherHeader);

            Queue queue = mQClient.GetQueue(queueKeyConst);
            List<KeyValuePair<string, string>> headerList = CreateHearList(queue.KeyName, header, otherHeaders);

            return mQClient.SendMessage(message, queue, headerList);
        }

        /// <summary>
        /// 发送Json消息到MQ系统
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">发送的消息体</param>
        /// <param name="queue">发送时的设置</param>
        /// <param name="headers">发送的头</param>
        /// <returns></returns>
        public static PublishResultInfo SendMessage<T>(
            this IMQClient mQClient,
            T message,
            Queue queue,
            IEnumerable<KeyValuePair<string, string>> headers)
        {
            return mQClient.SendMessage(
                request: message,
                messageName: queue.QueueName,
                password: queue.Password,
                contentType: MessageContentType.Json,
                headers: headers,
                callbackUri: null,
                subscribers: null,
                noSerialize: false
                );
        }

        #endregion 发送-同步

        #region 发送-异步

        /// <summary>
        /// 发送Json消息到MQ系统
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">消息体</param>
        /// <param name="queueKeyConst">queue的key名</param>
        /// <param name="header">消息头</param>
        /// <returns></returns>
        public static Task<PublishResultInfo> SendMessageAsync<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header)
            where T : class
        {
            header.CheckNull(nameof(header));
            message.CheckNull(nameof(message));
            return mQClient.SendMessageAsync(message, queueKeyConst, header, otherHeader: null);
        }

        /// <summary>
        /// 发送Json消息到MQ系统
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">要发送的消息对象</param>
        /// <param name="queueKeyConst">消息名</param>
        /// <param name="header">要发送的消息中的头对象</param>
        /// <param name="otherHeader">要附加的头数据</param>
        /// <returns></returns>
        public static Task<PublishResultInfo> SendMessageAsync<T>(
              this IMQClient mQClient,
              T message,
              string queueKeyConst,
              MQHeaderV2 header,
              IEnumerable<KeyValuePair<string, string>> otherHeader)
            where T : class
        {
            header.CheckNull(nameof(header));
            message.CheckNull(nameof(message));

            IEnumerable<KeyValuePair<string, string>> otherHeaders = new KeyValuePair<string, string>[]
            {
                 new KeyValuePair<string, string>(HeaderNames.Accept, ContentTypeConst.Json),
                 new KeyValuePair<string, string>(HeaderNames.ContentType, ContentTypeConst.Json)
            };
            otherHeaders = otherHeader == null ? otherHeaders : otherHeaders.Concat(otherHeader);

            Queue queue = mQClient.GetQueue(queueKeyConst);
            List<KeyValuePair<string, string>> headerList = CreateHearList(queue.KeyName, header, otherHeaders);

            return mQClient.SendMessageAsync(message, queue, headerList);
        }

        /// <summary>
        /// 发送Json消息
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="mQClient"></param>
        /// <param name="message">发送的消息体</param>
        /// <param name="queue">发送时的设置</param>
        /// <param name="headers">发送的头</param>
        /// <returns></returns>
        public static Task<PublishResultInfo> SendMessageAsync<T>(
            this IMQClient mQClient,
            T message,
            Queue queue,
            IEnumerable<KeyValuePair<string, string>> headers)
        {
            return mQClient.SendMessageAsync(
                request: message,
                messageName: queue.QueueName,
                password: queue.Password,
                contentType: MessageContentType.Json,
                headers: headers,
                callbackUri: null,
                subscribers: null,
                noSerialize: false
                );
        }

        #endregion 发送-异步
    }
}