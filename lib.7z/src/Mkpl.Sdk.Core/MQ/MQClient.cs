﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQClient created at  5/12/2018 10:50:36 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mkpl.Sdk.Core.Client
{
    /// <summary>
    /// The class of MQClient.
    /// </summary>
    public partial class MQClient : IMQClient
    {
        /// <summary>
        /// MQ配置-ConfigService
        /// </summary>
        protected readonly GroupQueue groupQueue;

        /// <summary>
        /// MQ发送接口
        /// </summary>
        protected readonly IMessagePublisher messagePublisher;

        public MQClient(MQConfig mqConfig, IMessagePublisher messagePublisher)
        {
            mqConfig.CheckNull(nameof(mqConfig));
            messagePublisher.CheckNull(nameof(messagePublisher));

            this.groupQueue = mqConfig.GroupQueues
                  .FirstOrDefault(t => t.GoupName == QueueGoupNameConst.Team_MKPL);
            if (this.groupQueue == null)
            {
                throw new InvalidOperationException($"GroupQueue Config is not found,Group Key:{QueueGoupNameConst.Team_MKPL}");
            }

            this.messagePublisher = messagePublisher;
        }

        public virtual Task<PublishResultInfo> SendMessageAsync<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false)
        {
            return this.messagePublisher.SendMessageAsync(
                request: request,
                messageName: messageName,
                password: password,
                contentType: MessageContentType.Json,
                headers: headers,
                callbackUri: null,
                subscribers: null,
                noSerialize: false
                );
        }

        public virtual PublishResultInfo SendMessage<T>(
            T request,
            string messageName,
            MessageContentType contentType = MessageContentType.Json,
            string password = null,
            IEnumerable<KeyValuePair<string, string>> headers = null,
            string callbackUri = null,
            List<string> subscribers = null,
            bool noSerialize = false)
        {
            return this.messagePublisher.SendMessage(
                request: request,
                messageName: messageName,
                password: password,
                contentType: MessageContentType.Json,
                headers: headers,
                callbackUri: null,
                subscribers: null,
                noSerialize: false
                );
        }

        public GroupQueue GetGroupQueue()
        {
            return this.groupQueue;
        }
    }
}