﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQClient.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQClient created at  5/12/2018 10:50:36 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Client
{
#pragma warning disable CS0618 // 类型或成员已过时

    /// <summary>
    /// The class of MQClient.
    /// </summary>
    public partial class MQClient : IMQClient
    {
        /// <summary>
        /// [已过时]基础发送方法<para></para>
        /// 请使用<see cref="IMQClientExtension.SendMessage{T}(IMQClient, T, string, MQHeaderV2)"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message"></param>
        /// <param name="queueKeyConst"></param>
        /// <param name="header"></param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        public virtual PublishResultInfo SendMessage<T>(T message, string queueKeyConst, MQHeader header)

               where T : class
        {
            if (header == null)
            {
                throw new ArgumentNullException(nameof(header), "The parameter ' header' cannot be empty when sending MQ");
            }

            if (message.IsNullOrEmpty() == true)
            {
                throw new ArgumentNullException(nameof(message), "The parameter ' message' cannot be empty when sending MQ");
            }

            Queue queue = this.groupQueue.FindQueue(queueKeyConst);
            List<KeyValuePair<string, string>> headerList = header.CreteHeaderList(queue.KeyName);

            //发送
            PublishResultInfo result = this.messagePublisher.SendMessage(
                message,
                queue.QueueName,
                contentType: MessageContentType.Json,
                password: queue.Password,
                headers: headerList
                );

            return result;
        }
    }

#pragma warning restore CS0618 // 类型或成员已过时
}