﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core;
using System;
using System.Linq;
using Mkpl.Sdk.Core.Env;

namespace Mkpl.Sdk.Core
{
    public static class MpsApiMQClientExtension
    {
        /// <summary>
        /// 注册 MPS组MQClien<para></para>
        /// 自动化环境时会增加响应的支持。用于开关的环境名:<see cref="CommomEnvNameConst.AUTO_TEST"/>
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="environmentInfo">控制MQ自动化环境支持的开关名</param>
        public static void AddMpsMQClientMPS(
            this IServiceCollection services,
            EnvironmentInfo environmentInfo = null)
        {
            services.CheckNull(nameof(services));
            var info = environmentInfo ?? EnvironmentInfo.Gobal;
            void action()
            {
                if (info.IsAutoTest())
                {
                    ServiceDescriptor serviceDescriptor = services
                        .FirstOrDefault(t => t.ServiceType == typeof(IMQClient));

                    if (serviceDescriptor != null)
                    {
                        services.Remove(serviceDescriptor);//清除之前的IMQClient注册
                    }

                    services.AddSingleton<IMQClient, AtApiRecordMQClient>();
                }
            }

            MpsMQClientExtension.AddMpsMQClientMPS(services, action);
        }
    }
}