﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMQClientMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMQClientMiddleware created at  5/12/2018 11:25:42 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.EggKeeper.Sdk.Default;
using System;

namespace Mkpl.Sdk.Core
{
    public static class MpsMQClientExtension
    {
        /// <summary>
        /// 注册 MPS组MQClient(框架内部使用)
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="action">附加操作</param>
        public static void AddMpsMQClientMPS(this IServiceCollection services, Action action)
        {
            services.TryAddSingletonService<IMQClient, MQClient>();

            //注册服务
            services.UseEggKeeperSimplizer();
            services.AddSingletonConfiguration<MQConfig>();

            //执行附加的操作
            action();
        }
    }
}