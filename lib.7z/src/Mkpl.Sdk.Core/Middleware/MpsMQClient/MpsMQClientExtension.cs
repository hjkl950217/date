﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMQClientMiddleware.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMQClientMiddleware created at  5/12/2018 11:25:42 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.EggKeeper.Sdk.Default;
using System;

namespace Mkpl.Sdk.Core
{
    public static class MpsMQClientExtension
    {
        /// <summary>
        /// 注册与配置 MPS组MQClient
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="setOpt">设置MpsMQOption的委托</param>
        public static void AddMpsMQClientMPS(
            this IServiceCollection services,
            Action<MpsMQOption> setOpt = null)
        {
            MpsMQOption opt = new MpsMQOption();
            setOpt?.Invoke(opt);//当setOpt不为空时，会调用这个委托
            services.AddSingleton<MpsMQOption>(t => { return opt; });

            services.AddSingleton<IMQClient, MQClient>();

            //注册服务
            services.UseEggKeeperSimplizer();
            services.AddSingletonConfiguration<MQConfig>();
        }
    }
}