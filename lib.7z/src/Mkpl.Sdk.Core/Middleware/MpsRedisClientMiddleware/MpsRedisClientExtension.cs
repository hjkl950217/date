﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Client.Kafka;
using Mkpl.Sdk.Core.Helpers;
using System;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core
{
    public static class MpsRedisClientExtension
    {
        /// <summary>
        /// 注册与配置 MPS组RedisClient
        /// </summary>
        /// <param name="services">IServiceCollection实例</param>
        /// <param name="configuration">配置接口</param>
        /// <param name="configName">配置名。具体请参考<see cref="CacheExtension.AddRedis(IServiceCollection, IConfiguration, string, string)"/>
        /// </param>
        /// <param name="redisCluster">redis集群名，首先读取"REDIS_CLUSTER"环境变量，读取不到时才会使用参数值。具体请参考<see cref="CacheExtension.AddRedis(IServiceCollection, IConfiguration, string, string)"/>
        /// </param>
        /// <param name="customRedisClientFactory">
        /// 添加自定义的<see cref="IRedisProvider"/>实现
        /// </param>
        public static void AddMpsRedisClientMPS(
            this IServiceCollection services,
            IConfiguration configuration,
            string configName = "RedisServer",
            string redisCluster = "E11",
            Func<IEnumerable<IRedisProvider>> customRedisClientFactory = null)
        {
            //1.配置redis
            if (EnvHelper.IsPreOrPrd())
            {
                redisCluster = Environment.GetEnvironmentVariable("REDIS_CLUSTER") ?? EnvHelper.GetLocation();
            }
            else
            {
                redisCluster = Environment.GetEnvironmentVariable("REDIS_CLUSTER") ?? redisCluster;
            }
            Console.WriteLine($"redis client connect to {redisCluster}");//输出连接集群到启动界面

            services.AddRedis(
                configuration,
                configName,
                redisCluster
               );
            services.AddCacheEntend();

            //2. 配置redis Client
            services.AddSingleton<IProducerBuilderWrapper, ProducerBuilderWrapper>();
            services.AddSingleton<IMpsRedisClientKafkaSender>(t =>
            {
                IProducerBuilderWrapper wrapper = t.GetService<IProducerBuilderWrapper>();

                if (services.IsNullOrEmpty())
                {
#pragma warning disable S3928
                    throw new ArgumentNullException("kafkaServerAddress", "Data failed to get from Config Service.");
#pragma warning restore S3928
                }

                string topic = MpsRedisClientKafkaConfig.GetTopic(redisCluster);
                string kafkaAddress = MpsRedisClientKafkaConfig.GetServerAddress(EnvHelper.GetRunEnv());
                return new MpsRedisClientKafkaSender(
                    wrapper,
                    t.GetService<ILogger<MpsRedisClientKafkaSender>>(),
                    topic,
                    kafkaAddress);
            });

            services.AddRedisProvider<DirectRedisClient>(100);
            services.AddRedisProvider<SyncToClusterRedisClient>(200);
            services.AddRedisProvider<EndRedisClient>(int.MaxValue);

            if (customRedisClientFactory != null)
            {
                foreach (var item in customRedisClientFactory())
                {
                    services.AddSingleton(item);
                }
            }

            // 3. 注册直接使用的接口
            services.AddSingleton<IMpsRedisClient, DefaultRedisClient>();
        }

        private static IServiceCollection AddRedisProvider<TImplement>(
            this IServiceCollection services,
            int orderNumber)
            where TImplement : class, IMpsRedisClient
        {
            services.AddSingleton<TImplement>();

            services.AddSingleton<IRedisProvider>(t =>
            {
                TImplement mpsRedisClient = t.GetService<TImplement>();
                mpsRedisClient.Order = orderNumber;
                return new RedisProvider(mpsRedisClient);
            });

            return services;
        }
    }
}