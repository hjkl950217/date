﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core
{
    public static class ICollectionExtensions
    {
        public static ICollection<KeyValuePair<Tkey, Tvalue>> Add<Tkey, Tvalue>(
            this ICollection<KeyValuePair<Tkey, Tvalue>> source,
            Tkey key,
            Tvalue value)
        {
            source.Add(new KeyValuePair<Tkey, Tvalue>(key, value));
            return source;
        }
    }
}