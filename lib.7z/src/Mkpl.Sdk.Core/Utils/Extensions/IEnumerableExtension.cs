﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.Linq
{
    public static class IEnumerableExtension
    {
        public static IList<KeyValuePair<TKey, TValue>> TryAdd<TKey, TValue>(
            this IList<KeyValuePair<TKey, TValue>> keyValuePairs,
            TKey headerName,
            TValue value)
        {
            if (!keyValuePairs.Any(t => t.Key.Equals(headerName)))
            {
                keyValuePairs.Add(new KeyValuePair<TKey, TValue>(headerName, value));
            }

            return keyValuePairs;
        }
    }
}