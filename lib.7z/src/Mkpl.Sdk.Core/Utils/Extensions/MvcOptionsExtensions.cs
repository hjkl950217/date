﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;

namespace Mkpl.Sdk.Core
{
    public static class MvcOptionsExtensions
    {
        public static void UseCentralRoutePrefix(this MvcOptions opts, IRouteTemplateProvider routeAttribute)
        {
            opts.Conventions.Insert(0, new RouteConvention(routeAttribute));
        }

        public static void UseCentralRoutePrefix(this MvcOptions opts, string prefix)
        {
            if (!string.IsNullOrWhiteSpace(prefix))
            {
                opts.Conventions.Insert(0, new RouteConvention(new RouteAttribute(prefix)));
            }
        }
    }
}