﻿using Mkpl.Sdk.Core.Entities.Attribute;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Reflection;

namespace Mkpl.Sdk.Core.Convert
{
    /// <summary>
    /// 枚举转换为json时使用<see cref="EnumDescriptionAttribute.Description"/>。<para></para>
    /// 目前只重写了转换为json。
    /// </summary>
    /// <remarks>
    /// 使用条件：<para></para>
    /// 1.枚举的定义上面需要打<see cref="UseDescriptionForJsonAttribute"/>特性，用来标记这个类型需要特定的转换逻辑。
    /// 2.枚举值上需要打<see cref="EnumDescriptionAttribute"/>标签,并且需要填写<see cref="EnumDescriptionAttribute.Description"/>的值
    /// </remarks>
    public class DescriptionEnumWriteConverter : StringEnumConverter
    {
        //Converter只会初始化一次

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            Enum e = (Enum)value;

            writer.WriteValue(e.GetDescription());
        }

        private readonly ConcurrentDictionary<Type, bool> UseDescriptionList = new ConcurrentDictionary<Type, bool>();

        public override bool CanConvert(Type objectType)
        {
            bool judgeAttribute(Type type)
            {
                return type.GetCustomAttribute<UseDescriptionForJsonAttribute>() != null;
            }

            return this.UseDescriptionList
                .GetOrAdd(objectType, t =>
                {
                    if (t.IsGenericType)
                    {
                        return t.GetGenericArguments().Any(judgeAttribute);
                    }
                    else
                    {
                        return judgeAttribute(t);
                    }
                });
        }

        public override bool CanRead => false;
        public override bool CanWrite => true;
    }
}