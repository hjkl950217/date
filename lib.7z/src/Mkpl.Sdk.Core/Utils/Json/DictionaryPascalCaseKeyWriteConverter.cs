﻿using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Convert
{
#pragma warning disable CS1584,CS1658

    /// <summary>
    /// <see cref="IDictionary{string, string}"/>转换时，key指定使用帕斯卡命名法
    /// </summary>
    public class DictionaryPascalCaseKeyWriteConverter : KeyValuePairPascalCaseKeyWriteConverter
#pragma warning restore CS1584,CS1658
    {
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            var valueEnumerable = value as System.Collections.IEnumerable;
            writer.WriteStartObject();
            foreach (var item in valueEnumerable)
            {
                base.WriteToJson(writer, item, serializer);
            }
            writer.WriteEndObject();
        }

        private readonly ConcurrentDictionary<Type, bool> UseDescriptionList = new ConcurrentDictionary<Type, bool>();

        public override bool CanConvert(Type objectType)
        {
            bool judgeAttribute(Type type)
            {
                return typeof(IDictionary<string, string>).IsAssignableFrom(type);

                //如果以后要扩展，支持更多的类型，可能用到下面的代码
                //if (type.GenericTypeArguments.Length == 0) return false;
                //return type.GetInterfaces()
                //      .Any(t => t.GetGenericTypeDefinition() == typeof(IDictionary<,>));
            }

            return this.UseDescriptionList
                .GetOrAdd(objectType, t =>
                {
                    return judgeAttribute(t);
                });
        }

        public override bool CanRead => false;
        public override bool CanWrite => true;
    }
}