﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Convert
{
#pragma warning disable CS1584, CS1658

    /// <summary>
    /// <see cref="KeyValuePair{string, string}"/>集合转换时，key指定使用帕斯卡命名法
    /// </summary>
    public class KeyValuePairPascalCaseKeyWriteConverter : KeyValuePairConverter
#pragma warning restore CS1584,CS1658
    {
        //CanConvert 方法用来判断类型，所以读写方法都能确定类型来编码的

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            writer.WriteStartObject();
            this.WriteToJson(writer, value, serializer);//真实写入数据
            writer.WriteEndObject();
        }

        /// <summary>
        /// 向写入器中写入数据，不包括<see cref="WriteState"/>的管理
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="value"></param>
        /// <param name="serializer"></param>
        protected void WriteToJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (value == null)
            {
                writer.WriteNull();
                return;
            }

            var valueObj = this.GetValue(value.GetType(), value);//解析对象
            writer.WritePropertyName(valueObj.Key.ToString());//写入Key的值
            serializer.Serialize(writer, valueObj.Value);//写入Value
        }

        private readonly ConcurrentDictionary<Type, bool> UseDescriptionList = new ConcurrentDictionary<Type, bool>();

        public override bool CanConvert(Type objectType)
        {
            bool judgeAttribute(Type type)
            {
                return typeof(KeyValuePair<string, string>).IsAssignableFrom(type);
                //如果以后要扩展，支持更多的类型，可能用到下面的代码
                //return type.IsValueType
                //    && type.IsGenericType
                //    && type.GetGenericTypeDefinition() == typeof(KeyValuePair<,>);
            }

            return this.UseDescriptionList
                .GetOrAdd(objectType, t =>
                {
                    return judgeAttribute(t);
                });
        }

        public override bool CanRead => false;
        public override bool CanWrite => true;

        /// <summary>
        /// 获取标记了泛型参数的<see cref="KeyValuePair{TKey, TValue}"/>
        /// </summary>
        /// <param name="types"></param>
        /// <returns></returns>
        public Type GetGenericKV(Type[] types)
        {
            Type genericKV = typeof(KeyValuePair<,>).MakeGenericType(types);
            return genericKV;
        }

        /// <summary>
        /// 从<paramref name="kvObject"/>中解析出数据
        /// </summary>
        /// <param name="type">标记了泛型参数的<see cref="KeyValuePair{TKey, TValue}"/></param>
        /// <param name="kvObject"></param>
        /// <returns></returns>
        public (object Key, object Value) GetValue(Type type, object kvObject)
        {
            object key = type.GetMethod("get_Key").Invoke(kvObject, null);
            object value = type.GetMethod("get_Value").Invoke(kvObject, null);

            return (key, value);
        }
    }
}