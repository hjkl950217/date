﻿namespace Mkpl.Sdk.Core
{
    /// <summary>
    /// 扩展方法的抽象
    /// </summary>
    public static class CommonExtension
    {
        ///// <summary>
        ///// 基本类型的互相转换
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <typeparam name="TResult"></typeparam>
        ///// <param name="source"></param>
        ///// <param name="defaultReuslt"></param>
        ///// <param name="convertFunc"></param>
        ///// <returns></returns>
        //internal static TResult BaseConvert<T, TResult>(
        //    this T source,
        //    TResult defaultReuslt,
        //    Func<T, TResult> convertFunc)
        //     where T : class
        //{
        //    if (source.IsNullOrEmpty()) return defaultReuslt;

        //    return convertFunc(source);
        //}
    }
}