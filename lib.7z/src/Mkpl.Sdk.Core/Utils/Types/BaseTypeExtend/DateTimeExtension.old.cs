﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;

namespace Mkpl.Sdk.Core
{
    public static partial class DateTimeExtensions
    {
        /// <summary>
        /// (已弃用)MKPL Cumstom extension metohed: format DateTIme to string as yyyy-MM-ddTHH:mm:ss
        /// <para>请使用<see cref="DateTimeExtensions.ToStringMPS(DateTime, string)"/></para>
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        [Obsolete("请参考说明使用新方法")]
        public static string ToDateTimeStringExt(this DateTime source)
        {
            return source.ToString("yyyy-MM-ddTHH:mm:ss");
        }

        /// <summary>
        /// (已弃用)MKPL Cumstom extension metohed。
        /// <para>format: yyyy-MM-ddTHH:mm:ss.fffZ</para>
        /// <para>请使用<see cref="DateTimeExtensions.ToStringMPS(DateTime, string)"/></para>
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        [Obsolete("请参考说明使用新方法")]
        public static string ToSolrDateTimeStringExt(this DateTime source)
        {
            return source.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
        }

        /// <summary>
        /// (已弃用)MKPL Cumstom extension metohed。
        /// <para>format:MM\\/dd\\/yyyy HH:mm:ss</para>
        /// <para>请使用<see cref="DateTimeExtensions.ToStringMPS(DateTime, string)"/></para>
        /// </summary>
        /// <param name="source">thre given original DateTime</param>
        /// <returns>the format datetime string</returns>
        [Obsolete("请参考说明使用新方法")]
        public static string ToDateTimeStringMpsExt(this DateTime source)
        {
            return source.ToString(DateTimeFormatConst.USA);
        }
    }
}