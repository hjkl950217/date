﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DictionaryExtension.cs" company="Newegg" Author="kl1m">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DictionaryExtension created at  12/4/2018 7:2:36 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using System.Linq;

namespace System.Collections.Generic
{
    /// <summary>
    /// Dictionary扩展类
    /// </summary>
    public static class DictionaryExtension
    {
        /// <summary>
        /// 将IEnumerable转换为Dictionary，存在重复键时，取第一个键
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of <paramref name="source" />.</typeparam>
        /// <typeparam name="TKey">The type of the key returned by <paramref name="keySelector" />.</typeparam>
        /// <typeparam name="TElement">The type of the value returned by <paramref name="elementSelector" />.</typeparam>
        ///
        /// <param name="source">An <see cref="T:System.Collections.Generic.IEnumerable`1" /> to create a <see cref="T:System.Collections.Generic.Dictionary`2" /> from.</param>
        /// <param name="keySelector">A function to extract a key from each element.</param>
        /// <param name="elementSelector">A transform function to produce a result element value from each element.</param>
        /// <returns>A <see cref="T:System.Collections.Generic.Dictionary`2" /> that contains values of type <typeparamref name="TElement"/> selected from the input sequence.</returns>
        public static Dictionary<TKey, TElement> ToDictionaryExt<TSource, TKey, TElement>(
            this IEnumerable<TSource> source,
            Func<TSource, TKey> keySelector,
            Func<TSource, TElement> elementSelector)
        {
            Dictionary<TKey, TElement> dict = new Dictionary<TKey, TElement>();

            if (source == null || keySelector == null || elementSelector == null)
            {
                return dict;
            }

            foreach (TSource k in source)
            {
                TKey key = keySelector(k);
                if (dict.ContainsKey(key))
                {
                    continue;
                }

                dict.Add(key, elementSelector(k));
            }

            return dict;
        }

        /// <summary>
        /// 判断某个Key的Value是否等于comparerValue的值
        /// <para>返回true为判断成功</para>
        /// </summary>
        /// <typeparam name="TKey">The type of the key returned by <paramref name="key" />.</typeparam>
        /// <typeparam name="TValue">The type of the key returned by <paramref name="comparerValue" />.</typeparam>
        /// <param name="dict">A <see cref="T:System.Collections.Generic.Dictionary`2" /></param>
        /// <param name="key">待比较的Dictionary的key</param>
        /// <param name="comparerValue">对比的值</param>
        /// <returns></returns>
        public static bool ContainsValueExt<TKey, TValue>(
            this Dictionary<TKey, TValue> dict,
            TKey key,
            TValue comparerValue)
        {
            if (dict == null || dict.Count < 1 || !dict.ContainsKey(key))
            {
                return false;
            }

            return dict[key].Equals(comparerValue);
        }

        public static TValue GetOrDefault<TKey, TValue>(
            this IDictionary<TKey, TValue> valuePairs,
            TKey key,
            TValue defaultValue = default)
        {
            key.CheckNull(nameof(key));
            valuePairs.CheckNull(nameof(valuePairs));

            bool isExist = valuePairs.TryGetValue(key, out TValue value);
            if (isExist) { return value; }
            else { return defaultValue; }
        }

        /// <summary>
        /// 尝试向<paramref name="valuePairs"/>中添加新key。如果已经存在相同的key,则不会添加
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="valuePairs"></param>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns>true，添加成功。否则false</returns>
        public static bool TryAdd<TKey, TValue>(
            this IDictionary<TKey, TValue> valuePairs,
             TKey key,
             TValue value)
        {
            key.CheckNull(nameof(key));
            value.CheckNull(nameof(value));
            valuePairs.CheckNull(nameof(valuePairs));

            bool isExist = valuePairs.ContainsKey(key);
            if (!isExist)
            {
                valuePairs.Add(key, value);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 连接key.<paramref name="valuePairs"/>为null时返回<see cref="string.Empty"/>
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="valuePairs"></param>
        /// <returns></returns>
        public static string ConcatKey<TKey, TValue>(
            this IEnumerable<KeyValuePair<TKey, TValue>> valuePairs)
        {
            if (valuePairs.IsNullOrEmpty()) return string.Empty;

            return string.Concat(valuePairs.Select(t => t.Key));
        }

        /// <summary>
        /// 获取或添加
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="valuePairs"></param>
        /// <param name="key"></param>
        /// <param name="factory"></param>
        /// <returns></returns>
        public static TValue GetOrAdd<TKey, TValue>(
            this IDictionary<TKey, TValue> valuePairs,
            TKey key,
            Func<TValue> factory)

        {
            key.CheckNull(nameof(key));
            valuePairs.CheckNull(nameof(valuePairs));
            factory.CheckNull(nameof(factory));

            bool isExist = valuePairs.TryGetValue(key, out TValue value);
            if (isExist) { return value; }
            else
            {
                TValue result = factory();
                lock (valuePairs)
                {
                    valuePairs.Add(key, result);
                }
                return result;
            }
        }

        /// <summary>
        /// 获取或添加一个默认值
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="valuePairs"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static TValue GetOrAddNew<TKey, TValue>(
           this IDictionary<TKey, TValue> valuePairs,
           TKey key)
            where TValue : new()
        {
            return valuePairs.GetOrAdd(key, () => new TValue());
        }

        /// <summary>
        /// 获取或添加一个默认值
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="valuePairs"></param>
        /// <param name="key"></param>
        /// <param name="factory"></param>
        /// <returns></returns>
        public static TValue GetOrAddNew<TKey, TValue>(
           this IDictionary<TKey, TValue> valuePairs,
           TKey key,
           Func<TValue> factory)

        {
            factory.CheckNull(nameof(factory));
            return valuePairs.GetOrAdd(key, () => factory());
        }
    }
}