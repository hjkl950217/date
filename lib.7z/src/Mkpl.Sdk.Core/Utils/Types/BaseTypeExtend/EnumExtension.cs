﻿using Mkpl.Sdk.Core.Entities.Attribute;
using Mkpl.Sdk.Core;
using System;

namespace Mkpl.Sdk.Core
{
    public static class EnumExtension
    {
        #region 针对MPS特定扩展

        /// <summary>
        /// 获取UI上的通用字符串。获取不到时返回null<para></para>
        /// 使用的Attribute为M公共库里的 EnumDescriptionAttribute
        /// </summary>
        /// <param name="en"></param>
        /// <returns></returns>
        public static string GetShowValue(this Enum en)
        {
            EnumDescriptionAttribute attr = en.GetAttribute<EnumDescriptionAttribute>();

            if (attr == null) return null;

            return attr.ShowValue;
        }

        /// <summary>
        /// 获取对应的DB值。获取不到时返回null<para></para>
        /// 使用的Attribute为公共库里的 EnumDescriptionAttribute
        /// </summary>
        /// <param name="en"></param>
        /// <returns></returns>
        public static string GetDBValue(this Enum en)
        {
            EnumDescriptionAttribute attr = en.GetAttribute<EnumDescriptionAttribute>();

            if (attr == null) return null;

            return attr.DBValue;
        }

        /// <summary>
        /// 获取描述数据。获取不到时返回null <para></para>
        /// 返回<see cref="EnumDescriptionAttribute"/>的<see cref="EnumDescriptionAttribute.Description"/>值
        /// </summary>
        /// <param name="en"></param>
        /// <returns></returns>
        public static string GetDescription(this Enum en)
        {
            EnumDescriptionAttribute attr = en.GetAttribute<EnumDescriptionAttribute>();

            if (attr == null) return null;

            return attr.Description;
        }

        #endregion 针对MPS特定扩展

        #region 公共方法

        /// <summary>
        /// 获取枚举值上的特性，获取不到时返回null
        /// </summary>
        /// <param name="en">枚举值</param>
        /// <param name="attributeType">枚举值上的Attribute类型</param>
        /// <returns></returns>
        public static System.Attribute GetAttribute(
            this Enum en,
            Type attributeType)
        {
            return EnumHelper.GetAttribute<System.Attribute>(attributeType, en);
        }

        /// <summary>
        /// 获取枚举值上的特性，获取不到时返回null
        /// </summary>
        /// <typeparam name="TAttribute">枚举上的Attribute类型</typeparam>
        /// <param name="en">枚举值</param>
        /// <returns></returns>
        public static TAttribute GetAttribute<TAttribute>(this Enum en)
            where TAttribute : System.Attribute
        {
            return EnumHelper.GetAttribute<TAttribute>(en.GetType(), en);
        }

        /// <summary>
        /// 获取枚举值（不是枚举名）对应的字符串类型。<para></para>
        /// 如: AAA.B=1  返回"1"
        /// </summary>
        /// <param name="en">枚举值</param>
        /// <returns>枚举值对应的值类型，字符串表现形式</returns>
        public static string GetValueString(this Enum en)
        {
            return Enum.Format(en.GetType(), en, "D");
        }

        /// <summary>
        /// 获取枚举值对应的值数据
        /// </summary>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="en"></param>
        /// <returns></returns>
        public static TValue GetValue<TValue>(this Enum en)
            where TValue : struct
        {
            try
            {
                return (TValue)System.Convert.ChangeType(en, typeof(TValue));
            }
            catch (InvalidCastException ex)
            {
                throw new InvalidCastException($"获取枚举值时出错。枚举名:{en.GetType().Name}", ex);
            }
        }

        #endregion 公共方法
    }
}