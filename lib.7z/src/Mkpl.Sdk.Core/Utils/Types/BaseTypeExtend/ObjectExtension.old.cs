﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core
{
    public static partial class ObjectExtension
    {
        /// <summary>
        /// (已弃用)转换成XML字符串。推荐使用<see cref="ToXmlExtV2"/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        public static string ToXmlExt<T>(this T obj)
             where T : class
        {
            return obj == null ? null : ServiceStack.Text.XmlSerializer.SerializeToString(obj);
        }
    }
}
