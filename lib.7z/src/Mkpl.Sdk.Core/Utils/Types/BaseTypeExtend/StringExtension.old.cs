﻿using System;

namespace Mkpl.Sdk.Core
{
    public static partial class StringExtension
    {
        /// <summary>
        /// (已弃用)格式化国家名字，转换成首字母大写，其他小写。如CHINA->China
        /// <para>推荐使用<see cref="ToCountryName(string)"/></para>
        /// </summary>
        /// <param name="countryName">国家名字</param>
        /// <returns></returns>
        [Obsolete("请参考说明使用新方法")]
        public static string FormatFullCountryNameExt(this string countryName)
        {
            return countryName.ToCountryName();
        }
    }
}