﻿using Microsoft.AspNetCore.Http;
using Newegg.MIS.Baymax.Cache;
using Xunit;

namespace Mkpl.Sdk.Core.Authentication.Test.Aop
{
    public class FunctionAttributeTest
    {
        private static class MockHelper
        {
            public static FunctionAttribute GetFunctionAttribute(
                string functionKey = null,
                IRedisConnection redisConnection = null,
                IHttpContextAccessor httpContextAccessor = null)
            {
                redisConnection = redisConnection.GetMockInterface();
                httpContextAccessor = httpContextAccessor.GetMockInterface();

                var result = new FunctionAttribute(functionKey ?? string.Empty);
                result.RedisConnection = redisConnection;
                result.HttpContextAccessor = httpContextAccessor;

                return result;
            }
        }
    }
}