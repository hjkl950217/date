﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Authentication.Entities;
using Mkpl.Sdk.Core.Authentication.Entities.Options;
using Mkpl.Sdk.Core.Entities.ConstOrEnum.Enum;
using NSubstitute;
using Xunit;

namespace Mkpl.Sdk.Core.Authentication.Test.Middleware
{
    public class MPSAuthenticationExtensionTest
    {
        private static class MockHelper
        {
            public static IConfiguration GetMockConfiguration(JwtToken jwtToken = null)
            {
                jwtToken = jwtToken ?? new JwtToken();

                IConfiguration configuration = CommMockHelper.GetMockInterface<IConfiguration>();

                configuration[Arg.Any<string>()]
                    .Returns(jwtToken.ToJsonExt());

                return configuration;
            }
        }

        public class AddAuthenticationMPSTest
        {
            [Fact]
            public void Run_NoError()
            {
                IServiceCollection services = CommMockHelper.GetMockInterface<IServiceCollection>();
                IConfiguration configuration = MockHelper.GetMockConfiguration();

                services.AddAuthenticationMPS(configuration);
            }

            [Fact]
            public void Run_NoError2()
            {
                IServiceCollection services = CommMockHelper.GetMockInterface<IServiceCollection>();
                IConfiguration configuration = MockHelper.GetMockConfiguration();

                services.AddAuthenticationMPS(configuration);
            }

            [Fact]
            public void TTTTTTTTTTTTTTTTTTT()
            {
                MPSAuthenticationOptions options = MPSAuthenticationOptions.GetDefaultMPSAuthenticationOptions();

                var result = (options.EnableErrorMessageEnv & ApplicationEnvEnum.GDEV) == ApplicationEnvEnum.GDEV;
            }
        }
    }
}