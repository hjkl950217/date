﻿using NSubstitute;

namespace Xunit
{
    public static class SubstituteExtension
    {
        public static T GetMockInterface<T>(this T obj)
            where T : class
        {
            return obj ?? Substitute.For<T>();
        }
    }
}