﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Mkpl.Sdk.Core.Job.Test
{
    public interface ITest
    {
        void Hello();
    }

    public class Test : ITest
    {
        public void Hello()
        {
            Console.WriteLine("hello world!");
        }
    }

    public class AJob : JobBase
    {
        private readonly ITest test;

        public static void ConfigServices(IServiceCollection services, IConfigurationBuilder configBuilder)
        {
            services.AddSingleton<ITest, Test>();
        }

        public AJob(ITest test,JobConfig jobConfig)
        {
            this.test = test;
        }

        public override void Execute()
        {
            test.Hello();
        }
    }
}