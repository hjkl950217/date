﻿using Microsoft.Extensions.CommandLineUtils;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Job.Test
{
    public class CommandOptionExtensionsTest
    {
        [Fact]
        public void GetValueOrDefaultTest()
        {
            var option = new CommandOption("--t", CommandOptionType.SingleValue);

            option.Values.Add("3");
            Assert.True(option.HasValue());
            Assert.Equal(3, option.GetValueOrDefault(1));

            option.Values.Clear();
            Assert.False(option.HasValue());
            Assert.Equal(1, option.GetValueOrDefault(1));
        }
    }
}
