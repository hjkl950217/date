﻿using System.IO;
using Xunit;

namespace Mkpl.Sdk.Core.Job.Test
{
    public class JobBootstrapperTest
    {
        [Fact]
        public void RunShouldNoError()
        {
            new JobBootstrapper("d")
                .Run(new string[] { "AJob", "--no-db-balance", "--env", "gdev" }, GetType().Assembly);
        }

        [Fact]
        public void AddRedisFailedButnShouldNoError()
        {
            new JobBootstrapper("d")
                .Run(new string[] { "AJob", "--env", "gdev" }, GetType().Assembly);
        }

        [Fact]
        public void AddCustomDBFileShouldNoError()
        {
            new JobBootstrapper("d")
                .Run(new string[] { "AJob", "--env", "gdev", "--db", Path.Combine(Directory.GetCurrentDirectory(), "testdb") }, GetType().Assembly);
        }
    }
}