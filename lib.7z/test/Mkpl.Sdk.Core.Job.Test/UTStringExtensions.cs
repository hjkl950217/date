﻿namespace Mkpl.Sdk.Core.Job.Test
{
    public static class UTStringExtensions
    {
        public static string ReplaceLine(this string str)
        {
            return str?.Replace("\r", "")?.Replace("\n", "");
        }
    }
}