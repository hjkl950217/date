﻿using NSubstitute;

namespace Xunit
{
    public static class CommMockHelper
    {
        public static T GetMockInterface<T>()
            where T : class
        {
            return Substitute.For<T>();
        }
    }
}