﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NairCache_Test.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   NairCache_Test created at  4/24/2018 1:50:09 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Nair;
using Nair.Sdk;
using NSubstitute;
using System;
using Xunit;
using Xunit.Abstractions;

namespace Mkpl.Sdk.Core.Test
{
    /// <summary>
    /// 针对NairCache类做测试
    /// </summary>
    public class NairCache_Test
    {
        //固定Nair配置
        public static readonly NairCacheOption mock_Option = new NairCacheOption()
        {
            DatebaseName = "Test",
            DefultExpired = 60 * 60 * 24,
            Password = "TestPwd"
        };

        ///// <summary>
        ///// 针对索引器的测试
        ///// </summary>
        //[Trait("Cache", "NairCache")]
        //public class This_Test
        //{
        //    //用索引器添加数据
        //    [Fact(DisplayName = "AddValue_True")]
        //    public void This_Test_AddValue_True()
        //    {
        //        #region 准备数据与复刻方法

        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairFactory.GetNairClient().Returns(mock_NairClient);

        //        mock_NairClient.Put(mock_Option.DatebaseName, "NumA", 1, mock_Option.DefultExpired, mock_Option.Password);
        //        mock_NairClient.Put(mock_Option.DatebaseName, "NumB", 1.0000000000000001, mock_Option.DefultExpired, mock_Option.Password);
        //        mock_NairClient.Put(mock_Option.DatebaseName, "NumC", 1.000001M, mock_Option.DefultExpired, mock_Option.Password);

        //        mock_NairClient.Get<object>(mock_Option.DatebaseName, "NumA", mock_Option.Password)
        //          .Returns(1);
        //        mock_NairClient.Get<object>(mock_Option.DatebaseName, "NumB", mock_Option.Password)
        //          .Returns(1.0000000000000001);
        //        mock_NairClient.Get<object>(mock_Option.DatebaseName, "NumC", mock_Option.Password)
        //          .Returns(1.000001M);

        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        #endregion 准备数据与复刻方法

        //        int resultA = nairCache.Get<int>("NumA");
        //        double resultB =  nairCache.Get<double>("NumB");
        //        decimal resultC =  nairCache.Get<decimal>("NumC");

        //        Assert.Equal(1, resultA);
        //        Assert.Equal(1.0000000000000001, resultB);
        //        Assert.Equal(1.000001M, resultC);
        //    }

        //    //用索引器添加数据发生异常
        //    [Fact(DisplayName = "AddValue_Exception")]
        //    public void This_Test_AddValue_Exception()
        //    {
        //        #region 准备数据与复刻方法

        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairClient
        //            .WhenForAnyArgs(t => t.Put<decimal>(
        //                null,
        //                null,
        //                0.0M,
        //                0,
        //                null))
        //            .Do(t => throw new Exception("AddValue_Exception"));

        //        mock_NairClient
        //            .WhenForAnyArgs(t => t.Put<object>(
        //                null,
        //                null,
        //                null,
        //                0,
        //                null))
        //            .Do(t => throw new Exception("AddValue_Exception"));

        //        mock_NairFactory.GetNairClient()
        //            .Returns(mock_NairClient);
        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        #endregion 准备数据与复刻方法

        //        //执行
        //        Exception exceA = new Exception();
        //        Exception exceB = new Exception();
        //        try
        //        {
        //            nairCache.Add("NumA", 1.000001M);

        //        }
        //        catch(Exception ex)
        //        {
        //            exceA = ex;
        //        }

        //        try
        //        {
        //            nairCache.Add("NumB", new object());
        //        }
        //        catch(Exception ex)
        //        {
        //            exceB = ex;
        //        }

        //        //验证
        //        Assert.True(exceA.Message.Contains("AddValue_Exception") == true);
        //        Assert.True(exceB.Message.Contains("AddValue_Exception") == true);
        //    }

        //    //用索引器覆盖数据
        //    [Fact(DisplayName = "AddValue_Cover_True")]
        //    public void This_Test_AddValue_Cover_True()
        //    {
        //        #region 准备数据

        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairClient
        //            .Put(mock_Option.DatebaseName, "NumA", 1, mock_Option.DefultExpired, mock_Option.Password);
        //        mock_NairClient
        //            .Put(mock_Option.DatebaseName, "NumA", 1.0000000000000001, mock_Option.DefultExpired, mock_Option.Password);
        //        mock_NairClient
        //            .Put(mock_Option.DatebaseName, "NumA", 1.000001M, mock_Option.DefultExpired, mock_Option.Password);

        //        mock_NairClient
        //            .Get<decimal>(mock_Option.DatebaseName, "NumA", mock_Option.Password)
        //          .Returns(1.000001M);
        //        mock_NairClient
        //            .Get<object>(mock_Option.DatebaseName, "NumA", mock_Option.Password)
        //         .Returns(1.000001M);

        //        mock_NairFactory.GetNairClient()
        //           .Returns(mock_NairClient);
        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        #endregion 准备数据

        //        //执行
        //        decimal num = (decimal)nairCache.Get<Object>("NumA");
        //        decimal result = num.ToString().ToDecimalExt();

        //        //验证
        //        Assert.Equal(1.000001M, result);
        //    }

        //    //用索引器取数据时key不存在
        //    [Fact(DisplayName = "GetObject_Null_True")]
        //    public void This_Test_GetObject_Null_True()
        //    {
        //        #region 准备数据

        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairFactory.GetNairClient().Returns(mock_NairClient);

        //        mock_NairClient
        //            .Get<object>(mock_Option.DatebaseName, "Obj", mock_Option.Password)
        //            .Returns(null);

        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        #endregion 准备数据

        //        //执行

        //        object resultObj = nairCache["Obj"] as object;

        //        //验证
        //        Assert.Null(resultObj);
        //    }

        //    [Fact(DisplayName = "GetObject_Exception")]
        //    public void This_Test_GetObject_Exception()
        //    {
        //        #region 准备数据

        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairFactory.GetNairClient().Returns(mock_NairClient);

        //        mock_NairClient
        //            .WhenForAnyArgs(t => t.Get<object>(
        //                Arg.Any<string>(),
        //                Arg.Any<string>(),
        //                Arg.Any<string>()
        //            ))
        //            .Do(t => throw new Exception("GetObject_Exception"));

        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        #endregion 准备数据

        //        //执行
        //        Exception exce = new Exception();
        //        try
        //        {
        //            object resultObj = nairCache["Obj"] as object;

        //        }
        //        catch(Exception ex)
        //        {
        //            exce = ex;
        //        }

        //        //验证
        //        Assert.True(exce.Message.Contains("GetObject_Exception") == true);
        //    }

        //    [Fact(DisplayName = "UpdateValue_True")]
        //    public void This_Test_UpdateValue_True()
        //    {
        //        INairFactory mock_NairFactory = Substitute.For<INairFactory>();
        //        INairClient mock_NairClient = Substitute.For<INairClient>();

        //        mock_NairFactory.GetNairClient().Returns(mock_NairClient);

        //        mock_NairClient
        //            .Get<object>(mock_Option.DatebaseName, "Obj", mock_Option.Password)
        //            .Returns(new List<string>() { "ABC" });

        //        INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        //第一次执行
        //        List<string> resultObj = nairCache["Obj"] as List<string>;
        //        int result = resultObj
        //            .Count(t => t == "ABC");

        //        //验证
        //        Assert.NotNull(resultObj);
        //        Assert.Equal(1, result);
        //        Assert.Equal("ABC", resultObj[0]);

        //        //第二次执行
        //        mock_NairClient
        //            .Put<object>(
        //                Arg.Any<string>(),
        //                Arg.Any<string>(),
        //                Arg.Any<object>(),
        //                Arg.Any<int>(),
        //                Arg.Any<string>()
        //            );

        //        mock_NairClient
        //          .Get<object>(mock_Option.DatebaseName, "Obj", mock_Option.Password)
        //          .Returns(new List<string>() { "AAA" });
        //        nairCache = new NairCache(mock_NairFactory, mock_Option);

        //        nairCache["Obj"] = new List<string>() { "AAA" };

        //        List<string> resultObj2 = nairCache["Obj"] as List<string>;
        //        int result2 = resultObj2
        //            .Count(t => t == "AAA");

        //        //第二次验证
        //        Assert.NotNull(resultObj2);
        //        Assert.Equal(1, result2);
        //        Assert.Equal("AAA", resultObj2[0]);
        //    }
        //}

        #region 其他方法

        [Trait("Cache", "NairCache")]
        public class OtherTest
        {
            /// <summary>
            /// 测试中输出信息对象
            /// </summary>
            private readonly ITestOutputHelper m_Output;

            public OtherTest(ITestOutputHelper output)
            {
                //给接口注册模拟实例
                this.m_Output = output;
            }

            [Fact(DisplayName = "GetString_True")]
            public void Other_Test_GetString_True()
            {
                #region 准备数据与复刻方法

                INairFactory mock_NairFactory = Substitute.For<INairFactory>();
                INairClient mock_NairClient = Substitute.For<INairClient>();

                mock_NairFactory.GetNairClient().Returns(mock_NairClient);

                mock_NairClient
                    .Get(mock_Option.DatebaseName, "NumA", mock_Option.Password)
                    .Returns("AAA");

                INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

                #endregion 准备数据与复刻方法

                string result = nairCache.Get("NumA");

                Assert.Equal("AAA", result);
            }

            [Fact(DisplayName = "GetString_Excepetion")]
            public void Other_Test_GetString_Excepetion()
            {
                #region 准备数据与复刻方法

                INairFactory mock_NairFactory = Substitute.For<INairFactory>();
                INairClient mock_NairClient = Substitute.For<INairClient>();

                mock_NairFactory.GetNairClient().Returns(mock_NairClient);

                mock_NairClient
                    .WhenForAnyArgs(t => t.Get(
                            Arg.Any<string>(),
                            Arg.Any<string>(),
                            Arg.Any<string>()
                    ))
                    .Do(t => throw new Exception("GetString_Excepetion"));

                INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

                #endregion 准备数据与复刻方法

                //执行
                Exception exce = new Exception("");
                try
                {
                    nairCache.Get("NumA");
                }
                catch (Exception ex)
                {
                    exce = ex;
                }

                this.m_Output.WriteLine(exce.Message);
                Assert.True(exce.Message.Contains("GetString_Excepetion") == true);//执行中捕获到异常
            }

            [Fact(DisplayName = "Remove_True")]
            public void Other_Test_Remove_True()
            {
                #region 准备数据与复刻方法

                INairFactory mock_NairFactory = Substitute.For<INairFactory>();
                INairClient mock_NairClient = Substitute.For<INairClient>();

                mock_NairFactory.GetNairClient().Returns(mock_NairClient);

                mock_NairClient
                    .Remove(mock_Option.DatebaseName, "NumA", mock_Option.Password);

                INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

                #endregion 准备数据与复刻方法

                Exception exce = new Exception("Remove_NoException");
                try
                {
                    nairCache.Delete("NumA");
                }
                catch (Exception ex)
                {
                    exce = ex;
                }

                this.m_Output.WriteLine(exce.Message);
                Assert.True(exce.Message.Contains("Remove_NoException") == true);//没有在执行中捕获到异常
            }

            [Fact(DisplayName = "Remove_Exception")]
            public void Other_Test_Remove_Exception()
            {
                #region 准备数据与复刻方法

                INairFactory mock_NairFactory = Substitute.For<INairFactory>();
                INairClient mock_NairClient = Substitute.For<INairClient>();

                mock_NairFactory
                    .GetNairClient()
                    .Returns(mock_NairClient);

                mock_NairClient
                    .WhenForAnyArgs(t => t.Remove(
                            Arg.Any<string>(),
                            Arg.Any<string>(),
                            Arg.Any<string>()
                    ))
                    .Do(t => throw new Exception("Remove_Exception"));

                INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

                #endregion 准备数据与复刻方法

                Exception exce = new Exception("");
                try
                {
                    nairCache.Delete("NumA");
                }
                catch (Exception ex)
                {
                    exce = ex;
                }

                this.m_Output.WriteLine(exce.Message);
                Assert.True(exce.Message.Contains("Remove_Exception") == true);//执行中捕获到异常
            }
        }

        #endregion 其他方法

        #region 测试key的处理

        [Trait("Cache", "NairCache")]
        public class KeyTest
        {
            /// <summary>
            /// 测试中输出信息对象
            /// </summary>
            private readonly ITestOutputHelper m_Output;

            public KeyTest(ITestOutputHelper output)
            {
                //给接口注册模拟实例
                this.m_Output = output;
            }

            private INairCache GetMockINairCache()
            {
                INairFactory mock_NairFactory = Substitute.For<INairFactory>();
                INairClient mock_NairClient = Substitute.For<INairClient>();

                mock_NairFactory.GetNairClient().Returns(mock_NairClient);

                INairCache nairCache = new NairCache(mock_NairFactory, mock_Option);

                return nairCache;
            }

            [Theory(DisplayName = "Key-Null-Exception")]
            [InlineData("Get")]
            [InlineData("GetT")]
            [InlineData("Add")]
            [InlineData("Delete")]
            //[InlineData("GetDir")]
            //[InlineData("Incr")]
            //[InlineData("Put")]
            //[InlineData("Remove")]

            public void Key_NoullKey_Exception(string methodName)
            {
                INairCache nairCache = this.GetMockINairCache();

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
               {
                   switch (methodName)
                   {
                       case "Get":
                           nairCache.Get(null);
                           break;

                       case "GetT":
                           nairCache.Get<object>(string.Empty);
                           break;

                       case "Add":
                           nairCache.Add(string.Empty, new object());
                           break;

                       case "Delete":
                           nairCache.Delete(string.Empty);
                           break;

                       //case "GetDir":
                       //    nairCache.Get<object>(new List<string>());
                       //    break;

                       //case "Incr":
                       //    nairCache.Incr(string.Empty, 50, 50);
                       //    break;

                       //case "Put":
                       //    nairCache.Put(string.Empty, new object());
                       //    break;

                       //case "Remove":
                       //    nairCache.Remove(string.Empty);
                       //    break;

                       default:
                           break;
                   }
               });

                Assert.Contains("Key is null", ex.Message);
                Assert.Equal("key", ex.ParamName);
            }
        }

        #endregion 测试key的处理
    }
}