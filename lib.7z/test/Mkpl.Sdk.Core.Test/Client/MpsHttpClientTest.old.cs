﻿using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.Client;
using NSubstitute;
using System;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Client", "MpsHttpClient")]
    public partial class MpsHttpClientTest_old
    {
        #region 复刻固定数据

        private static class MockHelper
        {
            public static string TeamKey1 = "A";
            public static string TeamKey_ApproveCenter = "ApproveCenter";

            public static string ApiKey1 = "API1";
            public static string ApiKey2 = "API2";

            /// <summary>
            /// 获取MpsHttpClientFactory
            /// </summary>
            /// <param name="AllAPIConfig"></param>
            /// <returns></returns>
            public static IMpsHttpClientFactory GetMpsHttpClientFactory(AllApiConfig AllAPIConfig = null)
            {
                IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();

                IMpsHttpClientFactory result = new MpsHttpClientFactory(restApiClientFactory, AllAPIConfig);

                return result;
            }

            /// <summary>
            /// 获取configServer
            /// </summary>
            /// <returns></returns>
            public static AllApiConfig GetAllAPIConfig()
            {
                AllApiConfig result = Substitute.For<AllApiConfig>();
                result.DevPlatformHost = "http://127.0.0.1";
                result.TeamApiConfigList = new Dictionary<string, TeamConfigEntity>()
                {
                    #region A团队

                    {
                        "A",
                        new TeamConfigEntity ()
                        {
                            BaseToken ="ab",
                            ApiConfigList=new Dictionary<string, ApiEntity>()
                            {
                                {
                                    MockHelper.ApiKey1,
                                    new ApiEntity ()
                                    {
                                        Address="API1"
                                    }
                                }
                            }
                        }
                    },

                    #endregion A团队

                    #region B团队

                    {
                        "B",
                        new TeamConfigEntity ()
                        {
                            BaseToken ="cd",
                            ApiConfigList=new Dictionary<string, ApiEntity>()
                            {
                                {
                                    MockHelper.ApiKey2,
                                    new ApiEntity ()
                                    {
                                        Address="API2"
                                    }
                                }
                            }
                        }
                    },

                    #endregion B团队

                    #region 模拟ApproveCenter

                    {
                        "ApproveCenter",
                        new TeamConfigEntity ()
                        {
                            BaseToken ="testToken3",
                            ApiConfigList=new Dictionary<string, ApiEntity>()
                            {
                                {
                                    "API3",
                                    new ApiEntity ()
                                    {
                                        Address="API3"
                                    }
                                }
                            }
                        }
                    }

                    #endregion 模拟ApproveCenter
                };

                return result;
            }

            /// <summary>
            /// 获取RequestHead
            /// </summary>
            /// <returns></returns>
            public static RequestHead GetRequestHead()
            {
                return new RequestHead()
                {
                    UserAgent = "UserAgent",
                    CustomHeaderList = new Dictionary<string, string>()
                {
                    {"TestKey","TestVlaue" }
                }
                };
            }
        }

        #endregion 复刻固定数据

        #region MpsHttpClientFactory

        [Trait("Client", "MpsHttpClient")]
        public class MpsHttpClientFactoryTest
        {
            [Fact(DisplayName = "GetClient-RestClient")]
            public void TC_GetClient_RestClient()
            {
                #region 模拟数据与模拟返回

                var config = MockHelper.GetAllAPIConfig();

                IMpsHttpClientFactory factory = MockHelper.GetMpsHttpClientFactory(config);

                #endregion 模拟数据与模拟返回

                //执行
#pragma warning disable CS0618 // 类型或成员已过时
                IMpsHttpClient client = factory.GetRestClient(MockHelper.TeamKey_ApproveCenter);
#pragma warning restore CS0618 // 类型或成员已过时
                RestClient result = client as RestClient;
                OAuthClient result2 = client as OAuthClient;

                //验证
                Assert.NotNull(client);
                Assert.NotNull(result);

                //OAuthClient继承了RestClient
                //所以返回的如果是RestClient，则转换成OAuthClient一定失败
                Assert.Null(result2);
                Assert.IsType<RestClient>(result);//确定返回的一定是RestClient
            }

            [Fact(DisplayName = "GetClient-OAuthClient")]
            public void TC_GetClient_OAuthClient()
            {
                #region 模拟数据与模拟返回

                var config = MockHelper.GetAllAPIConfig();

                IMpsHttpClientFactory factory = MockHelper.GetMpsHttpClientFactory(config);

                #endregion 模拟数据与模拟返回

                //执行
#pragma warning disable CS0618 // 类型或成员已过时
                IMpsHttpClient client = factory.GetOAuthClient(MockHelper.TeamKey1);
#pragma warning restore CS0618 // 类型或成员已过时
                OAuthClient result = client as OAuthClient;

                //验证
                Assert.NotNull(client);
                Assert.NotNull(result);
                Assert.IsType<OAuthClient>(result);
            }

            [Fact(DisplayName = "GetClient-TeamName-EqualsLoose")]
            public void Tc_GetClient_TeamName_EqualsLoose()
            {
                #region 模拟数据与模拟返回

                var config = MockHelper.GetAllAPIConfig();

                IMpsHttpClientFactory factory = MockHelper.GetMpsHttpClientFactory(config);

                #endregion 模拟数据与模拟返回

                //执行
#pragma warning disable CS0618 // 类型或成员已过时
                IMpsHttpClient client = factory.GetOAuthClient("approvecenter ");
#pragma warning restore CS0618 // 类型或成员已过时

                OAuthClient result = client as OAuthClient;

                //验证
                Assert.NotNull(client);
                Assert.NotNull(result);
                Assert.IsType<OAuthClient>(result);
            }
        }

        #endregion MpsHttpClientFactory

        #region 构造方法

        [Fact(DisplayName = "Init-NullConfig")]
        public void TC_Init_NullConfig()
        {
            //执行
            var ex = Assert.Throws<ArgumentException>(() =>
            {
                new MpsHttpClientFactory(null, null);
            });

            //验证
            Assert.Contains("object is null for", ex.Message);
        }

        [Fact(DisplayName = "Init-NullTeamNameKey")]
        public void TC_Init_OAuthClient()
        {
            var config = MockHelper.GetAllAPIConfig();

            //执行
            var ex = Assert.Throws<ArgumentException>(() =>
            {
                var factory = new MpsHttpClientFactory(null, config);
#pragma warning disable CS0618 // 类型或成员已过时
                factory.GetOAuthClient("NotApiTeam");
#pragma warning restore CS0618 // 类型或成员已过时
            });

            //验证
            Assert.Contains("key not found in", ex.Message);
        }

        #endregion 构造方法

        #region Client内部方法

        /*
         * 这里没有按规范来，因为两个客户端（或以后其他的）
         * 会依赖RestClient
         *
         * 所以用一个测试类继承它，就可以测试到内部方法
         *
         */

        private class TestClient : RestClient
        {
            public TestClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
            : base(clientFactory, devHost, teamConfigEntity)
            { }

            public ApiEntity FindApi2(string apiKey)
            {
                // return base.teamConfigEntity.FindApi(apiKey);
                return base.TeamConfig.FindApi(apiKey, base.DevPlatformHost);
            }

            public IRestApiClient BuildClient2(RequestHead requestHead = null, string CustomToken = null)
            {
                return base.BuildClient(requestHead, CustomToken);
            }
        }

        private class TestOAuthClient : OAuthClient
        {
            public TestOAuthClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
            : base(clientFactory, devHost, teamConfigEntity)
            { }

            public IRestApiClient BuildClient2(RequestHead requestHead = null, string CustomToken = null)
            {
                return base.BuildClient(requestHead, CustomToken);
            }
        }

        [Fact(DisplayName = "Protected-FindApi")]
        public void TC_RestClient_FindApi()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey1]);

            #endregion 模拟数据与模拟返回

            //执行
            var result = restClient.FindApi2("API1");

            //验证
            Assert.NotNull(result);
            Assert.Equal(config.TeamApiConfigList[MockHelper.TeamKey1].ApiConfigList[MockHelper.ApiKey1].Host
                , result.Host);
            Assert.Equal(config.TeamApiConfigList[MockHelper.TeamKey1].ApiConfigList[MockHelper.ApiKey1].Token
                , result.Token);
        }

        [Fact(DisplayName = "Protected-FindApi-NullKey-Exception")]
        public void TC_RestClient_FindApi_NullKey_Exception()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey1]);

            #endregion 模拟数据与模拟返回

            //执行

            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                restClient.FindApi2(null);
            });

            //验证
            Assert.Contains("Data is null for ApiKey", ex.Message);
        }

        [Fact(DisplayName = "Protected-FindApi-NullData-Exception")]
        public void TC_RestClient_FindApi_NullData_Exception()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey1]);

            #endregion 模拟数据与模拟返回

            //执行

            var ex = Assert.Throws<ArgumentException>(() =>
            {
                restClient.FindApi2("API111");
            });

            //验证
            Assert.Contains("Find Data failure for", ex.Message);
        }

        [Fact(DisplayName = "Protected-BuildClient")]
        public void TC_RestClient_BuildClient()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey1];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory.Build(Arg.Any<string>()).Returns(restApiClient);

            TestClient restClient = new TestClient(
                restApiClientFactory,
                config.DevPlatformHost,
                configTeam);

            RequestHead requestHead = MockHelper.GetRequestHead();
            string customToken = "mock_CustomToken";

            #endregion 模拟数据与模拟返回

            //执行
            restClient.BuildClient2(requestHead, customToken);

            //验证
            Assert.Equal(customToken, restApiClient.Authorization);

            //确保这头部数据被写入了
            restApiClient
                .Received()
                .AddCustomHeader(Arg.Any<string>(), Arg.Any<string>());
            restApiClient
                .Received()
                .SetUserAgent(Arg.Any<string>());
            restApiClient
                .Received()
                .SetAccept(Arg.Any<string>());
            restApiClient
                .Received()
                .ContentType = Arg.Any<string>();
        }

        [Fact(DisplayName = "Protected-OAuthClient-BuildClient")]
        public void TC_OAuthClient_BuildClient()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey1];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory.Build(string.Empty).Returns(restApiClient);

            TestOAuthClient restClient = new TestOAuthClient(
                restApiClientFactory,
             config.DevPlatformHost,
             configTeam);

            RequestHead requestHead = MockHelper.GetRequestHead();
            string customToken = "mock_CustomToken";

            #endregion 模拟数据与模拟返回

            //执行
            restClient.BuildClient2(requestHead, customToken);

            //验证
            Assert.Equal($"Bearer {customToken}", restApiClient.Authorization);

            //确保这头部数据被写入了
            restApiClient
                .Received()
                .AddCustomHeader(Arg.Any<string>(), Arg.Any<string>());
            restApiClient
                .Received()
                .SetUserAgent(Arg.Any<string>());
            restApiClient
                .Received()
                .SetAccept(Arg.Any<string>());
            restApiClient
                .Received()
                .ContentType = Arg.Any<string>();
        }

        #endregion Client内部方法
    }
}