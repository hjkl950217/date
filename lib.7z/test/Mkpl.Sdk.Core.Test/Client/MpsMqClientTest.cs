﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMqClientTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMqClientTest created at  5/15/2018 2:29:02 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.MQ;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using Xunit.Abstractions;

namespace Mkpl.Sdk.Core.Test
{
    public partial class MpsMqClientTest
    {
        #region 复刻固定数据

        private static class MockHelp
        {
            public static GroupQueue GetMockGroupQueue()
            {
                GroupQueue result = new GroupQueue()
                {
                    DefaultPassword = "123",
                    GoupName = QueueGoupNameConst.Team_MKPL,
                };

                result.Queues = new List<Queue>()
                {
                    new Queue()
                    {
                        KeyName="A",
                        QueueName="A"
                    },
                    new Queue()
                    {
                        KeyName="B",
                        QueueName="B",
                        Password="BVB"
                    }
                };

                return result;
            }

            public static (MQClient mQClient, IMessagePublisher messagePublisher) GetMockMQClient(PublishResultInfo publishResultInfo = null)
            {
                //只模拟了一个数据
                MQConfig mq = new MQConfig()
                {
                    GroupQueues = new List<GroupQueue>()
                    {
                        MockHelp.GetMockGroupQueue()
                    }
                };

                IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
                messagePublisher.SendMessage(
                    Arg.Any<object>(),
                    Arg.Any<string>(),
                    MessageContentType.Json,
                    Arg.Any<string>(),
                    Arg.Any<List<KeyValuePair<string, string>>>()
                    )
                    .Returns(publishResultInfo);

                MQClient mQClient = new MQClient(mq, messagePublisher);

                return (mQClient, messagePublisher);
            }

            public static MQHeaderV2 GetMockMQheaderV2()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                return mQHeaderV2;
            }
        }

        #endregion 复刻固定数据

        [Fact(DisplayName = "MQClient-NullGroupQueue")]
        [Trait("Client", "MQClient")]
        public void TC_MQClient_NullGroupQueue()
        {
            #region 模拟数据与模拟返回

            IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
            MQConfig mQConfig = new MQConfig()
            {
                GroupQueues = new List<GroupQueue>()
            };

            #endregion 模拟数据与模拟返回

            //执行
            var ex = Assert.Throws<InvalidOperationException>(() =>
            {
                new MQClient(mQConfig, messagePublisher);
            });

            //验证
            Assert.Contains("GroupQueue Config is not found", ex.Message);
        }

        #region BaseSend

        [Trait("Client", "MQClient")]
        public class BaseSendTest
        {
            /// <summary>
            /// 测试中输出信息对象
            /// </summary>
            private readonly ITestOutputHelper m_Output;

            public BaseSendTest(ITestOutputHelper output)
            {
                //给接口注册模拟实例
                this.m_Output = output;
            }

            [Fact(DisplayName = "BaseSend-NullHead")]
            public void TC_BaseSend_NullHead()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = null;

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage(new object(), "ZZ", mQHeaderV2);
                });

                //验证
                Assert.Contains("when sending MQ", ex.Message);
                Assert.Equal("header", ex.ParamName);
            }

            [Fact(DisplayName = "BaseSend-NullRequest")]
            public void TC_BaseSend_NullRequest()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage<object>(null, "ZZ", mQHeaderV2);
                });

                //验证
                Assert.Contains("when sending MQ", ex.Message);
                Assert.Equal("message", ex.ParamName);
            }

            [Fact(DisplayName = "BaseSend-ContentType")]
            public void TC_BaseSend_ContentType()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                mQClient.SendMessage<object>(new object(), "A", mQHeaderV2);

                //验证
                messagePublisher.Received()
                    .SendMessage<object>(
                        Arg.Any<object>(),
                        Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<List<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "Content-Type"))

                    );
            }

            [Fact(DisplayName = "BaseSend-Accept")]
            public void TC_BaseSend_Accept()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                mQClient.SendMessage<object>(new object(), "A", mQHeaderV2);

                //验证
                messagePublisher.Received()
                    .SendMessage<object>(
                        Arg.Any<object>(),
                        Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<List<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "Accept"))

                    );
            }
        }

        #endregion BaseSend
    }
}