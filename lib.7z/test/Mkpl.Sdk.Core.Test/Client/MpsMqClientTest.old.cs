﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMqClientTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMqClientTest created at  5/15/2018 2:29:02 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Newegg.MIS.Baymax.MQ;
using System;
using Xunit;
using Xunit.Abstractions;

namespace Mkpl.Sdk.Core.Test
{
#pragma warning disable CS0618 // 类型或成员已过时

    public partial class MpsMqClientTest
    {
        #region BaseSend

        [Trait("Client", "MQClient")]
        public class BaseSend_Old_Test
        {
            /// <summary>
            /// 测试中输出信息对象
            /// </summary>
            private readonly ITestOutputHelper m_Output;

            public BaseSend_Old_Test(ITestOutputHelper output)
            {
                //给接口注册模拟实例
                this.m_Output = output;
            }

            [Fact(DisplayName = "BaseSend-NullHead")]
            public void TC_BaseSend_NullHead()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeader mQHeader = null;

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage(new object(), "ZZ", mQHeader);
                });

                //验证
                Assert.Contains("when sending MQ", ex.Message);
                Assert.Equal("header", ex.ParamName);
            }

            [Fact(DisplayName = "BaseSend-NullRequest")]
            public void TC_BaseSend_NullRequest()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage<object>(null, "ZZ", new MQHeader());
                });

                //验证
                Assert.Contains("when sending MQ", ex.Message);
                Assert.Equal("message", ex.ParamName);
            }
        }

        #endregion BaseSend
    }

#pragma warning restore CS0618 // 类型或成员已过时
}