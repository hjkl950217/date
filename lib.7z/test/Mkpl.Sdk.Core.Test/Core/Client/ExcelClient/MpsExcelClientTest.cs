﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsExcelClientTest.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsExcelClientTest created at  10/23/2018 10:44:18 AM
// </summary>
//<Description>

//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    /// <summary>
    /// The class of MpsExcelClientTest.
    /// </summary>
    ///
    [Trait("Client", "MpsExcelClient")]
    public class MpsExcelClientTest
    {
        private readonly MpsExcelClient _mpsExcelClient;

        public MpsExcelClientTest()
        {
            this._mpsExcelClient = new MpsExcelClient();
        }

        #region 导出测试数据

#pragma warning disable S101 // Types should be named in PascalCase

        public class RFQTest
#pragma warning restore S101 // Types should be named in PascalCase
        {
            [ExcelMap("Tran#", Ordinal = 1, Width = 10)]
            public string RFQStatus { get; set; }

            [ExcelMap("Tran#", Ordinal = 2, Width = 10)]
            public string TicketNumber { get; set; }

            [ExcelMap("Tran#", Ordinal = 3, Width = 10)]
            public string AEName { get; set; }

            [ExcelMap("Tran#", Ordinal = 5, Width = 10)]
            public string LeadName { get; set; }

            [ExcelMap("Tran#", Ordinal = 4, Width = 10)]
            public int RFQNumber { get; set; }

            [ExcelMap("Tran#", Ordinal = 7, Width = 10)]
            public DateTime ExpiredDate { get; set; }

            [ExcelMap("Tran#", Ordinal = 6, Width = 10)]
            public DateTime CreatedTime { get; set; }

            [ExcelMap("Tran#", Ordinal = 8, Width = 10)]
            public string CreatedUser { get; set; }

            [ExcelMap("Tran#", Ordinal = 9, Width = 10)]
            public string SKUName { get; set; }

            [ExcelMap("Tran#", Ordinal = 11, Width = 10)]
            public string SKUURL { get; set; }

            [ExcelMap("Tran#", Ordinal = 10, Width = 10)]
            public int Quantity { get; set; }

            [ExcelMap("Tran#", Ordinal = 13, Width = 10)]
            public decimal UnitPrice { get; set; }

            [ExcelMap("Tran#", Ordinal = 12, Width = 10)]
            public string CustomerNumber { get; set; }

            [ExcelMap("Tran#", Ordinal = 14, Width = 10)]
            public string EmailAddress { get; set; }

            [ExcelMap("Tran#", Ordinal = 16, Width = 10)]
            public string CustomerName { get; set; }

            [ExcelMap("Tran#", Ordinal = 15, Width = 10)]
            public string CompanyName { get; set; }

            [ExcelMap("Tran#", Ordinal = 18, Width = 10)]
            public string PhoneNumber { get; set; }

            [ExcelMap("Tran#", Ordinal = 19, Width = 10)]
            public string PONumber { get; set; }

            [ExcelMap("Tran#", Ordinal = 17, Width = 10)]
            public string ShippingZip { get; set; }

            [ExcelMap("Tran#", Ordinal = 21, Width = 10)]
            public string DesiredDeliveryDate { get; set; }

            [ExcelMap("Tran#", Ordinal = 20, Width = 10)]
            public DateTime LastRFQTime { get; set; }

            [ExcelMap("Tran#", Ordinal = 22, Width = 10)]
            public int SubmittedSellerCount { get; set; }

            [ExcelMap("Tran#", Ordinal = 24, Width = 10)]
            public int SubmittedTotalSKUQTY { get; set; }

            [ExcelMap("Tran#", Ordinal = 25, Width = 10)]
            public DateTime LastSubmittedTime { get; set; }

            [ExcelMap("Tran#", Ordinal = 23, Width = 10)]
            public string SellerIDAndName { get; set; }

            [ExcelMap("Tran#", Ordinal = 31, Width = 10)]
            public int QTY { get; set; }

            [ExcelMap("Tran#", Ordinal = 1, Width = 10)]
            public decimal UnitPrice2 { get; set; }

            [ExcelMap("Tran#", Ordinal = 26, Width = 10)]
            public string ShippingMethod { get; set; }

            [ExcelMap("Tran#", Ordinal = 27, Width = 10)]
            public string ShippingOption { get; set; }

            [ExcelMap("Tran#", Ordinal = 28, Width = 10)]
            public decimal TotalShippingCharge { get; set; }

            [ExcelMap("Tran#", Ordinal = 29, Width = 10)]
            public decimal TotalQuotationAmount { get; set; }

            [ExcelMap("Tran#", Ordinal = 30, Width = 10)]
            public string SellerIDAndName2 { get; set; }
        }

        #endregion 导出测试数据

        private static class MockHelper
        {
            /// <summary>
            /// 返回测试模版的文件全名
            /// </summary>
            /// <returns></returns>
            public static string GetTestTemplateAddress()
            {
                return $"{Directory.GetCurrentDirectory()}{Path.DirectorySeparatorChar}Core{Path.DirectorySeparatorChar}Client{Path.DirectorySeparatorChar}ExcelClient{Path.DirectorySeparatorChar}TestFileTemplate{Path.DirectorySeparatorChar}RFQ Export Template.xlsx";
            }

            public static List<RFQTest> GetRFQTests()
            {
                List<RFQTest> excel = new List<RFQTest>();
                for (int i = 0 ; i < 100 ; i++)
                {
                    RFQTest rfq = new RFQTest()
                    {
                        RFQStatus = "closeed",
                        TicketNumber = "T1001",
                        RFQNumber = 123,
                        AEName = "Jason X",
                        LeadName = "Kathy Lee",
                        ExpiredDate = DateTime.Now,
                        CreatedTime = DateTime.Now,
                        CreatedUser = "Kathy Lee",
                        SKUName = "DELL XPS15-4234",
                        SKUURL = "https://www.ebay.com/Product/K5TZ7250",
                        Quantity = 100,
                        UnitPrice = (decimal)789.99,
                        CustomerNumber = "26265235",
                        EmailAddress = "lewis@newegg.com",
                        CustomerName = "Tom R",
                        CompanyName = "ABC INTL Corp.",
                        PhoneNumber = "626-271-9800",
                        ShippingZip = "1251",
                        DesiredDeliveryDate = "As soon as possible",
                        LastRFQTime = DateTime.Now.AddDays(12),
                        SubmittedSellerCount = 2,
                        SubmittedTotalSKUQTY = 180,
                        LastSubmittedTime = DateTime.Now,
                        SellerIDAndName2 = "(V124) ABC Store",
                        QTY = 100,
                        UnitPrice2 = (decimal)81300.00,
                        SellerIDAndName = "(V124) ABC Store",
                        ShippingMethod = "Standard Shiping (5-7 business days)",
                        ShippingOption = "Follow Shipping Rate Setting",
                        TotalShippingCharge = (decimal)250.00,
                        TotalQuotationAmount = (decimal)281300.00,
                    };
                    excel.Add(rfq);
                }
                return excel;
            }
        }

        [Fact(DisplayName = "GetTypeColumnMapping_TotalCount")]
        [Trait("Client", "ExcelClient")]
        public void TC_GetTypeColumnMapping()
        {
            var columnMapping = MpsExcelClient.GetTypeColumnMapping(typeof(RFQTest));
            //获得的mapping 关系中元素的数量和使用属性数量相同
            Assert.Equal(32, columnMapping.Count);
        }

        [Fact(DisplayName = "AppendRow_HasData")]
        [Trait("Client", "ExcelClient")]
        public void TC_AppendRow_HasData()
        {
            FileInfo file = new FileInfo(MockHelper.GetTestTemplateAddress());
            using (ExcelPackage package = new ExcelPackage(file))
            {
                var currentSheet = package.Workbook.Worksheets[1];
                var columnMapping = MpsExcelClient.GetTypeColumnMapping(typeof(RFQTest));
                List<RFQTest> excel = MockHelper.GetRFQTests();

                int affectRows = this._mpsExcelClient.AppendRow<RFQTest>(
                    currentSheet,
                    excel,
                    columnMapping,
                    3);

                //写入100行数据，因为是index++,所以是2+100+1
                Assert.Equal(103, affectRows);
            }
        }

        [Fact(DisplayName = "AppendRow_NoData")]
        [Trait("Client", "ExcelClient")]
        public void TC_AppendRow_NoData()
        {
            FileInfo file = new FileInfo(MockHelper.GetTestTemplateAddress());
            using (ExcelPackage package = new ExcelPackage(file))
            {
                var currentSheet = package.Workbook.Worksheets[1];
                var columnMapping = MpsExcelClient.GetTypeColumnMapping(typeof(RFQTest));

                int affectRows = this._mpsExcelClient.AppendRow<RFQTest>(currentSheet, null, columnMapping, 3);

                //未写入数据
                Assert.Equal(3, affectRows);
            }
        }

        [Fact(DisplayName = "ApplyStyle")]
        [Trait("Client", "ExcelClient")]
        public void TC_ApplyStyle()
        {
            FileInfo file = new FileInfo(MockHelper.GetTestTemplateAddress());
            using (ExcelPackage package = new ExcelPackage(file))
            {
                var currentSheet = package.Workbook.Worksheets[1];
                var sheet = this._mpsExcelClient.ApplyStyle(currentSheet, 3, 103, 32);

                //验证应用样式之后同一列的数据单元格的样式是否相同
                Assert.Equal(sheet.Cells[3, 1].StyleID, sheet.Cells[103, 1].StyleID);
                Assert.Equal(sheet.Cells[3, 12].StyleID, sheet.Cells[103, 12].StyleID);
            }
        }
    }
}