﻿using Microsoft.AspNetCore.Http;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.DFIS.Uploader;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Client", "FileClient")]
    public class MpsFileClientTest
    {
        #region 准备数据

        internal static class MockHelp
        {
            public const string TestKey1 = "Name1";
            public const string TestKey2 = "Name2";
            public const string TestSellerID = "AAAA";
            public const string MockFileName = "FileName.jpeg";
            public static string ExtendName = Path.GetExtension(MockHelp.MockFileName);
            public const string BusinessName = "BusinessName";

            public static FileConfig GetMockFiileConfig()
            {
                FileConfig fileConfig = new FileConfig();

                DfisConfig dfisConfig = new DfisConfig()
                {
                    UploadHostAddress = "http://UpHost:8080",
                    DownloadHostAddress = "http://DownHost:8080"
                };

                List<DfisConfigInfo> configInfos = new List<DfisConfigInfo>()
                {
                    new DfisConfigInfo()
                    {
                        Group="Group1",
                        Name=TestKey1,
                        Type="Type1"
                    },
                    new DfisConfigInfo()
                    {
                        Group="Group2",
                        Name=TestKey2,
                        Type="Type2"
                    }
                };

                dfisConfig.GroupInfoList = configInfos;
                fileConfig.Dfis = dfisConfig;

                return fileConfig;
            }

            public static IDownConfig GetMockDownConfig()
            {
                FileConfig fileConfig = MockHelp.GetMockFiileConfig();

                IDownConfig downConfig = Substitute.For<DownConfig>(fileConfig);

                return downConfig;
            }

            /// <summary>
            /// 测试用的IFormFile
            /// </summary>
            public class MockFormFile : IFormFile
            {
                public string ContentType => throw new NotImplementedException();

                public string ContentDisposition => throw new NotImplementedException();

                public IHeaderDictionary Headers => throw new NotImplementedException();

                public long Length => throw new NotImplementedException();

                public string Name => throw new NotImplementedException();

                public string FileName => MockHelp.MockFileName;

                public void CopyTo(Stream target)
                {
                    throw new NotImplementedException();
                }

                public Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken))
                {
                    throw new NotImplementedException();
                }

                public Stream OpenReadStream()
                {
                    return Substitute.For<Stream>();
                }
            }

            /// <summary>
            /// 获取模拟的请求数据，可选数据都没赋值
            /// </summary>
            /// <returns></returns>
            public static UploadIn GetMockUploadIn()
            {
                UploadIn testIn = new UploadIn()
                {
                    SellerID = MockHelp.TestSellerID,
                    File = new MockFormFile(),
                    GroupName = "MPS"
                };

                return testIn;
            }

            /// <summary>
            /// 获取一个不需要模拟数据的测试实例
            /// </summary>
            /// <returns></returns>
            public static IMpsFileClient GetDfisFileClient(IDfispUploader dfispUploader)
            {
                FileConfig fileConfig = MockHelp.GetMockFiileConfig();
                IDownConfig downConfig = MockHelp.GetMockDownConfig();

                MpsFileClientFactory mpsFileClientFactory = new MpsFileClientFactory(fileConfig, dfispUploader, downConfig);

                IMpsFileClient result = mpsFileClientFactory.GetDfisFileClient();

                return result;
            }

            public static IDfispUploader GetMockDfispUploaderExcepetion()
            {
                Action<IDfispUploader> matcher = t =>
                {
                    t.UploadFile(
                        Arg.Any<Stream>(),
                        Arg.Any<string>(),
                        Arg.Any<string>(),
                        Arg.Any<string>(),
                        Arg.Any<string>(),
                        Arg.Any<string>(),
                        Arg.Any<UploadMethod>());
                };

                IDfispUploader dfispUploader = Substitute.For<IDfispUploader>();
                dfispUploader
                    .When(matcher)
                    .Do(x => throw new Exception("An error occurred"));

                return dfispUploader;
            }
        }

        #endregion 准备数据

        #region Factory

        #region 构造方法

        [Fact]
        public void Init_BuildCilent()
        {
            FileConfig fileConfig = MockHelp.GetMockFiileConfig();
            IDownConfig downConfig = MockHelp.GetMockDownConfig();

            MpsFileClientFactory mpsFileClientFactory = new MpsFileClientFactory(fileConfig, null, downConfig);

            //执行
            IMpsFileClient result = mpsFileClientFactory.GetDfisFileClient();
            DfisFileClient result2 = result as DfisFileClient;

            //验证
            Assert.NotNull(result);
            Assert.NotNull(result2);
            Assert.IsType<DfisFileClient>(result2);
        }

        [Fact]
        public void Init_BuildCilent_Exception()
        {
            IDownConfig downConfig = MockHelp.GetMockDownConfig();

            //执行
            var ex = Assert.Throws<ArgumentException>(() =>
            {
                new MpsFileClientFactory(null, null, downConfig);
            });

            //验证
            Assert.Contains("object is null for", ex.Message);
        }

        #endregion 构造方法

        #endregion Factory

        #region BuildFileName

        [Trait("Client", "FileClient")]
        public class BuildFileNameTest
        {
            //测试默认情况
            [Fact]
            public void TC_BuildFileName_Format()
            {
                UploadIn request = MockHelp.GetMockUploadIn();
                IDfispUploader dfispUploader = Substitute.For<IDfispUploader>();

                IMpsFileClient mpsFileClient = MockHelp.GetDfisFileClient(dfispUploader);

                //执行
                UploadOut result = mpsFileClient.UploadFile(MockHelp.TestKey1, request);

                int num = 16 + 1
                    + MockHelp.TestSellerID.Length
                    + MockHelp.ExtendName.Length;
                Assert.Equal(MockHelp.MockFileName, result.UploadFileName);
                Assert.Equal(num, result.FileName.Length);
            }

            //测试有传业务的情况
            [Fact]
            public void TC_BuildFileName_Format2()
            {
                UploadIn request = MockHelp.GetMockUploadIn();
                request.BusinessName = MockHelp.BusinessName;
                IDfispUploader dfispUploader = Substitute.For<IDfispUploader>();

                IMpsFileClient mpsFileClient = MockHelp.GetDfisFileClient(dfispUploader);

                //执行
                UploadOut result = mpsFileClient.UploadFile(MockHelp.TestKey1, request);

                int num = 16 + 1
                    + MockHelp.TestSellerID.Length + 1
                    + MockHelp.BusinessName.Length
                    + MockHelp.ExtendName.Length;
                Assert.Equal(MockHelp.MockFileName, result.UploadFileName);
                Assert.Equal(num, result.FileName.Length);
                Assert.Contains(MockHelp.BusinessName, result.FileName);
            }

            //测试有传业务和添加key的情况
            [Fact]
            public void TC_BuildFileName_Format3()
            {
                UploadIn request = MockHelp.GetMockUploadIn();
                request.BusinessName = MockHelp.BusinessName;
                request.IsAddKey = true;
                IDfispUploader dfispUploader = Substitute.For<IDfispUploader>();

                IMpsFileClient mpsFileClient = MockHelp.GetDfisFileClient(dfispUploader);

                //执行
                UploadOut result = mpsFileClient.UploadFile(MockHelp.TestKey1, request);

                int num = 16 + 1
                    + MockHelp.TestSellerID.Length
                    + MockHelp.BusinessName.Length + 1
                    + MockHelp.TestKey1.Length + 1
                    + MockHelp.ExtendName.Length;
                Assert.Equal(MockHelp.MockFileName, result.UploadFileName);
                Assert.Equal(num, result.FileName.Length);
                Assert.Contains(MockHelp.BusinessName, result.FileName);
                Assert.Contains(MockHelp.TestKey1, result.FileName);
            }
        }

        #endregion BuildFileName

        #region UploadFile

        [Trait("Client", "FileClient")]
        public class UploadFileTest
        {
            [Fact]
            public void TC_UploadFile_Exception()
            {
                UploadIn request = MockHelp.GetMockUploadIn();
                IDfispUploader dfispUploader = MockHelp.GetMockDfispUploaderExcepetion();

                IMpsFileClient mpsFileClient = MockHelp.GetDfisFileClient(dfispUploader);

                //执行

                var ex = Assert.Throws<IOException>(() =>
                {
                    mpsFileClient.UploadFile(MockHelp.TestKey1, request);
                });

                Assert.Contains("Upload File Failed!,File:", ex.Message);
            }

            [Fact]
            public void TC_UploadFile_Out()
            {
                UploadIn request = MockHelp.GetMockUploadIn();
                IDfispUploader dfispUploader = Substitute.For<IDfispUploader>();

                IMpsFileClient mpsFileClient = MockHelp.GetDfisFileClient(dfispUploader);

                //执行
                UploadOut result = mpsFileClient.UploadFile(MockHelp.TestKey1, request);

                Assert.NotNull(result.FileName);
                Assert.NotNull(result.UploadFileName);
                Assert.NotNull(result.HostAddress);
                Assert.NotNull(result.FilePath);
                Assert.Equal(FileSoucreTypeEnum.Dfis, result.SoucreType);
            }
        }

        #endregion UploadFile
    }
}