﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.Client;
using Newegg.MIS.Baymax.Client.Attributes;
using NSubstitute;
using System;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Client
{
    public class MkplClientConfigAttributeTest
    {
        private static IRestApiClient CallClient(TeamNameEnum teamNameEnum, string apiName)
        {
            var client = Substitute.For<IRestApiClient>();
            var config = new AllApiConfig()
            {
                TeamApiConfigList = new Dictionary<string, TeamConfigEntity>()
                 {
                     { "SHEC", new TeamConfigEntity()
                         {
                           ApiConfigList = new Dictionary<string, ApiEntity>()
                           {
                               { "test", new ApiEntity()
                                   {
                                     Address = "http://dd" ,
                                     Token = "test"
                                   }
                               }
                           }
                         }
                     }
                 }
            };
            var serviceProvider = new ServiceCollection()
                .AddSingleton(config)
                .BuildServiceProvider();
            new MkplClientConfigAttribute(teamNameEnum, apiName).Config(client, null, serviceProvider);
            return client;
        }

        [Fact]
        public void WhenHasConfigShouldSet()
        {
#pragma warning disable CS0618
            IRestApiClient client = CallClient(TeamNameEnum.ShEc, "test");

            client.Received(1).SetOAuthToken("test");
            client.Received(1).BaseUri = "http://dd";
        }

        [Fact]
        public void WhenNoConfigShouldThrowArgumentException()
        {
            Assert.Throws<ArgumentException>(() => CallClient(TeamNameEnum.CdAcct, "test"));
        }

#pragma warning restore CS0618
    }
}