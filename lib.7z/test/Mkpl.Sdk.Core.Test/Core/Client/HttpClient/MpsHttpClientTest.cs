﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestMpsHttpClientFactory.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   TestMpsHttpClientFactory created at  5/2/2018 9:01:31 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.Client;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.IO;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Client", "MpsHttpClient")]
    public class MpsHttpClientTest
    {
        #region 复刻固定数据

        private static class MockHelper
        {
#pragma warning disable CS0618 // 类型或成员已过时
            public static TeamNameEnum TeamKey1 = TeamNameEnum.RestAPI;
#pragma warning restore CS0618 // 类型或成员已过时
            public static TeamNameEnum TeamKey_ApproveCenter = TeamNameEnum.ApproveCenter;

            public static string TestHost = "http://127.0.0.1";
            public static string ApiKey1 = "API1";
            public static string ApiKey_ApproveCenter = "API3";

            /// <summary>
            /// 获取MpsHttpClientFactory
            /// </summary>
            /// <param name="AllAPIConfig"></param>
            /// <returns></returns>
            public static IMpsHttpClientFactory GetMpsHttpClientFactory(AllApiConfig AllAPIConfig = null)
            {
                IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();

                IMpsHttpClientFactory result = new MpsHttpClientFactory(restApiClientFactory, AllAPIConfig);

                return result;
            }

            /// <summary>
            /// 获取configServer
            /// </summary>
            /// <returns></returns>
            public static AllApiConfig GetAllAPIConfig()
            {
                AllApiConfig result = Substitute.For<AllApiConfig>();
                result.DevPlatformHost = MockHelper.TestHost;
                result.TeamApiConfigList = new Dictionary<string, TeamConfigEntity>()
                {
                    #region 模拟MKPLRestAPI

                    {
                        "MKPLRestAPI",
                        new TeamConfigEntity ()
                        {
                            BaseToken ="ab",
                            ApiConfigList=new Dictionary<string, ApiEntity>()
                            {
                                {
                                    MockHelper.ApiKey1,
                                    new ApiEntity ()
                                    {
                                        Address="API1"
                                    }
                                }
                            }
                        }
                    },

                    #endregion 模拟MKPLRestAPI

                    #region 模拟ApproveCenter

                    {
                         "ApproveCenter",
                        new TeamConfigEntity ()
                        {
                            BaseToken ="testToken3",
                            ApiConfigList=new Dictionary<string, ApiEntity>()
                            {
                                {
                                    "API3",
                                    new ApiEntity ()
                                    {
                                        Address="API3"
                                    }
                                }
                            }
                        }
                    }

                    #endregion 模拟ApproveCenter
                };

                return result;
            }

            /// <summary>
            /// 获取RequestHead
            /// </summary>
            /// <returns></returns>
            public static RequestHead GetRequestHead()
            {
                return new RequestHead()
                {
                    UserAgent = "UserAgent",
                    CustomHeaderList = new Dictionary<string, string>()
                {
                    {"TestKey","TestVlaue" }
                }
                };
            }
        }

        #endregion 复刻固定数据

        #region MpsHttpClientFactory

        [Trait("Client", "MpsHttpClient")]
        public class MpsHttpClientFactoryTest
        {
            [Fact(DisplayName = "GetClient-RestClient-Enum")]
            public void TC_GetClient_RestClient_Enum()
            {
                #region 模拟数据与模拟返回

                var config = MockHelper.GetAllAPIConfig();

                IMpsHttpClientFactory factory = MockHelper.GetMpsHttpClientFactory(config);

                #endregion 模拟数据与模拟返回

                //执行
                IMpsHttpClient client = factory.GetRestClient(TeamNameEnum.ApproveCenter);
                RestClient result = client as RestClient;
                OAuthClient result2 = client as OAuthClient;

                //验证
                Assert.NotNull(client);
                Assert.NotNull(result);

                //OAuthClient继承了RestClient
                //所以返回的如果是RestClient，则转换成OAuthClient一定失败
                Assert.Null(result2);
                Assert.IsType<RestClient>(result);//确定返回的一定是RestClient
            }

            [Fact(DisplayName = "GetClient-OAuthClient_Enum")]
            public void TC_GetClient_OAuthClient_Enum()
            {
                #region 模拟数据与模拟返回

                var config = MockHelper.GetAllAPIConfig();

                IMpsHttpClientFactory factory = MockHelper.GetMpsHttpClientFactory(config);

                #endregion 模拟数据与模拟返回

                //执行
                IMpsHttpClient client = factory.GetOAuthClient(TeamNameEnum.ApproveCenter);
                OAuthClient result = client as OAuthClient;

                //验证
                Assert.NotNull(client);
                Assert.NotNull(result);
                Assert.IsType<OAuthClient>(result);
            }
        }

        #endregion MpsHttpClientFactory

        #region 构造方法

        [Fact(DisplayName = "Init-NullConfig")]
        public void TC_Init_NullConfig()
        {
            //执行
            var ex = Assert.Throws<ArgumentException>(() =>
            {
                new MpsHttpClientFactory(null, null);
            });

            //验证
            Assert.Contains("object is null for", ex.Message);
        }

        [Fact(DisplayName = "Init-NullTeamNameKey")]
        public void TC_Init_OAuthClient()
        {
            var config = MockHelper.GetAllAPIConfig();

            //执行
            var ex = Assert.Throws<ArgumentException>(() =>
            {
                var factory = new MpsHttpClientFactory(null, config);
#pragma warning disable CS0618 // 类型或成员已过时
                _ = factory.GetOAuthClient("NotApiTeam");
#pragma warning restore CS0618 // 类型或成员已过时
            });

            //验证
            Assert.Contains("key not found in", ex.Message);
        }

        #endregion 构造方法

        #region Client内部方法

        /*
         * 这里没有按规范来，因为两个客户端（或以后其他的）
         * 会依赖RestClient
         *
         * 所以用一个测试类继承它，就可以测试到内部方法
         *
         */

        private class TestClient : RestClient
        {
            public TestClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
            : base(clientFactory, devHost, teamConfigEntity)
            { }

            public ApiEntity FindApi2(string apiKey)
            {
                return base.TeamConfig.FindApi(apiKey, base.DevPlatformHost);
            }

            public void BuildClient2(
                RequestHead requestHead = null,
                string CustomToken = null,
                bool isStreamRequest = false)
            {
                base.BuildClient(requestHead, CustomToken, isStreamRequest);
            }
        }

        private class TestOAuthClient : OAuthClient
        {
            public TestOAuthClient(
            IRestApiClientFactory clientFactory,
            string devHost,
            TeamConfigEntity teamConfigEntity)
            : base(clientFactory, devHost, teamConfigEntity)
            { }

            public void BuildClient2(RequestHead requestHead = null, string CustomToken = null)
            {
                base.BuildClient(requestHead, CustomToken);
            }
        }

        [Fact(DisplayName = "Protected-FindApi")]
        public void TC_RestClient_FindApi()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()]);

            #endregion 模拟数据与模拟返回

            //执行
            var result = restClient.FindApi2(MockHelper.ApiKey_ApproveCenter);

            //验证
            string expectHost = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()].ApiConfigList[MockHelper.ApiKey_ApproveCenter].Host;

            string expectToken = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()].ApiConfigList[MockHelper.ApiKey_ApproveCenter].Token;

            Assert.NotNull(result);
            Assert.Equal(expectHost, result.Host);
            Assert.Equal(expectToken, result.Token);
        }

        [Fact(DisplayName = "Protected-FindApi-NullKey-Exception")]
        public void TC_RestClient_FindApi_NullKey_Exception()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey1.GetDescription()]);

            #endregion 模拟数据与模拟返回

            //执行

            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                restClient.FindApi2(null);
            });

            //验证
            Assert.Contains("Data is null for ApiKey", ex.Message);
        }

        [Fact(DisplayName = "Protected-FindApi-NullData-Exception")]
        public void TC_RestClient_FindApi_NullData_Exception()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();

            TestClient restClient = new TestClient(
                null,
                null,
                config.TeamApiConfigList[MockHelper.TeamKey1.GetDescription()]);

            #endregion 模拟数据与模拟返回

            //执行

            var ex = Assert.Throws<ArgumentException>(() =>
            {
                restClient.FindApi2("API111");
            });

            //验证
            Assert.Contains("Find Data failure for", ex.Message);
        }

        [Fact(DisplayName = "Protected-BuildClient")]
        public void TC_RestClient_BuildClient()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory
                .Build(Arg.Any<string>())
                .Returns(restApiClient);

            TestClient restClient = new TestClient(
                restApiClientFactory,
                config.DevPlatformHost,
                configTeam);

            RequestHead requestHead = MockHelper.GetRequestHead();
            string customToken = "mock_CustomToken";

            #endregion 模拟数据与模拟返回

            //执行
            restClient.BuildClient2(requestHead, customToken);

            //验证
            Assert.Equal(customToken, restApiClient.Authorization);

            //确保这头部数据被写入了
            restApiClient
                .Received()
                .AddCustomHeader(Arg.Any<string>(), Arg.Any<string>());
            restApiClient
                .Received()
                .SetUserAgent(Arg.Any<string>());
            restApiClient
                .Received()
                .SetAccept(Arg.Any<string>());
            restApiClient
                .Received()
                .ContentType = Arg.Any<string>();
        }

        [Fact(DisplayName = "Protected-BuildClient-Stream")]
        public void TC_RestClient_BuildClient_Stream()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory
                .Build(Arg.Any<string>())
                .Returns(restApiClient);

            TestClient restClient = new TestClient(
                restApiClientFactory,
                config.DevPlatformHost,
                configTeam);

            RequestHead requestHead = MockHelper.GetRequestHead();
            string customToken = "mock_CustomToken";

            #endregion 模拟数据与模拟返回

            //执行
            restClient.BuildClient2(requestHead, customToken, true);

            //验证
            restApiClient.Received().RawDeserializer = Arg.Any<Func<Stream, Type, object>>();
        }

        [Fact(DisplayName = "Protected-OAuthClient-BuildClient")]
        public void TC_OAuthClient_BuildClient()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey1.GetDescription()];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory.Build(string.Empty).Returns(restApiClient);

            TestOAuthClient restClient = new TestOAuthClient(
                restApiClientFactory,
             config.DevPlatformHost,
             configTeam);

            RequestHead requestHead = MockHelper.GetRequestHead();
            string customToken = "mock_CustomToken";

            #endregion 模拟数据与模拟返回

            //执行
            restClient.BuildClient2(requestHead, customToken);

            //验证
            Assert.Equal($"Bearer {customToken}", restApiClient.Authorization);

            //确保这头部数据被写入了
            restApiClient
                .Received()
                .AddCustomHeader(Arg.Any<string>(), Arg.Any<string>());
            restApiClient
                .Received()
                .SetUserAgent(Arg.Any<string>());
            restApiClient
                .Received()
                .SetAccept(Arg.Any<string>());
            restApiClient
                .Received()
                .ContentType = Arg.Any<string>();
        }

        #endregion Client内部方法

        #region Http方法

        [Fact(DisplayName = "Http-Get")]
        public void TC_RestClient_Get()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory
                .Build(Arg.Any<string>())
                .Returns(restApiClient);

            TestClient restClient = new TestClient(
                restApiClientFactory,
                config.DevPlatformHost,
                configTeam);

            #endregion 模拟数据与模拟返回

            //执行
            restClient.Get<string>(MockHelper.ApiKey_ApproveCenter);

            //验证
            restApiClient.Received().GetAsync<string>(Arg.Any<string>(), Arg.Any<object>());
        }

        [Fact(DisplayName = "Http-Post")]
        public void TC_RestClient_Post()
        {
            #region 模拟数据与模拟返回

            var config = MockHelper.GetAllAPIConfig();
            var configTeam = config.TeamApiConfigList[MockHelper.TeamKey_ApproveCenter.GetDescription()];

            IRestApiClientFactory restApiClientFactory = Substitute.For<IRestApiClientFactory>();
            IRestApiClient restApiClient = Substitute.For<IRestApiClient>();
            restApiClientFactory
                .Build(Arg.Any<string>())
                .Returns(restApiClient);

            TestClient restClient = new TestClient(
                restApiClientFactory,
                config.DevPlatformHost,
                configTeam);

            #endregion 模拟数据与模拟返回

            //执行
            restClient.Post<string>(MockHelper.ApiKey_ApproveCenter, new object());

            //验证
            restApiClient.Received().PostAsync<string>(Arg.Any<string>(), Arg.Any<object>());
        }

        #endregion Http方法
    }
}