﻿using Microsoft.Net.Http.Headers;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.MQ;
using NSubstitute;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Client.MqClient
{
    public static class IMQClientExtensionTest
    {
        public static class MockHelp
        {
            public const TeamNameEnum MockSendTeam = TeamNameEnum.Item;
            public const string MockSendeName = "test";

            public static GroupQueue GetMockGroupQueue()
            {
                GroupQueue result = new GroupQueue()
                {
                    DefaultPassword = "123",
                    GoupName = QueueGoupNameConst.Team_MKPL,
                };

                result.Queues = new List<Queue>()
                {
                    new Queue()
                    {
                        KeyName="A",
                        QueueName="A"
                    },
                    new Queue()
                    {
                        KeyName="B",
                        QueueName="B",
                        Password="BVB"
                    }
                };

                return result;
            }

            public static (MQClient mQClient, IMessagePublisher messagePublisher) GetMockMQClient(PublishResultInfo publishResultInfo = null)
            {
                //只模拟了一个数据
                MQConfig mq = new MQConfig()
                {
                    GroupQueues = new List<GroupQueue>()
                    {
                        MockHelp.GetMockGroupQueue()
                    }
                };

                IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
                messagePublisher.SendMessageAsync(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Any<List<KeyValuePair<string, string>>>(),
                        callbackUri: Arg.Any<string>(),
                        subscribers: Arg.Any<List<string>>(),
                        noSerialize: Arg.Any<bool>()
                    )
                    .Returns(publishResultInfo);

                MQClient mQClient = new MQClient(mq, messagePublisher);

                return (mQClient, messagePublisher);
            }

            public static MQHeaderV2 GetMockMQheaderV2()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                return mQHeaderV2;
            }
        }

        public class TestSync
        {
            [Theory]
            [InlineData("Version", "1.0")]
            [InlineData("SystemSource", "MKPL")]
            [InlineData("Accept", ContentTypeConst.Json)]
            [InlineData("Content-Type", ContentTypeConst.Json)]
            public void DefaultHeaderIsExpectedValue(string headreName, string expectedValue)
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();

                _ = mQClient.SendMessage(new object(), "A", header: mqHeaderV2);

                _ = messagePublisher.Received().SendMessage(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == headreName && b.Value == expectedValue))

                    );
            }

            [Fact]
            public void SenderHeaderFromatIsTrue()
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();
                string sender = $"{MockHelp.MockSendTeam.GetDescription()}_{MockHelp.MockSendeName}";

                _ = mQClient.SendMessage(new object(), "A", header: mqHeaderV2);

                _ = messagePublisher.Received().SendMessage(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "Sender" && b.Value == sender))

                    );
            }

            [Fact]
            public void MsgTypeHeaderFromatIsTrue()
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();
                string msgType = $"A_{mqHeaderV2.Action}";

                _ = mQClient.SendMessage(new object(), "A", header: mqHeaderV2);

                _ = messagePublisher.Received().SendMessage(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "MsgType" && b.Value == msgType))

                    );
            }
        }

        public class TestASync
        {
            [Theory]
            [InlineData("Version", "1.0")]
            [InlineData("SystemSource", "MKPL")]
            [InlineData("Accept", ContentTypeConst.Json)]
            [InlineData("Content-Type", ContentTypeConst.Json)]
            public async Task DefaultHeaderIsExpectedValueAsync(string headreName, string expectedValue)
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();

                _ = await mQClient.SendMessageAsync(new object(), "A", header: mqHeaderV2);

                _ = await messagePublisher.Received().SendMessageAsync(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == headreName && b.Value == expectedValue))

                    );
            }

            [Fact]
            public async Task SenderHeaderFromatIsTrueAsync()
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();
                string sender = $"{MockHelp.MockSendTeam.GetDescription()}_{MockHelp.MockSendeName}";

                _ = await mQClient.SendMessageAsync(new object(), "A", header: mqHeaderV2);

                _ = await messagePublisher.Received().SendMessageAsync(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "Sender" && b.Value == sender))

                    );
            }

            [Fact]
            public async Task MsgTypeHeaderFromatIsTrueAsync()
            {
                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mqHeaderV2 = MockHelp.GetMockMQheaderV2();
                string msgType = $"A_{mqHeaderV2.Action}";

                _ = await mQClient.SendMessageAsync(new object(), "A", header: mqHeaderV2);

                _ = await messagePublisher.Received().SendMessageAsync(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        contentType: Arg.Any<MessageContentType>(),
                        password: Arg.Any<string>(),
                        headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == "MsgType" && b.Value == msgType))

                    );
            }
        }
    }
}