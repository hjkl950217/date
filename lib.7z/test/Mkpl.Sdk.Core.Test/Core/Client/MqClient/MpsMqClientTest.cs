﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MpsMqClientTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MpsMqClientTest created at  5/15/2018 2:29:02 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.Net.Http.Headers;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.MQ;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public partial class MpsMqClientTest
    {
        public static class MockHelp
        {
            public static GroupQueue GetMockGroupQueue()
            {
                GroupQueue result = new GroupQueue()
                {
                    DefaultPassword = "123",
                    GoupName = QueueGoupNameConst.Team_MKPL,
                };

                result.Queues = new List<Queue>()
                {
                    new Queue()
                    {
                        KeyName="A",
                        QueueName="A"
                    },
                    new Queue()
                    {
                        KeyName="B",
                        QueueName="B",
                        Password="BVB"
                    }
                };

                return result;
            }

            public static (MQClient mQClient, IMessagePublisher messagePublisher) GetMockMQClient(PublishResultInfo publishResultInfo = null)
            {
                //只模拟了一个数据
                MQConfig mq = new MQConfig()
                {
                    GroupQueues = new List<GroupQueue>()
                    {
                        MockHelp.GetMockGroupQueue()
                    }
                };

                IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
                messagePublisher.SendMessage(
                   request: Arg.Any<object>(),
                   messageName: Arg.Any<string>(),
                   password: Arg.Any<string>(),
                   contentType: MessageContentType.Json,
                   headers: Arg.Any<List<KeyValuePair<string, string>>>(),
                   callbackUri: Arg.Any<string>(),
                   subscribers: Arg.Any<List<string>>(),
                   noSerialize: Arg.Any<bool>()
                   )
                    .Returns(publishResultInfo);

                messagePublisher.SendMessageAsync(
                   request: Arg.Any<object>(),
                   messageName: Arg.Any<string>(),
                   password: Arg.Any<string>(),
                   contentType: MessageContentType.Json,
                   headers: Arg.Any<List<KeyValuePair<string, string>>>(),
                   callbackUri: Arg.Any<string>(),
                   subscribers: Arg.Any<List<string>>(),
                   noSerialize: Arg.Any<bool>()
                   )
                    .Returns(Task.FromResult(publishResultInfo));

                MQClient mQClient = new MQClient(mq, messagePublisher);

                return (mQClient, messagePublisher);
            }

            public static MQHeaderV2 GetMockMQheaderV2()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                return mQHeaderV2;
            }
        }

        [Fact(DisplayName = "MQClient-NullGroupQueue")]
        [Trait("Client", "MQClient")]
        public void TC_MQClient_NullGroupQueue()
        {
            #region 模拟数据与模拟返回

            IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
            MQConfig mQConfig = new MQConfig()
            {
                GroupQueues = new List<GroupQueue>()
            };

            #endregion 模拟数据与模拟返回

            //执行
            var ex = Assert.Throws<InvalidOperationException>(() =>
            {
                new MQClient(mQConfig, messagePublisher);
            });

            //验证
            Assert.Contains("GroupQueue Config is not found", ex.Message);
        }

        #region BaseSend

        [Trait("Client", "MQClient")]
        public class BaseSendTest
        {
            [Fact]
            public void NullHead_Exception()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = null;

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage(new object(), "ZZ", mQHeaderV2);
                });
            }

            [Fact]
            public async Task NullHead_ExceptionAsync()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = null;

                #endregion 模拟数据与模拟返回

                //执行
                var ex = await Assert.ThrowsAsync<ArgumentNullException>(async () =>
                {
                    _ = await mQClient.SendMessageAsync(new object(), "ZZ", mQHeaderV2);
                });
            }

            [Fact]
            public void NullRequestBody_Exception()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    mQClient.SendMessage<object>(null, "ZZ", mQHeaderV2);
                });
            }

            [Fact]
            public async Task NullRequestBodyAsync_Exception()
            {
                #region 模拟数据与模拟返回

                (MQClient mQClient, IMessagePublisher messagePublisher) = MockHelp.GetMockMQClient();

                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                var ex = await Assert.ThrowsAsync<ArgumentNullException>(async () =>
                {
                    _ = await mQClient.SendMessageAsync<object>(null, "ZZ", mQHeaderV2);
                });
            }

            [Fact]
            public void CheckContentTypeIsJson()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                _ = mQClient.SendMessage<object>(new object(), "A", mQHeaderV2);

                //验证
                _ = messagePublisher.Received().SendMessage<object>(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        password: Arg.Any<string>(),
                        contentType: MessageContentType.Json,
                        headers: Arg.Any<IEnumerable<KeyValuePair<string, string>>>(),
                        callbackUri: Arg.Any<string>(),
                        subscribers: Arg.Any<List<string>>(),
                        noSerialize: Arg.Any<bool>()
                    );
            }

            [Fact]
            public async Task CheckContentTypeIsJsonAsync()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                _ = await mQClient.SendMessageAsync<object>(new object(), "A", mQHeaderV2);

                //验证
                _ = messagePublisher.Received().SendMessageAsync<object>(
                        request: Arg.Any<object>(),
                        messageName: Arg.Any<string>(),
                        password: Arg.Any<string>(),
                        contentType: MessageContentType.Json,
                        headers: Arg.Any<IEnumerable<KeyValuePair<string, string>>>(),
                        callbackUri: Arg.Any<string>(),
                        subscribers: Arg.Any<List<string>>(),
                        noSerialize: Arg.Any<bool>()
                    );
            }

            [Fact]
            public void CheckHeadreExistsAccept()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                _ = mQClient.SendMessage(new object(), "A", mQHeaderV2);

                //验证
                messagePublisher.Received().SendMessage(
                   request: Arg.Any<object>(),
                   messageName: Arg.Any<string>(),
                   password: Arg.Any<string>(),
                   contentType: MessageContentType.Json,
                   headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == HeaderNames.Accept)),
                   callbackUri: Arg.Any<string>(),
                   subscribers: Arg.Any<List<string>>(),
                   noSerialize: Arg.Any<bool>()

                   );
            }

            [Fact]
            public async Task CheckHeadreExistsAcceptAsync()
            {
                #region 模拟数据与模拟返回

                var (mQClient, messagePublisher) = MockHelp.GetMockMQClient();
                MQHeaderV2 mQHeaderV2 = MockHelp.GetMockMQheaderV2();

                #endregion 模拟数据与模拟返回

                //执行
                _ = await mQClient.SendMessageAsync(new object(), "A", mQHeaderV2);

                //验证
                _ = await messagePublisher.Received().SendMessageAsync(
                    request: Arg.Any<object>(),
                    messageName: Arg.Any<string>(),
                    password: Arg.Any<string>(),
                    contentType: MessageContentType.Json,
                    headers: Arg.Is<IEnumerable<KeyValuePair<string, string>>>(t => t.Any(b => b.Key == HeaderNames.Accept)),
                    callbackUri: Arg.Any<string>(),
                    subscribers: Arg.Any<List<string>>(),
                    noSerialize: Arg.Any<bool>()
                    );
            }
        }

        #endregion BaseSend
    }
}