﻿using Mkpl.Sdk.Core.Entities;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Entities
{
    public class BizValidatorResultTests
    {
    

        [Fact]
        public void Errors_NotNull()
        {
            // Act
            var result = new BizValidatorResult();
            // Assert
            Assert.NotNull(result.Errors);
        }

        [Fact]
        public void IsValid_ValueIsFale()
        {
            // Act
            var result = new BizValidatorResult();
            // Assert
            Assert.False(result.IsValid);
        }

       
    }
}