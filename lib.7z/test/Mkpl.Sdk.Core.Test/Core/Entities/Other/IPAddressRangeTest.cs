﻿using Mkpl.Sdk.Core.Entities;
using System.Net;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Entities.Other
{
    public class IPAddressRangeTest
    {
        [InlineData("10.16.18.1", "10.16.18.2", "10.16.18.0", false)]
        [InlineData("10.16.18.1", "10.16.18.2", "10.16.18.1", true)]
        [InlineData("10.16.18.1", "10.16.18.2", "10.16.18.2", true)]
        [InlineData("10.16.18.1", "10.16.18.2", "10.16.18.3", false)]
        [InlineData("10.16.16.1", "10.16.18.2", "10.16.17.2", true)]
        [InlineData("10.16.16.1", "10.16.18.2", "10.16.17.3", true)]
        [InlineData("10.16.16.1", "10.16.18.2", "10.16.15.3", false)]
        [InlineData("10.16.16.1", "10.16.18.2", "10.16.19.1", false)]
        [InlineData("10.16.16.1", "10.18.18.2", "10.16.17.3", true)]
        [InlineData("10.16.16.1", "10.18.18.2", "10.13.15.3", false)]
        [InlineData("10.16.16.1", "10.18.18.2", "10.19.19.1", false)]
        [InlineData("10.16.16.1", "11.18.18.2", "10.16.17.3", true)]
        [InlineData("10.16.16.1", "11.18.18.2", "9.13.15.3", false)]
        [InlineData("10.16.16.1", "11.18.18.2", "14.19.19.1", false)]
        [InlineData("::1", "::1", "::1", true)]
        [Theory]
        public void TestIPAddressRange(string begin, string end, string ip, bool result)
        {
            var range = new IPAddressRange()
            {
                Begin = begin,
                End = end
            };
            var testip = IPAddress.Parse(ip);
            Assert.Equal(result, range.IsInRangeByIpv4(testip.MapToIPv4().ToString()));
            Assert.Equal(result, range.IsInRangeByIpv6(testip.MapToIPv6().ToString()));
            Assert.Equal(result, new IPAddressRangeCollection() { range }.IsInRange(ip));
        }
    }
}