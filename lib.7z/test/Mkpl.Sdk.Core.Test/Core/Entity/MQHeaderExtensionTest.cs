﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeaderExtensionTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeaderExtensionTest created at  5/15/2018 3:09:17 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using System;
using Xunit;

#pragma warning disable CS0618 // 类型或成员已过时
namespace Mkpl.Sdk.Core.Test
{

    [Trait("Entity", "MQHeader")]
    public class MQHeaderExtensionTest
    {
        private static class MockHelp
        {
            public static MQHeader GetMockMQHeader()
            {
                MQHeader mQHeader = new MQHeader()
                {
                    Action = "A",
                    SellerID = "BHD6",
                    CountryCode = "USA",
                    Version = "1"
                };

                return mQHeader;
            }
        }

        [Fact(DisplayName = "MQHeader-NullQueueNamet")]
        public void TC_MQHeader_NullQueueName()
        {
            #region 模拟数据与模拟返回

            MQHeader mQHeader = MockHelp.GetMockMQHeader();

            #endregion 模拟数据与模拟返回

            //执行
            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                mQHeader.CreteHeaderList("\r\n");
            });

            //验证
            Assert.Contains("MQHeader CreteHeaderList Failed.", ex.Message);
            Assert.Equal("keyName", ex.ParamName);
        }

        [Fact(DisplayName = "MQHeader-NullAction")]
        public void TC_MQHeader_NullAction()
        {
            #region 模拟数据与模拟返回


            MQHeader mQHeader = MockHelp.GetMockMQHeader();

            mQHeader.Action = null;

            #endregion 模拟数据与模拟返回

            //执行
            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                mQHeader.CreteHeaderList("A");
            });

            //验证
            Assert.Contains("MQHeader`s Action is null, CreteHeaderList Failed.", ex.Message);
            Assert.Equal("mqHeader", ex.ParamName);
        }

        [Fact(DisplayName = "MQHeader-Succee")]
        public void TC_MQHeader_Succee()
        {
            #region 模拟数据与模拟返回

            MQHeader mQHeader = MockHelp.GetMockMQHeader();

            #endregion 模拟数据与模拟返回

            //执行
            var resultList = mQHeader.CreteHeaderList("A");

            //验证
            Assert.Equal("Portal2.0", resultList.Find(t => t.Key == "Sender").Value);
            Assert.Equal("A_A", resultList.Find(t => t.Key == "MsgType").Value);
            Assert.Equal("A", resultList.Find(t => t.Key == "Action").Value);
            Assert.Equal("USA", resultList.Find(t => t.Key == "CountryCode").Value);
            Assert.Equal("BHD6", resultList.Find(t => t.Key == "SellerID").Value);
            Assert.Equal("1", resultList.Find(t => t.Key == "Version").Value);
        }
    }
}
#pragma warning restore CS0618 // 类型或成员已过时