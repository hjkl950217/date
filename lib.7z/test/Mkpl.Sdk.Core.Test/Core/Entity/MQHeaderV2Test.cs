﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MQHeaderExtensionTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   MQHeaderExtensionTest created at  5/15/2018 3:09:17 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Entity", "MQHeaderV2")]
    public class MQHeaderV2Test
    {
        private static class MockHelp
        {
            public static MQHeaderV2 GetMockMQHeaderV2()
            {
                MQHeaderV2 mQHeader = new MQHeaderV2(TeamNameEnum.Item, "test")
                {
                    Action = "A",
                    SellerID = "BHD6",
                    PlatformCode = "USA",
                    Version = 1
                };

                return mQHeader;
            }
        }

        [Fact(DisplayName = "MQHeaderV2-NullQueueNamet")]
        public void TC_MQHeader_NullQueueName()
        {
            #region 模拟数据与模拟返回

            MQHeaderV2 mQHeader = MockHelp.GetMockMQHeaderV2();

            #endregion 模拟数据与模拟返回

            //执行
            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                mQHeader.CreteHeaderList("\r\n");
            });

            //验证
            Assert.Contains("The QueueKey is null or empty", ex.Message);
            Assert.Equal("keyName", ex.ParamName);
        }

        [Fact(DisplayName = "MQHeaderV2-Succee")]
        public void TC_MQHeader_Succee()
        {
            #region 模拟数据与模拟返回

            MQHeaderV2 mQHeader = MockHelp.GetMockMQHeaderV2();

            #endregion 模拟数据与模拟返回

            //执行
            var resultList = mQHeader.CreteHeaderList("A");

            //验证
            Assert.Equal($"{TeamNameEnum.Item.GetDescription()}_test", resultList.Find(t => t.Key == "Sender").Value);
            Assert.Equal("A_A", resultList.Find(t => t.Key == "MsgType").Value);
            Assert.Equal("A", resultList.Find(t => t.Key == "Action").Value);
            Assert.Equal("USA", resultList.Find(t => t.Key == "PlatformCode").Value);
            Assert.Equal("BHD6", resultList.Find(t => t.Key == "SellerID").Value);
            Assert.Equal("1.0", resultList.Find(t => t.Key == "Version").Value);
        }
    }
}