﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System.Linq;
using System.Xml.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Entity", nameof(PagingInfoV2))]
    public class PagingInfoV2Test
    {
        private static class MockHelper
        {
            public static PagingInfoV2 TestNonPaging = new PagingInfoV2
            {
                StartRowIndex = 0,
                PageSize = int.MaxValue,
                SortType = SortTypeEnum.ASC
            };

            public static PagingInfoV2 TestDefaultPaging = new PagingInfoV2
            {
                StartRowIndex = 0,
                PageSize = PagingInfoConst.PageSize_Default,
                SortType = SortTypeEnum.ASC
            };

            public static PagingInfoV2 TestPagingInfo = new PagingInfoV2()
            {
                PageSize = null,
                SortField = "AAA",
                SortType = SortTypeEnum.ASC,
                StartRowIndex = 50
            };
        }

        [Fact]
        public void ToXml_NullField()
        {
            var obj = MockHelper.TestPagingInfo;

            XElement result = obj.ToXml();

            //保证要有一个
            XElement testA = result.Elements(nameof(PagingInfoV2.PageSize)).First();
            //保证值为null时序列化的xml中值为""
            Assert.Empty(testA.Value);
        }

        [Fact]
        public void NonPaging_True()
        {
            var obj = MockHelper.TestNonPaging;

            var result = PagingInfoV2.GetNonPaging();

            Assert.Equal(obj.StartRowIndex, result.StartRowIndex);
            Assert.Equal(obj.PageSize, result.PageSize);
            Assert.Equal(obj.SortField, result.SortField);
            Assert.Equal(obj.SortType, result.SortType);
        }

        [Fact]
        public void DefaultPaging_True()
        {
            var obj = MockHelper.TestDefaultPaging;

            var result = PagingInfoV2.GetDefaultPaging();

            Assert.Equal(obj.StartRowIndex, result.StartRowIndex);
            Assert.Equal(obj.PageSize, result.PageSize);
            Assert.Equal(obj.SortField, result.SortField);
            Assert.Equal(obj.SortType, result.SortType);
        }
    }
}