﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mkpl.Sdk.Core.Test.Core.Env
{
    public class EnvironmentInfoExtensionTest
    {
    }
}
