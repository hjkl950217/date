﻿using Mkpl.Sdk.Core.Env;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env
{
    public class EnvironmentInfoTest
    {
        private readonly EnvironmentInfo EnvironmentInfo;

        public EnvironmentInfoTest()
        {
            EnvironmentInfo = new EnvironmentInfo();
            
        }

        [Fact]
        public void AddShouldAddInEnvironmentInfo()
        {
            var key = "add";
            var value = "addvalue";
            EnvironmentInfo.Add(key, i => value);
            Assert.Equal(value, EnvironmentInfo.EnvironmentVariables[key](EnvironmentInfo));
        }

        [Fact]
        public void TryGetShouldGetExistsRight()
        {
            var key = "haskey";
            var value = "addvalue";
            EnvironmentInfo.Add(key, i => value);
            Assert.True(EnvironmentInfo.TryGet(key, out var v));
            Assert.Equal(value, v);
        }

        [Fact]
        public void TryGetShouldGetNotExistsNoValue()
        {
            var key = "nokey";
            Assert.False(EnvironmentInfo.TryGet(key, out var v));
            Assert.Null(v);
        }
    }
}
