﻿using Mkpl.Sdk.Core.Env;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env
{
    public class EnvironmentVariableSourceTest
    {
        [Fact]
        public void SetEnvironmentVariableShouldGetData()
        {
            var key = "dadsdds";
            var value = "sddad";
            Environment.SetEnvironmentVariable(key, value);
            var source = new EnvironmentVariableSource();
            Assert.Equal(value, source.Get(key));
        }
    }
}