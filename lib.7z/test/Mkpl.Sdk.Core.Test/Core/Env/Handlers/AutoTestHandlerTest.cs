﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class AutoTestHandlerTest
    {
        private readonly EnvironmentInfo Info = new EnvironmentInfo();
        private bool HasValue = false;

        public AutoTestHandlerTest()
        {
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get("test")).Returns((string i) => HasValue ? "true" : null);
            Info.Init(mockSource.Object, new AutoTestHandler("test"));
        }

        [Fact]
        public void WhenNoSourceShouldBeFalse()
        {
            Assert.False(Info.IsAutoTest());
        }

        [Fact]
        public void WhenHasSourceShouldBeTrue()
        {
            HasValue = true;
            Assert.True(Info.IsAutoTest());
        }
    }
}