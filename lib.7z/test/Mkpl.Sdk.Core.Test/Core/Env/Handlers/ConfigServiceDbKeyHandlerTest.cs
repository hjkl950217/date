﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;


namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class ConfigServiceDbKeyHandlerTest
    {
        private readonly EnvironmentInfo Info = new EnvironmentInfo();
        private bool HasValue = false;

        public ConfigServiceDbKeyHandlerTest()
        {
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get("test")).Returns((string i) => HasValue ? "gqc" : null);
            Info.Init(mockSource.Object, new ConfigServiceDbKeyHandler("test"));
        }

        [Fact]
        public void WhenNoSourceShouldBedotnetDB()
        {
            Assert.Equal("dotnetDB", Info.GetConfigServiceDbKey());
        }

        [Fact]
        public void WhenHasSourceShouldBeGQC()
        {
            HasValue = true;
            Assert.Equal("gqc", Info.GetConfigServiceDbKey());
        }
    }
}
