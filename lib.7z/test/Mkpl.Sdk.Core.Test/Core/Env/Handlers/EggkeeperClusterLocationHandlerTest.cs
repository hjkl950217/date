﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class EggkeeperClusterLocationHandlerTest
    {
        public EnvironmentInfo CreateInfo(string env, string source = null)
        {
            var info = new EnvironmentInfo();
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get(source)).Returns((string i) => source);
            info.Add(EnvironmentNames.RunEnv, i => env);
            info.Add(EnvironmentNames.ClusterLocation, i => "testClusterLocation");
            info.Init(mockSource.Object, new EggkeeperClusterLocationHandler(source));
            return info;
        }

        [Fact]
        public void WhenHasSourceShouldBeSource()
        {
            var env = "development";
            var info = CreateInfo(env, "tests");
            Assert.Equal("tests", info.GetEggkeeperClusterLocation());
        }

        [Fact]
        public void WhenRunEnvIsdevelopmentShouldBedevelopment()
        {
            var env = "development";
            var info = CreateInfo(env);
            Assert.Equal(env, info.GetEggkeeperClusterLocation());
        }

        [Fact]
        public void WhenRunEnvIsgdevShouldBeGDEV()
        {
            var env = "gdev";
            var info = CreateInfo(env);
            Assert.Equal(env, info.GetEggkeeperClusterLocation());
        }

        [Fact]
        public void WhenRunEnvIsgqcShouldBegqc()
        {
            var env = "gqc";
            var info = CreateInfo(env);
            Assert.Equal(env, info.GetEggkeeperClusterLocation());
        }

        [Fact]
        public void WhenRunEnvIspreShouldBeWH7()
        {
            var env = "pre";
            var info = CreateInfo(env);
            Assert.Equal("WH7", info.GetEggkeeperClusterLocation());
        }

        [Fact]
        public void WhenRunEnvIsprdShouldBetestClusterLocation()
        {
            var env = "prd";
            var info = CreateInfo(env);
            Assert.Equal("testClusterLocation", info.GetEggkeeperClusterLocation());
        }
    }
}