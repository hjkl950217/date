﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class GensisHandlerTest
    {
        private readonly EnvironmentInfo Info = new EnvironmentInfo();
        private bool HasValue = false;

        public GensisHandlerTest()
        {
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get(EnvironmentNames.GenesisProjectID)).Returns((string i) => HasValue ? "gqc" : null);
            Info.Init(mockSource.Object, new GensisHandler());
        }

        [Fact]
        public void WhenNoSourceShouldBeNull()
        {
            Assert.Null(Info.GetGenesisProjectId());
        }

        [Fact]
        public void WhenHasSourceShouldBeGQC()
        {
            HasValue = true;
            Assert.Equal("gqc", Info.GetGenesisProjectId());
        }
    }
}
