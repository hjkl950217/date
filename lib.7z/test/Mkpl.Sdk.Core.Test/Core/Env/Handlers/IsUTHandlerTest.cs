﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class IsUTHandlerTest
    {
        private readonly EnvironmentInfo Info = new EnvironmentInfo();
        private bool HasValue = false;

        public IsUTHandlerTest()
        {
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get("test")).Returns((string i) => HasValue ? "true" : null);
            Info.Init(mockSource.Object, new IsUTHandler("test"));
        }

        [Fact]
        public void WhenNoSourceShouldBeFalse()
        {
            Assert.False(Info.IsUT());
        }

        [Fact]
        public void WhenHasSourceShouldBeTrue()
        {
            HasValue = true;
            Assert.True(Info.IsUT());
        }
    }
}
