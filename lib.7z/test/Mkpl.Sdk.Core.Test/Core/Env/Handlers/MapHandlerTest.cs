﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class MapHandlerTest
    {
        private readonly EnvironmentInfo Info = new EnvironmentInfo();
        private const string Key = "testkey";
        private const string Value = "testvalue";
        private const string NoValueKey = "NoValueKey";
        private const string DefaultValue = "testdefaultValue";

        public MapHandlerTest()
        {
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get(Key)).Returns(Value);
            Info.Init(mockSource.Object, new MapHandler(Key));
            Info.Init(mockSource.Object, new MapHandler(NoValueKey, defaultValue: DefaultValue));
        }

        [Fact]
        public void WhenNoSourceShouldBeDefaultValue()
        {
            Assert.Equal(DefaultValue, Info.Get(NoValueKey));
        }

        [Fact]
        public void WhenHasSourceShouldBeValue()
        {
            Assert.Equal(Value, Info.Get(Key));
        }

        [Fact]
        public void WhenNoValueShouldBeNull()
        {
            Assert.Null(Info.Get(Key + "Null"));
        }
    }
}