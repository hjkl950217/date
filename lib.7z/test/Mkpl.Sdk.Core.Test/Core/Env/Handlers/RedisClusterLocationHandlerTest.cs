﻿using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using Moq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Core.Env.Handlers
{
    public class RedisClusterLocationHandlerTest
    {
        public EnvironmentInfo CreateInfo(string env, string source = null)
        {
            var info = new EnvironmentInfo();
            var mockSource = new Mock<IEnvironmentInfoSource>();
            mockSource.Setup(i => i.Get(source)).Returns((string i) => source);
            info.Add(EnvironmentNames.RunEnv, i => env);
            info.Add(EnvironmentNames.ClusterLocation, i => "testClusterLocation");
            info.Init(mockSource.Object, new RedisClusterLocationHandler(source));
            return info;
        }

        [Fact]
        public void WhenHasSourceShouldBeSource()
        {
            var env = "development";
            var info = CreateInfo(env, "tests");
            Assert.Equal("tests", info.GetRedisClusterLocation());
        }

        [Fact]
        public void WhenNoSourceShouldBetestClusterLocation()
        {
            var env = "development";
            var info = CreateInfo(env);
            Assert.Equal("testClusterLocation", info.GetRedisClusterLocation());
        }

        [Fact]
        public void WhenIsPrdShouldRedisKafkaServerBeE7()
        {
            var env = "prd";
            var info = CreateInfo(env);
            Assert.Equal(RedisClusterLocationHandler.RedisKafkaServer_E7, info.GetRedisKafkaServer());
        }

        [Fact]
        public void WhenIsPreShouldRedisKafkaServerBeE7()
        {
            var env = "pre";
            var info = CreateInfo(env);
            Assert.Equal(RedisClusterLocationHandler.RedisKafkaServer_E7, info.GetRedisKafkaServer());
        }

        [Fact]
        public void WhenIsPreShouldRedisKafkaServerBeTest()
        {
            var env = "gqc";
            var info = CreateInfo(env);
            Assert.Equal(RedisClusterLocationHandler.RedisKafkaServer_Test, info.GetRedisKafkaServer());
        }

        [Fact]
        public void WhenRedisClusterLocationIsE4ShouldRedisKafkaTopicBeE11()
        {
            var env = "gqc";
            var info = CreateInfo(env, "e4");
            Assert.Equal(RedisClusterLocationHandler.RedisKafkaCommand_E11, info.GetRedisKafkaTopic());
        }

        [Fact]
        public void WhenRedisClusterLocationIsE11ShouldRedisKafkaTopicBeE4()
        {
            var env = "gqc";
            var info = CreateInfo(env, "e11");
            Assert.Equal(RedisClusterLocationHandler.RedisKafkaCommand_E4, info.GetRedisKafkaTopic());
        }
    }
}
