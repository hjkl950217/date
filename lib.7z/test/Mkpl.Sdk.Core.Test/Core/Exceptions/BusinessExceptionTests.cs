﻿using Mkpl.Sdk.Core;
using NSubstitute;
using System;
using System.Net;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Exceptions
{
    public class BusinessExceptionTests
    {
       

        [Fact]
        public void Errors_NotNull()
        {
            // Act
            var result = new BusinessException("s");
            // Assert
            Assert.NotNull(result.ErrorCode);
        }

        [Fact]
        public void StatusCode_ValueIsFale()
        {
            // Act
            var result = new BusinessException("s");
            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Message_Initialized()
        {
            // Act
            var result = new BusinessException("s");
            // Assert
            Assert.Equal("s", result.Message);
        }

        
    }
}
