﻿using Mkpl.Sdk.Core.Exceptions;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Exceptions
{
    public class ConfigExceptionTests
    {
        [Fact]
        public void Message_DefaultValue()
        {
            // Act
            var result = new ConfigException();

            // Assert
            Assert.Equal("A configuration error has occurred, please check the configuration", result.Message);
        }

        [Fact]
        public void Message_Value_Initialized()
        {
            // Act
            var result = new ConfigException("s");

            // Assert
            Assert.Equal("s", result.Message);
        }

        [Fact]
        public void Message_ConfigName_Initialized()
        {
            // Act
            var result = new ConfigException("s", "MKTPL_TEST");

            // Assert
            Assert.NotNull(result.Message);
            Assert.Contains("Config Name:", result.Message);
        }


        [Fact]
        public void Message_InnerException_Initialized()
        {
            // Act
            var result = new ConfigException("s",new System.ArithmeticException("a"));

            // Assert
            Assert.NotNull(result.InnerException);
            Assert.Equal("a", result.InnerException.Message);
        }


        [Fact]
        public void Message_InnerException_ConfigName_Initialized()
        {
            // Act
            var result = new ConfigException("s", "MKTPL_TEST", new System.ArithmeticException("a"));

            // Assert
            Assert.NotNull(result.Message);
            Assert.Contains("Config Name:", result.Message);
            Assert.NotNull(result.InnerException);
            Assert.Equal("a", result.InnerException.Message);
        }



    }
}