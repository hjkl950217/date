﻿using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class BoolExtensionTest
    {
        [Trait("Extend", "Bool")]
        public class ToBitTest
        {
            [Theory]
            [InlineData(true,1)]
            [InlineData(false, 0)]
            public void Value_Test(bool value, int expected)
            {
                Assert.Equal(value.ToBit(), expected);
            }

            [Theory]
            [InlineData(true, 1)]
            [InlineData(false, 0)]
            [InlineData(null, 0)]
            public void NullValue_Test(bool? value, int expected)
            {
                Assert.Equal(value.ToBit(), expected);
            }
        }
    }
}