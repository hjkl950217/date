﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DateTimeExtensionsTests.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DateTimeExtensionsTests created at  2/23/2018 11:33:01 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using System.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class DateTimeExtensionsTests
    {
        private static class MockHelper
        {
            /// <summary>
            /// 1970年之前的时间
            /// </summary>
            public static DateTime DataTimeA = DateTime.Parse("1520-12-11 21:50:02.123456789+08:00");

            /// <summary>
            /// 1970年之后的时间
            /// </summary>
            public static DateTime DataTimeB = DateTime.Parse("2020-12-11 21:50:02.123456789+08:00");
        }

        [Trait("Extend", "DateTime")]
        public class ToStringMPSTest
        {
            [Fact]
            public void UsaFormat_True()
            {
                string result = MockHelper.DataTimeA.ToStringMPS();

                //212/11/1520 21:50:02
                //有时区问题，所以使用这种比较弱的匹配
                Assert.Equal(2, result.Count(t => t == '/'));
            }

            [Fact]
            public void Standard_True()
            {
                string result = MockHelper.DataTimeB.ToStringMPS(DateTimeFormatConst.Standard);

                //2020-12-11T21:50:02.1234568+08:00
                //有时区问题，所以使用这种比较弱的匹配
                Assert.True(result.Contains('-') || result.Contains('+'));
                Assert.Contains("T", result);
            }

            [Fact]
            public void Format_Exception()
            {
                Assert.Throws<FormatException>(() => MockHelper.DataTimeA.ToStringMPS("q"));
            }

            [Fact]
            public void Format_ErrorString()
            {
                string result = MockHelper.DataTimeB.ToStringMPS("张三");
                Assert.Equal("张三", result);
            }
        }
    }
}