﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DeciamlExtensionTests.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   DeciamlExtensionTests created at  3/15/2018 4:00:41 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    /// <summary>
    ///
    /// </summary>
    [Trait("Extend", "Deciaml")]
    public class DeciamlExtensionTests
    {
        // 测试 Decimal去掉小数再保留指定位数
        [Theory]
        [InlineData(5.2, 4, "5.0000")]
        [InlineData(5.26645661, 4, "5.0000")]
        [InlineData(5.26645661, 0, "5")]
        public void ToStringByFloor_Test(decimal value, int p, string expectedNum)
        {
            string result = value.ToStringByFloor(p);
            Assert.Equal(expectedNum, result);
        }

        //测试decimal固定精度
        [Theory]
        [InlineData(15.26600000001, 2, "15.27")]
        [InlineData(15.26400000001, 2, "15.26")]
        [InlineData(15, 2, "15.00")]
        [InlineData(15.01, 2, "15.01")]
        [InlineData(15.4, 2, "15.40")]
        [InlineData(15.5, 2, "15.50")]
        [InlineData(15.1, 3, "15.100")]
        [InlineData(15.1, 0, "15")]
        [InlineData(15.1, -1, "15")]//这条用例是检测异常情况
        public void ToStringByRound_Test(decimal value, int p, string expectedNum)
        {
            string result = value.ToStringByRound(p);
            Assert.Equal(expectedNum, result);
        }
    }
}