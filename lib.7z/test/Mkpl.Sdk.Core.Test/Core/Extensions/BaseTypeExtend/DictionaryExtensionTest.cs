﻿using System;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Extensions.BaseTypeExtend
{
    public class DictionaryExtensionTest
    {
        public class TryAddTest
        {
            [Fact]
            public void WhenDuplicateKey_NoErrorAndReturnFalse()
            {
                Dictionary<string, string> testKv = new Dictionary<string, string>()
                {
                    {"k","v" }
                };

                bool result = DictionaryExtension.TryAdd(testKv, "k", "v2");
                Assert.False(result);
                Assert.Equal("v", testKv["k"]);
            }

            [Fact]
            public void WhenNoDuplicateKey_NoErrorAndReturnTrue()
            {
                Dictionary<string, string> testKv = new Dictionary<string, string>()
                {
                    {"k","v" }
                };

                bool result = DictionaryExtension.TryAdd(testKv, "k2", "v2");
                Assert.True(result);
                Assert.Equal("v2", testKv["k2"]);
            }

            [Fact]
            public void WhenDictionaryIsNull_Exception()
            {
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    DictionaryExtension.TryAdd(null, "k", "v");
                });

                Assert.NotNull(ex);
            }

            [Fact]
            public void WhenKeyIsNull_Exception()
            {
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    DictionaryExtension.TryAdd(new Dictionary<string, string>(), null, "v");
                });

                Assert.NotNull(ex);
            }

            [Fact]
            public void WhenValueIsNull_Exception()
            {
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    DictionaryExtension.TryAdd(new Dictionary<string, string>(), "k", null);
                });

                Assert.NotNull(ex);
            }
        }

        public class GetOrDefaultTest
        {
            [Fact]
            public void WhenExistKey_ReturnValue()
            {
                Dictionary<string, string> testKv = new Dictionary<string, string>()
                {
                    {"k","v" }
                };

                string result = DictionaryExtension.GetOrDefault(testKv, "k", "v2");
                Assert.NotNull(result);
                Assert.Equal("v", result);
            }

            [Fact]
            public void WhenNoExistKey_ReturnDefault()
            {
                Dictionary<string, string> testKv = new Dictionary<string, string>()
                {
                    {"k","v" }
                };

                string result = DictionaryExtension.GetOrDefault(testKv, "k2", "v2");
                Assert.NotNull(result);
                Assert.Equal("v2", result);
            }

            [Fact]
            public void WhenDictionaryIsNull_Exception()
            {
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    DictionaryExtension.GetOrDefault(null, "k", "v");
                });

                Assert.NotNull(ex);
            }

            [Fact]
            public void WhenKeyIsNull_Exception()
            {
                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    DictionaryExtension.GetOrDefault(new Dictionary<string, string>(), null, "v");
                });

                Assert.NotNull(ex);
            }
        }
    }
}