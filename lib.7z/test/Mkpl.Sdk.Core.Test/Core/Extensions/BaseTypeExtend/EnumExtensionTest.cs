﻿using Mkpl.Sdk.Core.Entities.Attribute;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class EnumExtensionTest
    {
        #region 测试数据

        protected enum TestEnumAttr
        {
            [EnumDescription(ShowValue: "MKTPLS", DbValue: "M", Description: "MPS组")]
            MPTL
        }

        protected enum TestEnumByte : byte
        {
            MPTL = 0x11
        }

        public sealed class TestAttribute : FlagsAttribute
        { }

        #endregion 测试数据

        [Trait("Extend", "Enum")]
        public class GetValueAndString
        {
            [Fact]
            public void Tc_GetValueString()
            {
                string result = TestEnumAttr.MPTL.GetValueString();

                Assert.NotNull(result);
                Assert.Equal("0", result);
            }

            [Fact]
            public void Tc_GetValue()
            {
                int result = TestEnumAttr.MPTL.GetValue<int>();
                Assert.Equal(0, result);
            }

            [Fact]
            public void Tc_GetValue_Exception()
            {
                var result = Assert.Throws<InvalidCastException>(() =>
                {
                    TestEnumByte.MPTL.GetValue<DateTime>();
                });

                Assert.Contains($"枚举名:{nameof(TestEnumByte)}", result.Message);
                Assert.NotNull(result.InnerException);
            }
        }
    }
}