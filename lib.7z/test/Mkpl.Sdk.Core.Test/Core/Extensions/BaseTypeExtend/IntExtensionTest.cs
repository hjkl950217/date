﻿using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class IntExtensionTest
    {
        [Trait("Extend", "Int")]
        public class ToBoolTest
        {
            [Theory]
            [InlineData(5, true)]
            [InlineData(1, true)]
            [InlineData(-1, false)]
            [InlineData(0, false)]
            [InlineData(-100, false)]
            public void Value_Test(int value, bool expected)
            {
                Assert.Equal(value.ToBool(), expected);
            }

            [Theory]
            [InlineData(5, true)]
            [InlineData(1, true)]
            [InlineData(-1, false)]
            [InlineData(0, false)]
            [InlineData(-100, false)]
            [InlineData(null, false)]
            public void NullValue_Test(int? value, bool expected)
            {
                Assert.Equal(value.ToBool(), expected);
            }
        }
    }
}