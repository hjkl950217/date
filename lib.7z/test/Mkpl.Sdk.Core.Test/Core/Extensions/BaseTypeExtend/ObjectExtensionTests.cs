﻿using Mkpl.Sdk.Core.Test.Sellers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class ObjectExtensionTests
    {
        #region IsNullOrEmpty方法

        [Trait("Extend", "Object")]
        public class IsNullOrEmptyTest
        {
            //测试引用为null
            [Fact]
            public void ObjectExtension_IsNullOrEmpty_ReferenceNull()
            {
                object testA = null;
                string[] testB = null;
                List<string> testC = null;
                Dictionary<string, string> testD = null;

                bool isA = testA.IsNullOrEmpty();
                bool isB = testB.IsNullOrEmpty();
                bool isC = testC.IsNullOrEmpty();
                bool isD = testD.IsNullOrEmpty();

                Assert.Equal($"isA:{true}", $"isA:{isA}");
                Assert.Equal($"isB:{true}", $"isB:{isB}");
                Assert.Equal($"isC:{true}", $"isC:{isC}");
                Assert.Equal($"isD:{true}", $"isD:{isD}");
            }

            //测试长度为null
            [Fact]
            public void ObjectExtension_IsNullOrEmpty_LengthNull()
            {
                string[] testB = Array.Empty<string>();
                List<string> testC = new List<string>();
                Dictionary<string, string> testD = new Dictionary<string, string>();

                bool isB = testB.IsNullOrEmpty();
                bool isC = testC.IsNullOrEmpty();
                bool isD = testD.IsNullOrEmpty();

                Assert.Equal($"isB:{true}", $"isB:{isB}");
                Assert.Equal($"isC:{true}", $"isC:{isC}");
                Assert.Equal($"isD:{true}", $"isD:{isD}");
            }

            ////测试长度不为空但内容没有引用
            ////因内容里面 ""或null这种。无法区分是否有效，不同的情况判别不一致。所以不做处理
            //[Fact]
            //public void ObjectExtension_IsNullOrEmpty_ContentNull()
            //{
            //    string[] testB = new string[1];
            //    List<string> testC = new List<string>() { null, "1" };
            //    Dictionary<string, string> testD = new Dictionary<string, string>()
            //    { { "1",null}, { "2",null}};

            //    bool isB = testB.IsNullOrEmpty();
            //    bool isC = testC.IsNullOrEmpty();
            //    bool isD = testD.IsNullOrEmpty();

            //    Assert.Equal($"isB:{true}", $"isB:{isB}");
            //    Assert.Equal($"isC:{true}", $"isC:{isC}");
            //    Assert.Equal($"isD:{true}", $"isD:{isD}");
            //}
        }

        #endregion IsNullOrEmpty方法

        #region IsNotNullOrEmpty方法

        [Trait("Extend", "Object")]
        public class IsNotNullOrEmptyTest
        {
            //测试引用为null
            [Fact]
            public void ObjectExtension_IsNotNullOrEmpty_ReferenceNull()
            {
                object testA = null;
                string[] testB = null;
                List<string> testC = null;
                Dictionary<string, string> testD = null;

                bool isA = testA.IsNotNullOrEmpty();
                bool isB = testB.IsNotNullOrEmpty();
                bool isC = testC.IsNotNullOrEmpty();
                bool isD = testD.IsNotNullOrEmpty();

                Assert.Equal($"isA:{false}", $"isA:{isA}");
                Assert.Equal($"isB:{false}", $"isB:{isB}");
                Assert.Equal($"isC:{false}", $"isC:{isC}");
                Assert.Equal($"isD:{false}", $"isD:{isD}");
            }

            //测试长度为null
            [Fact]
            public void ObjectExtension_IsNotNullOrEmpty_LengthNull()
            {
                string[] testB = Array.Empty<string>();
                List<string> testC = new List<string>();
                Dictionary<string, string> testD = new Dictionary<string, string>();

                bool isB = testB.IsNotNullOrEmpty();
                bool isC = testC.IsNotNullOrEmpty();
                bool isD = testD.IsNotNullOrEmpty();

                Assert.Equal($"isB:{false}", $"isB:{isB}");
                Assert.Equal($"isC:{false}", $"isC:{isC}");
                Assert.Equal($"isD:{false}", $"isD:{isD}");
            }
        }

        #endregion IsNotNullOrEmpty方法

        #region EqualsType方法

        [Trait("Extend", "Object")]
        public class EqualsTypeTest
        {
#pragma warning disable S1144 // Unused private types or members should be removed

            private class TestA
            {
                public int ID { get; set; }
            }

            private class TestB : TestA
            {
                public string Name { get; set; }
            }

#pragma warning restore S1144 // Unused private types or members should be removed

            [Theory]
            [InlineData("1", typeof(string), true)]
            [InlineData("1", typeof(object), false)]
            [InlineData("1", typeof(int), false)]
            [InlineData("1", typeof(double), false)]
            public void ObjectExtension_EqualsType_Type<T>(T object1, Type type2, bool expected)
            {
                bool result = object1.EqualsType(type2);

                Assert.Equal(expected, result);
            }

#pragma warning disable S4144 // Methods should not have identical implementations

            [Theory]
            [InlineData(1, typeof(int), true)]
            [InlineData(125.5, typeof(double), true)]
            [InlineData(1, typeof(string), false)]
            public void ObjectExtension_EqualsType_Type_Value<T>(T object1, Type type2, bool expected)

            {
                bool result = object1.EqualsType(type2);

                Assert.Equal(expected, result);
            }

#pragma warning restore S4144 // Methods should not have identical implementations

            [Fact]
            public void ObjectExtension_EqualsType_Object_Type()
            {
                object a = new object();
                Type typeA = typeof(object);

                bool result = a.EqualsType(typeA);
                Assert.True(result);
            }

            [Fact]
            public void ObjectExtension_EqualsType_Class_Type()
            {
                TestA a = new TestA();
                Type typeA = typeof(TestA);

                bool result = a.EqualsType(typeA);
                Assert.True(result);
            }

            [Fact]
            public void ObjectExtension_EqualsType_Null_True()
            {
                TestA a = null;
                Type typeA = typeof(TestA);

                bool result = a.EqualsType(typeA);
                Assert.True(result);
            }

            [Fact]
            public void ObjectExtension_EqualsType_Class_Type_False()
            {
                TestB a = new TestB();
                Type typeA = typeof(TestA);

                bool result = a.EqualsType(typeA);
                Assert.False(result);
            }

            [Fact]
            public void ObjectExtension_EqualsType_DateTime_Type()
            {
                DateTime a = DateTime.Now;
                Type typeA = typeof(DateTime);

                bool result = a.EqualsType(typeA);
                Assert.True(result);
            }

            [Fact]
            public void ObjectExtension_EqualsType_DateTime_Type_False()
            {
                DateTime a = DateTime.Now;
                Type typeA = typeof(DateTimeOffset);

                bool result = a.EqualsType(typeA);
                Assert.False(result);
            }
        }

        #endregion EqualsType方法

        #region ToXml方法

        [Trait("Extend", "Object")]
        public class ToXmlTest
        {
            [XmlRoot]
            public class TestXml
            {
                [XmlElement("StuID")]
                public int ID { get; set; }

                public string Name { get; set; }

                [XmlElement("StringList")]
                public List<string> StringList { get; set; }
            }

            protected static class MockHelper
            {
                public static TestXml GetTestObject()
                {
                    return new TestXml()
                    {
                        ID = 5,
                        Name = "ABC",
                        StringList = new List<string>() { "AA", "BB" }
                    };
                }
            }

            [Theory]
            [InlineData(true, false)]
            [InlineData(false, true)]
            public void ObjectExtension_ToXml(bool isRemove, bool expected)
            {
                var testObject = MockHelper.GetTestObject();

                string result = testObject.ToXmlExtV2(isRemove);

                Assert.True(result.Contains("<?") == expected);
            }
        }

        #endregion ToXml方法

        #region GetAllPropertyValue方法

        [Trait("Extend", "Object")]
        public class GetAllPropertyValueTest
        {
            //测试能正常转换
            [Fact]
            public void GetAllPropertyValue_True()
            {
                SellerInfo sellerInfo = new SellerInfo()
                {
                    UserID = 0,
                    SellerID = "BHD6",
                    SellerName = null,
                    StringValue = string.Empty
                };

                var result = sellerInfo.GetAllPropertyValue(false).ToArray();

                Assert.NotEmpty(result);
                Assert.Equal(7, result.Length);
                Assert.Equal(0, result.First(t => t.Key == nameof(UserInfo.UserID)).Value);
                Assert.Equal("BHD6", result.First(t => t.Key == nameof(SellerInfo.SellerID)).Value);
                Assert.Equal(string.Empty, result.First(t => t.Key == nameof(SellerInfo.StringValue)).Value);
            }

            //测试忽略空值的情况
            [Fact]
            public void GetAllPropertyValue_IgnoreNull()
            {
                SellerInfo sellerInfo = new SellerInfo()
                {
                    UserID = 0,
                    SellerID = "BHD6",
                    SellerName = null,
                    StringValue = string.Empty
                };

                var result = sellerInfo.GetAllPropertyValue(true).ToArray();

                Assert.NotEmpty(result);
                Assert.Equal(3, result.Length);
                Assert.Equal(0, result.First(t => t.Key == nameof(UserInfo.UserID)).Value);
                Assert.Equal("BHD6", result.First(t => t.Key == nameof(SellerInfo.SellerID)).Value);
                Assert.Equal(string.Empty, result.First(t => t.Key == nameof(SellerInfo.StringValue)).Value);
            }

            //测试参数为null时 抛出异常
            [Fact]
            public void GetAllPropertyValue_SourceIsNull_Exception()
            {
                SellerInfo sellerInfo = null;

                var result = Assert.Throws<ArgumentNullException>(() => sellerInfo.GetAllPropertyValue(true).ToArray());

                Assert.NotNull(result);
                Assert.Contains("source", result.Message);
            }

            //测试参数为数组类型时 抛出异常
            [Fact]
            public void GetAllPropertyValue_List_Exception()
            {
                List<SellerInfo> sellerInfos = new List<SellerInfo>()
                {
                    new SellerInfo()
                    {
                        UserID = 0,
                        SellerID = "BHD6",
                        SellerName = null,
                        StringValue = string.Empty
                    },
                    new SellerInfo()
                    {
                        UserID = 0,
                        SellerID = "BHD6",
                        SellerName = null,
                        StringValue = string.Empty
                    }
                };

                var result = Assert.Throws<TypeAccessException>(() => sellerInfos.GetAllPropertyValue(true).ToArray());

                Assert.NotNull(result);
                Assert.Contains("type not is array type", result.Message);
            }
        }

        #endregion GetAllPropertyValue方法

        #region 基础类型与Object之间的转换

        [Trait("Extend", "Object")]
        public class ToInt32ExtTest
        {
            [Theory]
            [InlineData("123")]
            public void ToInt32_True(object value)
            {
                value.ToInt32();
            }

            [Theory]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("15.2")]
            [InlineData("123a")]
            public void ToInt32_Exception(object value)
            {
                var ex = Record.Exception(() => value.ToInt32());
                Assert.NotNull(ex);
            }

            [Theory]
            [InlineData("123", 123, 123)]
            [InlineData("", 123, 123)]
            [InlineData(null, 123, 123)]
            [InlineData("15.2", 123, 123)]
            [InlineData("123a", 123, 123)]
            public void ToInt32OrDefault(object value, int defalultValue, int expectNum)
            {
                int result = value.ToInt32OrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToDecimalExtTest
        {
            [Theory]
            [InlineData("123")]
            [InlineData("123.1")]
            [InlineData("0.0000")]
            public void ToDecimal_True(object value)
            {
                value.ToDecimal();
            }

            [Theory]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            public void ToDecimal_Exception(object value)
            {
                var ex = Record.Exception(() => value.ToDecimal());
                Assert.NotNull(ex);
            }

            [Theory]
            [InlineData("123", 123.0, 123.0)]
            [InlineData("123.1", 123.1, 123.1)]
            [InlineData("0.0000", 0.0, 0.0)]
            [InlineData("", 123.1, 123.1)]
            [InlineData(null, 123.1, 123.1)]
            [InlineData("123a", 123.1, 123.1)]
            public void ToDecimalOrDefault(object value, decimal defalultValue, decimal expectNum)
            {
                decimal result = value.ToDecimalOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToBoolExtTest
        {
            [Theory]
            [InlineData("true")]
            [InlineData("false")]
            [InlineData("True")]
            [InlineData("False")]
            public void ToBool_True(object value)
            {
                value.ToBool();
            }

            [Theory]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            [InlineData("true1")]
            [InlineData("true ")]
            [InlineData(" true")]
            public void ToBool_Exception(object value)
            {
                var ex = Record.Exception(() => value.ToDecimal());
                Assert.NotNull(ex);
            }

            [Theory]
            [InlineData("true", true, true)]
            [InlineData("false", false, false)]
            [InlineData("", true, true)]
            [InlineData(null, true, true)]
            [InlineData("123a", true, true)]
            [InlineData("true1", true, true)]
            [InlineData("true ", true, true)]
            [InlineData(" true", true, true)]
            public void ToBoolOrDefault(object value, bool defalultValue, bool expectNum)
            {
                bool result = value.ToBoolOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToDoubleExtTest
        {
            [Theory]
            [InlineData("11.1")]
            [InlineData("11")]
            [InlineData("0")]
            [InlineData("-15.4")]
            public void ToDouble_True(object value)
            {
                value.ToDouble();
            }

            [Theory]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            public void ToDouble_Exception(object value)
            {
                var ex = Record.Exception(() => value.ToDouble());
                Assert.NotNull(ex);
            }

            [Theory]
            [InlineData("11.1", 11.1, 11.1)]
            [InlineData("11", 11, 11)]
            [InlineData("", 12.5, 12.5)]
            [InlineData(null, 12.5, 12.5)]
            [InlineData("123a", 12.5, 12.5)]
            [InlineData("true1", 12.5, 12.5)]
            [InlineData("true ", 12.5, 12.5)]
            [InlineData(" true", 12.5, 12.5)]
            public void ToDoubleOrDefault(object value, double defalultValue, double expectNum)
            {
                double result = value.ToDoubleOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        #endregion 基础类型与Object之间的转换
    }
}