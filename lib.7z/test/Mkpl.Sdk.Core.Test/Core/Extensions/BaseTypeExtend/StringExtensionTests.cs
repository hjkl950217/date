﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StringExtensionTests.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   StringExtensionTests created at  2/10/2018 1:52:27 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using Mkpl.Sdk.Core.Test.Sellers;
using System;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class StringExtensionTests
    {
        //字符中和json字符串这间的转换
        [Trait("Extend", "String")]
        public class JsonAndStringTest
        {
            [Fact]
            public void Serialize_Json()
            {
                var obj = new SellerInfo
                {
                    SellerID = "A001",
                    SellerName = "Zoo Store",
                    UserList = new List<UserInfo>
                    {
                        new UserInfo{
                            UserID=1,
                            UserName="Lion"
                        },
                         new UserInfo{
                            UserID=2,
                            UserName="Tiger"
                        }
                    }
                };

                var real_Result = obj.ToJsonExt();

                Assert.Contains("\"SellerID\": \"A001\"", real_Result);
            }

            //转换成string时使用父类的类型
            [Fact]
            public void Serialize_Json_SpecifiedType()
            {
                var obj = new SellerInfo
                {
                    SellerID = "A001",
                    SellerName = "Zoo Store",
                    UserList = new List<UserInfo>
                    {
                        new UserInfo{
                            UserID=1,
                            UserName="Lion"
                        },
                         new UserInfo{
                            UserID=2,
                            UserName="Tiger"
                        }
                    }
                };

                var real_Result = obj.ToJsonExt(typeof(UserInfo));

                Assert.Contains(nameof(UserInfo.UserID), real_Result);
                Assert.DoesNotContain("\"SellerID\": \"A001\"", real_Result);
            }

            //当数据不匹配类型应该没有错误，Json没有匹配类型
            [Fact]
            public void Serialize_Json_SpecifiedType_WhenDataNoMatchTypeShouldBeNoErrorAndJsonNoMatchData()
            {
                var obj = new SellerInfo
                {
                    SellerID = "A001",
                    SellerName = "Zoo Store",
                    UserList = new List<UserInfo>
                    {
                        new UserInfo{
                            UserID=1,
                            UserName="Lion"
                        },
                         new UserInfo{
                            UserID=2,
                            UserName="Tiger"
                        }
                    },
                    StringValue = "Test"
                };
                var real_Result = obj.ToJsonExt(typeof(TestEntity));

                Assert.DoesNotContain(nameof(SellerInfo.SellerID), real_Result);
                Assert.Contains("\"StringValue\": \"Test\"", real_Result);
            }

            [Fact]
            public void Deserialize_Jsont()
            {
                string expect_Result = "{  \"SellerID\": \"A001\",  \"SellerName\": \"Zoo Store\",  \"UserList\": [  {  \"UserID\": 1, \"UserName\": \"Lion\"  },    { \"UserID\": 2, \"UserName\": \"Tiger\"  } ]}";

                var real_Result = expect_Result.ToObjectExt<SellerInfo>();
                Assert.Equal("A001", real_Result.SellerID);
            }
        }

        [Trait("Extend", "String")]
        public class ToCountryNameTest
        {
            /// <summary>
            /// 测试国家名字的格式化
            /// </summary>
            /// <remarks>
            /// </remarks>
            /// <param name="typeNum">情况代码</param>
            [Theory]
            [InlineData("CHN")]
            [InlineData("CAF")]
            [InlineData("CAF2")]
            [InlineData("CAF3")]
            [InlineData("CAF4")]
            [InlineData("CAN")]
            [InlineData("CAN2")]
            public void ToCountryNameTest_All(string countryCode)
            {
                #region 准备测试数据

                var testData = new Dictionary<string, string>()
                {
                    {"CHN","CHINA" },
                    {"CAF","CENTRAL AFRICAN REPUBLIC" },
                    {"CAF2","CENTRAL AFRICAN REPUBLIC " },
                    {"CAF3"," CENTRAL AFRICAN REPUBLIC " },
                    {"CAF4"," CENT RAL AFRICAN REPUBLIC " },
                    {"CAN","CANADA  " },
                    { "CAN2","CAN       ADA  " }
                };

                #endregion 准备测试数据

                #region 按情况切换数据

                string testStr = testData[countryCode];

                #endregion 按情况切换数据

                //注册模拟方法

                //测试
                string result = testStr.ToCountryName();

                #region 验证测试结果

                switch (countryCode)
                {
                    case "CHN": Assert.True(result == "China"); break;
                    case "CAF": Assert.True(result == "Central African Republic"); break;
                    case "CAF2": Assert.True(result == "Central African Republic"); break;
                    case "CAF3": Assert.True(result == "Central African Republic"); break;
                    case "CAF4": Assert.True(result == "Cent Ral African Republic"); break;
                    case "CAN": Assert.True(result == "Canada"); break;
                    case "CAN2": Assert.True(result == "Can Ada"); break;
                    default: Assert.True(false); break;
                }

                #endregion 验证测试结果
            }
        }

        [Trait("Extend", "String")]
        public class ToInt32ExtTest
        {
            [Theory(DisplayName = nameof(ToInt32_True))]
            [InlineData("123")]
            public void ToInt32_True(string value)
            {
                value.ToInt32();
            }

            [Theory(DisplayName = nameof(ToInt32_Exception))]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("15.2")]
            [InlineData("123a")]
            public void ToInt32_Exception(string value)
            {
                var ex = Record.Exception(() => value.ToInt32());
                Assert.NotNull(ex);
            }

            [Theory(DisplayName = nameof(ToInt32OrDefault))]
            [InlineData("123", 123, 123)]
            [InlineData("", 123, 123)]
            [InlineData(null, 123, 123)]
            [InlineData("15.2", 123, 123)]
            [InlineData("123a", 123, 123)]
            public void ToInt32OrDefault(string value, int defalultValue, int expectNum)
            {
                int result = value.ToInt32OrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToDecimalExtTest
        {
            [Theory(DisplayName = nameof(ToDecimal_True))]
            [InlineData("123")]
            [InlineData("123.1")]
            [InlineData("0.0000")]
            public void ToDecimal_True(string value)
            {
                value.ToDecimal();
            }

            [Theory(DisplayName = nameof(ToDecimal_Exception))]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            public void ToDecimal_Exception(string value)
            {
                var ex = Record.Exception(() => value.ToDecimal());
                Assert.NotNull(ex);
            }

            [Theory(DisplayName = nameof(ToDecimalOrDefault))]
            [InlineData("123", 123.0, 123.0)]
            [InlineData("123.1", 123.1, 123.1)]
            [InlineData("0.0000", 0.0, 0.0)]
            [InlineData("", 123.1, 123.1)]
            [InlineData(null, 123.1, 123.1)]
            [InlineData("123a", 123.1, 123.1)]
            public void ToDecimalOrDefault(string value, decimal defalultValue, decimal expectNum)
            {
                decimal result = value.ToDecimalOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToBoolExtTest
        {
            [Theory(DisplayName = nameof(ToBool_True))]
            [InlineData("true")]
            [InlineData("false")]
            [InlineData("True")]
            [InlineData("False")]
            public void ToBool_True(string value)
            {
                value.ToBool();
            }

            [Theory(DisplayName = nameof(ToBool_Exception))]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            [InlineData("true1")]
            [InlineData("true ")]
            [InlineData(" true")]
            public void ToBool_Exception(string value)
            {
                var ex = Record.Exception(() => value.ToDecimal());
                Assert.NotNull(ex);
            }

            [Theory(DisplayName = nameof(ToBoolOrDefault))]
            [InlineData("true", true, true)]
            [InlineData("false", false, false)]
            [InlineData("", true, true)]
            [InlineData(null, true, true)]
            [InlineData("123a", true, true)]
            [InlineData("true1", true, true)]
            [InlineData("true ", true, true)]
            [InlineData(" true", true, true)]
            public void ToBoolOrDefault(string value, bool defalultValue, bool expectNum)
            {
                bool result = value.ToBoolOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class ToDoubleExtTest
        {
            [Theory(DisplayName = nameof(ToDouble_True))]
            [InlineData("11.1")]
            [InlineData("11")]
            [InlineData("0")]
            [InlineData("-15.4")]
            public void ToDouble_True(string value)
            {
                value.ToDouble();
            }

            [Theory(DisplayName = nameof(ToDouble_Exception))]
            [InlineData("")]
            [InlineData(null)]
            [InlineData("123a")]
            public void ToDouble_Exception(string value)
            {
                var ex = Record.Exception(() => value.ToDouble());
                Assert.NotNull(ex);
            }

            [Theory(DisplayName = nameof(ToDoubleOrDefault))]
            [InlineData("11.1", 11.1, 11.1)]
            [InlineData("11", 11, 11)]
            [InlineData("", 12.5, 12.5)]
            [InlineData(null, 12.5, 12.5)]
            [InlineData("123a", 12.5, 12.5)]
            [InlineData("true1", 12.5, 12.5)]
            [InlineData("true ", 12.5, 12.5)]
            [InlineData(" true", 12.5, 12.5)]
            public void ToDoubleOrDefault(string value, double defalultValue, double expectNum)
            {
                double result = value.ToDoubleOrDefault(defalultValue);
                Assert.Equal(expectNum, result);
            }
        }

        [Trait("Extend", "String")]
        public class EqualsStringTest
        {
            [Theory(DisplayName = "EqualsIgnoreCase")]
            [InlineData("Abc", "aBc", true)]
            [InlineData("Abc", "abc", true)]
            [InlineData("Abc", " aBc ", false)]
            [InlineData("Abc", " aBc", false)]
            [InlineData("Abc", " ab C", false)]
            [InlineData("Abc", "", false)]
            [InlineData("Abc", "  ", false)]
            [InlineData("Abc", null, false)]
            public void EqualsString_EqualsIgnoreCase_All(string value, string actualStr, bool expectResult)
            {
                //执行
                bool result = value.EqualsIgnoreCase(actualStr);
                //验证
                Assert.Equal(result, expectResult);
            }

            [Theory(DisplayName = "EqualsLoose")]
            [InlineData("Abc", "aBc", true)]
            [InlineData("Abc", "abc", true)]
            [InlineData("Abc", " aBc ", true)]
            [InlineData("Abc", " aBc", true)]
            [InlineData("Abc", " ab C", false)]
            [InlineData("Abc", "", false)]
            [InlineData("Abc", "  ", false)]
            [InlineData("Abc", null, false)]
            public void EqualsString_EqualsLoose_All(string value, string actualStr, bool expectResult)
            {
                //执行
                bool result = value.EqualsLoose(actualStr);
                //验证
                Assert.Equal(result, expectResult);
            }
        }

        [Trait("Extend", "String")]
        public class SplitToArrayTest
        {
            [Theory]
            [InlineData(";da,sd;d,", 3, "DA;SD;D")]
            [InlineData("", 0, "")]
            [InlineData(null, 0, "")]
            public void WhenDefualtSeparators(string test, int length, string expectedstr)
            {
                var result = test.SplitToArray();
                Assert.Equal(length, result.Length);
                var expecteds = expectedstr.Split(";", StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0 ; i < expecteds.Length ; i++)
                {
                    Assert.Equal(expecteds[i], result[i]);
                }
            }

            [Theory]
            [InlineData("dapsdpd", 3, "DA;SD;D")]
            [InlineData("", 0, "")]
            [InlineData(null, 0, "")]
            public void WhenCustomSeparators(string test, int length, string expectedstr)
            {
                var result = test.SplitToArray(new char[] { 'p' });
                Assert.Equal(length, result.Length);
                var expecteds = expectedstr.Split(";", StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0 ; i < expecteds.Length ; i++)
                {
                    Assert.Equal(expecteds[i], result[i]);
                }
            }
        }

        [Trait("Extend", "String")]
        public class RemoveExtraSymbolTest
        {
            [Fact]
            public void RemoveExtraSymbol_Exception()
            {
                string testStr = null;

                Assert.Throws<ArgumentNullException>(() =>
                {
                    testStr.RemoveExtraSymbol();
                });
            }

            [Fact]
            public void RemoveExtraSymbol_SourceIsEmpty()
            {
                string testStr = string.Empty;

                string result = testStr.RemoveExtraSymbol();

                Assert.Equal(string.Empty, result);
            }

            [Fact]
            public void RemoveExtraSymbol_SymbolsIsEmpty()
            {
                string testStr = "1";
                char[] symbols = Array.Empty<char>();

                string result = testStr.RemoveExtraSymbol(symbols);

                Assert.Equal("1", result);
            }

            [Fact]
            public void RemoveExtraSymbol_LengthLessThanTwo()
            {
                string testStr = "1";
                string testStr2 = "1;";
                char[] symbols = Array.Empty<char>();

                string result = testStr.RemoveExtraSymbol(symbols);
                string result2 = testStr2.RemoveExtraSymbol(symbols);

                Assert.Equal("1", result);
                Assert.Equal("1;", result2);
            }

            private readonly char[] TestSymbols = new char[] { ';', '-' };

            [Theory]
            [InlineData("1;2", "1;2")]
            [InlineData("1;2;", "1;2")]
            [InlineData("1;2-", "1;2")]
            [InlineData("1;2@", "1;2@")]
            public void RemoveExtraSymbol_OtherTest(string testStr, string expected)
            {
                // char[] symbols = new char[] { };

                string result = testStr.RemoveExtraSymbol(this.TestSymbols);

                Assert.Equal(expected, result);
            }
        }

        [Trait("Extend", "String")]
        public class SubstringExt
        {
            [Fact]
            public void String_Null()
            {
                string str = null;

                string result = str.SubstringExt(20);

                Assert.Equal(string.Empty, result);
            }

            [Fact]
            public void String_Empty()
            {
                string str = string.Empty;

                string result = str.SubstringExt(20);

                Assert.Equal(string.Empty, result);
            }

            [Fact]
            public void Lenth_LessThanZero()
            {
                string str = "1";

                var ex = Assert.Throws<ArgumentException>(() => str.SubstringExt(-1));

                Assert.NotNull(ex);
                Assert.NotEmpty(ex.Message);
            }

            [Fact]
            public void StartIndex_LessThanZero()
            {
                string str = "1";

                var ex = Assert.Throws<ArgumentException>(() => str.SubstringExt(20, -1));

                Assert.NotNull(ex);
                Assert.NotEmpty(ex.Message);
            }

            [Fact]
            public void String_LessThanStringLength()
            {
                string str = "123456";

                string result = str.SubstringExt(3);

                Assert.Equal("123", result);
            }

            [Fact]
            public void String_EqualStringLength()
            {
                string str = "123456";

                string result = str.SubstringExt(6);

                Assert.Equal(str, result);
            }

            [Fact]
            public void String_MoreThanStringLength()
            {
                string str = "123456";

                string result = str.SubstringExt(10);

                Assert.Equal(str, result);
            }
        }
    }
}