﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpExtension.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   HttpExtension created at  4/14/2018 10:26:14 AM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using NSubstitute;
using System;
using System.Net;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class HttpExtensionTest
    {
        #region 复刻固定数据

        public static class MockHelper
        {
            public const string Aip = "10.1.1.1";
            public const string Bip = "200.1.1.1";

            public static HttpRequest GetMockHttpRequest(bool isNew = false)
            {
                HttpRequest request = Substitute.For<HttpRequest>();

                if (isNew == true)//要求new出来时 直接返回
                {
                    return request;
                }

                request.Scheme.Returns("http");
                request.Host.Returns(new HostString("localhost:54851"));
                request.Path.Returns(new PathString("/Authenticationin/Validator"));
                request.QueryString.Returns(new QueryString(@"?test=a&testA=b"));

                return request;
            }

            /// <summary>
            /// 获取模拟HttpContext,参数传递null代表使用默认的
            /// </summary>
            /// <returns></returns>
            public static HttpContext GetMockHttpContext(string xip = null, string ipAddress = null)
            {
                xip = xip ?? "";
                ipAddress = ipAddress ?? "::1";

                var httpContext = Substitute.For<HttpContext>();
                httpContext.Request.Returns(Substitute.For<HttpRequest>());
                httpContext.Response.Returns(Substitute.For<HttpResponse>());
                httpContext.Connection.Returns(Substitute.For<ConnectionInfo>());
                httpContext.WebSockets.Returns(Substitute.For<WebSocketManager>());

                #region 模拟返回值

                //模拟IP
                httpContext.Request
                    .Headers[HttpHeaderNameConst.XSoucreIP]
                    .Returns(new StringValues(xip));

                httpContext.Connection
                      .RemoteIpAddress
                      .Returns(IPAddress.Parse(ipAddress));

                #endregion 模拟返回值

                return httpContext;
            }
        }

        #endregion 复刻固定数据

        #region GetUri

        [Trait("Extend", "Http")]
        public class GetUriTest
        {
            [Fact(DisplayName = "Get_Url_AbsoluteUri")]
            public void Get_Url_AbsoluteUri()
            {
                Uri url = MockHelper.GetMockHttpRequest().GetUri();

                //执行
                string result = url.AbsoluteUri;

                //验证
                Assert.Equal("http://localhost/Authenticationin/Validator?test=a&testA=b", result);
            }

            [Fact(DisplayName = "Get_Url_Scheme")]
            public void Get_Url_Scheme()
            {
                Uri url = MockHelper.GetMockHttpRequest().GetUri();

                //执行
                string result = url.Scheme;

                //验证
                Assert.Equal("http", result);
            }

            [Fact(DisplayName = "Get_Url_Host")]
            public void Get_Url_Host()
            {
                Uri url = MockHelper.GetMockHttpRequest().GetUri();

                //执行
                string result = url.Host;

                //验证
                Assert.Equal("localhost", result);
            }

            [Fact(DisplayName = "Get_Url_Query")]
            public void Get_Url_Query()
            {
                Uri url = MockHelper.GetMockHttpRequest().GetUri();

                //执行
                string result = url.Query;

                //验证
                Assert.Equal("?test=a&testA=b", result);
            }

            [Fact(DisplayName = "Get_Url_Null")]
            public void Get_Url_Null()
            {
                HttpRequest testHttpRequest = MockHelper.GetMockHttpRequest(true);

                //执行
                Uri url = testHttpRequest.GetUri();

                //验证
                Assert.Null(url);
            }
        }

        #endregion GetUri

        #region GetAbsoluteUri

        [Trait("Extend", "Http")]
        public class GetAbsoluteUriTest
        {
            [Fact(DisplayName = "Get_GetAbsoluteUri")]
            public void Get_GetAbsoluteUri_Null()
            {
                HttpRequest testHttpRequest = MockHelper.GetMockHttpRequest(true);

                //执行
                string result = testHttpRequest.GetAbsoluteUri();

                //验证
                Assert.Equal(string.Empty, result);
            }
        }

        #endregion GetAbsoluteUri

        #region GetRemoteIpAddress

        [Trait("Extend", "Http")]
        public class GetRemoteIpAddressTest
        {
            [Fact(DisplayName = "Get_GetRemoteIpAddress_xip")]
            public void Get_GetRemoteIpAddress_xip()
            {
                HttpContext context = MockHelper.GetMockHttpContext(xip: MockHelper.Aip);

                //执行
                string result = context.GetRemoteIpAddress();

                //验证
                Assert.Equal(MockHelper.Aip, result);
            }

            [Fact(DisplayName = "Get_GetRemoteIpAddress_RemoteIp")]
            public void Get_GetRemoteIpAddress_RemoteIp()
            {
                HttpContext context = MockHelper.GetMockHttpContext(xip: null, ipAddress: MockHelper.Bip);

                //执行
                string result = context.GetRemoteIpAddress();

                //验证
                Assert.Equal(MockHelper.Bip, result);
            }

            [Fact(DisplayName = "Get_GetRemoteIpAddress_TwoIP")]
            public void Get_GetRemoteIpAddress_TwoIP()
            {
                HttpContext context = MockHelper.GetMockHttpContext(xip: MockHelper.Aip, ipAddress: MockHelper.Bip);

                //执行
                string result = context.GetRemoteIpAddress();

                //验证
                Assert.Equal(MockHelper.Aip, result);
            }
        }

        #endregion GetRemoteIpAddress
    }
}