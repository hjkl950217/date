﻿using Mkpl.Sdk.Core.Nair;
using NSubstitute;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class NairCacheExtensionTests
    {
        private static class MockHeler
        {
            public static INairCache GetMockNairCache<TResult>(TResult result = default)
            {
                INairCache nairCache = Substitute.For<INairCache>();

                nairCache.TryGet<TResult>(Arg.Any<string>())
                    .Returns(result);

                return nairCache;
            }
        }

        [Fact]
        public void GetOrAdd_DataFactory_Null_NoException()
        {
            INairCache nairCache = MockHeler.GetMockNairCache("abc");
            string key = "123";
            Func<string> dataFactory = null;

            nairCache.GetOrAdd(
                key,
                dataFactory);
        }

        [Fact]
        public void GetOrAdd_DataFactory_AddData()
        {
            INairCache nairCache = MockHeler.GetMockNairCache(string.Empty);
            string key = "123";
            Func<string> dataFactory = () => "abc";

            string result = nairCache.GetOrAdd(
                 key,
                 dataFactory);

            Assert.Equal("abc", result);

            nairCache.Received()
                .Add(Arg.Any<string>(), Arg.Any<string>());
        }
    }
}