﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StreamExtensionTest.cs" company="Newegg" Author="ll0a">
//   Copyright (c) 2019 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   StreamExtensionTest created at  1/30/2019 3:20:09 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
using System.IO;
using System.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Extend", "Stream")]
    public class StreamExtensionTest
    {
        [Fact(DisplayName = "SaveAsByte长度验证")]
        public void TC_SaveAsByte_Length()
        {
            byte[] buffer = Enumerable.Repeat((byte)0x08, 10).ToArray();
            using (MemoryStream excelStream = new MemoryStream(buffer))
            {
                var result = excelStream.SaveAsByte();
                Assert.Equal(10, result.Length);
            }
        }

        [Fact(DisplayName = "SaveAsByte内容验证")]
        public void TC_SaveAsByte_Content()
        {
            byte[] buffer = Enumerable.Repeat((byte)0x08, 10).ToArray();
            using (MemoryStream excelStream = new MemoryStream(buffer))
            {
                var result = excelStream.SaveAsByte();
                Assert.Equal((byte)0x08, result[0]);
            }
        }

        [Fact(DisplayName = "MemoryStream为null")]
        public void TC_SaveAsByte_MemoryStream_Null()
        {
            MemoryStream excelStream = null;

            byte[] buffer = null;
            var ex = Xunit.Record.Exception(() =>
            {
                buffer = excelStream.SaveAsByte();
            });

            Assert.Null(ex);
            Assert.NotNull(buffer);
            Assert.Empty(buffer);
        }

        [Fact(DisplayName = "MemoryStream为内容为null")]
        public void TC_SaveAsByte_Content_Null()
        {
            byte[] buffer = System.Array.Empty<byte>();
            using (MemoryStream excelStream = new MemoryStream(buffer))
            {
                var result = excelStream.SaveAsByte();
                Assert.Empty(result);
            }
        }
    }
}