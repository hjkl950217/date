﻿using FluentValidation;
using FluentValidation.Internal;
using FluentValidation.Results;
using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Test.Sellers;
using NSubstitute;
using System;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Extensions
{
    public class ValidatorExtensionTest
    {
        #region Test_Validator

        internal class CheckSellerID_Validator : AbstractValidator<SellerInfo>
        {
            public CheckSellerID_Validator()
            {
                base.RuleFor(t => t.SellerID)
                    .CheckSellerID();
            }
        }

        internal class StrictCheckSellerID_Validator : AbstractValidator<SellerInfo>
        {
            public StrictCheckSellerID_Validator()
            {
                base.RuleFor(t => t.SellerID)
                    .StrictCheckSellerID();
            }
        }

        internal class RequiredForClass_SellerNameRequired_Validator : AbstractValidator<SellerInfo>
        {
            public RequiredForClass_SellerNameRequired_Validator()
            {
                base.RuleFor(t => t.SellerName)
                    .Required();

                //下面是集合式的写法
                //base.RuleForEach(t => t)
                //   .ChildRules(sellerInfo =>
                //   {
                //       sellerInfo.RuleFor(x => x.User).Required();
                //   });
            }
        }

        internal class RequiredForInt_UserIDRequired_Validator : AbstractValidator<SellerInfo>
        {
            public RequiredForInt_UserIDRequired_Validator()
            {
                base.RuleFor(t => t.UserID)
                    .Required();
            }
        }

        internal class All_UserIDEqual500_Validator : AbstractValidator<SellerInfo>
        {
            public All_UserIDEqual500_Validator()
            {
                base.RuleFor(t => t.UserList)
                    .All(b => b.UserID == 500, "user id must be equal 500");
            }
        }

        internal class AllNot_UserIDEqual500_Validator : AbstractValidator<SellerInfo>
        {
            public AllNot_UserIDEqual500_Validator()
            {
                base.RuleFor(t => t.UserList)
                    .AllNot(b => b.UserID == 500, "user id must be equal 500");
            }
        }

        internal class Any_UserIDEqual500_Validator : AbstractValidator<SellerInfo>
        {
            public Any_UserIDEqual500_Validator()
            {
                base.RuleFor(t => t.UserList)
                    .Any(b => b.UserID == 500, "user id more than 500");
            }
        }

        internal class AllUpper_UserNameAllUpper_Validator : AbstractValidator<SellerInfo>
        {
            public AllUpper_UserNameAllUpper_Validator()
            {
                base.RuleFor(t => t.UserName)
                    .AllUpper();
            }
        }

        internal class AnyUpper_UserNameAnyUpper__Validator : AbstractValidator<SellerInfo>
        {
            public AnyUpper_UserNameAnyUpper__Validator()
            {
                base.RuleFor(t => t.UserName)
                    .AnyUpper();
            }
        }

        internal class AllLower_UserNameAllLower_Validator : AbstractValidator<SellerInfo>
        {
            public AllLower_UserNameAllLower_Validator()
            {
                base.RuleFor(t => t.UserName)
                    .AllLower();
            }
        }

        internal class AnyLower_UserNameAnyLower_Validator : AbstractValidator<SellerInfo>
        {
            public AnyLower_UserNameAnyLower_Validator()
            {
                base.RuleFor(t => t.UserName)
                    .AnyLower();
            }
        }

        #endregion Test_Validator

        #region CheckSellerID

        public class CheckSellerIDTest
        {
            [Theory]
            [InlineData(null, false)]
            [InlineData("", false)]
            [InlineData("       ", false)]
            [InlineData(" bhd6-1", false)]
            [InlineData(" bhd6", true)]
            [InlineData(" bhd6    ", true)]
            [InlineData("BHD6", true)]
            public void CheckSellerID_Validator(string value, bool expected)
            {
                ValidationResult result = new CheckSellerID_Validator()
                    .Validate(new SellerInfo() { SellerID = value });

                Assert.Equal(expected, result.IsValid);
            }
        }

        public class StrictCheckSellerIDTest
        {
            [Theory]
            [InlineData(null, false)]
            [InlineData("", false)]
            [InlineData("       ", false)]
            [InlineData(" bhd6-1", false)]
            [InlineData(" bhd6", false)]
            [InlineData(" bhd6    ", false)]
            [InlineData("bhd6", false)]
            [InlineData("1hd6", false)]
            [InlineData("BHD6", true)]
            public void StrictCheckSellerID_Validator(string value, bool expected)
            {
                ValidationResult result = new StrictCheckSellerID_Validator()
                    .Validate(new SellerInfo() { SellerID = value });

                Assert.Equal(expected, result.IsValid);
            }
        }

        #endregion CheckSellerID

        #region Required

        public class RequiredTest
        {
            [Fact]
            public void RequiredForClass_WhenUserIsNull_False()
            {
                ValidationResult result = new RequiredForClass_SellerNameRequired_Validator()
                    .Validate(new SellerInfo() { SellerName = null });

                Assert.False(result.IsValid);
            }

            [Fact]
            public void RequiredForClass_WhenSellerNameIsEmpty_False()
            {
                ValidationResult result = new RequiredForClass_SellerNameRequired_Validator()
                    .Validate(new SellerInfo() { SellerName = string.Empty });

                Assert.False(result.IsValid);
            }

            [Fact]
            public void RequiredForClass_WhenSellerNameIsAAA_True()
            {
                ValidationResult result = new RequiredForClass_SellerNameRequired_Validator()
                    .Validate(new SellerInfo() { SellerName = "AAA" });

                Assert.True(result.IsValid);
            }

            [Fact]
            public void RequiredForInt_WhenUserIDIs0_False()
            {
                ValidationResult result = new RequiredForInt_UserIDRequired_Validator()
                    .Validate(new SellerInfo() { UserID = 0 });

                Assert.False(result.IsValid);
            }

            [Fact]
            public void RequiredForInt_WhenUserIDNotIs0_False()
            {
                ValidationResult result = new RequiredForInt_UserIDRequired_Validator()
                    .Validate(new SellerInfo() { UserID = 1 });

                Assert.True(result.IsValid);
            }
        }

        #endregion Required

        #region All and Any

        public class AllAndAnyTest
        {
            [Fact]
            public void All_UserIDEqual500_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=500},
                        new UserInfo(){UserID=500}
                    }
                };

                ValidationResult result = new All_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void All_UserIDEqual500_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=500},
                        new UserInfo(){UserID=1}
                    }
                };

                ValidationResult result = new All_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void AllNot_UserIDEqual500_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=1},
                        new UserInfo(){UserID=500}
                    }
                };

                ValidationResult result = new AllNot_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void AllNot_UserIDEqual500_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=500},
                        new UserInfo(){UserID=500}
                    }
                };

                ValidationResult result = new AllNot_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void Any_UserIDEqual500_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=500},
                        new UserInfo(){UserID=1}
                    }
                };

                ValidationResult result = new Any_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void Any_UserIDEqual500_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserList = new List<UserInfo>()
                    {
                        new UserInfo(){UserID=200},
                        new UserInfo(){UserID=1}
                    }
                };

                ValidationResult result = new Any_UserIDEqual500_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }
        }

        #endregion All and Any

        #region Upper and Lower

        public class UpperAndLower
        {
            [Fact]
            public void AllUpper_UserNameAllUpper_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "AAAA"
                };

                ValidationResult result = new AllUpper_UserNameAllUpper_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void AllUpper_UserNameAllUpper_Fase()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "AAAa"
                };

                ValidationResult result = new AllUpper_UserNameAllUpper_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void AllLower_UserNameAllUpper_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "aaaa"
                };

                ValidationResult result = new AllLower_UserNameAllLower_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void AllLower_UserNameAllUpper_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "aaaA"
                };

                ValidationResult result = new AllLower_UserNameAllLower_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void AnyUpper_UserNameAllUpper_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "aaaA"
                };

                ValidationResult result = new AnyUpper_UserNameAnyUpper__Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void AnyUpper_UserNameAllUpper_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "aaaa"
                };

                ValidationResult result = new AnyUpper_UserNameAnyUpper__Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void AnyLower_UserNameAllUpper_True()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "AAAa"
                };

                ValidationResult result = new AnyLower_UserNameAnyLower_Validator()
                    .Validate(sellerInfos);

                Assert.True(result.IsValid);
            }

            [Fact]
            public void AnyLower_UserNameAllUpper_False()
            {
                SellerInfo sellerInfos = new SellerInfo()
                {
                    UserName = "AAAA"
                };

                ValidationResult result = new AnyLower_UserNameAnyLower_Validator()
                    .Validate(sellerInfos);

                Assert.False(result.IsValid);
            }
        }

        #endregion Upper and Lower

        #region DI

        public class InjectValidatorTest
        {
            public class MockValidationContext : ValidationContext<SellerInfo>
            {
                public MockValidationContext(SellerInfo instanceToValidate) : base(instanceToValidate)
                {
                }

                public MockValidationContext(SellerInfo instanceToValidate, PropertyChain propertyChain, IValidatorSelector validatorSelector) : base(instanceToValidate, propertyChain, validatorSelector)
                {
                }

                public override bool IsChildContext => throw new Exception();

                public override bool IsChildCollectionContext => throw new Exception();
            }

            [Fact]
            public void Inject_NoError()
            {
                IRuleBuilder<SellerInfo, List<UserInfo>> ruleBuilder = Substitute.For<IRuleBuilder<SellerInfo, List<UserInfo>>>();
                IServiceProvider serviceProvider = Substitute.For<IServiceProvider>();
                IValidator<List<UserInfo>> validator = Substitute.For<IValidator<List<UserInfo>>>();
                Func<IServiceProvider, IValidator<List<UserInfo>>> simpCallback = t => t.GetService<IValidator<List<UserInfo>>>();

                _ = ruleBuilder.InjectValidator(simpCallback);
            }
        }

        #endregion DI
    }
}