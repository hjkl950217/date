﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EncryptionHelperTests.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   EncryptionHelperTests created at  2/10/2018 2:42:24 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    [Trait("Helper", "EncryptionHelper")]
    public class EncryptionHelperTests
    {
        #region RSA

        [Fact]
        public void Encryp_RSA()
        {
            string Password = "NeweggTestPwd";
            var real_result = EncryptionHelper.EncryptRSA(Password);

            Assert.NotNull(real_result);
        }

        [Fact]
        public void Decryp_RSA()
        {
            string Encryp_Password = "nuryxMELJh9gLMLWtShsV6uZk/SXlDqtF410ixtipQFxsEilEtOWiPm3SqmO6DTBxWYoNy0J/zjTOW1a5GulZOTQ1R2+RuhaYs/SBLfpN0fnHO9dKiYxx/LBfNtiiY0Pnb1OQJ6NpWnkUXdnQfFOIlC3kb22FnbxjJEM/Awc+FM=";
            var real_Result = EncryptionHelper.DecryptRSA(Encryp_Password);
            string expect_Result = "NeweggTestPwd";
            Assert.Equal(expect_Result, real_Result);
        }

        #endregion RSA

        #region AES

        [Fact]
        public void Encryp_AES()
        {
            string Password = "NeweggTestPwd";
            var real_Result = EncryptionHelper.EncryptAES(Password);
            Assert.NotNull(real_Result);
        }

        [Fact]
        public void Decryp_AES()
        {
            var Encryp_Password = "o2sgo8qfP6qR4wvQXH0Xyg==";

            var real_Result = EncryptionHelper.DecryptAES(Encryp_Password);
            string expect_Result = "NeweggTestPwd";
            Assert.Equal(expect_Result, real_Result);
        }

        #endregion AES

        #region Fence-栅栏加密

        [Fact]
        public void Encryp_Fence()
        {
            string testStr = @"ABCabc+=\&@";
            string testResult = @"Ab\Bc&C+@a=";

            string real_Result = EncryptionHelper.EncryptFence(testStr, 4);

            Assert.Equal(testResult, real_Result);
        }

        [Fact]
        public void Decryp_Fence()
        {
            string testStr = @"Ab\Bc&C+@a=";
            string testResult = @"ABCabc+=\&@";

            var real_Result = EncryptionHelper.DecryptFence(testStr, 4);

            Assert.Equal(testResult, real_Result);
        }

        [Fact]
        public void Decryp_Fence_ErrorData()
        {
            string testStr = @"ABCabc+=\&@";
            string testResult = @"Ab\Bc&C+@a=";

            string tempResult = EncryptionHelper.EncryptFence(testStr, 4);
            string real_Result = EncryptionHelper.DecryptFence(tempResult, 2);

            Assert.NotEqual(testResult, real_Result);
        }

        #endregion Fence-栅栏加密

        #region 其它方法

        public class GetNewGuidStringTest
        {
            [Fact]
            public void GuidIncludeHyphens_Ture()
            {
                string guidStr = EncryptionHelper.GetNewGuidString(isUpper: true);

                Assert.Contains("-", guidStr);
            }
        }

        #endregion 其它方法
    }
}