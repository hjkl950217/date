﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Helper
{
    public class PlatformCodeHelperTest
    {
        public class CheckPlatformCodeTest
        {
            [Theory]
            [InlineData(PlatformConst.Platform_USA, true)]
            [InlineData("usa", false)]
            [InlineData(" usa", false)]
            [InlineData("Usa", false)]
            [InlineData("", false)]
            [InlineData(null, false)]
            public void SingleData_Test(string value, bool expected)
            {
                bool result = PlatformCodeHelper.CheckPlatformCode(value);
                Assert.Equal(expected, result);
            }

            [Theory]
            [InlineData(PlatformConst.Platform_USA, PlatformConst.Platform_USB, true)]
            [InlineData(null, PlatformConst.Platform_USB, false)]
            [InlineData("", PlatformConst.Platform_USB, false)]
            [InlineData("usa", PlatformConst.Platform_USB, false)]
            [InlineData(" usa", PlatformConst.Platform_USB, false)]
            [InlineData(" Usa", PlatformConst.Platform_USB, false)]
            public void TwoData_Test(string value1, string value2, bool expected)
            {
                string[] testList = new string[] { value1, value2 };
                bool result = PlatformCodeHelper.CheckPlatformCode(testList);
                Assert.Equal(expected, result);
            }
        }
    }
}