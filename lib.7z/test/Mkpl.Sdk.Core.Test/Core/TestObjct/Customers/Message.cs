﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Message.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   Message created at  2/10/2018 6:04:46 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Sdk.Core.Test.Customers
{
    public class Message<T>
    {
        /// <summary>
        /// Message
        /// </summary>
        /// <param name="code">Code</param>
        /// <param name="errorCode"></param>
        /// <param name="description"></param>
        /// <param name="body"></param>
        public Message(string code, string errorCode, string description, T body = default(T))
        {
            this.Code = code;
            this.ErrorCode = errorCode;
            this.Description = description;
            this.Body = body;
        }

        /// <summary>
        ///
        /// </summary>
        public Message()
            : this(string.Empty, "000", string.Empty, default(T))
        {
        }

        /// <summary>
        /// 消息代码
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 錯誤代碼
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 消息描述
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 消息主体。
        /// </summary>
        public T Body { get; set; }
    }
}