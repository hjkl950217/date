﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="UIValidatorInfo.cs" company="Newegg" Author="aw78">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   UIValidatorInfo created at  2/10/2018 6:06:13 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------

namespace Mkpl.Sdk.Core.Test.Customers
{
    public class UIValidatorInfo
    {
        /// <summary>
        /// Whether show image validator.
        /// </summary>
        public bool IsShowCaptcha { get; set; }

        /// <summary>
        /// Captcha image url.
        /// </summary>
        public string CaptchaImageUrl { get; set; }

        /// <summary>
        /// Validate TransNo.
        /// </summary>
        public int ValidateTransNo { get; set; }

        /// <summary>
        /// Validate Token.
        /// </summary>
        public string ValidateToken { get; set; }
    }
}