﻿namespace Mkpl.Sdk.Core.Test
{
    public class TestEntity
    {
        public string StringValue { get; set; }
        public int IntegerValue { get; set; }
        public int? NullableIntValue { get; set; }
    }
}