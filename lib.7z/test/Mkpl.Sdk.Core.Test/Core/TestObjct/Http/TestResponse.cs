﻿namespace Mkpl.Sdk.Core.Test
{
    public class TestResponse
    {
        public bool Succeeded { get; set; }
        public TestEntity Entity { get; set; }
    }

  
}