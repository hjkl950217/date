﻿using System.Collections.Generic;

namespace Mkpl.Sdk.Core.Test.Sellers
{
    public class SellerInfo:UserInfo
    {
        public string SellerID { get; set; }
        public string SellerName { get; set; }

        /// <summary>
        /// 模拟对象类型的数据
        /// </summary>
        public UserInfo User { get; set; }

        /// <summary>
        /// 模拟集合类型的数据
        /// </summary>
        public List<UserInfo> UserList { get; set; }

        /// <summary>
        /// 这是测试json时使用的属性。
        /// 和<see cref="TestEntity.StringValue"/>相同
        /// </summary>
        public string StringValue { get; set; }
    }
}