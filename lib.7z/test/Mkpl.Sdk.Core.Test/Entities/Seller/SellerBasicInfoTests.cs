﻿using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using System;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Entities
{
    public class SellerBasicInfoTests
    {
        private static class MockHelper
        {
            public const string SellerID = "BHCT";
            public static readonly DateTime TestTime = DateTime.Now;

            public static SellerBasicInfo GetMockSellerBasicInfo()
            {
                return new SellerBasicInfo()
                {
                    SellerID = "BHCT",
                    SellerName = "张三",
                    SellerType = SellerTypeEnum.Domestic,
                    PaymentType = SellerPaymentTypeEnum.ACH,
                    PartnerID = 112,
                    IsUIHSeller = true,
                    IsSeller = true,
                    LanguageCode = "zh-CN",
                    OwnerCompanyCode = 666,
                    PlatformCode = "CHN",
                    SellerStatus = SellerStatusEnum.Inactive,
                    SellerUrlKey = "abc",
                    TestingTag = 0,
                    RegionCountryCode = "CHN",
                    CreateDate = MockHelper.TestTime,
                    SellerModel = "ISO",
                    EnableCustomerTaxExemption = true,
                    CompanyCode = 1003
                };
            }
        }

        [Fact]
        public void SimpleTest_Initialized()
        {
            // Arrange

            // Act
            var result = MockHelper.GetMockSellerBasicInfo();

            // Assert
            Assert.Equal(MockHelper.SellerID, result.SellerID);
            Assert.Equal("张三", result.SellerName);
            Assert.Equal(SellerTypeEnum.Domestic, result.SellerType);
            Assert.Equal(SellerPaymentTypeEnum.ACH, result.PaymentType);
            Assert.Equal(112, result.PartnerID);
            Assert.True(result.IsUIHSeller);
            Assert.True(result.IsSeller);
            Assert.Equal("zh-CN", result.LanguageCode);
            Assert.Equal(666, result.OwnerCompanyCode);
            Assert.Equal("CHN", result.PlatformCode);
            Assert.Equal(SellerStatusEnum.Inactive, result.SellerStatus);
            Assert.Equal("abc", result.SellerUrlKey);
            Assert.Equal(0, result.TestingTag);
            Assert.Equal("CHN", result.RegionCountryCode);
            Assert.Equal(MockHelper.TestTime, result.CreateDate);
            Assert.Equal("ISO", result.SellerModel);
            Assert.True(result.EnableCustomerTaxExemption);
            Assert.Equal(1003, result.CompanyCode);
        }
    }
}