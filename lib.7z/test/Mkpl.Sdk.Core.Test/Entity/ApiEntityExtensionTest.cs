﻿using Mkpl.Sdk.Core.Entities;
using Xunit;

namespace Mkpl.Sdk.Core.Test
{
    public class ApiEntityExtensionTest
    {
        #region 复刻固定数据

        private static class MockHelp
        {
            public static ApiEntity GetMockApiEntity()
            {
                ApiEntity apiEntity = new ApiEntity();

                apiEntity.Address = "/A";
                apiEntity.Host = "http://127.0.0.1";

                return apiEntity;
            }
        }

        #endregion 复刻固定数据

        #region GetAbsoluteURL方法

        [Trait("Entity", "ApiEntity")]
        public class GetAbsoluteUrlTest
        {
            [Fact(DisplayName = "ApiEntity-GetAbsoluteURL-Qurery")]
            public void TC_GetAbsoluteURL_Qurery()
            {
                ApiEntity apiEntity = MockHelp.GetMockApiEntity();
                apiEntity.Address = "/A?AAA={0}&bbb={1}";

                string url = apiEntity.GetAbsoluteURL(123, "DDDD");

                Assert.Equal($"{apiEntity.Host}/A?AAA=123&bbb=DDDD", url);
            }

            [Fact(DisplayName = "ApiEntity-GetAbsoluteURL-NoQurery")]
            public void TC_GetAbsoluteURL_NoQurery()
            {
                ApiEntity apiEntity = MockHelp.GetMockApiEntity();

                string url = apiEntity.GetAbsoluteURL();

                Assert.Equal($"{apiEntity.Host}{apiEntity.Address}", url);
            }
        }

        #endregion GetAbsoluteURL方法
    }
}