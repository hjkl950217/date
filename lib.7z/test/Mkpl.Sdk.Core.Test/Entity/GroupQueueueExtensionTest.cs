﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GroupqueueExtensionTest.cs" company="Newegg" Author="lw47">
//   Copyright (c) 2018 Newegg.inc. All rights reserved.
// </copyright>
// <summary>
//   GroupqueueExtensionTest created at  5/15/2018 2:30:57 PM
// </summary>
//<Description>
//
//</Description>
// --------------------------------------------------------------------------------------------------------------------
//向星辰大海前进！

using Mkpl.Sdk.Core.Entities;
using System;
using System.Collections.Generic;
using Xunit;
using Xunit.Abstractions;

namespace Mkpl.Sdk.Core.Test
{
    public class GroupQueueueTest
    {
        #region 复刻固定数据

        private static class MockHelp
        {
            public static GroupQueue GetMockGroupQueue()
            {
                GroupQueue result = new GroupQueue()
                {
                    DefaultPassword = "123",
                    GoupName = "Test",
                };

                result.Queues = new List<Queue>()
                {
                    new Queue()
                    {
                        KeyName="A",
                        QueueName="A"
                    },
                    new Queue()
                    {
                        KeyName="B",
                        QueueName="B",
                        Password="BVB"
                    }
                };

                return result;
            }
        }

        #endregion 复刻固定数据

        #region FindQueue

        [Trait("Entity", " GroupQueue")]
        public class GroupQueueExtensionTest
        {
            /// <summary>
            /// 测试中输出信息对象
            /// </summary>
            private readonly ITestOutputHelper m_Output;

            public GroupQueueExtensionTest(ITestOutputHelper output)
            {
                //给接口注册模拟实例
                this.m_Output = output;
            }

            [Fact(DisplayName = "FindQueue-Exception")]
            public void TC_FindQueue_Exception()
            {
                GroupQueue groupQueue = MockHelp.GetMockGroupQueue();

                //执行
                var ex = Assert.Throws<InvalidOperationException>(() =>
                  {
                      groupQueue.FindQueue("D");
                  });

                //验证
                Assert.Contains("Queue Config is not found", ex.Message);
            }

            [Fact(DisplayName = "FindQueue-Pwd")]
            public void TC_FindQueue_Pwd()
            {
                GroupQueue groupQueue = MockHelp.GetMockGroupQueue();

                //执行

                Queue queue = groupQueue.FindQueue("B");

                //验证
                Assert.NotEmpty(queue.Password);
                Assert.Equal("BVB", queue.Password);
            }
        }

        #endregion FindQueue
    }
}