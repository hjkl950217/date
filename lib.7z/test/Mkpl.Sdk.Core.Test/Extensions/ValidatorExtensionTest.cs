﻿using FluentValidation;
using FluentValidation.Results;
using Mkpl.Sdk.Core.Test.Sellers;

using Xunit;

namespace Mkpl.Sdk.Core.Test.Extensions
{
    public class ValidatorExtensionTest
    {
        #region Test_Validator

        internal class TestSeller_SellerID_Validator : AbstractValidator<SellerInfo>
        {
            public TestSeller_SellerID_Validator()
            {
                base.RuleFor(t => t.SellerID)
                    .CheckSellerID();
            }
        }

        internal class TestSeller_UserID_Validator : AbstractValidator<SellerInfo>
        {
            public TestSeller_UserID_Validator()
            {
                base.RuleFor(t => t.UserID)
                    .Required();
            }
        }

        #endregion Test_Validator

        #region CheckSellerID

        [Trait("Extend", "Validator")]
        public class CheckSellerIDTest
        {
            [Fact]
            public void SellerId_Null()
            {
                SellerInfo testSeller = new SellerInfo();

                ValidationResult result = new TestSeller_SellerID_Validator()
                    .Validate(testSeller);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void SellerId_Empty()
            {
                SellerInfo testSeller = new SellerInfo() { SellerID = string.Empty };

                ValidationResult result = new TestSeller_SellerID_Validator()
                    .Validate(testSeller);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void SellerId_Length()
            {
                SellerInfo testSeller = new SellerInfo() { SellerID = "bd" };

                ValidationResult result = new TestSeller_SellerID_Validator()
                    .Validate(testSeller);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void SellerId_NoTrim()
            {
                SellerInfo testSeller = new SellerInfo() { SellerID = " bhd6 " };

                ValidationResult result = new TestSeller_SellerID_Validator()
                    .Validate(testSeller);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void SellerId_True()
            {
                SellerInfo testSeller = new SellerInfo() { SellerID = "BHD6" };

                ValidationResult result = new TestSeller_SellerID_Validator()
                    .Validate(testSeller);

                Assert.True(result.IsValid);
            }
        }

        #endregion CheckSellerID

        #region Required_Int

        public class Required_Int_Test
        {
            [Fact]
            public void Required_Int_Zero()
            {
                SellerInfo testSeller = new SellerInfo() { UserID = 0 };

                ValidationResult result = new TestSeller_UserID_Validator()
                    .Validate(testSeller);

                Assert.False(result.IsValid);
            }

            [Fact]
            public void Required_Int_Two()
            {
                SellerInfo testSeller = new SellerInfo() { UserID = 2 };

                ValidationResult result = new TestSeller_UserID_Validator()
                    .Validate(testSeller);

                Assert.True(result.IsValid);
            }
        }

        #endregion Required_Int
    }
}