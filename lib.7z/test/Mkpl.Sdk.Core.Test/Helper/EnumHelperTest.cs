﻿using Mkpl.Sdk.Core.Entities.Attribute;
using Mkpl.Sdk.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Helper
{
    public class EnumHelperTest
    {
        #region 测试枚举

        protected enum TestEnumByte : byte
        {
            MPTL = 0x11
        }

        protected enum TestEnumInt 
        {
            MPTL
        }

        protected enum TestEnumNull
        {
        }

        protected enum TestEnumAttr
        {
            [EnumDescription(ShowValue: "MKTPLS", DbValue: "M", Description: "MPS组")]
            MPTL
        }

        public class TestAttribute : FlagsAttribute
        { }

        protected enum TestEnumMps
        {
            [EnumDescription(ShowValue: "MKTPLS", DbValue: "M", Description: "MPS组")]
            AllValue,

            [EnumDescription(ShowValue: null, DbValue: null, Description: null)]
            AllNull,

            [EnumDescription(ShowValue: null, DbValue: "M", Description: "MPS组")]
            ShowValueNull,

            [EnumDescription(ShowValue: "MKTPLS", DbValue: null, Description: "MPS组")]
            DBValue,

            [EnumDescription(ShowValue: "MKTPLS", DbValue: "M", Description: null)]
            DescriptionNull,

            NoAttribute,
        }

        #endregion 测试枚举

        [Trait("Helper", "EnumHelper")]
        public class GetEnumStructTest
        {
            [Fact]
            public void TC_GetStruct_Value()
            {
                IDictionary<string, byte> result = EnumHelper.GetEnumStruct<TestEnumByte, byte>();

                Assert.NotNull(result);
                Assert.Equal(TestEnumByte.MPTL.ToString(), result.First().Key);
                Assert.IsType<byte>(result.First().Value);
                Assert.Equal(17, result.First().Value);
            }

            [Fact]
            public void TC_GetStruct_Value_String()
            {
                IDictionary<string, string> result = EnumHelper.GetEnumStruct<TestEnumByte>();

                Assert.NotNull(result);
                Assert.Equal(TestEnumByte.MPTL.ToString(), result.First().Key);
                Assert.IsType<string>(result.First().Value);
                Assert.Equal($"{0x11}", result.First().Value);
            }

            [Fact]
            public void TC_GetStruct_Value_Exception()
            {
                var result = Assert.Throws<InvalidCastException>(() =>
                {
                    EnumHelper.GetEnumStruct<TestEnumByte, char>();
                });

                Assert.NotNull(result);
                Assert.NotNull(result.InnerException);
                Assert.Contains("获取枚举结构时，枚举值的类型传递错误。", result.Message);
                Assert.Contains("枚举名:TestEnumByte", result.Message);
            }

            [Fact]
            public void TC_GetStruct_String()
            {
                IDictionary<string, string> result = EnumHelper.GetEnumStruct<TestEnumByte>();

                Assert.NotNull(result);
                Assert.Equal(TestEnumByte.MPTL.ToString(), result.First().Key);
                Assert.IsType<string>(result.First().Value);
                Assert.Equal("17", result.First().Value);
            }
        }

        [Trait("Helper", "EnumHelper")]
        public class GetAttributeTest
        {
            [Fact]
            public void Tc_GetAttribute()
            {
                EnumDescriptionAttribute result = TestEnumAttr.MPTL
                    .GetAttribute(typeof(TestEnumAttr))
                    as EnumDescriptionAttribute;

                Assert.NotNull(result);
                Assert.Equal("MKTPLS", result.ShowValue);
                Assert.Equal("M", result.DBValue);
                Assert.Equal("MPS组", result.Description);
            }

            [Fact]
            public void Tc_GetAttribute_Null()
            {
                Attribute result = TestEnumAttr.MPTL
                      .GetAttribute(typeof(TestAttribute));

                Assert.Null(result);
            }

            [Fact]
            public void Tc_GetAttribute_Generic()
            {
                EnumDescriptionAttribute result = TestEnumAttr.MPTL
                    .GetAttribute<EnumDescriptionAttribute>();

                Assert.NotNull(result);
                Assert.Equal("MKTPLS", result.ShowValue);
                Assert.Equal("M", result.DBValue);
                Assert.Equal("MPS组", result.Description);
            }

            [Fact]
            public void Tc_GetAttribute_Generic_Null()
            {
                TestAttribute result = TestEnumAttr.MPTL
                    .GetAttribute<TestAttribute>();

                Assert.Null(result);
            }
        }

        /// <summary>
        /// 获取针对MPS制作的3个方法
        /// </summary>
        [Trait("Helper", "EnumHelper")]
        public class GetMpsData
        {
            [Fact]
            public void Tc_GetShowValue()
            {
                string result = TestEnumMps.AllValue.GetShowValue();

                Assert.NotNull(result);
                Assert.NotEmpty(result);
            }

            [Fact]
            public void Tc_GetShowValue_Null()
            {
                string result = TestEnumMps.ShowValueNull.GetShowValue();

                Assert.Null(result);
            }

            [Fact]
            public void Tc_GetDBValue()
            {
                string result = TestEnumMps.AllValue.GetDBValue();

                Assert.NotNull(result);
                Assert.NotEmpty(result);
            }

            [Fact]
            public void Tc_GetDBValue_Null()
            {
                string result = TestEnumMps.DBValue.GetDBValue();

                Assert.Null(result);
            }

            [Fact]
            public void Tc_GetDescription()
            {
                string result = TestEnumMps.AllValue.GetDescription();

                Assert.NotNull(result);
                Assert.NotEmpty(result);
            }

            [Fact]
            public void Tc_GetDescription_Null()
            {
                string result = TestEnumMps.DescriptionNull.GetDescription();

                Assert.Null(result);
            }

            //测试所有-有值
            [Fact]
            public void Tc_GetMpsData_All_NoNull()
            {
                string showValue = TestEnumMps.AllValue.GetShowValue();
                string dbValue = TestEnumMps.AllValue.GetDBValue();
                string descriptionValue = TestEnumMps.AllValue.GetDescription();

                Assert.NotNull(showValue);
                Assert.NotEmpty(showValue);

                Assert.NotNull(dbValue);
                Assert.NotEmpty(dbValue);

                Assert.NotNull(descriptionValue);
                Assert.NotEmpty(descriptionValue);
            }

            //测试所有-空值
            [Fact]
            public void Tc_GetMpsData_All_Null()
            {
                string showValue = TestEnumMps.AllNull.GetShowValue();
                string dbValue = TestEnumMps.AllNull.GetDBValue();
                string descriptionValue = TestEnumMps.AllNull.GetDescription();

                Assert.Null(showValue);
                Assert.Null(dbValue);
                Assert.Null(descriptionValue);
            }
        }
    }
}