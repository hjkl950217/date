﻿using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Helpers;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Helper
{
    public class EnvHelperTest
    {
        public static class MockHepler
        {
            public const string TestEnv = "TestEnv";

            /// <summary>
            /// 初始化环境
            /// </summary>
            public static void InitAppEnv(string envValue = ApplicationEnvConst.Development)
            {
                System.Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "");
                System.Environment.SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", envValue);
            }
        }

        /// <summary>
        /// 下面都是以测试用例的方式，所以用一个类包起来
        /// </summary>
        [Trait("Helper", "EnvHelper")]
        public class MultipleTest
        {
            [Theory]
            [InlineData(ApplicationEnvConst.PRE, true)]
            [InlineData("Other", true)]
            [InlineData(ApplicationEnvConst.Development, false)]
            [InlineData(ApplicationEnvConst.GQC, false)]
            [InlineData(ApplicationEnvConst.GDEV, false)]
            public void IsPreOrPrdTest(string actualEnv, bool expectResult)
            {
                MockHepler.InitAppEnv(actualEnv);
                bool result = EnvHelper.IsPreOrPrd();
                Assert.Equal(expectResult, result);
            }

            [Theory]
            [InlineData("Other", true)]
            [InlineData(ApplicationEnvConst.PRE, false)]
            [InlineData(ApplicationEnvConst.Development, false)]
            [InlineData(ApplicationEnvConst.GQC, false)]
            [InlineData(ApplicationEnvConst.GDEV, false)]
            public void IsPrdTest(string actualEnv, bool expectResult)
            {
                MockHepler.InitAppEnv(actualEnv);
                bool result = EnvHelper.IsPrd();
                Assert.Equal(expectResult, result);
            }

            [Theory]
            [InlineData(ApplicationEnvConst.GDEV, true)]
            [InlineData(ApplicationEnvConst.Development, true)]
            [InlineData("Other", false)]
            [InlineData(ApplicationEnvConst.PRE, false)]
            [InlineData(ApplicationEnvConst.GQC, false)]
            public void IsGdevTest(string actualEnv, bool expectResult)
            {
                MockHepler.InitAppEnv(actualEnv);
                bool result = EnvHelper.IsDev();
                Assert.Equal(expectResult, result);
            }

            [Theory]
            [InlineData(ApplicationEnvConst.GQC, true)]
            [InlineData(ApplicationEnvConst.GDEV, false)]
            [InlineData(ApplicationEnvConst.Development, false)]
            [InlineData("Other", false)]
            [InlineData(ApplicationEnvConst.PRE, false)]
            public void IsGqcTest(string actualEnv, bool expectResult)
            {
                MockHepler.InitAppEnv(actualEnv);
                bool result = EnvHelper.IsGqc();
                Assert.Equal(expectResult, result);
            }

            [Theory]
            [InlineData(ApplicationEnvConst.GQC, "gqc")]
            [InlineData(ApplicationEnvConst.GQC, "Gqc")]
            [InlineData(ApplicationEnvConst.GQC, "gqc ")]
            [InlineData(ApplicationEnvConst.GQC, " gqc ")]
            [InlineData(ApplicationEnvConst.GQC, "GqC")]
            [InlineData(ApplicationEnvConst.GQC, "GQC")]
            public void GetRunEnvTest(string expectEnv, string actualEnv)
            {
                MockHepler.InitAppEnv(actualEnv);
                string result = EnvHelper.GetRunEnv();
                Assert.Equal(expectEnv, result.Trim().ToUpper());
            }

            [Theory]
            [InlineData("", null)]
            [InlineData("", "")]
            [InlineData("1", "1")]
            public void GetVariableFromEnvTest(string expectEnv, string actualEnv)
            {
                System.Environment.SetEnvironmentVariable(MockHepler.TestEnv, actualEnv);

                string result = EnvHelper.GetVariableFromEnv(MockHepler.TestEnv);
                Assert.Equal(expectEnv, result);
            }
        }
    }
}