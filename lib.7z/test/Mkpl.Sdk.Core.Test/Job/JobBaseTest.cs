﻿using System;
using System.Threading.Tasks;
using Xunit;

namespace Mkpl.Sdk.Core.Job.Test
{
    public class JobBaseTest
    {
        /// <summary>
        /// 测试job同步方法与异步方法的调用
        ///
        /// 如果继承了异步方法，就不应该执行同步方法
        /// </summary>
        public class JobExecuteAsyncTest
        {
            private static bool isSyncRun = false;
            private static bool isAsyncRun = false;

            private class AJob : JobBase
            {
                public override void Execute()
                {
                    JobExecuteAsyncTest.isSyncRun = true;
                }
            }

            private class BJob : JobBase
            {
                public override Task ExecuteAsync()
                {
                    JobExecuteAsyncTest.isAsyncRun = true;
                    return Task.CompletedTask;
                }
            }

            private class CJob : JobBase { }

            [Fact]
            public void Job_Sync()
            {
                JobExecuteAsyncTest.isSyncRun = false;

                JobBase job = new AJob();
                job.Execute();

                Assert.True(JobExecuteAsyncTest.isSyncRun);
            }

            [Fact]
            public void Job_Async()
            {
                JobExecuteAsyncTest.isSyncRun = false;
                JobExecuteAsyncTest.isAsyncRun = false;

                JobBase job = new BJob();
                job.Execute();

                Assert.False(JobExecuteAsyncTest.isSyncRun);
                Assert.True(JobExecuteAsyncTest.isAsyncRun);
            }

            [Fact]
            public void Job_NoInherit_No()
            {
                Exception ex = Record.Exception(() =>
                 {
                     JobBase job = new CJob();
                     job.Execute();
                 });
                Assert.Null(ex);

                
            }
        }
    }
}