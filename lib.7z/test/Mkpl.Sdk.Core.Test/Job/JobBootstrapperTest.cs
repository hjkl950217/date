﻿using System.IO;
using Xunit;

namespace Mkpl.Sdk.Core.Job.Test
{
    public class JobBootstrapperTest
    {
        [Fact]
        public void RunShouldNoError()
        {
            new JobBootstrapper("Job_d")
                .Run(args: new string[]
                {
                    "AJob",
                    "--env",
                    "gdev",
                    "--db",
                    Path.Combine(Directory.GetCurrentDirectory(),
                    "Job","testdb")
                },
                this.GetType().Assembly);
        }
    }
}