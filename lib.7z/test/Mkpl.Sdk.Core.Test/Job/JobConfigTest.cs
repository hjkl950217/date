﻿using Xunit;

namespace Mkpl.Sdk.Core.Job.Test
{
    public class JobConfigTest
    {
        private readonly JobConfig jobConfig;

        public JobConfigTest()
        {
            this.jobConfig = new JobConfig();
        }

        [Fact]
        public void BlockSellerListXML()
        {
            this.jobConfig.BlockSellerList = new string[] { "a", "c" };
            Assert.Equal(
                "<BlockSellerList>  <BlockSeller>A</BlockSeller>  <BlockSeller>C</BlockSeller></BlockSellerList>",
                this.jobConfig.BlockSellerListXML.ReplaceLine());
        }

        [Fact]
        public void SpecialSellerListXML()
        {
            this.jobConfig.SpecialSellerList = new string[] { "a", "c" };
            Assert.Equal("<SpecialSellerList>  <SpecialSeller>A</SpecialSeller>  <SpecialSeller>C</SpecialSeller></SpecialSellerList>", this.jobConfig.SpecialSellerListXML.ReplaceLine());
        }

        [Fact]
        public void BlockUserListXML()
        {
            this.jobConfig.BlockUserList = new string[] { "a", "c" };
            Assert.Equal("<BlockUserList>  <BlockUser>A</BlockUser>  <BlockUser>C</BlockUser></BlockUserList>", this.jobConfig.BlockUserListXML.ReplaceLine());
        }

        [Fact]
        public void SpecialUserList()
        {
            this.jobConfig.SpecialUserList = new string[] { "a", "c" };
            Assert.Equal("<SpecialUserList>  <SpecialUser>A</SpecialUser>  <SpecialUser>C</SpecialUser></SpecialUserList>", this.jobConfig.SpecialUserListXML.ReplaceLine());
        }
    }
}