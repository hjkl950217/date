﻿namespace Mkpl.Sdk.Core.Job.Test
{
    public static class UTStringExtensions
    {
        /// <summary>
        /// 去掉换行符
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReplaceLine(this string str)
        {
            return str?.Replace("\r", "")?.Replace("\n", "");
        }
    }
}