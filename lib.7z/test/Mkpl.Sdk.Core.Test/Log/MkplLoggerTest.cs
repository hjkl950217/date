﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Mkpl.Sdk.Core.Log;
using Moq;
using Newegg.MIS.Baymax.Log;
using System.Collections.Generic;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Log
{
    public class MkplLoggerTest
    {
        private (Mock<ILog>, Mock<IHttpContextAccessor>, ILogger, List<LogEntry>) CreateMkplLogger()
        {
            var log = new Mock<ILog>();
            var contextAccessor = new Mock<IHttpContextAccessor>();
            var provider = new MkplLoggerProvider(log.Object, contextAccessor.Object, (s, i) => true);
            provider.Dispose();
            var logger = provider.CreateLogger("go");
            var logs = new List<LogEntry>();
            log.Setup(i => i.WriteLog(It.IsAny<LogEntry>()))
                .Callback((LogEntry data) => logs.Add(data));
            return (log, contextAccessor, logger, logs);
        }

        [Fact]
        public void WhenNoHttpContextShouldNoTraceInfo()
        {
            var (log, contextAccessor, logger, logs) = CreateMkplLogger();
            logger.BeginScope("t");
            Assert.True(logger.IsEnabled(LogLevel.Critical));
            logger.Log(LogLevel.Critical, "test");
            Assert.NotEmpty(logs);
            Assert.StartsWith("go", logs[0].Content);
        }

        [Fact]
        public void WhenHasHttpContextShouldHasTraceInfo()
        {
            var (log, contextAccessor, logger, logs) = CreateMkplLogger();
            var context = new Mock<HttpContext>();
            contextAccessor.SetupGet(i => i.HttpContext).Returns(context.Object);
            var request = new Mock<HttpRequest>();
            context.SetupGet(i => i.Request).Returns(request.Object);
            var header = new Mock<IHeaderDictionary>();
            request.SetupGet(i => i.Headers).Returns(header.Object);
            var str = It.IsAny<StringValues>();
            header.Setup(i => i.TryGetValue("x-gateway-tid", out str)).Returns(true);
            header.Setup(i => i.TryGetValue("client-profile-key", out str)).Returns(true);

            logger.Log(LogLevel.Critical, "test");
            Assert.NotEmpty(logs);
            Assert.Contains("client-profile-key", logs[0].Content);
            Assert.Contains("x-gateway-tid", logs[0].Content);
        }
    }
}