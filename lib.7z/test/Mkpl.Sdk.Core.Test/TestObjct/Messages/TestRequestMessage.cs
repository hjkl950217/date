﻿namespace Mkpl.Sdk.Core.Test.Messages
{
    public class TestRequestMessage
    {
        public string Body { get; set; }
    }
}