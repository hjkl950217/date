﻿using System.Xml.Serialization;

namespace Mkpl.Sdk.Core.Test.Sellers
{
    /// <summary>
    /// 此对象仅做为UT使用
    /// </summary>
    [XmlRoot("UserInfo")]
    public class UserInfo
    {
        /// <summary>
        /// 模拟Int类型的数据
        /// </summary>
        public int UserID { get; set; }
        public string UserName { get; set; }
    }
}