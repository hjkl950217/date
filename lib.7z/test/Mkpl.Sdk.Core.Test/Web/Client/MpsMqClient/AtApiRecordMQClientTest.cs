﻿using AutoFixture;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Newegg.MIS.Baymax.MQ;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Mkpl.Sdk.Core.Web.Test.Client.MpsMqClient
{
    public class AtApiRecordMQClientTest
    {
        protected static class MockHelper
        {
            public static Fixture fixture = new Fixture();

            public static GroupQueue GetMockGroupQueue()
            {
                GroupQueue result = new GroupQueue()
                {
                    DefaultPassword = "123",
                    GoupName = QueueGoupNameConst.Team_MKPL,
                };

                result.Queues = new List<Queue>()
                {
                    new Queue()
                    {
                        KeyName="A",
                        QueueName="A"
                    },
                    new Queue()
                    {
                        KeyName="B",
                        QueueName="B",
                        Password="BVB"
                    }
                };

                return result;
            }

            public static (IHttpContextAccessor httpContextAccessor, HttpContext httpContext, IHeaderDictionary responseHeaders) GetMockHttpObjests(Dictionary<string, List<string>> autoObjInfo = null)
            {
                IHttpContextAccessor httpContextAccessor = Substitute.For<IHttpContextAccessor>();
                HttpContext httpContext = Substitute.For<HttpContext>();
                HttpResponse httpResponse = Substitute.For<HttpResponse>();
                IHeaderDictionary responseHeaders = Substitute.For<IHeaderDictionary>();

                _ = httpContextAccessor.HttpContext.Returns(httpContext);
                _ = httpContext.Response.Returns(httpResponse);
                _ = httpResponse.Headers.Returns(responseHeaders);

                autoObjInfo = autoObjInfo ?? new Dictionary<string, List<string>>();
                StringValues autoInfo = autoObjInfo.ToJsonExt();
                _ = responseHeaders[AtApiRecordMQClient.MqRecordHeaderName]
                    .Returns(autoInfo);

                return (httpContextAccessor, httpContext, responseHeaders);
            }

            public static (
                AtApiRecordMQClient mqClient,
                MQConfig mqConfig,
                IMessagePublisher messagePublisher)
                GetMockMQClientObjects(
                IHttpContextAccessor httpContextAccessor,
                PublishResultInfo publishResultInfo = null)
            {
                publishResultInfo = publishResultInfo ?? MockHelper.GetMockPublishResultInfo();

                MQConfig mqConfig = new MQConfig()
                {
                    GroupQueues = new List<GroupQueue>()
                    {
                        MockHelper.GetMockGroupQueue()
                    }
                };

                IMessagePublisher messagePublisher = Substitute.For<IMessagePublisher>();
                AtApiRecordMQClient mqClient = new AtApiRecordMQClient(mqConfig, messagePublisher, httpContextAccessor);

                messagePublisher.SendMessage(
                   request: Arg.Any<object>(),
                   messageName: Arg.Any<string>(),
                   password: Arg.Any<string>(),
                   contentType: MessageContentType.Json,
                   headers: Arg.Any<List<KeyValuePair<string, string>>>(),
                   callbackUri: Arg.Any<string>(),
                   subscribers: Arg.Any<List<string>>(),
                   noSerialize: Arg.Any<bool>()
                   )
                    .Returns(publishResultInfo);

                messagePublisher.SendMessageAsync(
                   request: Arg.Any<object>(),
                   messageName: Arg.Any<string>(),
                   password: Arg.Any<string>(),
                   contentType: MessageContentType.Json,
                   headers: Arg.Any<List<KeyValuePair<string, string>>>(),
                   callbackUri: Arg.Any<string>(),
                   subscribers: Arg.Any<List<string>>(),
                   noSerialize: Arg.Any<bool>()
                   )
                    .Returns(Task.FromResult(publishResultInfo));

                return (mqClient, mqConfig, messagePublisher);
            }

            public static PublishResultInfo GetMockPublishResultInfo()
            {
                PublishResultInfo publishResultInfo = MockHelper.fixture.Create<PublishResultInfo>();

                return publishResultInfo;
            }
        }

        public class ConstructorTest
        {
            [Fact]
            public void Run_NoError()
            {
                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                _ = new AtApiRecordMQClient(mockObj.mqConfig, mockObj.messagePublisher, mockHttpObj.httpContextAccessor);
            }

            [Fact]
            public void WhenMQConfigIsNull_WithException()
            {
                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    _ = new AtApiRecordMQClient(null, mockObj.messagePublisher, mockHttpObj.httpContextAccessor);
                });

                Assert.NotNull(ex);
            }

            [Fact]
            public void WhenMessagePublisherIsNull_WithException()
            {
                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    _ = new AtApiRecordMQClient(mockObj.mqConfig, null, mockHttpObj.httpContextAccessor);
                });

                Assert.NotNull(ex);
            }

            [Fact]
            public void WhenHttpContextAccessorIsNull_WithException()
            {
                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                var ex = Assert.Throws<ArgumentNullException>(() =>
                {
                    _ = new AtApiRecordMQClient(mockObj.mqConfig, mockObj.messagePublisher, null);
                });

                Assert.NotNull(ex);
            }
        }

        public class AddOrUpdateMqRecordInfoTest
        {
            [Fact]
            public void Run_NoError()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                _ = mockObj.mqClient.SendMessage(new object(), "A", mQHeaderV2);
            }

            [Fact]
            public async Task Run_NoErrorAsync()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                _ = await mockObj.mqClient.SendMessageAsync(new object(), "A", mQHeaderV2);
            }

            [Fact]
            public void Add_NewMqId_NoError()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                var mockHttpObj = MockHelper.GetMockHttpObjests();
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                _ = mockObj.mqClient.SendMessage(new object(), "A", mQHeaderV2);

                //检查
                _ = mockHttpObj.
                    responseHeaders.Received()[AtApiRecordMQClient.MqRecordHeaderName];
            }

            [Fact]
            public void Add_AppendMqId_NoError()
            {
                MQHeaderV2 mQHeaderV2 = new MQHeaderV2(TeamNameEnum.Item, "test");

                Dictionary<string, List<string>> autoObjInfo = new Dictionary<string, List<string>>()
                {
                    { "123", new List<string>() { "a1" } }
                };

                var mockHttpObj = MockHelper.GetMockHttpObjests(autoObjInfo);
                var mockObj = MockHelper.GetMockMQClientObjects(mockHttpObj.httpContextAccessor);

                _ = mockObj.mqClient.SendMessage(new object(), "A", mQHeaderV2);

                //检查
                _ = mockHttpObj.
                   responseHeaders.Received()[AtApiRecordMQClient.MqRecordHeaderName] =
                   Arg.Is<StringValues>(t => t.ToString().Contains("123")
                        && t.ToString().Contains("a1")
                        && t.ToString().Contains("A"));
            }
        }
    }
}