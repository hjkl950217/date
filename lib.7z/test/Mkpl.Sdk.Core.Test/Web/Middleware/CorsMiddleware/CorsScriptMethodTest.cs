﻿using Mkpl.Sdk.Core.Middleware.CorsMiddleware;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Web.Test
{
    public class CorsScriptMethodTest
    {
        [Trait("CorsMiddleware", nameof(CorsScriptMethod))]
        public class BuildAllowOriginListTest
        {
            [Fact]
            public void BuildAllowOriginList_Default()
            {
                string[] result = new CorsScriptMethod().BuildAllowOriginList();

                Assert.NotNull(result);
                Assert.Equal(4, result.Length);

                Assert.Equal("newegg.org", result.FirstOrDefault(t => t == "newegg.org"));
                Assert.Equal("newegg.com", result.FirstOrDefault(t => t == "newegg.com"));
                Assert.Equal("newegg.cn", result.FirstOrDefault(t => t == "newegg.cn"));
                Assert.Equal("localhost", result.FirstOrDefault(t => t == "localhost"));
            }

            [Fact]
            public void BuildAllowOriginList_AddAction()
            {
                void testAction(List<string> t) => t.Add("123");

                string[] result = new CorsScriptMethod().BuildAllowOriginList(testAction);

                Assert.NotNull(result);
                Assert.Equal(5, result.Length);

                Assert.Equal("123", result.FirstOrDefault(t => t == "123"));
            }

            [Fact]
            public void BuildAllowOriginList_AddOther()
            {
                string[] result = new CorsScriptMethod().BuildAllowOriginList(null, new string[] { "222" });

                Assert.NotNull(result);
                Assert.Equal(5, result.Length);
                Assert.Equal("222", result.FirstOrDefault(t => t == "222"));
            }

            [Fact]
            public void BuildAllowOriginList_AddAction_AddOther()
            {
                void testAction(List<string> t) => t.Add("AAA");

                string[] result = new CorsScriptMethod()
                    .BuildAllowOriginList(testAction, new string[] { "222" });

                Assert.NotNull(result);
                Assert.Equal(6, result.Length);
                Assert.Equal("AAA", result.FirstOrDefault(t => t == "AAA"));
                Assert.Equal("222", result.FirstOrDefault(t => t == "222"));
            }

            [Fact]
            public void BuildAllowOriginList_Distinct()
            {
                void testAction(List<string> t) => t.AddRange(new string[] { "222", "AAA" });

                string[] testArry = new string[] { "222" };

                string[] result = new CorsScriptMethod()
                    .BuildAllowOriginList(testAction, testArry);

                Assert.NotNull(result);
                Assert.Equal(6, result.Length);
                Assert.Equal("AAA", result.FirstOrDefault(t => t == "AAA"));
                Assert.Equal("222", result.FirstOrDefault(t => t == "222"));
            }
        }
    }
}