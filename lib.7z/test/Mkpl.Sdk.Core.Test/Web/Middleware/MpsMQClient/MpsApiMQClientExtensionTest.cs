﻿using Microsoft.Extensions.DependencyInjection;
using Mkpl.Sdk.Core.Client;
using Mkpl.Sdk.Core.Entities.ConstOrEnum;
using Mkpl.Sdk.Core.Env;
using Mkpl.Sdk.Core.Env.Handlers;
using System;
using System.Linq;
using Xunit;

namespace Mkpl.Sdk.Core.Web.Test.Middleware.MpsMQClient
{
    public class MpsApiMQClientExtensionTest
    {
        public Func<ServiceDescriptor, bool> juadgeMQClient = t => t.ServiceType == typeof(IMQClient);

        [Fact]
        public void ServiceCollectionIsNull_WithExption()
        {
            IServiceCollection services = null;

            var ex = Assert.Throws<ArgumentNullException>(() =>
            {
                services.AddMpsMQClientMPS();
            });

            Assert.NotNull(ex);
        }

        [Fact]
        public void EnableAutoMqClient_IsEnable()
        {
            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "true");
            IServiceCollection services = new ServiceCollection();
            var info = new EnvironmentInfo();
            info.Init(new EnvironmentVariableSource(), new AutoTestHandler());
            services.AddMpsMQClientMPS(info);

            Assert.Equal(typeof(AtApiRecordMQClient), services.First(this.juadgeMQClient).ImplementationType);
            Assert.Equal(1, services.Count(this.juadgeMQClient));

            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "false");
        }

        [Fact]
        public void EnableAutoMqClient_Disable()
        {
            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "false");
            IServiceCollection services = new ServiceCollection();

            var info = new EnvironmentInfo();
            info.Init(new EnvironmentVariableSource(), new AutoTestHandler());
            services.AddMpsMQClientMPS(info);

            Assert.Equal(typeof(MQClient), services.First(this.juadgeMQClient).ImplementationType);
            Assert.Equal(1, services.Count(this.juadgeMQClient));

            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "false");
        }

        //多次注册
        [Fact]
        public void MultipleRegistrations_WithSingleton()
        {
            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "true");
            IServiceCollection services = new ServiceCollection();

            var info = new EnvironmentInfo();
            info.Init(new EnvironmentVariableSource(), new AutoTestHandler());
            services.AddMpsMQClientMPS(info);
            services.AddMpsMQClientMPS(info);
            services.AddMpsMQClientMPS(info);

            Assert.Equal(typeof(AtApiRecordMQClient), services.First(this.juadgeMQClient).ImplementationType);
            Assert.Equal(1, services.Count(this.juadgeMQClient));

            Environment.SetEnvironmentVariable(EnvironmentNames.IsAutoTest, "false");
        }
    }
}