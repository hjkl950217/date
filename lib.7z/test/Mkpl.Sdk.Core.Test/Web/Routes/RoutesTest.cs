﻿using Mkpl.Sdk.Core.Web.Routes;
using Xunit;

namespace Mkpl.Sdk.Core.Test.Web.Routes
{
    public class RoutesTest
    {
        [Fact]
        public void InternalRouteShouldAddMKPLNPrefix()
        {
            var route = new InternalRouteAttribute("test");
            Assert.Equal("mkpl/n/test", route.Template);
        }

        [Fact]
        public void ExternalRouteShouldAddExternalMKPLNPrefix()
        {
            var route = new ExternalRouteAttribute("test");
            Assert.Equal("external/mkpl/n/test", route.Template);
        }

        [Fact]
        public void InternalOAuthRouteAttributeShouldAddInternalOAuthMKPLNPrefix()
        {
            var route = new InternalOAuthRouteAttribute("test");
            Assert.Equal("o/mkpl/n/test", route.Template);
        }
    }
}