﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 建造者模式.Base
{
    /// <summary>
    /// 模拟请求对象
    /// </summary>
    public class Request
    {
        public string Url { get; set; }

        /// <summary>
        /// 模拟动作方法 如POST Get
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 模拟请求头
        /// </summary>
        public List<KeyValuePair<string, string>> Headers { get; set; } = new List<KeyValuePair<string, string>>();

        /// <summary>
        /// 模拟请求体
        /// </summary>
        public string Body { get; set; }
    }
}