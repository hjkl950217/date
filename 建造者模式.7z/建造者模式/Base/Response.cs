﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 建造者模式.Base
{
    /// <summary>
    /// 模拟响应对象
    /// </summary>
    public class Response
    {
        /// <summary>
        /// 模拟响应头
        /// </summary>
        public List<KeyValuePair<string, string>> Headers { get; set; } = new List<KeyValuePair<string, string>>();

        /// <summary>
        /// 模拟返回的Body
        /// </summary>
        public object Body { get; set; }
    }
}