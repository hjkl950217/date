﻿using System;
using System.Collections.Generic;

namespace 建造者模式.Base
{
    /// <summary>
    /// 模拟底层Http接口
    /// </summary>
    public class WebClient
    {
        public List<Action<Request>> RequestActions { get; set; } = new List<Action<Request>>();
        public List<Action<Response>> ResponseActions { get; set; } = new List<Action<Response>>();

        /// <summary>
        /// 模拟底层发送方法。实际情况下还有更多的参数
        /// </summary>
        /// <param name="request"></param>
        /// <param name="mockResponse"></param>
        /// <returns></returns>
        public Response SendHttp(Request request, Response mockResponse = null)
        {
            this.RequestActions.ForEach(t => t.Invoke(request));//调用外部注入的方法处理请求体

            Console.WriteLine($"基础Http接口被调用!");
            Console.WriteLine($"url:{request.Url}");
            Console.WriteLine($"Http动作方法：{request.Method}");
            Console.WriteLine("Header：");
            foreach (var item in request.Headers)
            {
                Console.WriteLine($"headerName:{item.Key} \t value:{item.Value}");
            }

            Console.WriteLine($"body:\t\n{request.Body}");
            Console.WriteLine();

            mockResponse = mockResponse ?? new Response();
            this.ResponseActions.ForEach(t => t.Invoke(mockResponse));//同上
            return mockResponse;
        }
    }
}