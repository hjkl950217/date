﻿using System;
using System.Collections.Generic;
using System.Text;
using 建造者模式.Base;

namespace 建造者模式
{
    public class HttpClientBuilder
    {
        protected HttpClientBuilder()
        {
        }

        public static HttpClientBuilder CreateDefaultHttpClientBuilder()
        {
            return new HttpClientBuilder();
        }

        /// <summary>
        /// WebClient构建过程中的处理方法
        /// </summary>
        public List<Action<WebClient>> Actions { get; set; } = new List<Action<WebClient>>();

        public WebClient BuildWebClient()
        {
            WebClient webClient = new WebClient();

            this.Actions.ForEach(t => t.Invoke(webClient));

            return webClient;
        }
    }

    public static class HttpClientBuilderEntension
    {
        public static HttpClientBuilder UseOAuth(this HttpClientBuilder httpClientBuilder, string toekn)
        {
            Action<WebClient> useOauth = webClient =>
            {
                webClient.RequestActions
                    .Add(t => t.Headers.Add(new KeyValuePair<string, string>("OAuth", toekn)));
            };

            httpClientBuilder.Actions.Add(useOauth);

            return httpClientBuilder;
        }
    }
}