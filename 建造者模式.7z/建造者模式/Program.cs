﻿using System;
using 建造者模式.Base;

namespace 建造者模式
{
    /*
     * HttpClient
     *
     * OAutHttpClient
     * MsgHttpClient
     *
     */

    public class Program
    {
        private static void Main(string[] args)
        {
            Request request = new Request()
            {
                Url = "http://test.com",
                Method = "POST",
                Body = "{\"demo\":\"demoString\"}"
            };

            WebClient client = HttpClientBuilder.CreateDefaultHttpClientBuilder()
                .BuildWebClient();

            //此时的client只是最基础的client

            client.SendHttp(request);

            client = HttpClientBuilder.CreateDefaultHttpClientBuilder()
                .UseOAuth("testToken")
                .UseOAuth("testToken2")
                .BuildWebClient();

            //此时的client就拥有了处理OAuth头的能力

            client.SendHttp(request);
            Console.WriteLine("End");
            Console.ReadLine();
        }
    }
}