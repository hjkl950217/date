﻿namespace _2016_12_14_时间服务器
{
    partial class Form_Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose( bool disposing )
        {
            if( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent( )
        {
            this.components = new System.ComponentModel.Container();
            this.Grp_Server = new System.Windows.Forms.GroupBox();
            this.Txt_LogServer = new System.Windows.Forms.TextBox();
            this.Dtp_Sever = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_Request = new System.Windows.Forms.Button();
            this.Txt_LogClient = new System.Windows.Forms.TextBox();
            this.Dtp_Client = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Txt_Num = new System.Windows.Forms.TextBox();
            this.Btn_Start = new System.Windows.Forms.Button();
            this.Tmr_Server = new System.Windows.Forms.Timer(this.components);
            this.Grp_Server.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Grp_Server
            // 
            this.Grp_Server.Controls.Add(this.Txt_LogServer);
            this.Grp_Server.Controls.Add(this.Dtp_Sever);
            this.Grp_Server.Controls.Add(this.label1);
            this.Grp_Server.Location = new System.Drawing.Point(8, 44);
            this.Grp_Server.Name = "Grp_Server";
            this.Grp_Server.Size = new System.Drawing.Size(264, 204);
            this.Grp_Server.TabIndex = 0;
            this.Grp_Server.TabStop = false;
            this.Grp_Server.Text = "时间服务端";
            // 
            // Txt_LogServer
            // 
            this.Txt_LogServer.Location = new System.Drawing.Point(4, 52);
            this.Txt_LogServer.Multiline = true;
            this.Txt_LogServer.Name = "Txt_LogServer";
            this.Txt_LogServer.Size = new System.Drawing.Size(252, 144);
            this.Txt_LogServer.TabIndex = 5;
            // 
            // Dtp_Sever
            // 
            this.Dtp_Sever.CustomFormat = "yyyy-MM-dd hh:MM:ss";
            this.Dtp_Sever.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Dtp_Sever.Location = new System.Drawing.Point(100, 28);
            this.Dtp_Sever.Name = "Dtp_Sever";
            this.Dtp_Sever.ShowUpDown = true;
            this.Dtp_Sever.Size = new System.Drawing.Size(164, 21);
            this.Dtp_Sever.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "现在时间：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_Request);
            this.groupBox1.Controls.Add(this.Txt_LogClient);
            this.groupBox1.Controls.Add(this.Dtp_Client);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(300, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 204);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "客户端";
            // 
            // Btn_Request
            // 
            this.Btn_Request.Location = new System.Drawing.Point(176, 52);
            this.Btn_Request.Name = "Btn_Request";
            this.Btn_Request.Size = new System.Drawing.Size(75, 23);
            this.Btn_Request.TabIndex = 6;
            this.Btn_Request.Text = "请求时间";
            this.Btn_Request.UseVisualStyleBackColor = true;
            this.Btn_Request.Click += new System.EventHandler(this.Btn_Request_Click);
            // 
            // Txt_LogClient
            // 
            this.Txt_LogClient.Location = new System.Drawing.Point(4, 80);
            this.Txt_LogClient.Multiline = true;
            this.Txt_LogClient.Name = "Txt_LogClient";
            this.Txt_LogClient.Size = new System.Drawing.Size(248, 116);
            this.Txt_LogClient.TabIndex = 4;
            // 
            // Dtp_Client
            // 
            this.Dtp_Client.CustomFormat = "yyyy-MM-dd hh:MM:ss";
            this.Dtp_Client.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Dtp_Client.Location = new System.Drawing.Point(88, 24);
            this.Dtp_Client.Name = "Dtp_Client";
            this.Dtp_Client.ShowUpDown = true;
            this.Dtp_Client.Size = new System.Drawing.Size(164, 21);
            this.Dtp_Client.TabIndex = 3;
            this.Dtp_Client.Value = new System.DateTime(1999, 1, 1, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "现在时间：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "服务器端口：";
            // 
            // Txt_Num
            // 
            this.Txt_Num.Location = new System.Drawing.Point(188, 8);
            this.Txt_Num.Name = "Txt_Num";
            this.Txt_Num.Size = new System.Drawing.Size(80, 21);
            this.Txt_Num.TabIndex = 3;
            this.Txt_Num.Text = "2333";
            // 
            // Btn_Start
            // 
            this.Btn_Start.Location = new System.Drawing.Point(296, 8);
            this.Btn_Start.Name = "Btn_Start";
            this.Btn_Start.Size = new System.Drawing.Size(75, 23);
            this.Btn_Start.TabIndex = 5;
            this.Btn_Start.Text = "启动";
            this.Btn_Start.UseVisualStyleBackColor = true;
            this.Btn_Start.Click += new System.EventHandler(this.Btn_Start_Click);
            // 
            // Tmr_Server
            // 
            this.Tmr_Server.Enabled = true;
            this.Tmr_Server.Tick += new System.EventHandler(this.Tmr_Server_Tick);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(573, 251);
            this.Controls.Add(this.Txt_Num);
            this.Controls.Add(this.Btn_Start);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Grp_Server);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Main";
            this.Text = "时间服务器实验";
            this.Grp_Server.ResumeLayout(false);
            this.Grp_Server.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Grp_Server;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker Dtp_Sever;
        private System.Windows.Forms.DateTimePicker Dtp_Client;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Txt_Num;
        private System.Windows.Forms.TextBox Txt_LogServer;
        private System.Windows.Forms.TextBox Txt_LogClient;
        private System.Windows.Forms.Button Btn_Start;
        private System.Windows.Forms.Button Btn_Request;
        private System.Windows.Forms.Timer Tmr_Server;
    }
}

