﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace _2016_12_14_时间服务器
{
    public partial class Form_Main : Form
    {
        public Form_Main( )
        {
            InitializeComponent( );

                    
            this.ServerShow = this.ShowTxtToSever;
            this.clientShow= this.ShowTimeToClient;

          //  this.Dtp_Client.Value = Convert.ToDateTime( "1999-01-01 00:00:00" );
           // this.Refresh( );
        }


        #region 属性区

        /// <summary>
        /// 服务端
        /// </summary>
        public TcpListener Server { get; set; }



        /// <summary>
        /// 显示时间到客户端
        /// </summary>
        public ClientToForm  clientShow { get; set; }
        public ServerToForm ServerShow { get; set; }
        #endregion


        #region 窗体逻辑

        /// <summary>
        /// 服务端接收数据
        /// </summary>
        private void ReceiveDataServer( )
        {
            while( true )
            {
                //获取数据
                NetworkStream netStream = this.Server.AcceptTcpClient( ).GetStream( );
                StreamReader reader = new StreamReader( netStream , Encoding.UTF8 );              
                string receiveStr = reader.ReadLine( ) ;

                if( receiveStr != "Quest Time" ) continue;
                else receiveStr += "\r\n";


                //传递数据给异步方法

                #region 异步更新服务端日志
                StreamWriter writer = new StreamWriter( netStream ,Encoding.UTF8);
                writer.WriteLine( DateTime.Now.ToString( "yyyy-MM-dd hh:mm:ss" ) );
                writer.Flush( );
                string strLog = $"发送时间：{DateTime.Now.ToString( "yyyy-MM-dd hh:mm:ss" )}\r\n";
                if( this.Txt_LogServer.InvokeRequired == false )
                {
                    this.Txt_LogServer.Text += "收到请求，正在发送时间\r\n";
                    this.Txt_LogServer.Text += strLog;
                }
                else
                {
                    //  this.Txt_LogServer.Invoke( this.showToForm , new object[ ] { strLog } );
                    this.Txt_LogServer.BeginInvoke
                        ( 
                        this.ServerShow , 
                        new object[ ] { "收到请求，正在发送时间\r\n" }
                        );
                    this.Txt_LogServer.BeginInvoke( this.ServerShow , new object[ ] { strLog } );
                }
               
                #endregion


                netStream.Close( );


            }

        }

        /// <summary>
        /// 客户端接收数据
        /// </summary>
        private void ReceiveDataClient( )
        {

            //初始化tcpClien
           TcpClient ClientTemp = new TcpClient( AddressFamily.InterNetwork );
            ClientTemp.Connect( "127.0.0.1" , Convert.ToInt32( this.Txt_Num.Text.Trim( ) ) );

            //发送数据
            NetworkStream netStream = ClientTemp.GetStream( );
            StreamWriter writer = new StreamWriter( netStream , Encoding.UTF8 );//得到写入流
            writer.WriteLine( "Quest Time" );//向流中写入数据
            writer.Flush( );
          

             //接收数据
            StreamReader reader = new StreamReader( netStream , Encoding.UTF8 );
            string strReceive = reader.ReadLine( );


            #region 异步更新客户端日志
           
            if( this.Txt_LogClient.InvokeRequired == false )
            {
           
                this.Txt_LogClient.Text += strReceive;
            }
            else
            {    
                this.Txt_LogClient.BeginInvoke
                    ( 
                    this.clientShow , 
                    new object[ ] { Convert.ToDateTime( strReceive ) } 
                    );
            }
          
            #endregion

            //释放资源
            writer.Close( );
           
        }


        /// <summary>
        /// 显示时间到客户端上
        /// </summary>
        /// <param name="dt"></param>
        public void ShowTimeToClient( DateTime dt )
        {
            this.Dtp_Client.Value = dt;
            this.Txt_LogClient.Text += "从服务端收到时间:" + dt.ToString("yyyy-MM-dd hh:mm:ss")+"\r\n";
        }

        /// <summary>
        /// 添加日志到服务端上
        /// </summary>
        /// <param name="str"></param>
        public void ShowTxtToSever(string str )
        {
            this.Txt_LogServer.Text += str;
        }

        #endregion

        private void Btn_Start_Click( object sender , EventArgs e )
        {

            //用端口号初始化监听对象
            IPAddress ipAddr = IPAddress.Parse( "127.0.0.1" );
            int numPoint = Convert.ToInt32( this.Txt_Num.Text.Trim( ) );
            this.Server = new TcpListener( new IPEndPoint( ipAddr , numPoint ) );
            this.Server.Start( );
            this.Txt_LogServer.Text = $"启动监听成功，端口号:{numPoint}\r\n";

            //开启新线程接收信息
            Thread tr = new Thread( this.ReceiveDataServer );
            tr.IsBackground = true;//设为后台线程
            tr.Start( );//启动

        }

        private void Btn_Request_Click( object sender , EventArgs e )
        {

            //开启新线程接收信息           
            Thread tr = new Thread( this.ReceiveDataClient )
            {
                IsBackground = true//设为后台线程
            };
            tr.Start( );//启动
      
        }




        /// <summary>
        /// 更新服务端的时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Tmr_Server_Tick( object sender , EventArgs e )
        {

            this.Dtp_Sever.Value = DateTime.Now;

        }

     



    }
    public delegate void ClientToForm( DateTime dt );
    public delegate void ServerToForm( string str );

}
