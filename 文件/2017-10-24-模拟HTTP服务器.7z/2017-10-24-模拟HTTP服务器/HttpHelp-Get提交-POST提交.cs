﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.IO;
using System.Collections.Specialized;

namespace Help
{
    /// <summary>
    /// Http伺服类(默认UTF-8)
    /// </summary>
    public class HttpHelp
    {

        /// <summary>
        /// Post提交并返回结果(过时)
        /// </summary>
        /// <param name="submitURL">需要请求的URL</param>
        /// <param name="postData">请求参数字符串</param>
        /// <returns>请求结果</returns>
        public string GetSubmitByPost( string submitURL , string postData )
        {
            #region 参数设置

            byte[ ] postArray = Encoding.UTF8.GetBytes( postData );
            //创建请求  
            HttpWebRequest request = ( HttpWebRequest )HttpWebRequest.Create( submitURL );
            request.Method = "POST";
            request.ContentLength = postArray.Length;
            //设置上传服务的数据格式  
            // request.ContentType = "application/x-www-form-urlencoded";

            //请求的身份验证信息为默认  
            request.Credentials = CredentialCache.DefaultCredentials;
            //请求超时时间  
            request.Timeout = 1000 * 10;
            //创建输入流  
            Stream dataStream;
            try
            {
                dataStream = request.GetRequestStream( );
            }
            catch( Exception )
            {
                return null;//连接服务器失败  
            }

            #endregion

            #region 发送请求获取返回信息
            //发送请求  
            dataStream.Write( postArray , 0 , postArray.Length );
            dataStream.Close( );
            //读取返回消息  
            string res;
            try
            {
                HttpWebResponse response = ( HttpWebResponse )request.GetResponse( );//获取返回响应
                StreamReader reader = new StreamReader( response.GetResponseStream( ) , Encoding.UTF8 );
                res = reader.ReadToEnd( );//读取信息
                reader.Close( );
            }
            catch( Exception ex )
            {

                return "{\"error\":\"connectToServer\",\"error_description\":\"" + ex.Message + "\"}";//连接服务器失败  
            }

            //返回
            return res;

            #endregion







        }

        /// <summary>
        /// GET提交并返回结果(过时)
        /// </summary>
        /// <param name="submitURL">需要请求的URL</param>
        /// <param name="postData">请求参数字符串</param>
        /// <returns>请求结果</returns>
        public string GetSubmitByGet( string submitURL , string postData )
        {
            #region 参数设置

            //创建请求  
            HttpWebRequest request = ( HttpWebRequest )HttpWebRequest.Create( submitURL + "?" + postData );
            request.Method = "GET";
            //设置上传服务的数据格式  
            // request.ContentType = "application/x-www-form-urlencoded";
            //请求的身份验证信息为默认  
            request.Credentials = CredentialCache.DefaultCredentials;
            //请求超时时间  
            request.Timeout = 1000 * 10;

            #endregion


            #region 读取返回信息
            //读取返回消息 
            string res;
            try
            {
                var response = ( HttpWebResponse )request.GetResponse( );
                var reader = new StreamReader( response.GetResponseStream( ) , Encoding.UTF8 );
                res = reader.ReadToEnd( );
                reader.Close( );
            }
            catch( Exception ex )
            {

                return "{\"error\":\"connectToServer\",\"error_description\":\"" + ex.Message + "\"}";
            }

            //返回
            return res;

            #endregion






        }



        /// <summary>
        /// Post提交并返回结果(用UTF8格式)
        /// </summary>
        /// <param name="submitURL">需要请求的URL</param>
        /// <param name="postData">请求参数字符串</param>
        /// <returns>请求结果</returns>
        public string GetSubmitByPost( string submitURL , Dictionary<string , string> listPara = null )
        {
            #region 参数设置     
            WebClient wc = new WebClient( );//连接对象
            wc.Encoding = Encoding.UTF8;
            wc.Headers.Add( "Content-Type" , "application/x-www-form-urlencoded" );//采取POST方式必须加的header，如果改为GET方式的话就去掉这句话即可  

            //转换参数
            NameValueCollection listValue = new NameValueCollection( );

            if( listPara != null || listPara.Count != 0 )
            {
                foreach( KeyValuePair<string , string> item in listPara )
                {
                    listValue.Add( item.Key , item.Value );
                }

            }

            #endregion


            #region 读取返回信息    
            byte[ ] resultByte;

            //发送请求
            try
            {
                resultByte = wc.UploadValues( submitURL , listValue );
            }
            catch( Exception ex )
            {

                return "请求失败：" + ex.Message;
            }


            //返回
            return Encoding.UTF8.GetString( resultByte );
            #endregion





        }

        /// <summary>
        /// Get提交并返回结果(用UTF8格式)
        /// </summary>
        /// <param name="submitURL">需要请求的URL</param>
        /// <param name="postData">请求参数字符串</param>
        /// <returns></returns>
        public string GetSubmitByGet( string submitURL , Dictionary<string , string> listPara = null )
        {
            #region 参数设置     
            WebClient wc = new WebClient( );//连接对象
            wc.Encoding = Encoding.UTF8;
            // wc.Headers.Add( "Content-Type" , "application/x-www-form-urlencoded" );//采取POST方式必须加的header，如果改为GET方式的话就去掉这句话即可  

            //转换参数
            NameValueCollection listValue = new NameValueCollection( );

            if( listPara != null || listPara.Count != 0 )
            {
                foreach( KeyValuePair<string , string> item in listPara )
                {
                    listValue.Add( item.Key , item.Value );
                }

            }



            #endregion


            #region 读取返回信息    
            byte[ ] resultByte;

            //发送请求
            try
            {
                resultByte = wc.UploadValues( submitURL , listValue );
            }
            catch( Exception ex )
            {

                return "请求失败：" + ex.Message;
            }


            //返回
            return Encoding.UTF8.GetString( resultByte );
            #endregion





        }





    }




}
