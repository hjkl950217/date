﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Globalization;

namespace Help
{
    public class HttpServer
    {
        public HttpServer( )
        {
            this.Server = new TcpListener( IPAddress.Parse( "127.0.0.1" ) , 10240 );
        }

        public TcpListener Server { get; set; }

        public async void StartListenAsync( )
        {
            StringBuilder responeStr = new StringBuilder( );
            responeStr.Append( "HTTP / 1.1 200 OK\r\n" );
            responeStr.Append( "Server:  ck\r\n" );
            responeStr.Append( "Date: " + DateTime.UtcNow.ToString( "R" ) + "\r\n" );
            responeStr.Append( "Content-Type: application/json; charset=utf-8\r\n" );
            responeStr.Append( "Content-Length: 1\r\n" );
            responeStr.Append( "Connection:close\r\n" );
            responeStr.Append( "\r\n" );
            responeStr.Append( "1" );

            //              HTTP / 1.1 200 OK
            //              Server: nginx
            //              Date: Tue, 24 Oct 2017 14:30:42 GMT
            //              Content - Type: text / html; charset = utf - 8
            //              Content - Length: 1506
            //              Connection: keep - alive
            //              Last - Modified: Thu, 01 Dec 2016 10:42:53 GMT
            //              ETag: "583ffead-5e2"
            //              Accept - Ranges: bytes

            //              < !doctype html >
            //              < html >

            this.Server.Start( );
            var stream = await this.Server.AcceptTcpClientAsync( );

            StreamReader reader = new StreamReader( stream.GetStream( ) , Encoding.UTF8 );//读取请求过来的数据
            string str = await reader.ReadLineAsync( );

            //返回数据
            StreamWriter writer = new StreamWriter( stream.GetStream( ) , Encoding.UTF8 );//读取请求过来的数据
            writer.WriteLine( responeStr.ToString() );
            writer.Flush( );

            stream.Close( );
            Console.WriteLine(str);
            Console.WriteLine( "已返回一次数据" );


        }

    }


}
