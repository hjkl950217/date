﻿using System;


namespace _2014_10_24_模拟HTTP服务器
{
    internal class Program
    {
        private static void Main( string[ ] args )
        {
 
            Help.HttpServer httpServer = new Help.HttpServer( );

        
        
                httpServer.StartListenAsync( );
      
           




            Console.WriteLine( "完成" );
            Console.ReadLine( );
        }



      

    }



}