﻿using System;

using Model;
using System.Collections.Generic;

namespace IHttp
{
    public interface IHttpServer
    {
        /// <summary>
        /// 获取要发送的Httpinfo（Get方式）
        /// </summary>
        /// <param name="dataStr">需要传递的数据</param>
        /// <param name="paraList">参数集合</param>
        /// <returns></returns>
        Model.HttpInfo GetRequestHttpInfo( string dataStr , Dictionary<string , string> paraList = null );

        /// <summary>
        /// 获取要发送的Httpinfo(POST方式)
        /// </summary>
        /// <param name="dataStr"></param>
        /// <returns></returns>
        Model.HttpInfo GetRequestHttpInfoPost( string dataStr , Dictionary<string , string> paraList = null );

        /// <summary>
        /// 将请求或响应报文反序列化成HttpInfo对象
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        Model.HttpInfo DeserializationToHttp( string str );

        /// <summary>
        /// 发送请求,若请求为POST，请传递paraList参数
        /// </summary>
        /// <param name="resuestStr">请求地址</param>
        /// <param name="paraList"></param>
        /// <returns></returns>
        Model.HttpInfo SendRequest( string resuestStr , Dictionary<string , string> paraList = null );


    }

}