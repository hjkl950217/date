﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    /// <summary>
    /// Http信息
    /// </summary>
    public class HttpInfo
    {
        //"GET /?username=tom&password=123 HTTP/1.1\r\nHost: localhost:49155\r\nConnection: keep-alive\r\nCache-Control: max-age=0\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36\r\nUpgrade-Insecure-Requests: 1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\nAccept-Encoding: gzip, deflate, br\r\nAccept-Language: zh-CN,zh;q=0.8\r\n\r\n"

        /// <summary>
        /// 请求地址
        /// </summary>
        public string RequestURL { get; set; }

        /// <summary>
        /// 请求数据（包括GET和POST方式）
        /// </summary>
        public Dictionary<string , string> DataArry { get; set; }

        /// <summary>
        /// 请求或响应里的数据
        /// </summary>
        public string Data { get; set; }
    }
}